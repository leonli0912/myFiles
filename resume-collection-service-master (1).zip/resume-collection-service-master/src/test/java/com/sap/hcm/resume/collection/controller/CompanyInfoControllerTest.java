package com.sap.hcm.resume.collection.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sap.hcm.resume.collection.bean.LogObjectType;
import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.bean.SimpleJsonResponse;
import com.sap.hcm.resume.collection.context.TestContext;
import com.sap.hcm.resume.collection.context.WebAppContext;
import com.sap.hcm.resume.collection.entity.ChangeLog;
import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.entity.Photo;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.hcp.HCPUserProvider;
import com.sap.hcm.resume.collection.service.ChangeLogService;
import com.sap.hcm.resume.collection.service.CompanyInfoService;
import com.sap.hcm.resume.collection.service.JobSchedulerService;
import com.sap.hcm.resume.collection.service.PhotoService;
import com.sap.hcm.resume.collection.util.ChangeLogUtil;
import com.sap.hcm.resume.collection.util.MockHCPUser;
import com.sap.security.um.user.User;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { TestContext.class, WebAppContext.class })
public class CompanyInfoControllerTest {

  @Resource(type = WebApplicationContext.class)
  private WebApplicationContext webApplicationContext;

  private MockMvc mockMvc;

  @Resource(name = "companyInfoService")
  private CompanyInfoService compInfoService;

  @Autowired
  private PhotoService photoService;

  @Autowired
  private HCPUserProvider hcpUserProvider;

  @Autowired
  private ChangeLogUtil changeLogUtil;

  @Autowired
  private JobSchedulerService jobSchedulerService;

  @Autowired
  private ChangeLogService changeLogService;

  @Autowired
  private Params params;

  private CompanyInfoController companyInfoController;

  @Before
  public void setUp() {
    reset(compInfoService);
    mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
    MockitoAnnotations.initMocks(this);
    companyInfoController = spy(new CompanyInfoController());

    params.setCompanyId("sap");
    params.setWechatOpenId("openid");

    ReflectionTestUtils.setField(companyInfoController, "compInfoService", compInfoService);
    ReflectionTestUtils.setField(companyInfoController, "photoService", photoService);
    ReflectionTestUtils.setField(companyInfoController, "hcpUserProvider", hcpUserProvider);
    ReflectionTestUtils.setField(companyInfoController, "changeLogUtil", changeLogUtil);
    ReflectionTestUtils.setField(companyInfoController, "jobSchedulerService", jobSchedulerService);
    ReflectionTestUtils.setField(companyInfoController, "params", params);
    ReflectionTestUtils.setField(companyInfoController, "changeLogService", changeLogService);
  }

  @Test
  public void testSaveCompanyinfoSuccess() throws Exception {
    ClassPathResource img = new ClassPathResource("/images/test.png");
    CompanyInfo companyInfo = new CompanyInfo();
    companyInfo.setDmMappingId(1L);
    companyInfo.setCompanyId("sap");

    when(compInfoService.getCompanyInfo("sap")).thenReturn(companyInfo);
    MockHttpSession session = new MockHttpSession();
    InputStream is = null;
    try {
      is = img.getInputStream();

      session.putValue(companyInfo.getCompanyId() + "_logo", IOUtils.toByteArray(is));
      session.putValue(companyInfo.getCompanyId() + "_twoDimension" + "_logo", "34".getBytes());
      MockHttpServletRequest request = new MockHttpServletRequest();
      request.setSession(session);
      companyInfo.setLogoId(1L);
      companyInfo.setTwoDimensionCode(2L);
      companyInfo.setSharePicId(3L);
      companyInfo.setApplyStatusMapping("123");
      Photo photo = new Photo();
      photo.setPhotoId(1L);
      when(photoService.saveImg(any(Photo.class))).thenReturn(photo);
      when(compInfoService.saveCompanyInfo(companyInfo)).thenReturn(companyInfo);

      User loginUser = new MockHCPUser();
      when(hcpUserProvider.getLoginUser(any(HttpServletRequest.class))).thenReturn(loginUser);

      assertEquals(companyInfo, companyInfoController.saveCompanyInfo(request, companyInfo));
    } catch (IOException e) {
    } finally {
      IOUtils.closeQuietly(is);
    }
  }

  @Test
  public void TestGetCompanyInfo() throws Exception {
    String companyId = "sap";
    CompanyInfo companyInfo = new CompanyInfo();
    companyInfo.setCompanyId(companyId);
    when(compInfoService.getCompanyInfo(companyId)).thenReturn(companyInfo);
    ResultActions result = mockMvc.perform(MockMvcRequestBuilders.get("/company/info")).andExpect(
        MockMvcResultMatchers.status().is(200));
    String content = result.andReturn().getResponse().getContentAsString();
    assertEquals(new ObjectMapper().writeValueAsString(companyInfo), content);
  }

  @Test
  public void TestGetJobStatuses() throws Exception {
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(0);
    rsp.setMessage("123");
    String companyId = "sap";
    CompanyInfo companyInfo = new CompanyInfo();
    companyInfo.setJobStatuses("123");
    when(compInfoService.getCompanyInfo(companyId)).thenReturn(companyInfo);
    ResultActions result = mockMvc.perform(MockMvcRequestBuilders.get("/company/jobStatusList")).andExpect(
        MockMvcResultMatchers.status().is(200));
    String content = result.andReturn().getResponse().getContentAsString();
    assertEquals(new ObjectMapper().writeValueAsString(rsp), content);
  }

  @Test
  public void TestMaintainCompanyInfoWithResultView() throws Exception {
    String companyId = "sap";
    MockHttpServletRequest request = new MockHttpServletRequest();
    doReturn("123").when(companyInfoController).validateCompanyAndUser(companyId);
    ModelAndView mav = new ModelAndView();
    mav.setViewName("123");
    assertEquals(mav.toString(), companyInfoController.maintainCompanyInfo(request).toString());
  }

  @Test
  public void TestMaintainCompanyInfoWithoutResultView() throws Exception {
    String companyId = "sap";
    MockHttpServletRequest request = new MockHttpServletRequest();
    doReturn(null).when(companyInfoController).validateCompanyAndUser(companyId);
    ModelAndView mav = new ModelAndView();
    mav.addObject(companyId);
    mav.setViewName("maintain_company");
    assertEquals(mav.toString(), companyInfoController.maintainCompanyInfo(request).toString());
  }

  @Test
  public void TestRemoveCompanyLogo() {
    String companyId = "sap";
    MockHttpSession session = new MockHttpSession();
    session.putValue(companyId + "_logo", "111");
    MockHttpServletRequest request = new MockHttpServletRequest();
    request.setSession(session);
    companyInfoController.removeCompanyLogo(request);
  }

  @Test
  public void TestGetDPCS() throws ServiceApplicationException, Exception {
    String dpcs = "sapdpcs";
    MockHttpServletRequest request = new MockHttpServletRequest();
    CompanyInfo companyInfo = new CompanyInfo();
    companyInfo.setDpcs(dpcs);
    when(compInfoService.getCompanyInfo("sap")).thenReturn(companyInfo);
    Map<String, String> result = companyInfoController.getDpcs(request);
    assertEquals(result.get("dpcs"), dpcs);
  }

  @Test
  public void TestGetChangeLogHistory() throws ServiceApplicationException, Exception {
    MockHttpServletRequest request = new MockHttpServletRequest();
    CompanyInfo companyInfo = new CompanyInfo();
    when(compInfoService.getCompanyInfo("sap")).thenReturn(companyInfo);
    List<ChangeLog> mockList = new ArrayList<ChangeLog>();
    ChangeLog log = new ChangeLog();
    log.setCompanyId("sap");
    mockList.add(log);
    when(changeLogService.getChangeLogList("sap", null, LogObjectType.COMPANY_SETTING.getObjectName())).thenReturn(
        mockList);
    List<ChangeLog> result = companyInfoController.showChangeCompanyHistory(request);
    assertEquals(result.get(0).getCompanyId(), "sap");
  }

  @Test
  public void TestGetJobSyncHistory() throws ServiceApplicationException, Exception {
    MockHttpServletRequest request = new MockHttpServletRequest();
    CompanyInfo companyInfo = new CompanyInfo();
    when(compInfoService.getCompanyInfo("sap")).thenReturn(companyInfo);
    List<ChangeLog> mockList = new ArrayList<ChangeLog>();
    ChangeLog log = new ChangeLog();
    log.setCompanyId("sap");
    mockList.add(log);
    when(changeLogService.getChangeLogList("sap", null, LogObjectType.JOB_SYNC.getObjectName())).thenReturn(mockList);
    List<ChangeLog> result = companyInfoController.showjobSyncHistory(request);
    assertEquals(result.get(0).getCompanyId(), "sap");
  }

  @Test
  public void TestSaveJobStatuses() throws ServiceApplicationException, Exception {
    String status = "sap";
    // MockHttpServletRequest request = new MockHttpServletRequest();
    CompanyInfo companyInfo = new CompanyInfo();
    companyInfo.setJobStatuses(status);
    when(compInfoService.getCompanyInfo("sap")).thenReturn(companyInfo);
    when(compInfoService.saveCompanyInfo(companyInfo)).thenReturn(companyInfo);
    // List<ChangeLog> mockList = new ArrayList<ChangeLog>();
    // ChangeLog log = new ChangeLog();
    // log.setCompanyId("sap");
    // mockList.add(log);
    // when(changeLogService.getChangeLogList("sap", null,
    // LogObjectType.JOB_SYNC.getObjectName())).thenReturn(mockList);
    SimpleJsonResponse rsp = companyInfoController.saveJobStatuses(status);
    assertEquals(rsp.getCode(), 0);
  }

  @Test(expected = ServiceApplicationException.class)
  public void TestGetJobSyncHistoryFail() throws ServiceApplicationException, Exception {
    MockHttpServletRequest request = new MockHttpServletRequest();
    CompanyInfo companyInfo = new CompanyInfo();
    when(compInfoService.getCompanyInfo("sap")).thenReturn(companyInfo);
    List<ChangeLog> mockList = new ArrayList<ChangeLog>();
    ChangeLog log = new ChangeLog();
    log.setCompanyId("sap");
    mockList.add(log);
    when(changeLogService.getChangeLogList("sap", null, LogObjectType.JOB_SYNC.getObjectName())).thenThrow(
        new ServiceApplicationException("abc"));
    List<ChangeLog> result = companyInfoController.showjobSyncHistory(request);
    assertEquals(result.get(0).getCompanyId(), "sap");
  }

  @Test(expected = ServiceApplicationException.class)
  public void TestGetChangeLogHistoryFail() throws ServiceApplicationException, Exception {
    MockHttpServletRequest request = new MockHttpServletRequest();
    CompanyInfo companyInfo = new CompanyInfo();
    when(compInfoService.getCompanyInfo("sap")).thenReturn(companyInfo);
    List<ChangeLog> mockList = new ArrayList<ChangeLog>();
    ChangeLog log = new ChangeLog();
    log.setCompanyId("sap");
    mockList.add(log);
    when(changeLogService.getChangeLogList("sap", null, LogObjectType.COMPANY_SETTING.getObjectName())).thenThrow(
        new ServiceApplicationException("abc"));
    List<ChangeLog> result = companyInfoController.showChangeCompanyHistory(request);
    assertEquals(result.get(0).getCompanyId(), "sap");
  }
}
