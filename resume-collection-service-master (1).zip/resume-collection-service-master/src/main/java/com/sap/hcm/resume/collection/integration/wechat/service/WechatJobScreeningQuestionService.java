package com.sap.hcm.resume.collection.integration.wechat.service;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sap.hcm.resume.collection.bean.CompanyIdInfo;
import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJob;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJobScreeningQuestion;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJobScreeningQuestionAndChoice;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJobScreeningQuestionChoice;

@Service
public class WechatJobScreeningQuestionService {
  @PersistenceContext
  private EntityManager entityManager;

  @Autowired
  Params params;

  @Autowired
  private WechatJobService wechatJobService;

  @Autowired
  private CompanyIdInfo companyIdInfo;

  @Autowired
  private WechatJobScreeningQuestionChoiceService wechatJobScreeningQuestionChoiceService;

  public WechatJobScreeningQuestion saveJobScreeningQuestion(WechatJobScreeningQuestion jobScreeningQuestion)
      throws ServiceApplicationException {

    jobScreeningQuestion = entityManager.merge(jobScreeningQuestion);
    return jobScreeningQuestion;
  }

  public List<WechatJobScreeningQuestion> findJobScreeningQuestion(String jobReqId) {
    List<WechatJobScreeningQuestion> jobScreeningQuestionList = new ArrayList<WechatJobScreeningQuestion>();
    String sel = "select h from WechatJobScreeningQuestion h where h.companyId = :companyId AND h.jobReqId = :jobReqId ";
    sel = sel.concat("order by h.questionOrder");
    TypedQuery<WechatJobScreeningQuestion> queryJobInfo = entityManager.createQuery(sel,
        WechatJobScreeningQuestion.class);
    String companyId = null;
    if (companyIdInfo.getCompanyId() != null) {
      companyId = companyIdInfo.getCompanyId();
    } else {
      companyId = params.getCompanyId();
    }
    queryJobInfo.setParameter("companyId", companyId);
    queryJobInfo.setParameter("jobReqId", jobReqId);
    jobScreeningQuestionList = queryJobInfo.getResultList();
    return jobScreeningQuestionList;
  }

  public int deleteJobScreeningQuestionAndChoice(Long jobId, String companyId) throws ServiceApplicationException {
    int res = -1;
    /* Delete choice */
    WechatJob wechatJob = wechatJobService.findJobById(jobId);
    String jobReqId = wechatJob.getExternalJobId();

    List<WechatJobScreeningQuestion> jobScreeningQuestionList = this.findJobScreeningQuestion(jobReqId);
    if (jobScreeningQuestionList.size() > 0) {
      for (WechatJobScreeningQuestion question : jobScreeningQuestionList) {
        String jobReqQuestionChoiceKey = constructJobReqQuestionChoiceKey(question.getQuestionOrder().toString(),
            question.getJobReqId(), question.getQuestionLocale());
        String deleteJobChoice = "delete from WechatJobScreeningQuestionChoice j where j.jobReqQuestionChoiceKey = :jobReqQuestionChoiceKey";
        Query query = entityManager.createQuery(deleteJobChoice);

        try {
          query.setParameter("jobReqQuestionChoiceKey", jobReqQuestionChoiceKey);
          query.executeUpdate();
          res = 1;
        } catch (PersistenceException e) {
          res = -1;
        }

      }
    }

    /* Delete question */
    String deleteJobScreenQuestion = "delete from WechatJobScreeningQuestion j where j.jobReqId = :jobReqId AND j.companyId = :companyId";
    Query query = entityManager.createQuery(deleteJobScreenQuestion);

    try {
      query.setParameter("jobReqId", jobReqId);
      query.setParameter("companyId", companyId);
      query.executeUpdate();
      res = 1;
    } catch (PersistenceException e) {
      res = -1;
    }

    /* Add logic to delete question & choices corresponding to the job */
    return res;
  }

  public List<WechatJobScreeningQuestionAndChoice> findJobScreeningQuestionAndChoice(String jobReqId) {
    List<WechatJobScreeningQuestionAndChoice> wechatJobScreeningQuestionAndChoiceList = null;
    List<WechatJobScreeningQuestion> jobScreeningQuestionList = this.findJobScreeningQuestion(jobReqId);
    if (jobScreeningQuestionList.size() > 0) {
      wechatJobScreeningQuestionAndChoiceList = new ArrayList<WechatJobScreeningQuestionAndChoice>();
      for (WechatJobScreeningQuestion question : jobScreeningQuestionList) {
        WechatJobScreeningQuestionAndChoice wechatJobScreeningQuestionAndChoice = new WechatJobScreeningQuestionAndChoice();
        wechatJobScreeningQuestionAndChoice.setWechatJobScreeningQuestion(question);
        List<WechatJobScreeningQuestionChoice> wechatJobScreeningQuestionChoiceList = wechatJobScreeningQuestionChoiceService
            .findJobScreeningQuestionChoice(constructJobReqQuestionChoiceKey(question.getQuestionOrder().toString(),
                question.getJobReqId(), question.getQuestionLocale()));
        wechatJobScreeningQuestionAndChoice.setJobScreeningQuestionChoiceList(wechatJobScreeningQuestionChoiceList);
        wechatJobScreeningQuestionAndChoiceList.add(wechatJobScreeningQuestionAndChoice);
      }
    }
    return wechatJobScreeningQuestionAndChoiceList;
  }

  public String constructJobReqQuestionChoiceKey(String questionOrder, String jobReqId, String locale) {
    String companyId = null;
    if (companyIdInfo.getCompanyId() != null) {
      companyId = companyIdInfo.getCompanyId();
    } else {
      companyId = params.getCompanyId();
    }
    return questionOrder + "_" + jobReqId + "_" + locale + "_" + companyId;
  }
}
