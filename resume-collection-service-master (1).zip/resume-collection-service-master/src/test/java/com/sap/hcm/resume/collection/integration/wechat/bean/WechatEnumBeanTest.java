package com.sap.hcm.resume.collection.integration.wechat.bean;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class WechatEnumBeanTest {

  @Test
  public void testMonthEnum() {
    MonthEnum may = MonthEnum.May;
    assertEquals(5, may.getRangeByLabel("May"));
    assertEquals("May", may.getLabelByRange(5));
  }

  @Test
  public void testUnknownMonthEnum() {
    MonthEnum may = MonthEnum.May;
    may.setLabel("haha");
    may.setRange(987);
    assertEquals(0, may.getRangeByLabel("hehe"));
    assertEquals("Unknown", may.getLabelByRange(789));
  }

}
