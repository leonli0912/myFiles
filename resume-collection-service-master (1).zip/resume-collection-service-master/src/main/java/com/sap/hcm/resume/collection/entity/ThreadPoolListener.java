package com.sap.hcm.resume.collection.entity;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ThreadPoolListener implements ServletContextListener{
  public static ScheduledExecutorService executor = Executors.newScheduledThreadPool(10);
  
  private Logger logger = LoggerFactory.getLogger(this.getClass());
  
  @Override
  public void contextDestroyed(ServletContextEvent arg0) {
    executor.shutdown();
  }

  @Override
  public void contextInitialized(ServletContextEvent arg0) {
    logger.debug("ThreadPoolListener has been initialized");
    executor.scheduleWithFixedDelay(new ExceptionStatistics(), 0, 1, TimeUnit.SECONDS);
  }
}
