package com.sap.hcm.resume.collection.integration.wechat.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.EntityManager;

import org.apache.http.client.ClientProtocolException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.util.ReflectionTestUtils;

import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.wechat.entity.AccessToken;
import com.sap.hcm.resume.collection.integration.wechat.entity.OAuthAccessToken;
import com.sap.hcm.resume.collection.integration.wechat.util.WechatHelper;
import com.sap.hcm.resume.collection.service.CompanyInfoService;
import com.sap.hcm.resume.collection.service.PhotoService;
import com.sap.hcm.resume.collection.util.CandidateFileUtil;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ CandidateFileUtil.class })
public class WechatLoginServiceTest {

  private EntityManager entityManager;

  private CompanyInfoService compInfoService;

  private WechatHelper wechatHelper;

  private PhotoService photoService;

  private WechatLoginService loginService;
  
  public final int WIDTH = 200;

  public final int HEIGHT = 200;

  @Before
  public void setUp() {
    loginService = new WechatLoginService();

    entityManager = Mockito.mock(EntityManager.class);
    compInfoService = Mockito.mock(CompanyInfoService.class);
    wechatHelper = Mockito.mock(WechatHelper.class);
    photoService = Mockito.mock(PhotoService.class);

    ReflectionTestUtils.setField(loginService, "entityManager", entityManager);
    ReflectionTestUtils.setField(loginService, "companyInfoService", compInfoService);
    ReflectionTestUtils.setField(loginService, "wechatHelper", wechatHelper);
    ReflectionTestUtils.setField(loginService, "photoService", photoService);
  }

  @Test
  public void testGetLoginUrl() throws ServiceApplicationException {
    String loginUrl = loginService.getLoginURL("sap", "test");
    Assert.assertNotNull(loginUrl);
  }

  @Test
  public void testGetOAuthAcessToken() {
    OAuthAccessToken token = new OAuthAccessToken();
    token.setOpenId("123");

    Mockito.when(wechatHelper.getOAuthAccessToken("sap")).thenReturn(token);
    OAuthAccessToken result = loginService.getOAuthAccessToken("sap");
    Assert.assertEquals(result.getOpenId(), token.getOpenId());
  }

  @Test
  public void testGetAccessToken() throws ClientProtocolException, IOException {
    String companyId = "a";
    String appId = "b";
    String appSecret = "c";
    String tokenValue = "d";
    AccessToken token = Mockito.mock(AccessToken.class);
    when(wechatHelper.getAccessToken(companyId, appId, appSecret)).thenReturn(token);
    when(token.getAccess_token()).thenReturn(appSecret);
    loginService.getAccessToken(companyId, appId, appSecret);
  }

  @Test
  public void testCreateMenu() throws ClientProtocolException, IOException {
    String token = "abc";
    String serverPath = "efg";
    when(wechatHelper.createMenu(token, serverPath)).thenReturn(token);
    assertEquals(token, loginService.createMenu(token, serverPath));
  }
  
  @Test
  public void testGetWechatJsAPIConfiguration() throws ServiceApplicationException, ClientProtocolException, IOException{
    String companyId = "sap";
    String url = "zxc";
    MockHttpServletRequest request = new MockHttpServletRequest();
    CompanyInfo companyInfo = new CompanyInfo();
    companyInfo.setSharePicId(001L);
    companyInfo.setCompanyName("SAP");
    when(compInfoService.getCompanyInfo(companyId)).thenReturn(companyInfo);
    AccessToken at = new AccessToken(companyId);
    at.setAccess_token("123");
    when(wechatHelper.getAccessToken(companyId, WechatHelper.JS_TICKET_WECHAT_APP_ID,
        WechatHelper.JS_TICKET_WECHAT_APP_SECRET)).thenReturn(at);
    String jsapi_ticket = "asd";
    when(wechatHelper.getApiTicket(at.getAccess_token())).thenReturn(jsapi_ticket);
    Map<String,String> result = new HashMap<String,String>();
    when(wechatHelper.sign(jsapi_ticket, url)).thenReturn(result);
    assertEquals("SAP", loginService.getWechatJsAPIConfiguration(companyId, url, request).get("companyName"));
  }
  
}
