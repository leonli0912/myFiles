package com.sap.hcm.resume.collection.integration.service;

import java.io.UnsupportedEncodingException;
import java.util.Map;

import com.sap.hcm.resume.collection.exception.ServiceApplicationException;

public interface JobRequisitionIntegrationService extends IntegrationService {
  Map<String, String> getJobRequisition(String jobReqMappingId, String lowDate, String highDate, String jobReqIdStr)
      throws ServiceApplicationException;

  void syncJobRequisition(String companyId) throws ServiceApplicationException;

  Map<String, Object> getJobRequisitionForSearch(String condition) throws UnsupportedEncodingException;
}
