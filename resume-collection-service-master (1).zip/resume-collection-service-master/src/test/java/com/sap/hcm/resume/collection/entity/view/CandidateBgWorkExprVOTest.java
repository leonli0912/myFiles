package com.sap.hcm.resume.collection.entity.view;

import org.junit.Assert;
import org.junit.Test;


public class CandidateBgWorkExprVOTest {
  
  @Test
  public void testGetterSetter(){
    CandidateBgWorkExprVO vo = new CandidateBgWorkExprVO();
    vo.setEmployer("test");
    vo.setBusinessType("test");
    vo.setDepartment("test");
    vo.setDescription("test");
    vo.setEndDate("test");
    vo.setExitReason("test");
    vo.setIsPresent(false);
    vo.setJobTitle("test");
    vo.setPresentEmployer("test");
    vo.setSalary("test");
    vo.setSalaryEnd("test");
    vo.setStartDate("test");
    
    Assert.assertEquals(vo.getEmployer(), "test");
    Assert.assertEquals(vo.getBusinessType(), "test");
    Assert.assertEquals(vo.getDepartment(), "test");
    Assert.assertEquals(vo.getDescription(), "test");
    Assert.assertEquals(vo.getEndDate(), "test");
    Assert.assertEquals(vo.getExitReason(), "test");
    Assert.assertEquals(vo.getIsPresent(), false);
    Assert.assertEquals(vo.getJobTitle(), "test");
    Assert.assertEquals(vo.getPresentEmployer(), "test");
    Assert.assertEquals(vo.getSalary(), "test");
    Assert.assertEquals(vo.getSalaryEnd(), "test");
    Assert.assertEquals(vo.getEndDate(), "test");
  }
}
