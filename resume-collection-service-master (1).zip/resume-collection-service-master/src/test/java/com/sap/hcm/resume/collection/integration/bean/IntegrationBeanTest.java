package com.sap.hcm.resume.collection.integration.bean;

import org.junit.Test;

public class IntegrationBeanTest {

	@Test
	public void testGetterSetter(){
		IntegrationBeanUtil.registerBean(ApplyDataModelMappingItem.class);
		IntegrationBeanUtil.registerBean(DataMappingApplyStatus.class);
		IntegrationBeanUtil.registerBean(DataMappingApplyStatusList.class);
		IntegrationBeanUtil.registerBean(DataMappingOverwrite.class);
		IntegrationBeanUtil.registerBean(DataMappingPicklist.class);
		IntegrationBeanUtil.registerBean(DataMappingPicklistOption.class);
		IntegrationBeanUtil.registerBean(DataMappingPkOptionMapping.class);
		IntegrationBeanUtil.registerBean(DataModelMappingItem.class);
		IntegrationBeanUtil.registerBean(JobReqDataModelMapping.class);
		IntegrationBeanUtil.registerBean(JobReqDataModelMappingItem.class);
		IntegrationBeanUtil.registerBean(MappingPropertyAlias.class);
		IntegrationBeanUtil.registerBean(ResumeDownloadBean.class);
		
		IntegrationBeanUtil.executeBeanTest();
	}
}

//IntegrationBeanUtil.registerBean(DataModelMappingItem.class);
//IntegrationBeanUtil.registerBean(JobReqDataModelMapping.class);