package com.sap.hcm.resume.collection.security;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatUserService;

/**
 * @author I323239 SAP
 */
public class ValidateWechatUserLoginInterceptor implements HandlerInterceptor {
  // private static final Logger logger = LoggerFactory.getLogger(CsrfInterceptor.class);

  @Autowired
  private WechatUserService wechatUserService;
  
  @Autowired
  private Params params;


  @Override
  public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
    String openId = params.getWechatOpenId();
    String companyId = params.getCompanyId();
    if (StringUtils.isEmpty(openId)) {
      this.handleError(request, response);
      return false;
    } else {

      String candidateId = request.getParameter("candidateId");

      if (candidateId != null && !candidateId.equals("undefined")) {


        boolean isWechatUserValid = wechatUserService
            .checkIsCurrentID(Long.parseLong(candidateId), params.getUserEmail(), companyId);
        if (!isWechatUserValid) {
          this.handleError(request, response);
        }
      }
    }
    return true;
  }

  private void handleError(HttpServletRequest request, HttpServletResponse response)
      throws ServiceApplicationException, IOException {
    if (request.getHeader("x-requested-with") != null
        && request.getHeader("x-requested-with").equalsIgnoreCase("XMLHttpRequest")) {
      throw new ServiceApplicationException(-1006, "User not authorized to view the page");

    } else {
      response.sendRedirect(request.getContextPath() + "/invalidwechatuser");
    }
  }

  /*
   * (non-Javadoc)
   * @see org.springframework.web.servlet.HandlerInterceptor#postHandle(javax.servlet.http.HttpServletRequest,
   * javax.servlet.http.HttpServletResponse, java.lang.Object, org.springframework.web.servlet.ModelAndView)
   */
  @Override
  public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
      ModelAndView modelAndView) throws Exception {

    // if (!StringUtils.isEmpty(request.getSession().getAttribute("CSRFTokenStatus"))
    // && "error".equals(request.getSession().getAttribute("CSRFTokenStatus"))) {
    // modelAndView.setViewName("redirect:/denied");
    // }
  }

  /*
   * (non-Javadoc)
   * @see org.springframework.web.servlet.HandlerInterceptor#afterCompletion(javax.servlet.http.HttpServletRequest,
   * javax.servlet.http.HttpServletResponse, java.lang.Object, java.lang.Exception)
   */
  @Override
  public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
      throws Exception {
    // TODO Auto-generated method stub

  }

}
