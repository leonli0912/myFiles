package com.sap.hcm.resume.collection.integration.dajie;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.HttpClientUtils;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.sap.hcm.resume.collection.bean.ResumeInfo;
import com.sap.hcm.resume.collection.exception.AuthenticationFailedException;
import com.sap.hcm.resume.collection.exception.InvalidVerifyCodeException;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.JobBoardBaseProvider;
import com.sap.hcm.resume.collection.integration.bean.ResumeDownloadBean;
import com.sap.hcm.resume.collection.util.CandidateFileUtil;


@Component(value="dajieProvider")
@Scope(value = "session", proxyMode = ScopedProxyMode.TARGET_CLASS)
public class DajieProvider extends JobBoardBaseProvider{
  
  /**
   * logger
   */
  private Logger logger = LoggerFactory.getLogger(this.getClass());
  
  private static String VERIFY_CODE_PATH = "http://www.dajie.com/captcha/code";
  
  public DajieProvider(){
    this.cookieStore.clear();
  }
  
  @Override
  public void preLogin() throws ServiceApplicationException {
    cookieStore.clear();
    CloseableHttpClient client = this.createHttpClient();
    
    try {
      HttpGet get = new HttpGet("http://www.dajie.com/account/login");
      get.addHeader("Host", "www.dajie.com");
      get.addHeader("Upgrade-Insecure-Requests", "1");
      get.addHeader("User-Agent",
          "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.109 Safari/537.36");
      CloseableHttpResponse response = client.execute(get);
      setCookieStore(response);

    } catch (IOException e) {
      throw new ServiceApplicationException("failed to connection to dajie" + e.getMessage());
    } finally {
      HttpClientUtils.closeQuietly(client);
    }
    
  }

  @Override
  public void getVerifyCode(HttpServletRequest request) throws ServiceApplicationException {
    CloseableHttpClient client = this.createHttpClient();
    HttpEntity entity = null;
    try {
      HttpGet get = new HttpGet(VERIFY_CODE_PATH);
      get.addHeader("Accept", "image/webp,image/*,*/*;q=0.8");
      get.addHeader("User-Agent",
          "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.109 Safari/537.36");
      
      CloseableHttpResponse response = client.execute(get);
      setCookieStore(response);
      entity = response.getEntity();
      byte[] image = CandidateFileUtil.cropImage(entity.getContent(), 120, 60);
      request.getSession().setAttribute("verifyCode", image);

    }catch(Exception e){ 
      throw new ServiceApplicationException("failed to retrieve the verify code: " + e.getMessage());
    }finally {
      EntityUtils.consumeQuietly(entity);
      HttpClientUtils.closeQuietly(client);
    }
  }

  @Override
  public List<ResumeDownloadBean> getResume(HttpServletRequest request, String username, String password, String captcha) throws ServiceApplicationException {
    List<ResumeDownloadBean> fileList = new ArrayList<ResumeDownloadBean>();
    
    if(StringUtils.isEmpty(captcha)){
      throw new InvalidVerifyCodeException();
    }else{
      try {
        captcha = new String(captcha.getBytes("iso-8859-1"),"utf-8");
      } catch (UnsupportedEncodingException e) {
        logger.error("mistery exception happened, should never happen" + e.getMessage());
      }
    }
    
    CloseableHttpClient client = this.createHttpClient();
    HttpEntity entity = null;
    InputStream content = null;
    FileOutputStream fileOutputStream = null;
    try {
      HttpPost post = new HttpPost(
          "http://www.dajie.com/account/newloginsubmit?callback=LOGIN_CALLBACK&ajax=1&_CSRFToken=");
      List<NameValuePair> list = new ArrayList<NameValuePair>();
      list.add(new BasicNameValuePair("email", username));
      list.add(new BasicNameValuePair("password", password));
      list.add(new BasicNameValuePair("from", "login"));
      list.add(new BasicNameValuePair("captcha",captcha));
      list.add(new BasicNameValuePair("redir", "/home?f=inbound"));
      UrlEncodedFormEntity encodedFormEntity = new UrlEncodedFormEntity(list, "UTF-8");
      post.setEntity(encodedFormEntity);

      post.addHeader("X-Requested-With", "XMLHttpRequest");
      post.addHeader("HOST", "www.dajie.com");
      post.addHeader("Origin", "http://www.dajie.com");
      post.addHeader("Referer","http://www.dajie.com/");
      post.addHeader("User-Agent","Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/52.0.2743.116 Safari/537.36");
      
      CloseableHttpResponse response = client.execute(post);
      if (response == null) {
        throw new ServiceApplicationException("network error, can not connect to remote service");
      } else {
        entity = response.getEntity();
        content = entity.getContent();
        String respTxt = IOUtils.toString(content);
        if (respTxt.indexOf("帐号和密码不匹配") >= 0 || respTxt.indexOf("手机号或密码错误") >= 0) {
          throw new AuthenticationFailedException();
        }
        if(respTxt.indexOf("请输入正确验证码") >= 0){
          logger.error("the input verify code is" + captcha);
          throw new InvalidVerifyCodeException();
        }
        if(respTxt.indexOf("使用大街网帐号登录") >= 0){
          logger.error("login failed");
          throw new ServiceApplicationException("login failed without useful information");
        }
      }
      setCookieStore(response);
      
      HttpGet get = new HttpGet("http://job.dajie.com/resume/save?type=html?time="
          + Calendar.getInstance().getTimeInMillis());
      CloseableHttpResponse rsp2 = client.execute(get);
      entity = rsp2.getEntity();

      ResumeDownloadBean rdb = new ResumeDownloadBean();
      rdb.setLocale(Locale.CHINA);
      rdb.setExternalResumeId("1");
      rdb.setFileContent(IOUtils.toByteArray(entity.getContent()));
      fileList.add(rdb);

    }catch (IOException e){
      throw new ServiceApplicationException("failed to connect to dajie: " + e.getMessage());
    }finally {
      IOUtils.closeQuietly(content);
      IOUtils.closeQuietly(fileOutputStream);
      EntityUtils.consumeQuietly(entity);
      HttpClientUtils.closeQuietly(client);
    }
    return fileList;
  }
  
  @Override
  public ResumeInfo getFileContent(byte[] content) throws ServiceApplicationException {
    ResumeInfo resumeInfo = new ResumeInfo();
    resumeInfo.setResumeExtension("html");
    resumeInfo.setHtmlDocument(CandidateFileUtil.getFileContentFromHtml(content));
    return resumeInfo;
  }
}
