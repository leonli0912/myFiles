package com.sap.hcm.resume.collection.entity;

import java.io.Serializable;



public class CandBackgroundID implements Serializable{
	
	/**
	 * serialVersionUID
	 */
    private static final long serialVersionUID = 8401302278574964436L;

	private Long candidateId;
	
	private String backgroundType;
	
	
	public CandBackgroundID(){
		
	}

	/**
	 * @return the candidateId
	 */
	public Long getCandidateId() {
		return candidateId;
	}

	/**
	 * @param candidateId the candidateId to set
	 */
	public void setCandidateId(Long candidateId) {
		this.candidateId = candidateId;
	}

	/**
	 * @return the backgroundType
	 */
	public String getBackgroundType() {
		return backgroundType;
	}

	/**
	 * @param backgroundType the backgroundType to set
	 */
	public void setBackgroundType(String backgroundType) {
		this.backgroundType = backgroundType;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
    @Override
    public int hashCode() {
	    final int prime = 31;
	    int result = 1;
	    result = prime * result + ((backgroundType == null) ? 0 : backgroundType.hashCode());
	    result = prime * result + ((candidateId == null) ? 0 : candidateId.hashCode());
	    return result;
    }

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
    @Override
    public boolean equals(Object obj) {
	    if (this == obj)
		    return true;
	    if (obj == null)
		    return false;
	    if (getClass() != obj.getClass())
		    return false;
	    CandBackgroundID other = (CandBackgroundID) obj;
	    if (backgroundType == null) {
		    if (other.backgroundType != null)
			    return false;
	    } else if (!backgroundType.equals(other.backgroundType))
		    return false;
	    if (candidateId == null) {
		    if (other.candidateId != null)
			    return false;
	    } else if (!candidateId.equals(other.candidateId))
		    return false;
	    return true;
    }

	

	

	
}
