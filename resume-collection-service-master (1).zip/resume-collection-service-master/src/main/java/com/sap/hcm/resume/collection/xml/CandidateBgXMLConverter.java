package com.sap.hcm.resume.collection.xml;

import java.util.Collection;
import java.util.List;

import com.sap.hcm.resume.collection.entity.view.CandidateBgCertificateVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgEducationVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgFamilyVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgLanguageVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgWorkExprVO;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.security.NullPermission;
import com.thoughtworks.xstream.security.PrimitiveTypePermission;

/**
 * candidate background xml converter
 * @author i065831
 *
 */
public class CandidateBgXMLConverter {
	
	private static XStream stream = new XStream();
	
	private CandidateBgXMLConverter(){
		
	}
	
	static{
		 stream.autodetectAnnotations(true);
		 stream.processAnnotations(CandidateBgWorkExprVO.class);
		 stream.processAnnotations(CandidateBgLanguageVO.class);
		 stream.processAnnotations(CandidateBgEducationVO.class);
		 stream.processAnnotations(CandidateBgCertificateVO.class);
		 stream.processAnnotations(CandidateBgFamilyVO.class);
		 
		 // add permissions, allow some basics
		 stream.addPermission(NullPermission.NULL);
		 stream.addPermission(PrimitiveTypePermission.PRIMITIVES);
		 stream.allowTypeHierarchy(Collection.class);
		 // allow any type from the same package
		 stream.allowTypesByWildcard(new String[] {
		     CandidateBgWorkExprVO.class.getPackage().getName()+".*"
		 });
	}
	
	public static String convertFromBgElementToXML(List<?> bgList){
	    return stream.toXML(bgList);
	}
	
	public static Object convertFromXMLToBgElement(String xml){
	    return stream.fromXML(xml);
	}
	
}
