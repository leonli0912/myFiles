package com.sap.hcm.resume.collection.bean;

import org.junit.Assert;
import org.junit.Test;

public class CandidateVendorTest {
  
  @Test
  public void testSetAndGetter(){
    CandidateVendor vendor = new CandidateVendor();
    
    vendor.setTemplateName("job");
    vendor.setTemplatePath("path");
    vendor.setCountry(CountryEnum.CN);
    vendor.setName(CandidateVendorEnum.DAJIE);
    
    Assert.assertEquals(vendor.getCountry(), CountryEnum.CN);
    Assert.assertEquals(vendor.getName(), CandidateVendorEnum.DAJIE);
    Assert.assertEquals(vendor.getTemplateName(),"job");
    Assert.assertEquals(vendor.getTemplatePath(), "path");
  }
}
