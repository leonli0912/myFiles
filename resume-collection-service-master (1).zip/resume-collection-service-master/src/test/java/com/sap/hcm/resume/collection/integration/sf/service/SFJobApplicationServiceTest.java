package com.sap.hcm.resume.collection.integration.sf.service;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.olingo.odata2.api.ep.entry.ODataEntry;
import org.apache.olingo.odata2.api.ep.feed.ODataFeed;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;

import com.sap.hcm.resume.collection.bean.JobAppQuestionResponse;
import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.context.TestContext;
import com.sap.hcm.resume.collection.context.WebAppContext;
import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.entity.DataModelMapping;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;
import com.sap.hcm.resume.collection.entity.view.JobApplyMappingVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.bean.CandProfileDataModelMapping;
import com.sap.hcm.resume.collection.integration.sf.SFOdataFormatter;
import com.sap.hcm.resume.collection.integration.sf.bean.QueryInfo;
import com.sap.hcm.resume.collection.integration.sf.odata.SFODataService;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJob;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJobApplicationVO;
import com.sap.hcm.resume.collection.service.CompanyInfoService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { TestContext.class, WebAppContext.class })
public class SFJobApplicationServiceTest {

  private SFJobApplicationService sFJobApplicationService;

  @Resource(name = "sfODataService")
  private SFODataService sfODataService;

  @Resource(name = "sfOdataFormatter")
  private SFOdataFormatter sfOdataFormatter;

  @Resource(name = "companyInfoService")
  private CompanyInfoService companyInfoService;

  @Autowired
  private Params params;

  @Before
  public void setUp() {
    reset(sfODataService);
    reset(sfOdataFormatter);
    reset(companyInfoService);

    sFJobApplicationService = new SFJobApplicationService();
    ReflectionTestUtils.setField(sFJobApplicationService, "sfOdataService", sfODataService);
    ReflectionTestUtils.setField(sFJobApplicationService, "odataFormatter", sfOdataFormatter);
    ReflectionTestUtils.setField(sFJobApplicationService, "companyInfoService", companyInfoService);
    ReflectionTestUtils.setField(sFJobApplicationService, "params", params);
  }

  @Test
  public void testInsertJobApplication() throws ServiceApplicationException {

    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    DataModelMapping mapping = new DataModelMapping();
    WechatJob wechatJob = new WechatJob();
    JobApplyMappingVO jobApplyMappingVO = new JobApplyMappingVO();
    CandProfileDataModelMapping profileMapping = new CandProfileDataModelMapping();
    List<JobAppQuestionResponse> questionResponses = new ArrayList<JobAppQuestionResponse>();
    CompanyInfo info = new CompanyInfo();
    when(companyInfoService.getCompanyInfo("sap")).thenReturn(info);
    WechatJobApplicationVO wechatJobApplicationVO = sFJobApplicationService.insertJobApplication(candidateProfileVO,
        mapping, wechatJob, jobApplyMappingVO, profileMapping, questionResponses);
  }

  @Test(expected = ServiceApplicationException.class)
  public void testInsertJobApplicationError() throws ServiceApplicationException {

    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    DataModelMapping mapping = new DataModelMapping();
    WechatJob wechatJob = new WechatJob();
    JobApplyMappingVO jobApplyMappingVO = new JobApplyMappingVO();
    CandProfileDataModelMapping profileMapping = new CandProfileDataModelMapping();
    List<JobAppQuestionResponse> questionResponses = new ArrayList<JobAppQuestionResponse>();
    CompanyInfo info = new CompanyInfo();
    when(companyInfoService.getCompanyInfo("sap")).thenReturn(info);
    when(
        sfOdataFormatter.getSFJobApplicationOdataFormat(profileMapping, candidateProfileVO, jobApplyMappingVO, info,
            wechatJob, questionResponses)).thenThrow(
        new ServiceApplicationException("jobApplicationQuestionResponse required"));
    WechatJobApplicationVO wechatJobApplicationVO = sFJobApplicationService.insertJobApplication(candidateProfileVO,
        mapping, wechatJob, jobApplyMappingVO, profileMapping, questionResponses);
  }

  @Test
  public void testInsertJobApplicationWithNewApplication() throws ServiceApplicationException {

    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    DataModelMapping mapping = new DataModelMapping();
    WechatJob wechatJob = new WechatJob();
    JobApplyMappingVO jobApplyMappingVO = new JobApplyMappingVO();
    CandProfileDataModelMapping profileMapping = new CandProfileDataModelMapping();
    List<JobAppQuestionResponse> questionResponses = new ArrayList<JobAppQuestionResponse>();
    CompanyInfo info = new CompanyInfo();
    when(companyInfoService.getCompanyInfo("sap")).thenReturn(info);
    Map<String, Object> data = new HashMap<String, Object>();
    when(
        sfOdataFormatter.getSFJobApplicationOdataFormat(profileMapping, candidateProfileVO, jobApplyMappingVO, info,
            wechatJob, questionResponses)).thenReturn(data);
    ODataEntry newApplication = Mockito.mock(ODataEntry.class);
    when(sfODataService.createEntry("application/json;charset=utf-8", "JobApplication", data, false)).thenReturn(
        newApplication);
    Map<String, Object> map = new HashMap<String, Object>();
    map.put("applicationId", 123L);
    when(newApplication.getProperties()).thenReturn(map);
    WechatJobApplicationVO wechatJobApplicationVO = sFJobApplicationService.insertJobApplication(candidateProfileVO,
        mapping, wechatJob, jobApplyMappingVO, profileMapping, questionResponses);
  }

  @Test
  public void testGetOdataFeedStringFromSF() throws ServiceApplicationException, IOException {
    QueryInfo queryInfo = new QueryInfo("abc");
    when(sfODataService.readFeedAsString("application/json;charset=utf-8", queryInfo)).thenReturn("efg");
    sFJobApplicationService.getOdataFeedStringFromSF(queryInfo);
  }

  @Test(expected = ServiceApplicationException.class)
  public void testGetOdataFeedStringFromSFWithException() throws ServiceApplicationException, IOException {
    QueryInfo queryInfo = new QueryInfo("abc");
    when(sfODataService.readFeedAsString("application/json;charset=utf-8", queryInfo)).thenThrow(
        new ServiceApplicationException("efg"));
    sFJobApplicationService.getOdataFeedStringFromSF(queryInfo);
  }

  @Test
  public void testQueryApplicationStatus() throws ServiceApplicationException {
    String applicationId = "123";
    Locale locale = Locale.CHINA;
    ODataFeed feed = Mockito.mock(ODataFeed.class);
    when(sfODataService.readFeed(any(String.class), any(QueryInfo.class))).thenReturn(feed);
    List<ODataEntry> entryList = new ArrayList<ODataEntry>();
    ODataEntry entry = Mockito.mock(ODataEntry.class);
    entryList.add(entry);
    when(feed.getEntries()).thenReturn(entryList);
    Map<String, Object> map = new HashMap<String, Object>();
    map.put("locale", locale.toString());
    when(entry.getProperties()).thenReturn(map);
    sFJobApplicationService.queryApplicationStatus(applicationId, locale);
  }
}
