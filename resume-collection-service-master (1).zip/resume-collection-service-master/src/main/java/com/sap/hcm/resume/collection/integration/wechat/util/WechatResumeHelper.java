package com.sap.hcm.resume.collection.integration.wechat.util;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.springframework.stereotype.Component;

import com.sap.hcm.resume.collection.entity.view.CandidateBgCertificateVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgEducationVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgLanguageVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgWorkExprVO;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;

/**
 * class to generate a pdf version of resume using apache pdfbox.
 * 
 * @author i065831
 */
@Component
public class WechatResumeHelper {

  protected static final String DOUBLE_SPACE = "  ";

  protected static final String SINGLE_SPACE = " ";

  protected static final String SPLITTER = " | ";

  // private Configuration cfg;

  public WechatResumeHelper() {
    
  }

  public byte[] generateResumePDF(CandidateProfileVO profile) throws IOException {
    PDDocument doc = new PDDocument();
    PDFPageWriter pageWriter = new PDFPageWriter(doc);
    byte[] content = null;
    ByteArrayOutputStream byteOutputStream = new ByteArrayOutputStream();

    this.renderBasicProfile(profile, pageWriter);

    this.renderWorkExperience(profile, pageWriter);

    this.renderLanguages(profile, pageWriter);

    this.renderEducation(profile, pageWriter);

    this.renderCertificates(profile, pageWriter);

    pageWriter.close();
    doc.save(byteOutputStream);
    doc.close();
    content = byteOutputStream.toByteArray();
    IOUtils.closeQuietly(byteOutputStream);
    return content;
  }

  private void renderWorkExperience(CandidateProfileVO profile, PDFPageWriter pageWriter) throws IOException {
    pageWriter.write(50, 40, 16, Color.BLUE, "工作经验");
    pageWriter.writeSplitterLine(50, 10, Color.GRAY);

    List<CandidateBgWorkExprVO> exprList = profile.getWorkExprs();
    if (exprList != null) {
      for (CandidateBgWorkExprVO expr : exprList) {
        StringBuilder builder = new StringBuilder();
        builder.append(expr.getStartDate());
        builder.append(" -- ");
        builder.append(expr.getEndDate());
        builder.append(":");
        builder.append(expr.getEmployer() == null ? "" : expr.getEmployer());
        pageWriter.write(50, 20, 10, Color.BLACK, builder.toString());

        pageWriter.write(50, 20, 9, Color.BLACK, "所属行业： " + (expr.getBusinessType() == null ? "" : expr.getBusinessType()));

        pageWriter.write(50, 20, 9, Color.BLACK, "所属部门： " + (expr.getDepartment() == null ? "" : expr.getDepartment()));

        pageWriter.write(50, 20, 9, Color.BLACK, "职位名称： " + (expr.getJobTitle() == null ? "" : expr.getJobTitle()));

        String desc = expr.getDescription();
        
        pageWriter.write(50, 20, 9, Color.BLACK, "工作描述 : ");
        pageWriter.write(100, 15, 9, Color.BLACK, desc);
        
        pageWriter.deductOffsetBy(10);
      }

    }
  }

  private void renderLanguages(CandidateProfileVO profile, PDFPageWriter pageWriter) throws IOException {

    pageWriter.write(50, 40, 16, Color.BLUE, "语言能力");
    pageWriter.writeSplitterLine(50, 10, Color.GRAY);

    List<CandidateBgLanguageVO> languages = profile.getLanguages();
    if (languages != null) {
      for (CandidateBgLanguageVO lang : languages) {

        StringBuilder builder = new StringBuilder();
        builder.append(lang.getName());
        builder.append(": ");
        builder.append(DOUBLE_SPACE);
        builder.append("阅读能力： " + (lang.getReadingProf() == null ? "" : lang.getReadingProf()));
        builder.append(SPLITTER);
        builder.append("写作能力： " + (lang.getWritingProf() == null ? "" : lang.getWritingProf()));
        builder.append(SPLITTER);
        builder.append("口语能力： " + (lang.getSpeakingProf() == null ? "" : lang.getSpeakingProf()));
        pageWriter.write(50, 20, 9, Color.BLACK, builder.toString());
      }
    }
  }

  private void renderEducation(CandidateProfileVO profile, PDFPageWriter pageWriter) throws IOException {

    pageWriter.write(50, 40, 16, Color.BLUE, "教育经历");
    pageWriter.writeSplitterLine(50, 10, Color.GRAY);

    List<CandidateBgEducationVO> educations = profile.getEducation();
    if (educations != null) {
      for (CandidateBgEducationVO edu : educations) {
        StringBuilder builder = new StringBuilder();
        builder.append(edu.getStartDate());
        builder.append(" -- ");
        builder.append(edu.getEndDate());
        builder.append(DOUBLE_SPACE + DOUBLE_SPACE);
        builder.append(edu.getSchool());
        builder.append(DOUBLE_SPACE);
        builder.append(edu.getMajor());
        builder.append(DOUBLE_SPACE);
        builder.append(edu.getDegree());
        pageWriter.write(50, 20, 10, Color.BLACK, builder.toString());
      }
    }
  }

  private void renderCertificates(CandidateProfileVO profile, PDFPageWriter pageWriter) throws IOException {

    pageWriter.write(50, 40, 16, Color.BLUE, "证书");
    pageWriter.writeSplitterLine(50, 10, Color.GRAY);

    List<CandidateBgCertificateVO> certs = profile.getCertificates();
    if (certs != null) {
      for (CandidateBgCertificateVO cert : certs) {
        StringBuilder builder = new StringBuilder();
        builder.append(cert.getStartDate());
        builder.append(DOUBLE_SPACE + DOUBLE_SPACE);
        builder.append(cert.getName());
        pageWriter.write(50, 20, 10, Color.BLACK, builder.toString());
      }
    }
  }

  private void renderBasicProfile(CandidateProfileVO profile, PDFPageWriter pageWriter) throws IOException {

    pageWriter.write(50, 0, 16, Color.BLACK, profile.getFirstName() + " " + profile.getLastName());
    
    pageWriter.writeSplitterLine(50, 10, Color.GRAY);
    
    String gender = "";
    String dob = "";
    String marriage = "";
    StringBuilder builder = new StringBuilder();

    if ("Male".equalsIgnoreCase(profile.getGender())) {
      gender = "男";
    } else {
      gender = "女";
    }
    dob = profile.getDateOfBirth();
    if (dob == null) {
      dob = "未知";
    }
    if ("Y".equals(profile.getMarriage())) {
      marriage = "已婚";
    }
    if ("N".equals(profile.getMarriage())) {
      marriage = "未婚";
    }

    builder.append(gender);
    builder.append(SPLITTER);
    builder.append("（出生日期）");
    builder.append(dob);
    builder.append(SPLITTER);
    builder.append(marriage);
    pageWriter.write(50, 20, 9, Color.BLUE, builder.toString());

    // residence
    pageWriter.write(50, 15, 10, Color.BLACK,
        "居住地:" + SINGLE_SPACE + (profile.getResidence() == null ? "" : profile.getResidence()));
        
    // Address
    pageWriter.write(50, 15, 10, Color.BLACK,
        "地    址:" + SINGLE_SPACE + (profile.getAddress() == null ? "" : profile.getAddress()));
        
    // 手机
    pageWriter.write(50, 15, 10, Color.BLACK,
        "邮    件:" + SINGLE_SPACE + (profile.getPrimaryEmail() == null ? "" : profile.getPrimaryEmail()));

    // email
    pageWriter.write(50, 15, 10, Color.BLACK,
        "手    机:" + SINGLE_SPACE + (profile.getCellPhone() == null ? "" : profile.getCellPhone()));
  }

}
