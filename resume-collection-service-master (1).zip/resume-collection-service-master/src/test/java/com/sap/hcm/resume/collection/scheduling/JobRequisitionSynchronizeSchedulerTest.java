package com.sap.hcm.resume.collection.scheduling;

import static org.junit.Assert.fail;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;

import com.sap.hcm.resume.collection.context.TestContext;
import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.service.CompanyInfoService;
import com.sap.hcm.resume.collection.service.JobRequisitionService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { TestContext.class })
public class JobRequisitionSynchronizeSchedulerTest {

  @Autowired
  private JobRequisitionService jobRequisitionService;

  @Autowired
  private CompanyInfoService companyInfoService;
  
  private JobRequisitionSynchronizeScheduler jobRequisitionSynchronizeScheduler;
  
  @Before
  public void setUp() {
    reset(jobRequisitionService);
    reset(companyInfoService);
    jobRequisitionSynchronizeScheduler = new JobRequisitionSynchronizeScheduler();
    ReflectionTestUtils.setField(jobRequisitionSynchronizeScheduler, "jobRequisitionService", jobRequisitionService);
    ReflectionTestUtils.setField(jobRequisitionSynchronizeScheduler, "companyInfoService", companyInfoService);
  }
  
  @Test
  public void testWorkSuccess() throws ServiceApplicationException {
    try {
      CompanyInfo companyInfo = new CompanyInfo();
      companyInfo.setEnableJobSync(true);
      String companyId = "sap";
      PowerMockito.doNothing().when(jobRequisitionService).syncJobRequisition(companyId);
      when(companyInfoService.getCompanyInfo(companyId)).thenReturn(companyInfo);
      jobRequisitionSynchronizeScheduler.work(companyId);
    } catch(Exception e) {
      fail();
    }
  }
  
  @Test
  public void testWorkGetCompanyInfoError() throws ServiceApplicationException {
    try {
      String companyId = "sap";
      PowerMockito.doNothing().when(jobRequisitionService).syncJobRequisition(companyId);
      when(companyInfoService.getCompanyInfo(companyId)).thenThrow(new ServiceApplicationException("time out"));
      jobRequisitionSynchronizeScheduler.work(companyId);
    } catch(Exception e) {
      fail();
    }
  }
  
  @Test
  public void testWorkGetCompanyInfoIsNull() throws ServiceApplicationException {
    try {
      CompanyInfo companyInfo = null;
      String companyId = "sap";
      PowerMockito.doNothing().when(jobRequisitionService).syncJobRequisition(companyId);
      when(companyInfoService.getCompanyInfo(companyId)).thenReturn(companyInfo);
      jobRequisitionSynchronizeScheduler.work(companyId);
    } catch(Exception e) {
      fail();
    }
  }
  
  @Test
  public void testWorkEnableJobSyncIsFalse() throws ServiceApplicationException {
    try {
      CompanyInfo companyInfo = new CompanyInfo();
      companyInfo.setEnableJobSync(false);
      String companyId = "sap";
      PowerMockito.doNothing().when(jobRequisitionService).syncJobRequisition(companyId);
      when(companyInfoService.getCompanyInfo(companyId)).thenReturn(companyInfo);
      jobRequisitionSynchronizeScheduler.work(companyId);
    } catch(Exception e) {
      fail();
    }
  }
  
  @Test
  public void testWorkSyncJobError() throws ServiceApplicationException {
    try {
      CompanyInfo companyInfo = new CompanyInfo();
      companyInfo.setEnableJobSync(true);
      String companyId = "sap";
      PowerMockito.doThrow(new ServiceApplicationException("time out")).when(jobRequisitionService).syncJobRequisition(companyId);
      when(companyInfoService.getCompanyInfo(companyId)).thenReturn(companyInfo);
      jobRequisitionSynchronizeScheduler.work(companyId);
    } catch(Exception e) {
      fail();
    }
  }
}
