package com.sap.hcm.resume.collection.bean;

import org.junit.Assert;
import org.junit.Test;

public class FunctionTypeEnumTest {
  
  @Test
  public void testGetLabelKey(){
    FunctionTypeEnum fenum = FunctionTypeEnum.JOB_APPLY;
    fenum.setLabelKey("test");
    
    Assert.assertEquals(fenum.getLabelKey(), "test");
  }
}
