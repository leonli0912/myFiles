package com.sap.hcm.resume.collection.integration.wechat.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import javax.annotation.Resource;
import javax.persistence.PersistenceException;
import javax.servlet.http.HttpSession;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.context.WebApplicationContext;

import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.bean.SimpleJsonResponse;
import com.sap.hcm.resume.collection.context.TestContext;
import com.sap.hcm.resume.collection.context.WebAppContext;
import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.entity.view.CandidateBgCertificateVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgEducationVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgFamilyVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgLanguageVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgWorkExprVO;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileWrapperVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.bean.CandProfileDataModelMapping;
import com.sap.hcm.resume.collection.integration.bean.DataModelMappingItem;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatUserResumeMapping;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatUserService;
import com.sap.hcm.resume.collection.integration.wechat.util.WechatResumeHelper;
import com.sap.hcm.resume.collection.service.CandidateProfileService;
import com.sap.hcm.resume.collection.service.CompanyInfoService;
import com.sap.hcm.resume.collection.service.DataModelMappingService;
import com.sap.hcm.resume.collection.util.CandidateProfileHelper;
import com.sap.hcm.resume.collection.util.ChangeLogUtil;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { TestContext.class, WebAppContext.class })
public class CandidateEditorControllerTest {

  @Resource(type = WebApplicationContext.class)
  private WebApplicationContext webApplicationContext;

  @Resource(name = "wechatUserService")
  private WechatUserService wechatUserService;

  @Resource(name = "candidateProfileService")
  private CandidateProfileService candidateProfileService;

  @Resource(name = "wechatResumeHelper")
  private WechatResumeHelper wechatResumeHelper;

  @Resource(name = "companyInfoService")
  private CompanyInfoService companyInfoService;

  @Resource(name = "dataModelMappingService")
  private DataModelMappingService dataModelMappingService;

  @Resource(name = "candidateProfileHelper")
  private CandidateProfileHelper candidateProfileHelper;

  @Autowired
  private ChangeLogUtil changeLogUtil;

  private CandidateEditorController candidateEditorController;

  @Autowired
  private Params params;

  @Before
  public void setUp() {
    reset(wechatUserService);
    reset(candidateProfileService);
    candidateEditorController = spy(new CandidateEditorController());
    params.setCompanyId("sap");
    params.setUserEmail("abc@sap.com");
    ReflectionTestUtils.setField(candidateEditorController, "wechatUserService", wechatUserService);
    ReflectionTestUtils.setField(candidateEditorController, "candidateProfileService", candidateProfileService);
    ReflectionTestUtils.setField(candidateEditorController, "wechatResumeHelper", wechatResumeHelper);
    ReflectionTestUtils.setField(candidateEditorController, "compInfoService", companyInfoService);
    ReflectionTestUtils.setField(candidateEditorController, "dataModelMappingService", dataModelMappingService);
    ReflectionTestUtils.setField(candidateEditorController, "changeLogUtil", changeLogUtil);
    ReflectionTestUtils.setField(candidateEditorController, "candidateProfileHelper", candidateProfileHelper);
    ReflectionTestUtils.setField(candidateEditorController, "params", params);
  }

  @Test
  public void testGetCandidateListByRequest() throws ServiceApplicationException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    MockHttpSession session = new MockHttpSession();
    String companyId = "sap";
    String userMail = "abc@sap.com";
    request.setSession(session);
    WechatUserResumeMapping wechatUserResumeMapping = new WechatUserResumeMapping();
    wechatUserResumeMapping.setCandidateId(1L);
    List<WechatUserResumeMapping> candidateList = new ArrayList<WechatUserResumeMapping>();
    candidateList.add(wechatUserResumeMapping);
    Map<String, Object> map = new HashMap<String, Object>();
    when(wechatUserService.getCandidateListByWechatId(userMail, companyId)).thenReturn(candidateList);

    CandidateProfileVO profileVO = new CandidateProfileVO();
    profileVO.setFirstName("ina");
    CandidateBgWorkExprVO candidateBgWorkExprVO = new CandidateBgWorkExprVO();
    candidateBgWorkExprVO.setDescription("workExpr");
    List<CandidateBgWorkExprVO> workExprs = new ArrayList<CandidateBgWorkExprVO>();
    workExprs.add(candidateBgWorkExprVO);
    profileVO.setWorkExprs(workExprs);
    CandidateBgLanguageVO candidateBgLanguageVO = new CandidateBgLanguageVO();
    candidateBgLanguageVO.setName("English");
    List<CandidateBgLanguageVO> languages = new ArrayList<CandidateBgLanguageVO>();
    languages.add(candidateBgLanguageVO);
    profileVO.setLanguages(languages);
    CandidateBgEducationVO candidateBgEducationVO = new CandidateBgEducationVO();
    candidateBgEducationVO.setSchool("Uni");
    List<CandidateBgEducationVO> educations = new ArrayList<CandidateBgEducationVO>();
    educations.add(candidateBgEducationVO);
    profileVO.setEducation(educations);
    CandidateBgCertificateVO candidateBgCertificateVO = new CandidateBgCertificateVO();
    candidateBgCertificateVO.setDescription("certificate");
    List<CandidateBgCertificateVO> certificates = new ArrayList<CandidateBgCertificateVO>();
    certificates.add(candidateBgCertificateVO);
    profileVO.setCertificates(certificates);
    CandidateBgFamilyVO candidateBgFamilyVO = new CandidateBgFamilyVO();
    candidateBgFamilyVO.setName("father");
    List<CandidateBgFamilyVO> families = new ArrayList<CandidateBgFamilyVO>();
    families.add(candidateBgFamilyVO);
    profileVO.setFamilies(families);

    when(candidateProfileService.getCandidateProfileById(wechatUserResumeMapping.getCandidateId())).thenReturn(
        profileVO);
    CompanyInfo companyInfo = new CompanyInfo();
    companyInfo.setDmMappingId(2L);
    when(companyInfoService.getCompanyInfo(companyId)).thenReturn(companyInfo);
    CandProfileDataModelMapping candProfileDataModelMapping = new CandProfileDataModelMapping();
    SortedSet<DataModelMappingItem> profile = new TreeSet<DataModelMappingItem>();
    DataModelMappingItem item = new DataModelMappingItem();
    item.setRequired(true);
    item.setTo("firstName");
    item.setFrom("firstName");
    profile.add(item);
    SortedSet<DataModelMappingItem> profileWork = new TreeSet<DataModelMappingItem>();
    DataModelMappingItem itemWork = new DataModelMappingItem();
    itemWork.setRequired(true);
    itemWork.setTo("description");
    itemWork.setFrom("description");
    profileWork.add(itemWork);
    SortedSet<DataModelMappingItem> profileEducation = new TreeSet<DataModelMappingItem>();
    DataModelMappingItem itemEducation = new DataModelMappingItem();
    itemEducation.setRequired(true);
    itemEducation.setTo("school");
    itemEducation.setFrom("school");
    profileEducation.add(itemEducation);
    SortedSet<DataModelMappingItem> profileLanguage = new TreeSet<DataModelMappingItem>();
    DataModelMappingItem itemLanguage = new DataModelMappingItem();
    itemLanguage.setRequired(true);
    itemLanguage.setTo("name");
    itemLanguage.setFrom("name");
    profileLanguage.add(itemLanguage);
    SortedSet<DataModelMappingItem> profileCertificate = new TreeSet<DataModelMappingItem>();
    DataModelMappingItem itemCertificate = new DataModelMappingItem();
    itemCertificate.setRequired(true);
    itemCertificate.setTo("description");
    itemCertificate.setFrom("description");
    profileCertificate.add(itemCertificate);
    SortedSet<DataModelMappingItem> profileFamily = new TreeSet<DataModelMappingItem>();
    DataModelMappingItem itemFamily = new DataModelMappingItem();
    itemFamily.setRequired(true);
    itemFamily.setTo("name");
    itemFamily.setFrom("name");
    profileFamily.add(itemFamily);
    candProfileDataModelMapping.setProfile(profile);
    candProfileDataModelMapping.setWorkExprs(profileWork);
    candProfileDataModelMapping.setEducation(profileEducation);
    candProfileDataModelMapping.setLanguages(profileLanguage);
    candProfileDataModelMapping.setCertificates(profileCertificate);
    candProfileDataModelMapping.setFamilies(profileFamily);
    Map<String, String> aliases = new HashMap<String, String>();
    aliases.put("workExprs", "workExprs");
    aliases.put("education", "education");
    aliases.put("languages", "languages");
    aliases.put("certificates", "certificates");
    aliases.put("families", "families");
    candProfileDataModelMapping.setAliases(aliases);
    when(dataModelMappingService.getCandidateProfileDataModelMappingById(companyInfo.getDmMappingId())).thenReturn(
        candProfileDataModelMapping);
    Map<String, Object> ratioDetail = new HashMap<String, Object>();
    ratioDetail.put("ratio", 1.0);
    ratioDetail.put("missing", Collections.EMPTY_SET);
    Map<Long, Object> ratioMap = new HashMap<Long, Object>();
    ratioMap.put(wechatUserResumeMapping.getCandidateId(), ratioDetail);
    map.put("candidateList", candidateList);
    map.put("completion", ratioMap);
    // assertEquals(map.get("completion").toString(), candidateEditorController.getCandidateList(request)
    // .get("completion").toString());
    assertEquals(map.get("candidateList"), candidateEditorController.getCandidateList(request).get("candidateList"));
  }

  @SuppressWarnings("rawtypes")
  @Test
  public void testGetCandidateMissingRequiredFields() throws ServiceApplicationException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    MockHttpSession session = new MockHttpSession();
    String companyId = "sap";
    String userMail = "abc@sap.com";
    request.setSession(session);
    WechatUserResumeMapping wechatUserResumeMapping = new WechatUserResumeMapping();
    wechatUserResumeMapping.setCandidateId(1L);
    List<WechatUserResumeMapping> candidateList = new ArrayList<WechatUserResumeMapping>();
    candidateList.add(wechatUserResumeMapping);
    Map<String, Object> map = new HashMap<String, Object>();
    when(wechatUserService.getCandidateListByWechatId(userMail, companyId)).thenReturn(candidateList);

    CandidateProfileVO profileVO = new CandidateProfileVO();
    CandidateBgWorkExprVO candidateBgWorkExprVO = new CandidateBgWorkExprVO();
    candidateBgWorkExprVO.setDescription("workExpr");
    List<CandidateBgWorkExprVO> workExprs = new ArrayList<CandidateBgWorkExprVO>();
    workExprs.add(candidateBgWorkExprVO);
    profileVO.setWorkExprs(workExprs);
    CandidateBgLanguageVO candidateBgLanguageVO = new CandidateBgLanguageVO();
    List<CandidateBgLanguageVO> languages = new ArrayList<CandidateBgLanguageVO>();
    languages.add(candidateBgLanguageVO);
    profileVO.setLanguages(languages);
    CandidateBgEducationVO candidateBgEducationVO = new CandidateBgEducationVO();
    List<CandidateBgEducationVO> educations = new ArrayList<CandidateBgEducationVO>();
    educations.add(candidateBgEducationVO);
    profileVO.setEducation(educations);
    CandidateBgCertificateVO candidateBgCertificateVO = new CandidateBgCertificateVO();
    List<CandidateBgCertificateVO> certificates = new ArrayList<CandidateBgCertificateVO>();
    certificates.add(candidateBgCertificateVO);
    profileVO.setCertificates(certificates);
    CandidateBgFamilyVO candidateBgFamilyVO = new CandidateBgFamilyVO();
    List<CandidateBgFamilyVO> families = new ArrayList<CandidateBgFamilyVO>();
    families.add(candidateBgFamilyVO);
    profileVO.setFamilies(families);

    when(candidateProfileService.getCandidateProfileById(wechatUserResumeMapping.getCandidateId())).thenReturn(
        profileVO);
    CompanyInfo companyInfo = new CompanyInfo();
    companyInfo.setDmMappingId(2L);
    when(companyInfoService.getCompanyInfo(companyId)).thenReturn(companyInfo);
    CandProfileDataModelMapping candProfileDataModelMapping = new CandProfileDataModelMapping();
    SortedSet<DataModelMappingItem> profile = new TreeSet<DataModelMappingItem>();
    DataModelMappingItem item = new DataModelMappingItem();
    item.setRequired(true);
    item.setTo("firstName");
    item.setFrom("firstName");
    item.setLabel("FIRSTNAME");
    profile.add(item);
    SortedSet<DataModelMappingItem> profileWork = new TreeSet<DataModelMappingItem>();
    DataModelMappingItem itemWork = new DataModelMappingItem();
    itemWork.setRequired(true);
    itemWork.setTo("description");
    itemWork.setFrom("description");
    itemWork.setLabel("DESCRIPTION");
    profileWork.add(itemWork);
    SortedSet<DataModelMappingItem> profileEducation = new TreeSet<DataModelMappingItem>();
    DataModelMappingItem itemEducation = new DataModelMappingItem();
    itemEducation.setRequired(true);
    itemEducation.setTo("school");
    itemEducation.setFrom("school");
    profileEducation.add(itemEducation);
    SortedSet<DataModelMappingItem> profileLanguage = new TreeSet<DataModelMappingItem>();
    DataModelMappingItem itemLanguage = new DataModelMappingItem();
    itemLanguage.setRequired(true);
    itemLanguage.setTo("name");
    itemLanguage.setFrom("name");
    profileLanguage.add(itemLanguage);
    SortedSet<DataModelMappingItem> profileCertificate = new TreeSet<DataModelMappingItem>();
    DataModelMappingItem itemCertificate = new DataModelMappingItem();
    itemCertificate.setRequired(true);
    itemCertificate.setTo("description");
    itemCertificate.setFrom("description");
    profileCertificate.add(itemCertificate);
    SortedSet<DataModelMappingItem> profileFamily = new TreeSet<DataModelMappingItem>();
    DataModelMappingItem itemFamily = new DataModelMappingItem();
    itemFamily.setRequired(true);
    itemFamily.setTo("name");
    itemFamily.setFrom("name");
    profileFamily.add(itemFamily);
    candProfileDataModelMapping.setProfile(profile);
    candProfileDataModelMapping.setWorkExprs(profileWork);
    candProfileDataModelMapping.setEducation(profileEducation);
    candProfileDataModelMapping.setLanguages(profileLanguage);
    candProfileDataModelMapping.setCertificates(profileCertificate);
    candProfileDataModelMapping.setFamilies(profileFamily);
    Map<String, String> aliases = new HashMap<String, String>();
    aliases.put("workExprs", "workExprs");
    aliases.put("education", "education");
    aliases.put("languages", "languages");
    aliases.put("certificates", "certificates");
    aliases.put("families", "families");
    candProfileDataModelMapping.setAliases(aliases);
    when(dataModelMappingService.getCandidateProfileDataModelMappingById(companyInfo.getDmMappingId())).thenReturn(
        candProfileDataModelMapping);

    Map completionMap = (Map) candidateEditorController.getCandidateList(request).get("completion");
    Map ratioDetail = (Map) completionMap.get(1L);
    Set missing = (Set) ratioDetail.get("missing");
    // Assert.assertEquals(missing.size(), 2);

    map.put("candidateList", candidateList);
    assertEquals(map.get("candidateList"), candidateEditorController.getCandidateList(request).get("candidateList"));
  }

  @Test
  public void testGetCandidateListByRequestWithProfileVOIsNull() throws ServiceApplicationException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    MockHttpSession session = new MockHttpSession();
    String wechatId = "001";
    String companyId = "sap";
    String userMail = "abc@sap.com";
    request.setSession(session);
    WechatUserResumeMapping wechatUserResumeMapping = new WechatUserResumeMapping();
    wechatUserResumeMapping.setCandidateId(1L);
    List<WechatUserResumeMapping> candidateList = new ArrayList<WechatUserResumeMapping>();
    candidateList.add(wechatUserResumeMapping);
    when(wechatUserService.getCandidateListByWechatId(userMail, companyId)).thenReturn(candidateList);
    when(candidateProfileService.getCandidateProfileById(wechatUserResumeMapping.getCandidateId())).thenReturn(null);
    Map<String, Object> map = new HashMap<String, Object>();
    Map<Long, Object> ratioMap = new HashMap<Long, Object>();
    ratioMap.put(wechatUserResumeMapping.getCandidateId(), Collections.EMPTY_MAP);
    map.put("completion", ratioMap);
    assertEquals(map.get("completion").toString(), candidateEditorController.getCandidateList(request)
        .get("completion").toString());
  }

  @Test
  public void testGetCandidateListByRequestWithProfileDMMappingIsNull() throws ServiceApplicationException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    MockHttpSession session = new MockHttpSession();
    String userMail = "abc@sap.com";
    String companyId = "sap";
    request.setSession(session);
    WechatUserResumeMapping wechatUserResumeMapping = new WechatUserResumeMapping();
    wechatUserResumeMapping.setCandidateId(1L);
    List<WechatUserResumeMapping> candidateList = new ArrayList<WechatUserResumeMapping>();
    candidateList.add(wechatUserResumeMapping);
    when(wechatUserService.getCandidateListByWechatId(userMail, companyId)).thenReturn(candidateList);
    CandidateProfileVO profileVO = new CandidateProfileVO();
    when(candidateProfileService.getCandidateProfileById(wechatUserResumeMapping.getCandidateId())).thenReturn(
        profileVO);
    CompanyInfo companyInfo = new CompanyInfo();
    companyInfo.setDmMappingId(2L);
    when(companyInfoService.getCompanyInfo(companyId)).thenReturn(companyInfo);
    when(dataModelMappingService.getCandidateProfileDataModelMappingById(companyInfo.getDmMappingId()))
        .thenReturn(null);
    Map<String, Object> map = new HashMap<String, Object>();
    Map<Long, Object> ratioMap = new HashMap<Long, Object>();
    ratioMap.put(wechatUserResumeMapping.getCandidateId(), Collections.EMPTY_MAP);
    map.put("completion", ratioMap);
    assertEquals(map.get("completion").toString(), candidateEditorController.getCandidateList(request)
        .get("completion").toString());
  }

  @Test
  public void testGetCandidateListByCandidateId() throws ServiceApplicationException {
    ReflectionTestUtils.setField(candidateEditorController, "wechatUserService", wechatUserService);
    Long candidateId = 1111L;
    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    when(candidateProfileService.getCandidateProfileById(candidateId)).thenReturn(candidateProfileVO);
    CandidateProfileWrapperVO candidateProfileWrapperVO = new CandidateProfileWrapperVO();

    assertEquals(candidateProfileVO.getCandidateId(), candidateEditorController.getCandidateList(candidateId)
        .getCandidateProfileVO().getCandidateId());
  }

  @Test
  public void testSaveCandidateSuccess() throws ServiceApplicationException, ParseException, IOException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    MockHttpSession session = new MockHttpSession();
    request.setSession(session);
    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    candidateProfileVO.setCandidateId(111L);
    byte[] resumeContent = "resume".getBytes();
    when(wechatResumeHelper.generateResumePDF(candidateProfileVO)).thenReturn(resumeContent);
    WechatUserResumeMapping resumeMapping = new WechatUserResumeMapping();
    resumeMapping.setResumeName("testResume");
    resumeMapping.setCandidateId(111L);
    when(wechatUserService.getCandidateByCandidateId(111L)).thenReturn(resumeMapping);
    CandidateProfileWrapperVO candidateProfileWrapperVO = new CandidateProfileWrapperVO();
    candidateProfileWrapperVO.setCandidateProfileVO(candidateProfileVO);
    assertEquals(candidateProfileWrapperVO, candidateEditorController.saveCandidate(request, candidateProfileWrapperVO));
  }

  @Test(expected = ServiceApplicationException.class)
  public void testSaveCandidateFail() throws ServiceApplicationException, ParseException, IOException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    MockHttpSession session = new MockHttpSession();
    request.setSession(session);
    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    candidateProfileVO.setExtProfile(null);
    when(wechatResumeHelper.generateResumePDF(candidateProfileVO)).thenThrow(new IOException("11"));
    doThrow(new ServiceApplicationException("22")).when(wechatUserService).saveUserResumeMapping(
        any(WechatUserResumeMapping.class));
    CandidateProfileWrapperVO candidateProfileWrapperVO = new CandidateProfileWrapperVO();
    candidateProfileWrapperVO.setCandidateProfileVO(candidateProfileVO);
    candidateEditorController.saveCandidate(request, candidateProfileWrapperVO);
  }

  @Test
  public void testEditWorkExp() throws ServiceApplicationException {
    Long candidateId = 1L;
    int workExpId = 0;
    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    List<CandidateBgWorkExprVO> candidateBgWorkExprVOList = new ArrayList<CandidateBgWorkExprVO>();
    CandidateBgWorkExprVO candidateBgWorkExprVO = new CandidateBgWorkExprVO();
    candidateBgWorkExprVOList.add(candidateBgWorkExprVO);
    candidateProfileVO.setWorkExprs(candidateBgWorkExprVOList);
    when(candidateProfileService.getCandidateProfileById(candidateId)).thenReturn(candidateProfileVO);
    assertEquals(candidateBgWorkExprVO, candidateEditorController.editWorkExp(candidateId, workExpId));
  }

  @Test
  public void testSaveWorkExpSuccessWithWorkExpId() throws ServiceApplicationException, IOException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    request.setParameter("candidateId", "001");
    request.setParameter("workExpId", "0");
    List<CandidateBgWorkExprVO> candidateBgWorkExprVOList = new ArrayList<CandidateBgWorkExprVO>();
    CandidateBgWorkExprVO candidateBgWorkExprVO = new CandidateBgWorkExprVO();
    candidateBgWorkExprVOList.add(candidateBgWorkExprVO);
    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    candidateProfileVO.setCandidateId(1L);
    candidateProfileVO.setWorkExprs(candidateBgWorkExprVOList);
    when(candidateProfileService.getCandidateProfileById(Long.valueOf(request.getParameter("candidateId"))))
        .thenReturn(candidateProfileVO);
    byte[] resumeContent = "resume".getBytes();
    when(wechatResumeHelper.generateResumePDF(candidateProfileVO)).thenReturn(resumeContent);

    WechatUserResumeMapping wechatUserResumeMapping = new WechatUserResumeMapping();
    wechatUserResumeMapping.setResumeName("testResume");
    when(wechatUserService.getCandidateByCandidateId(1L)).thenReturn(wechatUserResumeMapping);

    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(0);
    rsp.setMessage("success");
    assertEquals(rsp.getMessage(), candidateEditorController.saveWorkExp(request, candidateBgWorkExprVO).getMessage());
  }

  @Test
  public void testSaveWorkExpSuccessWithoutWorkExpId() throws ServiceApplicationException, IOException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    request.setParameter("candidateId", "1");
    List<CandidateBgWorkExprVO> candidateBgWorkExprVOList = new ArrayList<CandidateBgWorkExprVO>();
    CandidateBgWorkExprVO candidateBgWorkExprVO = new CandidateBgWorkExprVO();
    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    candidateProfileVO.setCandidateId(1L);
    candidateProfileVO.setWorkExprs(candidateBgWorkExprVOList);
    when(candidateProfileService.getCandidateProfileById(Long.valueOf(request.getParameter("candidateId"))))
        .thenReturn(candidateProfileVO);
    byte[] resumeContent = "resume".getBytes();
    when(wechatResumeHelper.generateResumePDF(candidateProfileVO)).thenReturn(resumeContent);
    WechatUserResumeMapping resumeMapping = new WechatUserResumeMapping();
    resumeMapping.setResumeName("testResume");
    resumeMapping.setCandidateId(1L);
    when(wechatUserService.getCandidateByCandidateId(1L)).thenReturn(resumeMapping);

    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(0);
    rsp.setMessage("success");
    assertEquals(rsp.getMessage(), candidateEditorController.saveWorkExp(request, candidateBgWorkExprVO).getMessage());
  }

  @Test
  public void testSaveWorkExpFail() throws ServiceApplicationException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    request.setParameter("candidateId", "001");
    request.setParameter("workExpId", "0");
    CandidateBgWorkExprVO candidateBgWorkExprVO = new CandidateBgWorkExprVO();
    when(candidateProfileService.getCandidateProfileById(Long.valueOf(request.getParameter("candidateId")))).thenThrow(
        new PersistenceException());
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(-1);
    rsp.setMessage("failed");
    assertEquals(rsp.getMessage(), candidateEditorController.saveWorkExp(request, candidateBgWorkExprVO).getMessage());
  }

  @Test
  public void testDeleteBgElementOfWorkExprs() throws ServiceApplicationException, IOException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    Long candidateId = 1L;
    String elementType = "workExprs";
    int rowNo = 0;
    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    candidateProfileVO.setCandidateId(candidateId);
    List<CandidateBgWorkExprVO> workExprs = new ArrayList<CandidateBgWorkExprVO>();
    CandidateBgWorkExprVO candidateBgWorkExprVO = new CandidateBgWorkExprVO();
    workExprs.add(candidateBgWorkExprVO);
    candidateProfileVO.setWorkExprs(workExprs);
    when(candidateProfileService.getCandidateProfileById(candidateId)).thenReturn(candidateProfileVO);
    byte[] resumeContent = "resume".getBytes();
    when(wechatResumeHelper.generateResumePDF(candidateProfileVO)).thenReturn(resumeContent);

    WechatUserResumeMapping wechatUserResumeMapping = new WechatUserResumeMapping();
    wechatUserResumeMapping.setResumeName("testResume");
    when(wechatUserService.getCandidateByCandidateId(candidateId)).thenReturn(wechatUserResumeMapping);

    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(0);
    rsp.setMessage("success");
    assertEquals(rsp.getMessage(), candidateEditorController.deleteBgElement(request, candidateId, elementType, rowNo)
        .getMessage());
  }

  @Test
  public void testDeleteBgElementOfLanguages() throws ServiceApplicationException, IOException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    Long candidateId = 1L;
    String elementType = "languages";
    int rowNo = 0;
    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    candidateProfileVO.setCandidateId(candidateId);
    List<CandidateBgLanguageVO> languages = new ArrayList<CandidateBgLanguageVO>();
    CandidateBgLanguageVO candidateBgLanguageVO = new CandidateBgLanguageVO();
    languages.add(candidateBgLanguageVO);
    candidateProfileVO.setLanguages(languages);
    when(candidateProfileService.getCandidateProfileById(candidateId)).thenReturn(candidateProfileVO);
    byte[] resumeContent = "resume".getBytes();
    when(wechatResumeHelper.generateResumePDF(candidateProfileVO)).thenReturn(resumeContent);

    WechatUserResumeMapping wechatUserResumeMapping = new WechatUserResumeMapping();
    wechatUserResumeMapping.setResumeName("testResume");
    when(wechatUserService.getCandidateByCandidateId(candidateId)).thenReturn(wechatUserResumeMapping);

    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(0);
    rsp.setMessage("success");
    assertEquals(rsp.getMessage(), candidateEditorController.deleteBgElement(request, candidateId, elementType, rowNo)
        .getMessage());
  }

  @Test
  public void testDeleteBgElementOfEducation() throws ServiceApplicationException, IOException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    Long candidateId = 1L;
    String elementType = "education";
    int rowNo = 0;
    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    candidateProfileVO.setCandidateId(1L);
    List<CandidateBgEducationVO> educ = new ArrayList<CandidateBgEducationVO>();
    CandidateBgEducationVO candidateBgEducationVO = new CandidateBgEducationVO();
    educ.add(candidateBgEducationVO);
    candidateProfileVO.setEducation(educ);
    when(candidateProfileService.getCandidateProfileById(candidateId)).thenReturn(candidateProfileVO);
    byte[] resumeContent = "resume".getBytes();
    when(wechatResumeHelper.generateResumePDF(candidateProfileVO)).thenReturn(resumeContent);
    WechatUserResumeMapping resumeMapping = new WechatUserResumeMapping();
    resumeMapping.setResumeName("testResume");
    resumeMapping.setCandidateId(1L);
    when(wechatUserService.getCandidateByCandidateId(1L)).thenReturn(resumeMapping);

    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(0);
    rsp.setMessage("success");
    assertEquals(rsp.getMessage(), candidateEditorController.deleteBgElement(request, candidateId, elementType, rowNo)
        .getMessage());
  }

  @Test
  public void testDeleteBgElementOfCertificate() throws ServiceApplicationException, IOException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    Long candidateId = 1L;
    String elementType = "certificates";
    int rowNo = 0;
    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    candidateProfileVO.setCandidateId(1L);
    List<CandidateBgCertificateVO> certs = new ArrayList<CandidateBgCertificateVO>();
    CandidateBgCertificateVO candidateBgCertificateVO = new CandidateBgCertificateVO();
    certs.add(candidateBgCertificateVO);
    candidateProfileVO.setCertificates(certs);
    when(candidateProfileService.getCandidateProfileById(candidateId)).thenReturn(candidateProfileVO);
    byte[] resumeContent = "resume".getBytes();
    when(wechatResumeHelper.generateResumePDF(candidateProfileVO)).thenReturn(resumeContent);
    WechatUserResumeMapping resumeMapping = new WechatUserResumeMapping();
    resumeMapping.setResumeName("testResume");
    resumeMapping.setCandidateId(1L);
    when(wechatUserService.getCandidateByCandidateId(1L)).thenReturn(resumeMapping);

    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(0);
    rsp.setMessage("success");
    assertEquals(rsp.getMessage(), candidateEditorController.deleteBgElement(request, candidateId, elementType, rowNo)
        .getMessage());
  }

  @Test
  public void testDeleteBgElementOfFamilies() throws ServiceApplicationException, IOException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    Long candidateId = 1L;
    String elementType = "families";
    int rowNo = 0;
    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    candidateProfileVO.setCandidateId(1L);
    List<CandidateBgFamilyVO> families = new ArrayList<CandidateBgFamilyVO>();
    CandidateBgFamilyVO candidateBgFamilyVO = new CandidateBgFamilyVO();
    families.add(candidateBgFamilyVO);
    candidateProfileVO.setFamilies(families);
    when(candidateProfileService.getCandidateProfileById(candidateId)).thenReturn(candidateProfileVO);
    byte[] resumeContent = "resume".getBytes();
    when(wechatResumeHelper.generateResumePDF(candidateProfileVO)).thenReturn(resumeContent);
    WechatUserResumeMapping resumeMapping = new WechatUserResumeMapping();
    resumeMapping.setResumeName("testResume");
    resumeMapping.setCandidateId(1L);
    when(wechatUserService.getCandidateByCandidateId(1L)).thenReturn(resumeMapping);

    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(0);
    rsp.setMessage("success");
    assertEquals(rsp.getMessage(), candidateEditorController.deleteBgElement(request, candidateId, elementType, rowNo)
        .getMessage());
  }

  @Test
  public void testDeleteBgElementFail() throws ServiceApplicationException, IOException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    Long candidateId = 1L;
    String elementType = "families";
    int rowNo = 0;
    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    List<CandidateBgFamilyVO> families = new ArrayList<CandidateBgFamilyVO>();
    CandidateBgFamilyVO candidateBgFamilyVO = new CandidateBgFamilyVO();
    families.add(candidateBgFamilyVO);
    candidateProfileVO.setFamilies(families);
    when(candidateProfileService.getCandidateProfileById(candidateId)).thenThrow(new PersistenceException());
    byte[] resumeContent = "resume".getBytes();
    when(wechatResumeHelper.generateResumePDF(candidateProfileVO)).thenReturn(resumeContent);
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(-1);
    rsp.setMessage("failed");
    assertEquals(rsp.getMessage(), candidateEditorController.deleteBgElement(request, candidateId, elementType, rowNo)
        .getMessage());
  }

  @Test
  public void testDeleteCandidateSuccess() throws ServiceApplicationException {
    Long candidateId = 123L;
    when(candidateProfileService.deleteCandidateProfileById(candidateId)).thenReturn(1);
    when(wechatUserService.deleteUserResumeMappingById(candidateId)).thenReturn(1);

    WechatUserResumeMapping wechatUserResumeMapping = new WechatUserResumeMapping();
    wechatUserResumeMapping.setResumeName("testResume");
    when(wechatUserService.getCandidateByCandidateId(candidateId)).thenReturn(wechatUserResumeMapping);

    MockHttpServletRequest mockRequest = new MockHttpServletRequest();
    HttpSession session = new MockHttpSession();
    mockRequest.setSession(session);

    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(0);
    rsp.setMessage("success");
    assertEquals(rsp.getMessage(), candidateEditorController.deleteCandidate(mockRequest, candidateId).getMessage());
  }

  @Test
  public void testDeleteCandidateFail() throws ServiceApplicationException {
    Long candidateId = 123L;
    WechatUserResumeMapping wechatResumeMapping = new WechatUserResumeMapping();
    wechatResumeMapping.setResumeName("resumeName");
    when(candidateProfileService.deleteCandidateProfileById(candidateId)).thenReturn(1);
    when(wechatUserService.deleteUserResumeMappingById(candidateId)).thenReturn(0);
    when(wechatUserService.getCandidateByCandidateId(candidateId)).thenReturn(wechatResumeMapping);

    MockHttpServletRequest mockRequest = new MockHttpServletRequest();
    HttpSession session = new MockHttpSession();
    mockRequest.setSession(session);

    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(-1);
    rsp.setMessage("failed");
    assertEquals(rsp.getMessage(), candidateEditorController.deleteCandidate(mockRequest, candidateId).getMessage());
  }

  @Test
  public void testEditEducation() throws ServiceApplicationException {

    Long candidateId = 1L;
    int educId = 0;
    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    List<CandidateBgEducationVO> candidateBgEducationVOList = new ArrayList<CandidateBgEducationVO>();
    CandidateBgEducationVO candidateBgEducationVO = new CandidateBgEducationVO();
    candidateBgEducationVOList.add(candidateBgEducationVO);
    candidateProfileVO.setEducation(candidateBgEducationVOList);
    when(candidateProfileService.getCandidateProfileById(candidateId)).thenReturn(candidateProfileVO);
    assertEquals(candidateBgEducationVO, candidateEditorController.editEducation(candidateId, educId));
  }

  @Test
  public void testEditLanguage() throws ServiceApplicationException {

    Long candidateId = 1L;
    int educId = 0;
    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    List<CandidateBgLanguageVO> candidateBgLanguageVOList = new ArrayList<CandidateBgLanguageVO>();
    CandidateBgLanguageVO candidateBgLanguageVO = new CandidateBgLanguageVO();
    candidateBgLanguageVOList.add(candidateBgLanguageVO);
    candidateProfileVO.setLanguages(candidateBgLanguageVOList);
    when(candidateProfileService.getCandidateProfileById(candidateId)).thenReturn(candidateProfileVO);
    assertEquals(candidateBgLanguageVO, candidateEditorController.editLanguage(candidateId, educId));
  }

  @Test
  public void testEditCertificate() throws ServiceApplicationException {

    Long candidateId = 1L;
    int educId = 0;
    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    List<CandidateBgCertificateVO> candidateBgCertificateVOList = new ArrayList<CandidateBgCertificateVO>();
    CandidateBgCertificateVO candidateBgCertificateVO = new CandidateBgCertificateVO();
    candidateBgCertificateVOList.add(candidateBgCertificateVO);
    candidateProfileVO.setCertificates(candidateBgCertificateVOList);
    when(candidateProfileService.getCandidateProfileById(candidateId)).thenReturn(candidateProfileVO);
    assertEquals(candidateBgCertificateVO, candidateEditorController.editCertificate(candidateId, educId));
  }

  @Test
  public void testEditFamily() throws ServiceApplicationException {

    Long candidateId = 1L;
    int educId = 0;
    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    List<CandidateBgFamilyVO> candidateBgFamilyVOList = new ArrayList<CandidateBgFamilyVO>();
    CandidateBgFamilyVO candidateBgFamilyVO = new CandidateBgFamilyVO();
    candidateBgFamilyVOList.add(candidateBgFamilyVO);
    candidateProfileVO.setFamilies(candidateBgFamilyVOList);
    when(candidateProfileService.getCandidateProfileById(candidateId)).thenReturn(candidateProfileVO);
    assertEquals(candidateBgFamilyVO, candidateEditorController.editFamily(candidateId, educId));
  }

  @Test
  public void testSaveEducationSuccessWithEducId() throws ServiceApplicationException, IOException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    request.setParameter("candidateId", "001");
    request.setParameter("educId", "0");
    List<CandidateBgEducationVO> candidateBgEducationVOList = new ArrayList<CandidateBgEducationVO>();
    CandidateBgEducationVO candidateBgEducationVO = new CandidateBgEducationVO();
    candidateBgEducationVOList.add(candidateBgEducationVO);
    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    candidateProfileVO.setCandidateId(1L);
    candidateProfileVO.setEducation(candidateBgEducationVOList);
    when(candidateProfileService.getCandidateProfileById(Long.valueOf(request.getParameter("candidateId"))))
        .thenReturn(candidateProfileVO);
    byte[] resumeContent = "resume".getBytes();
    when(wechatResumeHelper.generateResumePDF(candidateProfileVO)).thenReturn(resumeContent);
    WechatUserResumeMapping resumeMapping = new WechatUserResumeMapping();
    resumeMapping.setResumeName("testResume");
    resumeMapping.setCandidateId(1L);
    when(wechatUserService.getCandidateByCandidateId(1L)).thenReturn(resumeMapping);

    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(0);
    rsp.setMessage("success");
    assertEquals(rsp.getMessage(), candidateEditorController.saveEducation(request, candidateBgEducationVO)
        .getMessage());
  }

  @Test
  public void testSaveEducationSuccessWithoutEducId() throws ServiceApplicationException, IOException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    request.setParameter("candidateId", "001");
    List<CandidateBgEducationVO> candidateBgEducationVOList = new ArrayList<CandidateBgEducationVO>();
    CandidateBgEducationVO candidateBgEducationVO = new CandidateBgEducationVO();
    candidateBgEducationVOList.add(candidateBgEducationVO);
    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    candidateProfileVO.setCandidateId(1L);
    candidateProfileVO.setEducation(candidateBgEducationVOList);
    when(candidateProfileService.getCandidateProfileById(Long.valueOf(request.getParameter("candidateId"))))
        .thenReturn(candidateProfileVO);
    byte[] resumeContent = "resume".getBytes();
    when(wechatResumeHelper.generateResumePDF(candidateProfileVO)).thenReturn(resumeContent);

    WechatUserResumeMapping wechatUserResumeMapping = new WechatUserResumeMapping();
    wechatUserResumeMapping.setResumeName("testResume");
    when(wechatUserService.getCandidateByCandidateId(1L)).thenReturn(wechatUserResumeMapping);

    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(0);
    rsp.setMessage("success");
    assertEquals(rsp.getMessage(), candidateEditorController.saveEducation(request, candidateBgEducationVO)
        .getMessage());
  }

  @Test
  public void testSaveEducationFail() throws ServiceApplicationException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    request.setParameter("candidateId", "001");
    request.setParameter("educId", "0");
    CandidateBgEducationVO candidateBgEducationVO = new CandidateBgEducationVO();
    when(candidateProfileService.getCandidateProfileById(Long.valueOf(request.getParameter("candidateId")))).thenThrow(
        new PersistenceException());
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(-1);
    rsp.setMessage("failed");
    assertEquals(rsp.getMessage(), candidateEditorController.saveEducation(request, candidateBgEducationVO)
        .getMessage());
  }

  @Test
  public void testSaveLanguageSuccessWithLangId() throws ServiceApplicationException, IOException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    request.setParameter("candidateId", "001");
    request.setParameter("langId", "0");
    List<CandidateBgLanguageVO> candidateBgLanguageVOList = new ArrayList<CandidateBgLanguageVO>();
    CandidateBgLanguageVO candidateBgLanguageVO = new CandidateBgLanguageVO();
    candidateBgLanguageVOList.add(candidateBgLanguageVO);
    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    candidateProfileVO.setCandidateId(1L);
    candidateProfileVO.setLanguages(candidateBgLanguageVOList);
    when(candidateProfileService.getCandidateProfileById(Long.valueOf(request.getParameter("candidateId"))))
        .thenReturn(candidateProfileVO);
    byte[] resumeContent = "resume".getBytes();
    when(wechatResumeHelper.generateResumePDF(candidateProfileVO)).thenReturn(resumeContent);

    WechatUserResumeMapping resumeMapping = new WechatUserResumeMapping();
    resumeMapping.setResumeName("testResume");
    resumeMapping.setCandidateId(1L);
    when(wechatUserService.getCandidateByCandidateId(1L)).thenReturn(resumeMapping);

    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(0);
    rsp.setMessage("success");
    assertEquals(rsp.getMessage(), candidateEditorController.saveLanguage(request, candidateBgLanguageVO).getMessage());
  }

  @Test
  public void testSaveLanguageSuccessWithoutLangId() throws ServiceApplicationException, IOException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    request.setParameter("candidateId", "001");
    List<CandidateBgLanguageVO> candidateBgLanguageVOList = new ArrayList<CandidateBgLanguageVO>();
    CandidateBgLanguageVO candidateBgLanguageVO = new CandidateBgLanguageVO();
    candidateBgLanguageVOList.add(candidateBgLanguageVO);
    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    candidateProfileVO.setCandidateId(1L);
    candidateProfileVO.setLanguages(candidateBgLanguageVOList);
    when(candidateProfileService.getCandidateProfileById(Long.valueOf(request.getParameter("candidateId"))))
        .thenReturn(candidateProfileVO);
    byte[] resumeContent = "resume".getBytes();
    when(wechatResumeHelper.generateResumePDF(candidateProfileVO)).thenReturn(resumeContent);
    WechatUserResumeMapping resumeMapping = new WechatUserResumeMapping();
    resumeMapping.setResumeName("testResume");
    resumeMapping.setCandidateId(1L);
    when(wechatUserService.getCandidateByCandidateId(1L)).thenReturn(resumeMapping);

    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(0);
    rsp.setMessage("success");
    assertEquals(rsp.getMessage(), candidateEditorController.saveLanguage(request, candidateBgLanguageVO).getMessage());
  }

  @Test
  public void testSaveLanguageFail() throws ServiceApplicationException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    request.setParameter("candidateId", "001");
    request.setParameter("langId", "0");
    CandidateBgLanguageVO candidateBgLanguageVO = new CandidateBgLanguageVO();
    when(candidateProfileService.getCandidateProfileById(Long.valueOf(request.getParameter("candidateId")))).thenThrow(
        new PersistenceException());
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(-1);
    rsp.setMessage("failed");
    assertEquals(rsp.getMessage(), candidateEditorController.saveLanguage(request, candidateBgLanguageVO).getMessage());
  }

  @Test
  public void testSaveCertificateSuccessWithcertId() throws ServiceApplicationException, IOException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    request.setParameter("candidateId", "001");
    request.setParameter("certId", "0");
    List<CandidateBgCertificateVO> candidateBgCertificateVOList = new ArrayList<CandidateBgCertificateVO>();
    CandidateBgCertificateVO candidateBgCertificateVO = new CandidateBgCertificateVO();
    candidateBgCertificateVOList.add(candidateBgCertificateVO);
    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    candidateProfileVO.setCandidateId(1L);
    candidateProfileVO.setCertificates(candidateBgCertificateVOList);
    when(candidateProfileService.getCandidateProfileById(Long.valueOf(request.getParameter("candidateId"))))
        .thenReturn(candidateProfileVO);
    byte[] resumeContent = "resume".getBytes();
    when(wechatResumeHelper.generateResumePDF(candidateProfileVO)).thenReturn(resumeContent);

    WechatUserResumeMapping resumeMapping = new WechatUserResumeMapping();
    resumeMapping.setResumeName("testResume");
    resumeMapping.setCandidateId(1L);
    when(wechatUserService.getCandidateByCandidateId(1L)).thenReturn(resumeMapping);

    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(0);
    rsp.setMessage("success");
    assertEquals(rsp.getMessage(), candidateEditorController.saveCertificate(request, candidateBgCertificateVO)
        .getMessage());
  }

  @Test
  public void testSaveCertificateSuccessWithoutcertId() throws ServiceApplicationException, IOException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    request.setParameter("candidateId", "001");
    List<CandidateBgCertificateVO> candidateBgCertificateVOList = new ArrayList<CandidateBgCertificateVO>();
    CandidateBgCertificateVO candidateBgCertificateVO = new CandidateBgCertificateVO();
    candidateBgCertificateVOList.add(candidateBgCertificateVO);
    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    candidateProfileVO.setCandidateId(1L);
    candidateProfileVO.setCertificates(candidateBgCertificateVOList);
    when(candidateProfileService.getCandidateProfileById(Long.valueOf(request.getParameter("candidateId"))))
        .thenReturn(candidateProfileVO);
    byte[] resumeContent = "resume".getBytes();
    when(wechatResumeHelper.generateResumePDF(candidateProfileVO)).thenReturn(resumeContent);

    WechatUserResumeMapping wechatUserResumeMapping = new WechatUserResumeMapping();
    wechatUserResumeMapping.setResumeName("testResume");
    when(wechatUserService.getCandidateByCandidateId(1L)).thenReturn(wechatUserResumeMapping);

    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(0);
    rsp.setMessage("success");
    assertEquals(rsp.getMessage(), candidateEditorController.saveCertificate(request, candidateBgCertificateVO)
        .getMessage());
  }

  @Test
  public void testSaveCertificateFail() throws ServiceApplicationException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    request.setParameter("candidateId", "001");
    request.setParameter("certId", "0");
    CandidateBgCertificateVO candidateBgCertificateVO = new CandidateBgCertificateVO();
    when(candidateProfileService.getCandidateProfileById(Long.valueOf(request.getParameter("candidateId")))).thenThrow(
        new PersistenceException());
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(-1);
    rsp.setMessage("failed");
    assertEquals(rsp.getMessage(), candidateEditorController.saveCertificate(request, candidateBgCertificateVO)
        .getMessage());
  }

  @Test
  public void testSaveFamilySuccessWithfamId() throws ServiceApplicationException, IOException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    request.setParameter("candidateId", "001");
    request.setParameter("famId", "0");
    List<CandidateBgFamilyVO> candidateBgFamilyVOList = new ArrayList<CandidateBgFamilyVO>();
    CandidateBgFamilyVO candidateBgFamilyVO = new CandidateBgFamilyVO();
    candidateBgFamilyVOList.add(candidateBgFamilyVO);
    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    candidateProfileVO.setFamilies(candidateBgFamilyVOList);
    candidateProfileVO.setCandidateId(123L);
    when(candidateProfileService.getCandidateProfileById(Long.valueOf(request.getParameter("candidateId"))))
        .thenReturn(candidateProfileVO);
    byte[] resumeContent = "resume".getBytes();
    when(wechatResumeHelper.generateResumePDF(candidateProfileVO)).thenReturn(resumeContent);

    WechatUserResumeMapping resumeMapping = new WechatUserResumeMapping();
    resumeMapping.setResumeName("testResume");
    resumeMapping.setCandidateId(123L);
    when(wechatUserService.getCandidateByCandidateId(123L)).thenReturn(resumeMapping);

    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(0);
    rsp.setMessage("success");
    assertEquals(rsp.getMessage(), candidateEditorController.saveFamily(request, candidateBgFamilyVO).getMessage());
  }

  @Test
  public void testSaveFamilySuccessWithoutfamId() throws ServiceApplicationException, IOException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    request.setParameter("candidateId", "001");
    List<CandidateBgFamilyVO> candidateBgFamilyVOList = new ArrayList<CandidateBgFamilyVO>();
    CandidateBgFamilyVO candidateBgFamilyVO = new CandidateBgFamilyVO();
    candidateBgFamilyVOList.add(candidateBgFamilyVO);
    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    candidateProfileVO.setCandidateId(1L);
    candidateProfileVO.setFamilies(candidateBgFamilyVOList);
    when(candidateProfileService.getCandidateProfileById(Long.valueOf(request.getParameter("candidateId"))))
        .thenReturn(candidateProfileVO);
    byte[] resumeContent = "resume".getBytes();
    when(wechatResumeHelper.generateResumePDF(candidateProfileVO)).thenReturn(resumeContent);

    WechatUserResumeMapping wechatUserResumeMapping = new WechatUserResumeMapping();
    wechatUserResumeMapping.setResumeName("testResume");
    when(wechatUserService.getCandidateByCandidateId(1L)).thenReturn(wechatUserResumeMapping);

    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(0);
    rsp.setMessage("success");
    assertEquals(rsp.getMessage(), candidateEditorController.saveFamily(request, candidateBgFamilyVO).getMessage());
  }

  @Test
  public void testSaveFamilyFail() throws ServiceApplicationException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    request.setParameter("candidateId", "001");
    request.setParameter("famId", "0");
    CandidateBgFamilyVO candidateBgFamilyVO = new CandidateBgFamilyVO();
    when(candidateProfileService.getCandidateProfileById(Long.valueOf(request.getParameter("candidateId")))).thenThrow(
        new PersistenceException());
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(-1);
    rsp.setMessage("failed");
    assertEquals(rsp.getMessage(), candidateEditorController.saveFamily(request, candidateBgFamilyVO).getMessage());
  }

  @Test
  public void testGetMissingRequiredField() throws ServiceApplicationException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    request.setParameter("candidateId", "1");

    MockHttpSession session = new MockHttpSession();
    request.setSession(session);

    Map<String, Object> missing = candidateEditorController.getMissingRequiredField(request, 1L);
    Assert.assertEquals(missing.keySet().size(), 0);
  }

  @Test
  public void testGetMissingRequiredFieldWithoutCompany() throws ServiceApplicationException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    request.setParameter("candidateId", "1");

    Map<String, Object> missing = candidateEditorController.getMissingRequiredField(request, 1L);
    Assert.assertEquals(missing.keySet().size(), 0);
  }
}
