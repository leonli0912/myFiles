jQuery.sap.require("sap.m.MessageBox");
sap.ui.controller("static.js.layout.jobApplicationMappingAdd", {


	_router: null,
	_candidateProfileMapId: null,
	_jobAppMapId: null,
	_candidateProfileData: null,
	_currentLabelRow:null,
/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf resume-collection-service.mappingAdd
*/
	onInit: function() {

		var oData = {
	    	"options":[{
	    		"key":"SF",
	    		"label":"SuccessFactor"
	    	}]
	    };

		/* Set Target System */
	    var oTargetSystem = this.getView().byId("targetSystem");
	    var oTargetSystemModel = new sap.ui.model.json.JSONModel();
	    oTargetSystemModel.setData(oData);
	    oTargetSystem.setModel(oTargetSystemModel);

	    this._router = sap.ui.core.UIComponent.getRouterFor(this);

	    /* Get the candidate profile data model currently in use */
	    var companyInfoModel = new sap.ui.model.json.JSONModel();
		companyInfoModel.loadData("company/info",null,false);
		var companyInfoData = companyInfoModel.getData();
	    this._candidateProfileMapId = companyInfoData.dmMappingId;

	    if (this._candidateProfileMapId){
		    /* Get the candidate profile field list for user to select */
		    var candidateProfileModel = new sap.ui.model.json.JSONModel();
		    candidateProfileModel.loadData("dm/" + this._candidateProfileMapId,null,false);
		    this._candidateProfileData = candidateProfileModel.getData();
		}

		var jobAppMappingListModel = new sap.ui.model.json.JSONModel();
		jobAppMappingListModel.loadData("appl/loadJobApplicationDmConf",null,false);
		var jobAppMappingListData = jobAppMappingListModel.getData();

		/* Add candidate profile list into import result list */
		if(this._candidateProfileData){
			var resultData = this._mergeData(this._candidateProfileData, jobAppMappingListData.itemList);
			var jobAppConfModel = new sap.ui.model.json.JSONModel();
			jobAppConfModel.setData(resultData);
		}
		this._jobAppMapId = jobAppMappingListData.id;
		this.getView().byId("mappingName").setValue(jobAppMappingListData.mappingName);
		this.getView().byId("importResultList").setModel(jobAppConfModel);
	},


	alertMsg : function(requiredMsg) {
		var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
	    sap.m.MessageBox.alert(
	    	requiredMsg,
	    	{
	    		styleClass: bCompact? "sapUiSizeCompact" : ""
	    	}
	    );
	},

	doUpload : function(oEvent) {

		var oFileUploader = this.getView().byId("fileUploader");

		if (this._candidateProfileMapId){
			oFileUploader.setUploadUrl("appl/uploadSFDataModel?mapId="+this._candidateProfileMapId);
		}
		oFileUploader.upload();
		oFileUploader.clear();

	},

	uploadComplete : function(oEvent) {
		var canProData = this._candidateProfileData;
		var sResponse = oEvent.getParameter("response");
	    var oImportResultList = this.getView().byId("importResultList");
	    oImportResultList.setBusy(false);
	    var oModel = new sap.ui.model.json.JSONModel();
	    var jsonDataStr = /\[.*\]/.exec(sResponse);

	    var jsonData = JSON.parse(jsonDataStr);
	    if(canProData){
	    	var resultData = this._mergeData(canProData, jsonData);
	    }
	    oModel.setData(resultData);
	    oImportResultList.setModel(oModel);

	},

	_mergeData: function(CandidateProfileData, importResultList){
		 var emptyData = {
		    		"from":""
		    };

		 var candidateSource = {
        	     "from":"candidateSource",
        	     "to":""
         };

		 var candidateType = {
        	     "from":"candidateType",
        	     "to":""
         };

		 for(var i = CandidateProfileData.profile.length - 1; i >= 0; i--) {
			    if(CandidateProfileData.profile[i].from === "") {
			    	CandidateProfileData.profile.splice(i, 1);
			    }
			}
		//Predefined field ChannelName & ChannelType
		 CandidateProfileData.profile.push(candidateSource);
		 CandidateProfileData.profile.push(candidateType);

		 if (CandidateProfileData.profile[CandidateProfileData.profile.length-1].from !=""){
			 CandidateProfileData.profile.push(emptyData);
		 }
		 for (row in importResultList){
			 importResultList[row].profile = CandidateProfileData.profile;
		    }
		 return importResultList;
	},

	onSave : function(oEvent) {

		var mappingModel = this.getView().byId("importResultList").getModel();
		var targetSystemData = this.getView().byId("targetSystem").getSelectedKey();
		var mappingNameData = this.getView().byId("mappingName").getValue();
		var mappingData = mappingModel.getData();
		var jsonData = {
				id : this._jobAppMapId ? this._jobAppMapId : null,
				targetSystem : targetSystemData,
				mappingName : mappingNameData,
				itemList : mappingData
		};
		var that = this;
		var cfg = {
			type : 'POST',
			data: JSON.stringify(jsonData),
			dataType : 'json',
			contentType : 'application/json;charset=UTF-8'
		};
		this.getView().setBusy(true);
		cfg.url = "appl/saveJobApplicationDmConf";
	    $.ajax(cfg).success(function(data) {
	    	that.getView().setBusy(false);
	    	jQuery.sap.require("sap.m.MessageToast");
	    	if(data && data.code == "-1"){
	    		that.alertMsg(data.message);
	    	}else{
	    		sap.m.MessageToast.show("Job application data model successfully updated");
	    	}

	    });

	},

	translateText: function(val){
		return this.getView().getModel("i18n").getResourceBundle().getText(val);
	},

	onCancel : function() {
		window.close();
	},

	onSourceNameTypeChange: function(oEvent){
		var selectedKey = oEvent.getSource().getSelectedKey();
		var row = oEvent.getSource().getParent();
		var rowIdxStr = row.getBindingContext().sPath;
		var rowIdxArray = rowIdxStr.match(/\d+/g);
		var rowIdx = rowIdxArray[rowIdxArray.length - 1];
		var data = row.getBindingContext().getModel().getData();
		if (selectedKey == "selectFromCandidateProfile"){
			data[rowIdx].displaySourceName = true;
			data[rowIdx].displayDefaultValue = true;
			data[rowIdx].displayFieldLabel = false;
			data[rowIdx].fieldLabel = "";
		}
		else if (selectedKey == "inputExtraField"){
			data[rowIdx].displaySourceName = false;
			data[rowIdx].sourceField = "";
			data[rowIdx].displayDefaultValue = true;
			data[rowIdx].displayFieldLabel = false;
			data[rowIdx].fieldLabel = "";
		}else{
			data[rowIdx].displaySourceName = false;
			data[rowIdx].displayFieldLabel = true;
			data[rowIdx].sourceField = "";
			data[rowIdx].displayDefaultValue = false;
			data[rowIdx].defaultValue = "";
		}
		row.getBindingContext().getModel().setData(data);
	},

	onSourceNameChange: function(oEvent){
		var selectedKey = oEvent.getSource().getSelectedKey();
		var row = oEvent.getSource().getParent();
		var data = row.getBindingContext().getModel().getData();
	},
	showValueHelp: function(oEvent){
		var bindContext = oEvent.getSource().getBindingContext();
		var rowData = bindContext.getModel().getObject(bindContext.sPath);
		this._picklist = rowData.picklist;

		if(this._picklist){
			this.openPicklistOptionsDialog(oEvent, this._picklist);
		}

	},

	openPicklistOptionsDialog: function(oEvent, picklist){

		var picklistOptionDialog = this.getView().byId("picklistOptionsPopover");
		this.getView().byId("pklLocale").setSelectedKey("zh_CN");

		//load picklist from SF
		var cfg = {
			type : 'GET',
			dataType : 'json',
			contentType : 'application/json;charset=UTF-8'
		};
		cfg.url = "sf/picklistOptions?&picklist=" + picklist;
		var that = this;
		picklistOptionDialog.setBusy(true);
	    $.ajax(cfg).success(function(data) {
	    	var ojsonModel = new sap.ui.model.json.JSONModel();
	    	if(data && data.code == "-1"){
	    		ojsonModel.setData({errorMsg: data.message, options:[]});
	    	}else{
	    		ojsonModel.setData({errorMsg:"",options:data});
	    	}
			picklistOptionDialog.setModel(ojsonModel);
			picklistOptionDialog.setBusy(false);
	    });

	    picklistOptionDialog.openBy(oEvent.getSource());
	},

	pickOptionsLocaleChange: function(oEvent){
		var picklistOptionDialog = this.getView().byId("picklistOptionsPopover");
		//load picklist from SF
		var cfg = {
			type : 'GET',
			dataType : 'json',
			contentType : 'application/json;charset=UTF-8'
		};
		var locale = this.getView().byId("pklLocale").getSelectedKey();
		cfg.url = "sf/picklistOptions?&picklist=" + this._picklist + "&locale="+locale;
		var that = this;
		picklistOptionDialog.setBusy(true);
    $.ajax(cfg).success(function(data) {
    	var ojsonModel = new sap.ui.model.json.JSONModel();
    	if(data && data.code == "-1"){
    		ojsonModel.setData({errorMsg: data.message, options:[]});
    	}else{
    		ojsonModel.setData({errorMsg:"",options:data});
    	}
			picklistOptionDialog.setModel(ojsonModel);
			picklistOptionDialog.setBusy(false);
	    });
	},

	pickOptionsDialogCloseOK: function(){
		this.getView().byId("picklistOptionsPopover").close();
		this._picklist = null;
	},
	pickOptionsDialogClose: function(){
		this.getView().byId("picklistOptionsPopover").close();
		this._picklist = null;
	},

	exportConfigure: function(oEvent){
		window.open("appl/"+this._jobAppMapId+"/export");
	},

	importConfigure: function(oEvent){
		var sResponse = JSON.parse(oEvent.getParameter("responseRaw"));
//		var raw = oEvent.getParameter("response");
//		var result = JSON.parse(raw.replace(/<[^>]+>/gi,""));
		if(this._candidateProfileData){
			var resultData = this._mergeData(this._candidateProfileData, sResponse);
			var jobAppConfModel = new sap.ui.model.json.JSONModel();
			jobAppConfModel.setData(resultData);
		}
		this.getView().byId("importResultList").setModel(jobAppConfModel);
	},

	addNewMappingItemDialogOpen: function(){
		this.getView().byId("addNewMappingItemDialog").open();
	},

	addNewMappingItemDialogClose: function(){
		var mappingModel = this.getView().byId("importResultList").getModel();
		var mappingData = mappingModel.getData();
		if(!mappingData){
			var mappingData = new Array();
		}
		var sdmfnaValue = this.getView().byId("sfDataModelFieldNameAdd").getValue();
		var requiredValue = this.getView().byId("requiredAdd").getSelectedKey();
		var required = true;
		if(requiredValue ==="false"){
			required = false;
		}
		var pickListIdValue = this.getView().byId("pickListIdAdd").getValue();
		var label = "LB_"+sdmfnaValue.replace(new RegExp(/([A-Z])/g),"_$1").toUpperCase();
		var oData = {
		    		"defaultValue":null,
		    		"displayDefaultValue":true,
		    		"displaySourceName":true,
					"displayFieldLabel":false,
		    		"label":label,
		    		"picklist":pickListIdValue,
		    		"required":required,
		    		"sfDmField":sdmfnaValue,
		    		"sourceField":null,
		    		"sourceNameType":"selectFromCandidateProfile"
		   };
		mappingData.push(oData);
		mappingData = this._mergeData(this._candidateProfileData, mappingData);
		mappingModel.setData(mappingData);
		this.getView().byId("addNewMappingItemDialog").close();
	},

	deleteItem: function(oEvent){
		var rowId = oEvent.getSource().getBindingContext().getPath();
		var rows = rowId.match(/\d+/g);
		var rowNo = rows[rows.length - 1];

		var mappingModel = this.getView().byId("importResultList").getModel();
		var mappingData = mappingModel.getData();
		mappingData.splice(rowNo,1);
		mappingModel.setData(mappingData);
	},

	onRefreshPicklistCache: function(){
		var cfg = {
				type : 'GET',
				dataType : 'json',
				contentType : 'application/json;charset=UTF-8'
			};
			cfg.url = "appl/renewPicklistCache";
			that = this;
			var oDialog = this.getView().byId("BusyDialog");
			oDialog.open();
		    $.ajax(cfg).success(function(data) {
		    	oDialog.close();
		    	if(data && data.code < 0){
		    		that.alertMsg(data.message);
		    	}else{
		    		sap.m.MessageBox.success(that.translateText("REFRESH_PICKLIST_SUCCESS"));
		    	}

		    }).error(function(data){
		    	oDialog.close();
		    });
	},

	editCandInputFieldLabel: function(oEvent){
		var model = this.getView().byId("importResultList").getModel();
		var bindPath = oEvent.getSource().getBindingContext().sPath;
		var rowNo = bindPath.match("\\d+$");
		this._currentLabelRow = rowNo;
		var currentRow = model.getData()[rowNo];

		if(currentRow){
			var translateData = currentRow.labelTranslations;
			if(translateData == null){
				translateData = [];
				translateData.push({
					languageKey:"en_US",
					translation:""
				});
				translateData.push({
					languageKey:"zh_CN",
					translation:""
				});
			}
			var jsonModel = new sap.ui.model.json.JSONModel(translateData);
			this.getView().byId("requiredFieldLabelPopover").setModel(jsonModel);
			this.getView().byId("requiredFieldLabelPopover").openBy(oEvent.getSource());
		}
	},

	translateTheLabelClose: function(){
		if(this._currentLabelRow){
			var model = this.getView().byId("importResultList").getModel();
			var modelData = model.getData();
			var currentRow = modelData[this._currentLabelRow];
			var translations = this.getView().byId("requiredFieldLabelPopover").getModel().getData();
			currentRow.labelTranslations = translations;
			model.setData(modelData);
		}

		this.getView().byId("requiredFieldLabelPopover").close();
		this._currentLabelRow = null;
	},

	formateLanguageLabel: function(val){
		if(!val) return;
		if(val === "en_US"){
			return "English";
		}
		if(val === "zh_CN"){
			return "中文";
		}
	},
/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf resume-collection-service.mappingAdd
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf resume-collection-service.mappingAdd
*/
	onAfterRendering: function() {
		   if(!this._candidateProfileMapId){
		    	this.alertMsg("Pleases first configure candidate profile data model mapping or active any existing mapping!");

		    	setTimeout(function(){location.href="company/maintain";},5000);
		    }
	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf resume-collection-service.mappingAdd
*/
//	onExit: function() {
//
//	}

});
