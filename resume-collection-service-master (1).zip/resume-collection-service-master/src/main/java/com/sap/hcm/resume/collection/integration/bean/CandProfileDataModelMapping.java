package com.sap.hcm.resume.collection.integration.bean;

import java.io.Serializable;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;

import org.springframework.util.StringUtils;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileConstants;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.sf.bean.SFPicklist;
import com.sap.hcm.resume.collection.integration.xml.DataModelMappingXMLConverter;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamOmitField;

@XStreamAlias("data-model-mapping")
@JsonIgnoreProperties(value="picklistOptionMapping")
public class CandProfileDataModelMapping implements Serializable{
    
    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = -6558219983473696274L;
    
    private SortedSet<DataModelMappingItem> profile;
    
    private SortedSet<DataModelMappingItem> workExprs;
    
    private SortedSet<DataModelMappingItem> languages;
    
    private SortedSet<DataModelMappingItem> certificates;
    
    private SortedSet<DataModelMappingItem> families;
    
    private SortedSet<DataModelMappingItem> education;
    
    private Map<String, String> aliases = new HashMap<String, String>();
    
    @XStreamAlias("picklist-option-mapping")
    private DataMappingPkOptionMapping picklistOptionMapping;
    
    @XStreamAlias("data-mapping-overwrites")
    private DataMappingOverwrite dataMappingOverwrites;
    
    @XStreamOmitField
    private String pkOptionMappingString;

    /**
     * @return the profile
     */
    public SortedSet<DataModelMappingItem> getProfile() {
        return profile;
    }

    /**
     * @param profile the profile to set
     */
    public void setProfile(SortedSet<DataModelMappingItem> profile) {
        this.profile = profile;
    }

    /**
     * @return the workExprs
     */
    public SortedSet<DataModelMappingItem> getWorkExprs() {
        return workExprs;
    }

    /**
     * @param workExprs the workExprs to set
     */
    public void setWorkExprs(SortedSet<DataModelMappingItem> workExprs) {
        this.workExprs = workExprs;
    }

    /**
     * @return the languages
     */
    public SortedSet<DataModelMappingItem> getLanguages() {
        return languages;
    }

    /**
     * @param languages the languages to set
     */
    public void setLanguages(SortedSet<DataModelMappingItem> languages) {
        this.languages = languages;
    }

    /**
     * @return the certificates
     */
    public SortedSet<DataModelMappingItem> getCertificates() {
        return certificates;
    }

    /**
     * @param certificates the certificates to set
     */
    public void setCertificates(SortedSet<DataModelMappingItem> certificates) {
        this.certificates = certificates;
    }

    /**
     * @return the families
     */
    public SortedSet<DataModelMappingItem> getFamilies() {
        return families;
    }

    /**
     * @param families the families to set
     */
    public void setFamilies(SortedSet<DataModelMappingItem> families) {
        this.families = families;
    }

    /**
     * @return the education
     */
    public SortedSet<DataModelMappingItem> getEducation() {
        return education;
    }

    /**
     * @param education the education to set
     */
    public void setEducation(SortedSet<DataModelMappingItem> education) {
        this.education = education;
    }

    /**
     * @return the aliases
     */
    public Map<String, String> getAliases() {
        return aliases;
    }

    /**
     * @param aliases the aliases to set
     */
    public void setAliases(Map<String, String> aliases) {
        this.aliases = aliases;
    }
    
    /**
     * query all the picklist existed in the mapping
     * @return
     */
    public List<SFPicklist> picklists(){
        List<SFPicklist> pickLists = new ArrayList<SFPicklist>();
        this.resolvePickListFromDMElement(pickLists, this.profile, null);
        this.resolvePickListFromDMElement(pickLists, this.workExprs, CandidateProfileConstants.BG_WORKEXPR_NAME);
        this.resolvePickListFromDMElement(pickLists, this.certificates, CandidateProfileConstants.BG_CERT_NAME);
        this.resolvePickListFromDMElement(pickLists, this.education, CandidateProfileConstants.BG_EDUC_NAME);
        this.resolvePickListFromDMElement(pickLists, this.families, CandidateProfileConstants.BG_FAMI_NAME);
        this.resolvePickListFromDMElement(pickLists, this.languages, CandidateProfileConstants.BG_LANGU_NAME);
        return pickLists;
    }
    
    private void resolvePickListFromDMElement(List<SFPicklist> plList, Set<DataModelMappingItem> modelItems, String category){
        SFPicklist pl = null;
        if(modelItems != null && modelItems.size() > 0){
            for (DataModelMappingItem item : modelItems) {
                if(!StringUtils.isEmpty(item.getPicklist())){
                    pl = new SFPicklist();
                    pl.setSrcPropertyName(item.getFrom());
                    pl.setSFPropertyName(item.getTo());
                    pl.setPicklistName(item.getPicklist());
                    pl.setCategory(category);
                    plList.add(pl);
                }
            }
        }
    }

    public DataMappingPkOptionMapping getPicklistOptionMapping() {
        return picklistOptionMapping;
    }

    public void setPicklistOptionMapping(DataMappingPkOptionMapping picklistOptionMapping) {
        this.picklistOptionMapping = picklistOptionMapping;
    }

    public String getPkOptionMappingString() {
        String xml = null;
        if(this.picklistOptionMapping != null){
            xml = DataModelMappingXMLConverter.toOptionXML(this.picklistOptionMapping);
        }
        return xml;
    }

    public void setPkOptionMappingString(String pkOptionMappingString) {
        this.pkOptionMappingString = pkOptionMappingString;
    }
    
    /**
     * @return the dataMappingOverwrites
     */
    public DataMappingOverwrite getDataMappingOverwrites() {
      return dataMappingOverwrites;
    }

    /**
     * @param dataMappingOverwrites the dataMappingOverwrites to set
     */
    public void setDataMappingOverwrites(DataMappingOverwrite dataMappingOverwrites) {
      this.dataMappingOverwrites = dataMappingOverwrites;
    }

    /**
     * must be called before save the option mapping
     * @throws ServiceApplicationException
     */
    public void converFromPkOptionMappingStringtoBean() throws ServiceApplicationException{
        if(!StringUtils.isEmpty(this.pkOptionMappingString)){
            try{
                DataMappingPkOptionMapping optionMapping =  DataModelMappingXMLConverter.fromOptionXML(URLDecoder.decode(this.pkOptionMappingString, "utf-8"));
                this.setPicklistOptionMapping(optionMapping);
            }catch(Exception e){
                throw new ServiceApplicationException("Invalid option profile mapping template");
            }
        }
    }

}
