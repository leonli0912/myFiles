package com.sap.hcm.resume.collection.bean;

import org.junit.Assert;
import org.junit.Test;

public class LogObjectTypeTest {
  
  @Test
  public void testFromObjectName(){
    LogObjectType type = LogObjectType.CANDIDATE_PROFILE;
    Assert.assertEquals("candidateProfile", type.getObjectName());
    
    type = LogObjectType.fromObjectName("candidateProfile");
    Assert.assertEquals("candidateProfile", type.getObjectName());
  }
  
  @Test
  public void testInvalidObjectName(){
    LogObjectType type = LogObjectType.fromObjectName("invalid");
    Assert.assertNull(type);
  }
  
}
