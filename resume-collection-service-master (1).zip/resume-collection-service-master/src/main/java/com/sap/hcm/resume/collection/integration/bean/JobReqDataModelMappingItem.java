package com.sap.hcm.resume.collection.integration.bean;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("jobreq-mapping-item")
public class JobReqDataModelMappingItem implements Serializable{

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 1149177615132382330L;

    private String sourceField;

    private String sfDmField;
    
    private String picklist;
    
    private String defaultValue;
    
    private String label;
    
    private boolean filterable = false;
    
    private boolean displayInWeChat = false;

    public String getSourceField() {
        return sourceField;
    }

    public void setSourceField(String sourceField) {
        this.sourceField = sourceField;
    }

    public String getSfDmField() {
        return sfDmField;
    }

    public void setSfDmField(String sfDmField) {
        this.sfDmField = sfDmField;
    }

    public String getPicklist() {
        return picklist;
    }

    public void setPicklist(String picklist) {
        this.picklist = picklist;
    }

    public String getDefaultValue() {
        return defaultValue;
    }

    public void setDefaultValue(String defaultValue) {
        this.defaultValue = defaultValue;
    }

    public boolean isFilterable() {
        return filterable;
    }

    public void setFilterable(boolean filterable) {
        this.filterable = filterable;
    }

    /**
     * @return the label
     */
    public String getLabel() {
        return label;
    }

    /**
     * @param label the label to set
     */
    public void setLabel(String label) {
        this.label = label;
    }
    
    public boolean isDisplayInWeChat() {
      return displayInWeChat;
    }

    public void setDisplayInWeChat(boolean displayInWeChat) {
      this.displayInWeChat = displayInWeChat;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((picklist == null) ? 0 : picklist.hashCode());
        result = prime * result + ((sourceField == null) ? 0 : sourceField.hashCode());
        return result;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        JobReqDataModelMappingItem other = (JobReqDataModelMappingItem) obj;
        if (picklist == null) {
            if (other.picklist != null)
                return false;
        } else if (!picklist.equals(other.picklist))
            return false;
        if (sourceField == null) {
            if (other.sourceField != null)
                return false;
        } else if (!sourceField.equals(other.sourceField))
            return false;
        return true;
    }
}
