package com.sap.hcm.resume.collection.integration.wechat.entity;

import java.util.List;

public class WechatJobScreeningQuestionAndChoice {
  private WechatJobScreeningQuestion wechatJobScreeningQuestion;

  List<WechatJobScreeningQuestionChoice> jobScreeningQuestionChoiceList;

  public WechatJobScreeningQuestion getWechatJobScreeningQuestion() {
    return wechatJobScreeningQuestion;
  }

  public void setWechatJobScreeningQuestion(WechatJobScreeningQuestion wechatJobScreeningQuestion) {
    this.wechatJobScreeningQuestion = wechatJobScreeningQuestion;
  }

  public List<WechatJobScreeningQuestionChoice> getJobScreeningQuestionChoiceList() {
    return jobScreeningQuestionChoiceList;
  }

  public void setJobScreeningQuestionChoiceList(List<WechatJobScreeningQuestionChoice> jobScreeningQuestionChoiceList) {
    this.jobScreeningQuestionChoiceList = jobScreeningQuestionChoiceList;
  }

}
