package com.sap.hcm.resume.collection.bean;

/**
 * @author I075908 SAP
 */
public class JobAppQuestionResponse {

  private Long order;

  private String answer;

  public Long getOrder() {
    return order;
  }

  public void setOrder(Long order) {
    this.order = order;
  }

  public String getAnswer() {
    return answer;
  }

  public void setAnswer(String answer) {
    this.answer = answer;
  }

}
