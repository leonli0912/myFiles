
package com.sap.hcm.resume.collection.integration.wechat.bean;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("sub_button")
public class WechatSubMenuItem implements Serializable {

  /**
   * 
   */
  private static final long serialVersionUID = 6531753519609414277L;

  private String name;

  private String type;

  private String key;

  private String url;
  
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getType() {
    return type;
  }

  public void setType(String type) {
    this.type = type;
  }

  public String getKey() {
    return key;
  }

  public void setKey(String key) {
    this.key = key;
  }

  public String getUrl() {
    return url;
  }

  public void setUrl(String url) {
    this.url = url;
  }

  
}

