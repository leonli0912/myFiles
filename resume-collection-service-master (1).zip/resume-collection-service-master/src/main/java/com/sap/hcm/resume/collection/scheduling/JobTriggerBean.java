package com.sap.hcm.resume.collection.scheduling;

import org.springframework.scheduling.quartz.SchedulerFactoryBean;
import org.springframework.stereotype.Component;

@Component(value="jobTriggerBean")
public class JobTriggerBean {
  
  private SchedulerFactoryBean schedulerFactoryBean;

  /**
   * @return the schedulerFactoryBean
   */
  public SchedulerFactoryBean getSchedulerFactoryBean() {
    return schedulerFactoryBean;
  }

  /**
   * @param schedulerFactoryBean the schedulerFactoryBean to set
   */
  public void setSchedulerFactoryBean(SchedulerFactoryBean schedulerFactoryBean) {
    this.schedulerFactoryBean = schedulerFactoryBean;
  }
}
