package com.sap.hcm.resume.collection.integration.wechat.entity;

import java.util.Date;

public class JsTicket {

  private String js_ticket;

  private long createTime;

  static class JsTicketHolder {

    static JsTicket instance = new JsTicket();

  }

  public static JsTicket getInstance() {

    return JsTicketHolder.instance;

  }

  public boolean isExpired() {

    long time = new Date().getTime();

    // 如果当前记录时间为0

    if (this.createTime <= 0) {

      return true;

    }

    // 判断记录时间是否超过7200s

    if (this.createTime / 1000 + 7200 < time / 1000) {

      return true;

    }

    return false;

  }

  public void saveLocalJsTicket(String jsTicket) {

    this.js_ticket = jsTicket;

    this.createTime = new Date().getTime();

  }

  public long getCreateTime() {
    return createTime;
  }

  public void setCreateTime(long createTime) {
    this.createTime = createTime;
  }

  public String getJs_ticket() {
    return js_ticket;
  }

  public void setJs_ticket(String js_ticket) {
    this.js_ticket = js_ticket;
  }



}
