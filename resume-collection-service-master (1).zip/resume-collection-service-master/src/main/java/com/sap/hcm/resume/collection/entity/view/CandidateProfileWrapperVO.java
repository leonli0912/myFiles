
package com.sap.hcm.resume.collection.entity.view;

import java.io.Serializable;
import java.util.List;

/**
 * @author I324117
 * SAP
 */
public class CandidateProfileWrapperVO implements Serializable{

  private static final long serialVersionUID = 6839421732692543243L;

  private CandidateProfileVO candidateProfileVO;
  
  private List<JobApplicationRequiredFieldVO> fieldVOList;

  public CandidateProfileVO getCandidateProfileVO() {
    return candidateProfileVO;
  }

  public void setCandidateProfileVO(CandidateProfileVO candidateProfileVO) {
    this.candidateProfileVO = candidateProfileVO;
  }

  public List<JobApplicationRequiredFieldVO> getFieldVOList() {
    return fieldVOList;
  }

  public void setFieldVOList(List<JobApplicationRequiredFieldVO> fieldVOList) {
    this.fieldVOList = fieldVOList;
  }


  

}
