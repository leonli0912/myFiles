package com.sap.hcm.resume.collection.integration.wechat.service;

import java.util.Date;
import java.util.List;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.AuthenticationFailedException;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.SendFailedException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.sap.cloud.account.TenantContext;
import com.sap.core.connectivity.api.configuration.ConnectivityConfiguration;
import com.sap.core.connectivity.api.configuration.DestinationConfiguration;
import com.sap.hcm.resume.collection.entity.Photo;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatUser;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatUserResumeMapping;

@Service
public class WechatUserService {

  private Logger logger = LoggerFactory.getLogger(WechatUserService.class);

  @PersistenceContext
  private EntityManager entityManager;

  @Autowired
  private ConnectivityConfiguration connectivityConfiguration;

  @Autowired
  private TenantContext tenantContext;

  public List<WechatUserResumeMapping> getCandidateListByWechatId(String wechatId, String companyId)
      throws ServiceApplicationException {
    try {

      TypedQuery<WechatUserResumeMapping> query = entityManager.createQuery(
          "select urm from WechatUserResumeMapping urm where urm.wechatId = :wechatId and urm.companyId = :companyId",
          WechatUserResumeMapping.class);
      query.setParameter("wechatId", wechatId);
      query.setParameter("companyId", companyId);
      List<WechatUserResumeMapping> mappingList = query.getResultList();
      return mappingList;
    } catch (Exception exception) {
      throw new ServiceApplicationException(exception.getMessage());
    }
  }

  public boolean checkIsCurrentID(Long candidateId, String wechatId, String companyId)
      throws ServiceApplicationException {
    try {
      String countQuery = "select count(urm) from WechatUserResumeMapping urm "
          + "where urm.wechatId = :wechatId and urm.companyId = :companyId " + "and urm.candidateId = :candidateId";
      TypedQuery<Long> query = entityManager.createQuery(countQuery, Long.class);
      query.setParameter("wechatId", wechatId);
      query.setParameter("companyId", companyId);
      query.setParameter("candidateId", candidateId);
      if (query.getSingleResult() > 0) {
        return true;
      }
      return false;
    } catch (Exception exception) {
      throw new ServiceApplicationException(exception.getMessage());
    }
  }

  public WechatUserResumeMapping getCandidateByCandidateId(Long candidateId) throws ServiceApplicationException {
    try {
      Query query = entityManager
          .createQuery("select urm from WechatUserResumeMapping urm where urm.candidateId = :candidateId");
      query.setParameter("candidateId", candidateId);
      WechatUserResumeMapping mapping = (WechatUserResumeMapping) query.getSingleResult();
      return mapping;
    } catch (Exception exception) {
      throw new ServiceApplicationException(exception.getMessage());
    }
  }

  public WechatUser saveWechatUser(WechatUser wechatUser) throws ServiceApplicationException {
    WechatUser user = null;
    if (StringUtils.isEmpty(wechatUser)) {
      throw new ServiceApplicationException("invalid wechat user request");
    }
    try {
      user = entityManager.merge(wechatUser);
    } catch (Exception e) {
      throw new ServiceApplicationException(e.getMessage());
    }
    return user;
  }

  public Photo saveImg(Photo photo) {
    photo = entityManager.merge(photo);
    return photo;
  }

  /**
   * check same resume already imported
   * 
   * @param wechatId
   * @param companyId
   * @param vendorName
   * @param externalResumeId
   * @param language
   * @param isSameResumeId
   *          when Chinese resume and English resume share the same resume Id, if yes then add language together with
   *          externalResumeId to check the uniqueness
   * @return
   */
  public boolean checkResumeAlreadyImported(String wechatId, String companyId, String vendorName,
      String externalResumeId, String language, boolean isSameResumeId) {

    String countQuery = "select count(urm) from WechatUserResumeMapping urm where urm.wechatId = :wechatId and urm.companyId = :companyId"
        + " and urm.vendorName = :vendorName and urm.externalResumeId = :resumeId";

    if (isSameResumeId) {
      countQuery = countQuery.concat(" and urm.language = :language");
    }
    TypedQuery<Long> query = entityManager.createQuery(countQuery, Long.class);

    query.setParameter("wechatId", wechatId);
    query.setParameter("companyId", companyId);
    query.setParameter("vendorName", vendorName);
    if (isSameResumeId) {
      query.setParameter("language", language);
    }
    query.setParameter("resumeId", externalResumeId);

    long count = query.getSingleResult();
    if (count > 0) {
      return true;
    }
    return false;
  }

  public WechatUser getUserInfoByEmail(String wechatId, String companyId) {
    WechatUser wechatUser = null;
    try {
      Query query = entityManager.createQuery("select wu from WechatUser wu where wu.wechatId = :wechatId "
          + "and wu.companyId = :companyId");
      query.setParameter("wechatId", wechatId);
      query.setParameter("companyId", companyId);
      wechatUser = (WechatUser) query.getSingleResult();
    } catch (Exception e) {
      logger.error("User with ID:" + wechatId + " is not found");
      return null;
    }
    return wechatUser;
  }

  public void saveUserResumeMapping(WechatUserResumeMapping userResumeMapping) throws ServiceApplicationException {
    try {
      TypedQuery<WechatUserResumeMapping> query = entityManager
          .createQuery("select urm from WechatUserResumeMapping urm where urm.wechatId = :wechatId "
              + "and urm.companyId = :companyId " + "and urm.candidateId = :candidateId", WechatUserResumeMapping.class);
      query.setParameter("wechatId", userResumeMapping.getWechatId());
      query.setParameter("companyId", userResumeMapping.getCompanyId());
      query.setParameter("candidateId", userResumeMapping.getCandidateId());
      try {
        query.getSingleResult();
      } catch (PersistenceException ex) {
        // insert
        entityManager.persist(userResumeMapping);
      }

    } catch (Exception exception) {
      throw new ServiceApplicationException(exception.getMessage());
    }
  }

  public int deleteUserResumeMappingById(Long candidateId) {
    int res = -1;
    String deleteCandidate = "delete from WechatUserResumeMapping urm where urm.candidateId = :candidateId";
    Query query = entityManager.createQuery(deleteCandidate);

    try {
      query.setParameter("candidateId", candidateId);
      query.executeUpdate();
      res = 1;
    } catch (PersistenceException e) {
      res = -1;
    }
    return res;
  }

  public void sendVerificationCode(String to, String veriCode) throws ServiceApplicationException {
    Properties props = System.getProperties();
    try {
      String currentTenantId = tenantContext.getTenant().getAccount().getId();
      DestinationConfiguration destConfiguration;
      if (currentTenantId.equals("dev_default")) {
        destConfiguration = connectivityConfiguration.getConfiguration("VERIFY_INTERNAL_EMAIL");
      } else {
        destConfiguration = connectivityConfiguration.getConfiguration(currentTenantId, "VERIFY_INTERNAL_EMAIL");
      }

      if ("MAIL".equals(destConfiguration.getProperty("Type"))) {
        final String username = destConfiguration.getProperty("mail.user");
        final String password = destConfiguration.getProperty("mail.password");

        props.put("mail.smtp.host", destConfiguration.getProperty("mail.smtp.host"));
        props.put("mail.smtp.port", destConfiguration.getProperty("mail.smtp.port"));
        props.put("mail.smtp.starttls.enable", destConfiguration.getProperty("mail.smtp.starttls.enable"));
        props.put("mail.smtp.ssl.trust", destConfiguration.getProperty("mail.smtp.host"));
        props.put("mail.smtp.auth", "true");

        Session mailSession = Session.getInstance(props, new javax.mail.Authenticator() {
          protected PasswordAuthentication getPasswordAuthentication() {
            return new PasswordAuthentication(username, password);
          }
        });

        MimeMessage msg = new MimeMessage(mailSession);
        msg.setFrom(new InternetAddress(username));
        msg.setRecipient(Message.RecipientType.TO, new InternetAddress(to));
        msg.setSubject(destConfiguration.getProperty("mail.subject"));
        msg.setSentDate(new Date());
        msg.setText("Verification Code: " + veriCode, "UTF-8");

        Transport.send(msg);
        logger.info("Message has been successfully sent to Recipient:" + to);
      }
    } catch (MessagingException mex) {
      mex.printStackTrace();
      Exception ex = mex;
      do {
        if (ex instanceof SendFailedException) {
          SendFailedException sfex = (SendFailedException) ex;
          Address[] invalid = sfex.getInvalidAddresses();
          if (invalid != null) {
            logger.error("    ** Invalid Addresses");
            for (int i = 0; i < invalid.length; i++) {
              logger.error("           " + invalid[i]);
            }
          }
          Address[] validUnsent = sfex.getValidUnsentAddresses();
          if (validUnsent != null) {
            logger.error("    ** ValidUnsent Addresses");
            for (int i = 0; i < validUnsent.length; i++) {
              logger.error("           " + validUnsent[i]);
            }
          }

        }
        if (ex instanceof AuthenticationFailedException) {
          AuthenticationFailedException afex = (AuthenticationFailedException) ex;
          logger.error(afex.toString());
        }
        if (ex instanceof MessagingException) {
          ex = ((MessagingException) ex).getNextException();
        } else {
          ex = null;
        }
        throw new ServiceApplicationException("Sending Verify Code has failed. "
            + "Double check the email address, ensure the network is working fine "
            + "and the Destination named VERIFY_INTERNAL_EMAIL is correctly configured");
      } while (ex != null);
    }
  }

}
