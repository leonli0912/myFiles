/**
 * 
 */
package com.sap.hcm.resume.collection.annotation;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;


/**
 * profile attribute for datamodel builder
 * @author i065831
 *
 */
@Target({ java.lang.annotation.ElementType.FIELD })
@Retention(RetentionPolicy.RUNTIME)
public @interface ProfileAttribute {
	
	String name() default "";
	
	Class<?> type();
	
	String label() default "";
	
}
