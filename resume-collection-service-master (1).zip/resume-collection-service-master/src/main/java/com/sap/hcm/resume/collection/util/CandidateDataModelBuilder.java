package com.sap.hcm.resume.collection.util;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import org.springframework.util.StringUtils;

import com.sap.hcm.resume.collection.annotation.ExtendedProfile;
import com.sap.hcm.resume.collection.annotation.ProfileAttribute;
import com.sap.hcm.resume.collection.annotation.ProfileBackground;
import com.sap.hcm.resume.collection.bean.CandidateAttribute;
import com.sap.hcm.resume.collection.bean.CandidateComplexAttribute;
import com.sap.hcm.resume.collection.bean.CandidateProfileModel;
import com.sap.hcm.resume.collection.entity.CandidateProfile;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;

/**
 * candidate datamodel builder, responsible to build candidate profile data model 
 * @author i065831
 *
 */
public class CandidateDataModelBuilder {

	private static CandidateDataModelBuilder instance = new CandidateDataModelBuilder();

	public static CandidateDataModelBuilder getInstance() {
		return instance;
	}

	public CandidateProfileModel build() {

		List<CandidateAttribute> attributeList = new ArrayList<CandidateAttribute>();
		Class<CandidateProfileVO> sourceClaz = CandidateProfileVO.class;

		// parse general profile attribute
		this.parseComplexType(attributeList, CandidateProfile.class, false);

		Field[] fields = sourceClaz.getDeclaredFields();
		for (Field field : fields) {
			ExtendedProfile profileAnno = field.getAnnotation(ExtendedProfile.class);
			if (profileAnno != null) {
				this.parseComplexType(attributeList, profileAnno.type(), true);
			}
			
			ProfileBackground backgroundAnno = field.getAnnotation(ProfileBackground.class);
			
			if(backgroundAnno != null){
				List<CandidateAttribute> subAttributeList = new ArrayList<CandidateAttribute>();
				this.parseComplexType(subAttributeList, backgroundAnno.type(), false);
				CandidateComplexAttribute backgroundAttr = new CandidateComplexAttribute();
				backgroundAttr.setIsExt(false);
				backgroundAttr.setType("complex");
				backgroundAttr.setSubAttributes(subAttributeList);
				backgroundAttr.setName(field.getName());
				attributeList.add(backgroundAttr);
			}
		}
		CandidateProfileModel model = new CandidateProfileModel();
		model.setAttributes(attributeList);
		return model;
	}
	
	private void parseComplexType(List<CandidateAttribute> attrList, Class<?> profileClass, Boolean isExt) {
		Field[] fields = profileClass.getDeclaredFields();
		for (Field field : fields) {

			ProfileAttribute profileAttr = field.getAnnotation(ProfileAttribute.class);
			if (profileAttr != null) {
				String attrName = profileAttr.name();
				if (StringUtils.isEmpty(profileAttr.name())) {
					attrName = field.getName();
				}
				CandidateAttribute attr = new CandidateAttribute();
				attr.setName(attrName);
				attr.setType(profileAttr.type().getSimpleName().toLowerCase());
				attr.setIsExt(isExt);
				attr.setLabel(profileAttr.label());
				
				attrList.add(attr);
			}

		}
	}
}
