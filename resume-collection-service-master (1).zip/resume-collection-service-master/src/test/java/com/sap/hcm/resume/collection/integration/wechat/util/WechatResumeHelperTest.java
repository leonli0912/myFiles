package com.sap.hcm.resume.collection.integration.wechat.util;

import static org.mockito.Mockito.spy;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.sap.hcm.resume.collection.context.TestContext;
import com.sap.hcm.resume.collection.context.WebAppContext;
import com.sap.hcm.resume.collection.entity.view.CandidateBgCertificateVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgEducationVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgFamilyVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgLanguageVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgWorkExprVO;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileExtVO;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { TestContext.class, WebAppContext.class })
public class WechatResumeHelperTest {

  private WechatResumeHelper wechatResumeHelper;
  
  private CandidateProfileVO profileVO;

  @Before
  public void setUp() {
    wechatResumeHelper = spy(new WechatResumeHelper());
    this.buildCandidateProfile();
  }
  
  private void buildCandidateProfile(){
    profileVO = new CandidateProfileVO();
    profileVO.setFirstName("ina");
    profileVO.setResidence("shanghai");
    profileVO.setPrimaryEmail("hhha@123.com");
    profileVO.setCellPhone("1234567890");
    CandidateBgWorkExprVO candidateBgWorkExprVO = new CandidateBgWorkExprVO();
    candidateBgWorkExprVO.setDescription("workExpr");
    List<CandidateBgWorkExprVO> workExprs = new ArrayList<CandidateBgWorkExprVO>();
    CandidateBgWorkExprVO workExpr = new CandidateBgWorkExprVO();
    workExprs.add(workExpr);
    workExpr.setEmployer("CDP");
    workExpr.setBusinessType("工程师");
    workExpr.setDepartment("HR");
    workExpr.setJobTitle("hrbp");
    workExprs.add(candidateBgWorkExprVO);
    profileVO.setWorkExprs(workExprs);
    CandidateBgLanguageVO candidateBgLanguageVO = new CandidateBgLanguageVO();
    candidateBgLanguageVO.setName("English");
    candidateBgLanguageVO.setReadingProf("1");
    candidateBgLanguageVO.setSpeakingProf("2");
    candidateBgLanguageVO.setWritingProf("3");
    List<CandidateBgLanguageVO> languages = new ArrayList<CandidateBgLanguageVO>();
    languages.add(candidateBgLanguageVO);
    profileVO.setLanguages(languages);
    CandidateBgEducationVO candidateBgEducationVO = new CandidateBgEducationVO();
    candidateBgEducationVO.setSchool("Uni");
    List<CandidateBgEducationVO> educations = new ArrayList<CandidateBgEducationVO>();
    educations.add(candidateBgEducationVO);
    profileVO.setEducation(educations);
    CandidateBgCertificateVO candidateBgCertificateVO = new CandidateBgCertificateVO();
    candidateBgCertificateVO.setDescription("certificate");
    List<CandidateBgCertificateVO> certificates = new ArrayList<CandidateBgCertificateVO>();
    certificates.add(candidateBgCertificateVO);
    profileVO.setCertificates(certificates);
    CandidateBgFamilyVO candidateBgFamilyVO = new CandidateBgFamilyVO();
    candidateBgFamilyVO.setName("father");
    List<CandidateBgFamilyVO> families = new ArrayList<CandidateBgFamilyVO>();
    families.add(candidateBgFamilyVO);
    profileVO.setFamilies(families);
  }

  @Test
  public void testGenerateResumePDF() throws IOException {
    CandidateProfileExtVO extProfile = profileVO.getExtProfile();
    extProfile.setAttachment(wechatResumeHelper.generateResumePDF(profileVO));
    Assert.assertNotEquals(null, extProfile.getAttachment());
  }
}
