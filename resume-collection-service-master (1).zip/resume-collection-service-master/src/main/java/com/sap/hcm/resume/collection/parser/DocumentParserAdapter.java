package com.sap.hcm.resume.collection.parser;

import com.sap.hcm.resume.collection.bean.ResumeInfo;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;

public class DocumentParserAdapter {

  HTMLDocumentParser htmlParser;

  TextDocumentParser textParser;

  public DocumentParserAdapter(HTMLDocumentParser htmlParser, TextDocumentParser textParser) {
    this.htmlParser = htmlParser;
    this.textParser = textParser;
  }

  public CandidateProfileVO parseProfile(CandidateProfileVO candidateProfileVO, ResumeInfo resumeInfo)
      throws ServiceApplicationException {
    if (htmlParser != null) {
      return htmlParser.parseProfile(candidateProfileVO, resumeInfo.getHtmlDocument());
    } else {
      if (textParser != null) {
        return textParser.parseProfile(candidateProfileVO, resumeInfo.getTextContent());
      }
    }
    throw new ServiceApplicationException("parser not found");
  }

  /*
   * (non-Javadoc)
   * 
   * @see
   * com.sap.hcm.resume.collection.parser.DocumentParser#parseBackgroundWorkExp(
   * com.sap.hcm.resume.collection.entity.view.CandidateProfileVO,
   * org.jsoup.nodes.Document)
   */
  public CandidateProfileVO parseBackgroundWorkExp(CandidateProfileVO candidateProfileVO, ResumeInfo resumeInfo)
      throws ServiceApplicationException {
    if (htmlParser != null) {
      return htmlParser.parseBackgroundWorkExp(candidateProfileVO, resumeInfo.getHtmlDocument());
    } else {
      if (textParser != null) {
        return textParser.parseBackgroundWorkExp(candidateProfileVO, resumeInfo.getTextContent());
      }
    }
    throw new ServiceApplicationException("parser not found");
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.sap.hcm.resume.collection.parser.DocumentParser#
   * parseBackgroundEducation(com.sap.hcm.resume.collection.entity.view.
   * CandidateProfileVO, org.jsoup.nodes.Document)
   */
  public CandidateProfileVO parseBackgroundEducation(CandidateProfileVO candidateProfileVO, ResumeInfo resumeInfo)
      throws ServiceApplicationException {
    if (htmlParser != null) {
      return htmlParser.parseBackgroundEducation(candidateProfileVO, resumeInfo.getHtmlDocument());
    } else {
      if (textParser != null) {
        return textParser.parseBackgroundEducation(candidateProfileVO, resumeInfo.getTextContent());
      }
    }
    throw new ServiceApplicationException("parser not found");
  }

  /*
   * (non-Javadoc)
   * 
   * @see
   * com.sap.hcm.resume.collection.parser.DocumentParser#parseBackgroundLanguage
   * (com.sap.hcm.resume.collection.entity.view.CandidateProfileVO,
   * org.jsoup.nodes.Document)
   */
  public CandidateProfileVO parseBackgroundLanguage(CandidateProfileVO candidateProfileVO, ResumeInfo resumeInfo)
      throws ServiceApplicationException {
    if (htmlParser != null) {
      return htmlParser.parseBackgroundLanguage(candidateProfileVO, resumeInfo.getHtmlDocument());
    } else {
      if (textParser != null) {
        return textParser.parseBackgroundLanguage(candidateProfileVO, resumeInfo.getTextContent());
      }
    }
    throw new ServiceApplicationException("parser not found");
  }

  /*
   * (non-Javadoc)
   * 
   * @see com.sap.hcm.resume.collection.parser.DocumentParser#
   * parseBackgroundCertificate(com.sap.hcm.resume.collection.entity.view.
   * CandidateProfileVO, org.jsoup.nodes.Document)
   */
  public CandidateProfileVO parseBackgroundCertificate(CandidateProfileVO candidateProfileVO, ResumeInfo resumeInfo)
      throws ServiceApplicationException {
    if (htmlParser != null) {
      return htmlParser.parseBackgroundCertificate(candidateProfileVO, resumeInfo.getHtmlDocument());
    } else {
      if (textParser != null) {
        return textParser.parseBackgroundCertificate(candidateProfileVO, resumeInfo.getTextContent());
      }
    }
    throw new ServiceApplicationException("parser not found");
  }

}
