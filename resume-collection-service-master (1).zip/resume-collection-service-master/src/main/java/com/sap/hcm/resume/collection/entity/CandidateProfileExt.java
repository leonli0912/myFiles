package com.sap.hcm.resume.collection.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

/**
 * Candidate profile extension table
 * @author i065831
 *
 */
@Entity
@IdClass(CandProExtID.class)
@Table(name = "CANDIDATE_PROFILE_EXT")
public class CandidateProfileExt implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -6414498250356556125L;
	
	@Id
	@Column(name = "candidate_id")
	private Long candidateId;
	
	@Id
	@Column(name = "param_name", length = 50)
	private String paramName;
	
    @Column(name="company_id", length=100)
    private String companyId;

	@Column(name = "string_value", length = 200)
	private String stringValue;

	@Temporal(TemporalType.DATE)
	@Column(name = "date_value")
	private Date dateValue;

	@Lob
	@Column(name = "blob_value")
	private byte[] blobValue;


	/**
	 * @return the candiateId
	 */
	public Long getCandidateId() {
		return candidateId;
	}

	/**
	 * @param candiateId
	 *            the candiateId to set
	 */
	public void setCandidateId(Long candidateId) {
		this.candidateId = candidateId;
	}

	/**
	 * @return the paramName
	 */
	public String getParamName() {
		return paramName;
	}

	/**
	 * @param paramName
	 *            the paramName to set
	 */
	public void setParamName(String paramName) {
		this.paramName = paramName;
	}

	/**
     * @return the companyId
     */
    public String getCompanyId() {
      return companyId;
    }
  
    /**
     * @param companyId the companyId to set
     */
    public void setCompanyId(String companyId) {
      this.companyId = companyId;
    }

  /**
	 * @return the stringValue
	 */
	public String getStringValue() {
		return stringValue;
	}

	/**
	 * @param stringValue
	 *            the stringValue to set
	 */
	public void setStringValue(String stringValue) {
		this.stringValue = stringValue;
	}

	/**
	 * @return the dateValue
	 */
	public Date getDateValue() {
		return dateValue;
	}

	/**
	 * @param dateValue
	 *            the dateValue to set
	 */
	public void setDateValue(Date dateValue) {
		this.dateValue = dateValue;
	}

	/**
	 * @return the blobValue
	 */
	public byte[] getBlobValue() {
		return blobValue;
	}

	/**
	 * @param blobValue
	 *            the blobValue to set
	 */
	public void setBlobValue(byte[] blobValue) {
		this.blobValue = blobValue;
	}

}
