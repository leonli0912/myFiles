package com.sap.hcm.resume.collection.integration.bean;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

@XStreamAlias("status-set-item")
public class DataMappingApplyStatus implements Serializable {

  /**
   * serialVersionUID
   */
  private static final long serialVersionUID = 7191354678557795149L;
  
  @XStreamAsAttribute
  private String statusSetId;
  
  @XStreamAsAttribute
  private String statusSetItemId;

  /**
   * @return the statusSetId
   */
  public String getStatusSetId() {
    return statusSetId;
  }

  /**
   * @param statusSetId the statusSetId to set
   */
  public void setStatusSetId(String statusSetId) {
    this.statusSetId = statusSetId;
  }

  /**
   * @return the statusSetItemId
   */
  public String getStatusSetItemId() {
    return statusSetItemId;
  }

  /**
   * @param statusSetItemId the statusSetItemId to set
   */
  public void setStatusSetItemId(String statusSetItemId) {
    this.statusSetItemId = statusSetItemId;
  }

}
