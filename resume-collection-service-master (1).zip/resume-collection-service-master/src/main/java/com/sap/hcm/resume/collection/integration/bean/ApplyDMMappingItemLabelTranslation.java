package com.sap.hcm.resume.collection.integration.bean;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("label-translation")
public class ApplyDMMappingItemLabelTranslation {
  
  private String languageKey;
  
  private String translation;

  /**
   * @return the languageKey
   */
  public String getLanguageKey() {
    return languageKey;
  }

  /**
   * @param languageKey the languageKey to set
   */
  public void setLanguageKey(String languageKey) {
    this.languageKey = languageKey;
  }

  /**
   * @return the translation
   */
  public String getTranslation() {
    return translation;
  }

  /**
   * @param translation the translation to set
   */
  public void setTranslation(String translation) {
    this.translation = translation;
  }
  
  
}
