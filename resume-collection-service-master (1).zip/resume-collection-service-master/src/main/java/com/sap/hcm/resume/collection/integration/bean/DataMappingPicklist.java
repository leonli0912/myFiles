package com.sap.hcm.resume.collection.integration.bean;

import java.io.Serializable;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

@XStreamAlias("picklist")
public class DataMappingPicklist implements Serializable{
    
    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = -4046249095308252166L;
    
    @XStreamAsAttribute
    private String id;
    
    @XStreamImplicit(itemFieldName="option")
    private List<DataMappingPicklistOption> options;
    
    private String other;

    public List<DataMappingPicklistOption> getOptions() {
        return options;
    }

    public void setOptions(List<DataMappingPicklistOption> options) {
        this.options = options;
    }

    public String getOther() {
        return other;
    }

    public void setOther(String other) {
        this.other = other;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
