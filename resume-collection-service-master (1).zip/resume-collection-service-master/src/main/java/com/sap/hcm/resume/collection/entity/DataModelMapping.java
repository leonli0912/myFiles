package com.sap.hcm.resume.collection.entity;

import java.nio.charset.StandardCharsets;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

/**
 * entity to store datamodel mapping
 * to replace the original UserCompanyMapping
 *
 * @author i065831
 *
 */
@Entity
@Table(name="DATA_MODEL_MAPPING")
@JsonIgnoreProperties(value={"mappingContent"})
public class DataModelMapping {
    
    @Id
    @Column(name = "MAPPING_ID")
    @GeneratedValue(strategy = GenerationType.TABLE, generator = "data_model_map_seq")
    @TableGenerator(initialValue = 1, table = "SEQUENCE", name = "data_model_map_seq", pkColumnName = "SEQ_NAME", 
                    valueColumnName = "SEQ_COUNT", pkColumnValue = "DATA_MODEL_MAP_PK", allocationSize = 1)
    private Long mappingId;
    
    @Column(name="MAPPING_NAME", length=100)
    private String mappingName;
    
    /**
     * e.g: candidate profile data model mapping
     * e.g: candidate data model mapping
     */
    @Column(name="MAPPING_TYPE", length=50)
    private String mappingType;
    
    @Column(name="COMPANY_ID", length=50)
    private String companyId;
    
    @Column(name="CREATE_BY", length=50)
    private String createBy;
    
    @Column(name="TARGET_SYSTEM", length=50)
    private String targetSystem;
    
    @Temporal(TemporalType.DATE)
    @Column(name="LAST_MODIFY")
    private Date lastmodify;
    
    @Lob
    @Column(name="MAPPING_CONTENT")
    @JsonIgnore
    private byte[] mappingContent;

    public Long getMappingId() {
        return mappingId;
    }

    public void setMappingId(Long mappingId) {
        this.mappingId = mappingId;
    }

    public String getMappingName() {
        return mappingName;
    }

    public void setMappingName(String mappingName) {
        this.mappingName = mappingName;
    }

    public String getMappingType() {
        return mappingType;
    }

    public void setMappingType(String mappingType) {
        this.mappingType = mappingType;
    }

    public String getCompanyId() {
        return companyId;
    }

    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public String getTargetSystem() {
        return targetSystem;
    }

    public void setTargetSystem(String targetSystem) {
        this.targetSystem = targetSystem;
    }

    public Date getLastmodify() {
        return lastmodify;
    }

    public void setLastmodify(Date lastmodify) {
        this.lastmodify = lastmodify;
    }

    public byte[] getMappingContent() {
        return mappingContent;
    }

    public void setMappingContent(byte[] mappingContent) {
        this.mappingContent = mappingContent;
    }
    
    public String toXML(){
      return new String(this.mappingContent, StandardCharsets.UTF_8);
    }
}
