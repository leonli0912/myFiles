package com.sap.hcm.resume.collection.integration.wechat.service;

import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Map;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.IOUtils;
import org.apache.http.client.ClientProtocolException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.entity.Photo;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.wechat.entity.OAuthAccessToken;
import com.sap.hcm.resume.collection.integration.wechat.entity.UserBascInfo;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatUser;
import com.sap.hcm.resume.collection.integration.wechat.util.WechatHelper;
import com.sap.hcm.resume.collection.service.CompanyInfoService;
import com.sap.hcm.resume.collection.service.PhotoService;
import com.sap.hcm.resume.collection.util.CandidateFileUtil;

@Service
public class WechatLoginService {

  @PersistenceContext
  private EntityManager entityManager;

  @Autowired
  CompanyInfoService companyInfoService;

  @Autowired
  private WechatHelper wechatHelper;

  @Autowired
  private PhotoService photoService;

  public final int WIDTH = 200;

  public final int HEIGHT = 200;

  public Map<String, String> getWechatJsAPIConfiguration(String companyId, String url, HttpServletRequest request)
      throws ServiceApplicationException, IOException {
    CompanyInfo companyInfo = companyInfoService.getCompanyInfo(companyId);
    String access_token = wechatHelper.getAccessToken(companyId, WechatHelper.JS_TICKET_WECHAT_APP_ID,
        WechatHelper.JS_TICKET_WECHAT_APP_SECRET).getAccess_token();
    String jsapi_ticket = wechatHelper.getApiTicket(access_token);
    Map<String, String> result = wechatHelper.sign(jsapi_ticket, url);

    /*
     * Persist the company logo to the server side, it will be used as the logo when specific job are hared to friends
     * through wechat
     */

    Long shareLogoId = companyInfo.getSharePicId();

    result.put("appId", WechatHelper.JS_TICKET_WECHAT_APP_ID);
    result.put("companyName", companyInfo.getCompanyName());
    if(shareLogoId != null){
      result.put("imageName", Long.toString(shareLogoId));
    }
    return result;
  }

  public String getLoginURL(String companyId, String redirectUrl) throws ServiceApplicationException {
    String encodedRedirectUrl;
    try {
      encodedRedirectUrl = URLEncoder.encode(redirectUrl + "/callback/" + companyId,
          StandardCharsets.UTF_8.displayName());
    } catch (UnsupportedEncodingException e) {
      throw new ServiceApplicationException("unsupported encoding: " + StandardCharsets.UTF_8.displayName());
    }
    String loginUrl = WechatHelper.OAUTH_LOGIN_URL.replace("%APPID%", WechatHelper.WECHAT_APP_ID).replace(
        "%REDIRECT_URI%", encodedRedirectUrl);
    return loginUrl;
  }

  public OAuthAccessToken getOAuthAccessToken(String code) {
    return wechatHelper.getOAuthAccessToken(code);
  }

  public WechatUser getUserInfo(String accessToken, String openId, WechatUser wechatUser)
      throws ServiceApplicationException {
    UserBascInfo userBascInfo = wechatHelper.getUserBascInfo(accessToken, openId);
    wechatUser.setNickname(userBascInfo.getNickname());
    URL portraitUrl = null;
    try {
      portraitUrl = new URL(userBascInfo.getHeadimgurl());
    } catch (MalformedURLException e) {
      throw new ServiceApplicationException("Error When get the Headimgurl.");
    }
    HttpURLConnection conn;
    try {
      conn = (HttpURLConnection) portraitUrl.openConnection();
      conn.setDoInput(true);
      conn.connect();
    } catch (IOException e) {
      throw new ServiceApplicationException("Error When connect to the Headimgurl.");
    }
    InputStream is = null;
    try {
      is = conn.getInputStream();
      byte[] portraitByte = CandidateFileUtil.cropImage(is, WIDTH, HEIGHT);
      Photo photo = new Photo();
      photo.setCategory("wechat_portrait");
      photo.setContent(portraitByte);
      photo = photoService.saveImg(photo);
      wechatUser.setPhotoId(photo.getPhotoId());
    } catch (IOException e) {
      throw new ServiceApplicationException("Error When get the Headimg.");
    }finally{
      IOUtils.closeQuietly(is);
    }
    return wechatUser;
  }

  public String getAccessToken(String companyId, String appId, String appSecret) throws ClientProtocolException,
      IOException {
    return wechatHelper.getAccessToken(companyId, appId, appSecret).getAccess_token();
  }

  public String createMenu(String token, String menuString) {
    return wechatHelper.createMenu(token, menuString);
  }
}
