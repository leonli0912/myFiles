sap.ui.define([
               'static/wechat/js/layout/ResumeInputUtil',
               'sap/ui/core/mvc/Controller',
               'sap/m/MessageBox',
               'sap/m/MessageStrip'
             ], function(ResumeInputUtil,Controller,MessageBox,MessageStrip){
	"use strict";
	var candidatePreview = Controller.extend("static.wechat.js.layout.candidatePreview", {
		_router : null,
		   _candidateId : null,
		   _jobId: null,
		   _mapping: [],
		   _inputs: [],
		   _profileLan: null,

		/**
		* Called when a controller is instantiated and its View controls (if available) are already created.
		* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		* @memberOf resume-collection-service.candidatePreview
		*/
			onInit: function() {

				this._router = sap.ui.core.UIComponent.getRouterFor(this);
				var that = this;

				this._router.getRoute("candidatePreview").attachPatternMatched(function(oEvent){

	        if(sap.ui.getCore().byId("msgStrip") != null){
	          sap.ui.getCore().byId("msgStrip").destroy();
	        }

          var resumeInputUtil = new ResumeInputUtil();

		      //process Data
					var query = oEvent.getParameter("arguments")['?query'];
					if(query && query.jobId) {
						that._jobId = query.jobId;
					}else{
						that._jobId = null;
					}
					if(query && query.profileLan){
						that._profileLan = query.profileLan;
					}
					that._candidateId = oEvent.getParameter("arguments").candidateId;
					if(that._candidateId){
						var lanModel = new sap.ui.model.resource.ResourceModel({bundleName:"static.i18n.i18n",bundleLocale:that._profileLan});
						that.getView().setModel(lanModel, "pi18n");
			var pickListModel = new sap.ui.model.json.JSONModel();
			pickListModel.loadData("cv/picklists?locale="+that._profileLan, null, false);
			that.getView().setModel(pickListModel, "picklistModel");
            var oModel = resumeInputUtil.getCandidateData(that._candidateId);
						that.getView().setModel(oModel);
			
			      //process UI update
			      that.processUIUpdate();
			      //after data is ready
					  //resumeInputUtil.buildPreviewPage(that.getView());

            var missingFieldModel = new sap.ui.model.json.JSONModel("cv/missingFields?candidateId=" + that._candidateId);
            missingFieldModel.attachRequestCompleted(function(){
              var missingData = missingFieldModel.getData();
              var missingFieldAtrr = [];
              if(missingData.missing && missingData.missing.length > 0){
                for(var idx in missingData.missing){
                  var fieldName = missingData.missing[idx];
                  fieldName = that.translatLabel(fieldName);
                  missingFieldAtrr.push(fieldName);
                }

                var requiredMessage = that.translatEnumLabel("ERROR_MSG_CANDIDATE_INPUT_EMPTY") + ": " + missingFieldAtrr.join(",");
                that.showMessageStrip(requiredMessage);
              }
            },that);
					};

					var oUserModel = new sap.ui.model.json.JSONModel("wechatuser/user");
					that.getView().setModel(oUserModel,"user");
				})

			},

      showMessageStrip : function(message){
        var oMsgStrip = new MessageStrip("msgStrip", {
    				text: message,
    				showCloseButton: true,
    				showIcon: true,
    				type: "Warning"
  			});
        this.getView().byId("headerPanel").addContent(oMsgStrip);
      },
	  
      processUIUpdate : function(){
		var oControler = this;
        var resumeInputUtil = new ResumeInputUtil();
        var mapping = resumeInputUtil.getFullDM();
        //process candidate profile part
        var profilePanel = this.getView().byId("profilePanel");
		profilePanel = resumeInputUtil.buildPreviewPage(oControler,profilePanel,mapping["profile"],"profile");
		
		var additionalFieldPanel = this.getView().byId("additionalFieldPanel");
		additionalFieldPanel.destroyContent();
		var oHbox = resumeInputUtil.buildGenericAdditionalFieldPreview();
		
		var oAdditionalFieldLayout = new sap.ui.layout.VerticalLayout({
			width:"100%"
		});
		oAdditionalFieldLayout.bindAggregation("content",{
			path:"/applyReqFieldList",
			template:oHbox
		});
		additionalFieldPanel.addContent(oAdditionalFieldLayout);

		var oData = this.getView().getModel().getData();
        //process background elements
        var uidata = [{uiId:"workExprsPanel", propName:"workExprs", titleData:"jobTitle" ,buttonName:"WorkExp"},
                      {uiId:"educationPanel", propName:"education", titleData:"school" ,buttonName:"Education"},
                      {uiId:"languagePanel", propName:"languages", titleData:"name" ,buttonName:"Language"},
                      {uiId:"certificatePanel", propName:"certificates", titleData:"name" ,buttonName:"Certificate"},
                      {uiId:"familyPanel", propName:"families", titleData:"name" ,buttonName:"Family"}];
		for(var i=0;i<uidata.length;i++){
			if(!mapping[uidata[i].propName].ui_visible){
				var inVisiblePanel = this.getView().byId(uidata[i].uiId);
				inVisiblePanel.setVisible(false);
				inVisiblePanel.destroyHeaderToolbar();
				continue;
			}
			var oTitle = new sap.m.Title({
				text:{path:uidata[i].titleData, formatter:jQuery.proxy(oControler.formatPicklist,oControler)},
				titleStyle:"H5"
			});
			var oToolbarSpacer = new sap.m.ToolbarSpacer();
			var oButtonEdit = new sap.m.Button({
				type:"Transparent",
				icon:"sap-icon://edit"
			});
			oButtonEdit.attachPress(oControler["onEdit" + uidata[i].buttonName],oControler);
			var oButtonDelete = new sap.m.Button({
				type:"Transparent",
				icon:"sap-icon://delete"
			});
			oButtonDelete.attachPress(oControler["onDelete" + uidata[i].buttonName],oControler);
			var oToolBar = new sap.m.Toolbar();
			oToolBar.addContent(oTitle);
			oToolBar.addContent(oToolbarSpacer);
			oToolBar.addContent(oButtonEdit);
			oToolBar.addContent(oButtonDelete);
			var oPanel = new sap.m.Panel({
				width:"100%"
			});
			oPanel.setHeaderToolbar(oToolBar);
			oPanel = resumeInputUtil.buildPreviewPage(oControler,oPanel,mapping[uidata[i].propName],uidata[i].propName);
			var oVerticalLayout = new sap.ui.layout.VerticalLayout({
				width:"100%"
			});
			oVerticalLayout.bindAggregation("content",{
				path:"/"+uidata[i].propName,
				template:oPanel
			});

			var oButtonAdd = new sap.m.Button({
				width:"100%",
				text:"{pi18n>Add}"
			});
			oButtonAdd.attachPress(oControler["onEdit" + uidata[i].buttonName],oControler);
			var bgElementPanel = this.getView().byId(uidata[i].uiId);
			bgElementPanel.destroyContent();
			bgElementPanel.addContent(oVerticalLayout);
			bgElementPanel.addContent(oButtonAdd);
		}
      },

			onUpdateCandidate : function() {
				if(this._jobId) {
					this._router.navTo("candidateInput",{candidateId:this._candidateId, query:{jobId:this._jobId,profileLan:this._profileLan}});
				}else{
					this._router.navTo("candidateInput",{candidateId:this._candidateId, query:{profileLan:this._profileLan}});
				}
			},

			setEmailContentVisible: function(val){
				if(!val || val == "@" || val == "@null"){
					return false;
				}
				return true;
			},

			onEditWorkExp : function(oEvent) {

				var rowNo = -1;

				if (oEvent.getSource().getBindingContext()) {
					var rowId = oEvent.getSource().getBindingContext().getPath();
					var rows = rowId.match(/\d+/g);
					rowNo = rows[rows.length - 1];
				}
				if(this._jobId) {
					this._router.navTo("candidateWorkExpInput",{candidateId:this._candidateId, workExpId:rowNo, query:{jobId:this._jobId,profileLan:this._profileLan}});
				}else{
					this._router.navTo("candidateWorkExpInput",{candidateId:this._candidateId, workExpId:rowNo,query:{profileLan:this._profileLan}});
				}
			},

			onDeleteWorkExp : function(oEvent) {
				this.onDeleteBgElement(oEvent, "workExprs",this.translatEnumLabel('DELETEMSG'));
			},

			onDeleteBgElement : function(oEvent, elementType, msg) {

				var rowNo = null;
				var that = this;
				if (oEvent.getSource().getBindingContext()) {
					var bindContext = oEvent.getSource().getBindingContext();
					var rowId = bindContext.getPath();
					var rows = rowId.match(/\d+/g);
					rowNo = rows[rows.length - 1];
				}
				if(!rowNo){
					return;
				}

				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			    sap.m.MessageBox.confirm(
			    	msg,
			    	{
			    		styleClass: bCompact? "sapUiSizeCompact" : "",
			    		onClose:function(action){
			    			if(action == "OK"){
			    				var cfg = {
									type : 'GET',
									dataType : 'json',
									contentType : 'application/json;charset=UTF-8'
								};
								cfg.url = "cv/deleteBgElement?candidateId=" + that._candidateId + "&elementType=" + elementType + "&rowNo="+rowNo;
							    $.ajax(cfg).success(function(rsp) {
							    	if(rsp && rsp.code == 0){
							    		var viewData = bindContext.getModel().getData();
							    		viewData[elementType].splice(rowNo, 1);
							    		that.getView().getModel().setData(viewData);
							    	}
							    });
			    			}
			    		}
			    	}
			    );
			},

			onEditEducation : function(oEvent) {

				var rowNo = -1;

				if (oEvent.getSource().getBindingContext()) {
					var rowId = oEvent.getSource().getBindingContext().getPath();
					var rows = rowId.match(/\d+/g);
					rowNo = rows[rows.length - 1];
				}
				if(this._jobId) {
				this._router.navTo("candidateEducationInput",{candidateId:this._candidateId, educId:rowNo, query:{jobId:this._jobId,profileLan:this._profileLan}});
				}else{
					this._router.navTo("candidateEducationInput",{candidateId:this._candidateId, educId:rowNo,query:{profileLan:this._profileLan}});
				}
			},

			onDeleteEducation : function(oEvent) {

				this.onDeleteBgElement(oEvent, "education",this.translatEnumLabel('DELETEMSG'));
			},

			onEditLanguage : function(oEvent) {

				var rowNo = -1;

				if (oEvent.getSource().getBindingContext()) {
					var rowId = oEvent.getSource().getBindingContext().getPath();
					var rows = rowId.match(/\d+/g);
					rowNo = rows[rows.length - 1];
				}
				if(this._jobId) {
					this._router.navTo("candidateLanguageInput",{candidateId:this._candidateId, langId:rowNo, query:{jobId:this._jobId,profileLan:this._profileLan}});
				}else{
					this._router.navTo("candidateLanguageInput",{candidateId:this._candidateId, langId:rowNo, query:{profileLan:this._profileLan}});
				}
			},

			onDeleteLanguage : function(oEvent) {
				this.onDeleteBgElement(oEvent, "languages",this.translatEnumLabel('DELETEMSG'));
			},

			onEditCertificate : function(oEvent) {

				var rowNo = -1;

				if (oEvent.getSource().getBindingContext()) {
					var rowId = oEvent.getSource().getBindingContext().getPath();
					var rows = rowId.match(/\d+/g);
					rowNo = rows[rows.length - 1];
				}
				if(this._jobId) {
					this._router.navTo("candidateCertificateInput",{candidateId:this._candidateId, certId:rowNo, query:{jobId:this._jobId,profileLan:this._profileLan}});
				}else{
					this._router.navTo("candidateCertificateInput",{candidateId:this._candidateId, certId:rowNo,query:{profileLan:this._profileLan}});
				}
			},

			onDeleteCertificate : function(oEvent) {
				this.onDeleteBgElement(oEvent, "certificates",this.translatEnumLabel('DELETEMSG'));
			},

			onEditFamily : function(oEvent) {

				var rowNo = -1;

				if (oEvent.getSource().getBindingContext()) {
					var rowId = oEvent.getSource().getBindingContext().getPath();
					var rows = rowId.match(/\d+/g);
					rowNo = rows[rows.length - 1];
				}
				if(this._jobId) {
					this._router.navTo("candidateFamilyInput",{candidateId:this._candidateId, famId:rowNo, query:{jobId:this._jobId,profileLan:this._profileLan}});
				}else {
					this._router.navTo("candidateFamilyInput",{candidateId:this._candidateId, famId:rowNo,query:{profileLan:this._profileLan}});
				}
			},

			onDeleteFamily : function(oEvent) {
				this.onDeleteBgElement(oEvent, "families",this.translatEnumLabel('DELETEMSG'));
			},

			translatEnumLabel:function(val){
				return this.getView().getModel("wi18n").getResourceBundle().getText(val);
			},

      translatLabel:function(val){
				return this.getView().getModel("i18n").getResourceBundle().getText(val);
			},

			onButtonPress : function() {

				if(this._jobId){
					this._router.navTo("candidateList", {query:{jobId:this._jobId}});
				}else{
					var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					this._router.navTo("candidateList");
				}
			},

			formatPhoto: function(photoId){
				if(photoId){
					return "wphoto/"+photoId;
				}else{
					return "static/img/photoNotAvailable.gif";
				}
			},

		/**
		* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		* (NOT before the first rendering! onInit() is used for that one!).
		* @memberOf resume-collection-service.candidatePreview
		*/
//			onBeforeRendering: function() {
		//
//			},

		/**
		* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		* This hook is the same one that SAPUI5 controls get after being rendered.
		* @memberOf resume-collection-service.candidatePreview
		*/
//			onAfterRendering: function() {
		//
//			},

		/**
		* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		* @memberOf resume-collection-service.candidatePreview
		*/
//			onExit: function() {
		//
//			}
	});
	return candidatePreview;
});
