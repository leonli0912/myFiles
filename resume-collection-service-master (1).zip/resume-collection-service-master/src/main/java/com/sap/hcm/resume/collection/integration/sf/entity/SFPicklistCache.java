package com.sap.hcm.resume.collection.integration.sf.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "SF_PICKLIST_CACHE")
public class SFPicklistCache {
    
    @Id
    @Column(name="COMPANY_ID", length=100)
    private String companyId;
    
    @Id
    @Column(name="PKL_NAME", length=100)
    private String pklName;
    
    @Id
    @Column(name="PKL_OPTION_ID")
    private Long pklOptionId;
    
    @Id
    @Column(name="LOCALE")
    private String locale;
    
    @Id
    @Column(name="ENTITY_TYPE", length=30)
    private String entityType;
    
    @Column(name="PKL_LABEL", length=200)
    private String pklLabel;
    
    /**
     * @return the companyId
     */
    public String getCompanyId() {
        return companyId;
    }

    /**
     * @param companyId the companyId to set
     */
    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    /**
     * @return the pklName
     */
    public String getPklName() {
        return pklName;
    }

    /**
     * @param pklName the pklName to set
     */
    public void setPklName(String pklName) {
        this.pklName = pklName;
    }

    /**
     * @return the pklOptionId
     */
    public Long getPklOptionId() {
        return pklOptionId;
    }

    /**
     * @param pklOptionId the pklOptionId to set
     */
    public void setPklOptionId(Long pklOptionId) {
        this.pklOptionId = pklOptionId;
    }

    /**
     * @return the locale
     */
    public String getLocale() {
        return locale;
    }

    /**
     * @param locale the locale to set
     */
    public void setLocale(String locale) {
        this.locale = locale;
    }

    /**
     * @return the pklLabel
     */
    public String getPklLabel() {
        return pklLabel;
    }

    /**
     * @param pklLabel the pklLabel to set
     */
    public void setPklLabel(String pklLabel) {
        this.pklLabel = pklLabel;
    }

    /**
     * @return the entityType
     */
    public String getEntityType() {
      return entityType;
    }

    /**
     * @param entityType the entityType to set
     */
    public void setEntityType(String entityType) {
      this.entityType = entityType;
    }
}
