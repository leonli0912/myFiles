package com.sap.hcm.resume.collection.integration.bean;

import org.junit.Assert;
import org.junit.Test;

import com.sap.hcm.resume.collection.entity.view.DummyClass;

public class DummyClassTest {
  
  @Test
  public void testInit(){
    DummyClass d = new DummyClass();
    Assert.assertNotNull(d);
  }
}
