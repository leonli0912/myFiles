package com.sap.hcm.resume.collection.bean;

public enum ActionType {
  
  ADD("Add"),
  DEL("Delete"),
  EDT("Edit");
  
  private String actionName;
  
  public String getActionName(){
    return actionName;
  }
  
  ActionType(String actionName){
    this.actionName = actionName;
  }
  
  public static ActionType fromActionName(String actionName){
    for(ActionType at : ActionType.values()){
      if(at.getActionName().equals(actionName)){
        return at;
      }
    }
    return null;
  }
}
