package com.sap.hcm.resume.collection.integration.wechat.controller;

import java.io.IOException;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sap.hcm.resume.collection.bean.CandidateVendorEnum;
import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.bean.ResumeInfo;
import com.sap.hcm.resume.collection.controller.ControllerBase;
import com.sap.hcm.resume.collection.entity.view.CandidateBgWorkExprVO;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileExtVO;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.factory.CandidateFactory;
import com.sap.hcm.resume.collection.integration.JobBoardProviderFactory;
import com.sap.hcm.resume.collection.integration.bean.ResumeDownloadBean;
import com.sap.hcm.resume.collection.integration.wechat.bean.WechatImportResult;
import com.sap.hcm.resume.collection.integration.wechat.bean.WechatImportResultWrapper;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatUser;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatUserResumeMapping;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatUserService;
import com.sap.hcm.resume.collection.integration.wechat.util.WechatResumeHelper;
import com.sap.hcm.resume.collection.parser.DocumentParserAdapter;
import com.sap.hcm.resume.collection.service.CandidateProfileService;
import com.sap.hcm.resume.collection.util.CandidateProfileHelper;

@Controller
@RequestMapping(value = "parse")
public class CandidateParserController extends ControllerBase {

  @Autowired
  private CandidateProfileService candidateProfileService;

  @Autowired
  private WechatUserService wechatUserService;

  @Autowired
  private WechatResumeHelper wechatResumeHelper;

  @Autowired
  private JobBoardProviderFactory jobBoardProviderFactory;

  @Autowired
  private MessageSource messageSource;
  
  @Autowired
  private CandidateProfileHelper candidateProfileHelper;
  
  @Autowired
  private Params params;

  /**
   * logger
   */
  private static final Logger logger = LoggerFactory.getLogger(CandidateParserController.class);

  @RequestMapping(value = "{vendor}/preLogin", method = RequestMethod.GET)
  public @ResponseBody Map<String, String> getPreLoginInfo(HttpServletRequest request,
      @PathVariable(value = "vendor") String vendor) throws Exception {

    Map<String, String> result = new HashMap<String, String>();
    jobBoardProviderFactory.getProvider(vendor).preLogin();
    result.put("result", "success");
    return result;
  }

  @RequestMapping(value = "{vendor}/verifyCode", method = RequestMethod.GET)
  public @ResponseBody void getVerifyCode(HttpServletRequest request, @PathVariable(value = "vendor") String vendor)
      throws Exception {
    jobBoardProviderFactory.getProvider(vendor).getVerifyCode(request);
  }

  @RequestMapping(value = "/verifyCodeImage", method = RequestMethod.GET)
  public @ResponseBody void getVerifyCodeImage(HttpServletRequest request, HttpServletResponse response)
      throws Exception {

    byte[] item = (byte[]) request.getSession().getAttribute("verifyCode");
    OutputStream ops = null;
    if (item != null) {
      try {
        response.setContentType("image/png");
        ops = response.getOutputStream();
        ops.write(item);
      } catch (Exception ex) {
        throw new IOException(ex.getMessage());
      } finally {
        IOUtils.closeQuietly(ops);
      }
    }
  }

  @RequestMapping(value = "/pr/{vendor}", method = RequestMethod.POST)
  public @ResponseBody WechatImportResultWrapper parseResume(HttpServletRequest request,
      @RequestParam("username") String username, @RequestParam("password") String password,
      @RequestParam(value = "captcha", required = false) String captcha, @RequestParam("vendor") String vendor,
      @RequestParam("dpcsAgreed") boolean dpcsAgreed) throws ServiceApplicationException {

    String userEmail = params.getUserEmail();
    String companyId = params.getCompanyId();

    WechatImportResultWrapper result = new WechatImportResultWrapper();

    List<ResumeDownloadBean> fileNameList = null;

    fileNameList = jobBoardProviderFactory.getProvider(vendor).getResume(request, username, password, captcha);

    int successCount = 0;
    int failureCount = 0;

    if (fileNameList != null && fileNameList.size() > 0) {
      for (ResumeDownloadBean rdb : fileNameList) {

        WechatImportResult singleResult = new WechatImportResult();
        boolean isAreadyExist = wechatUserService.checkResumeAlreadyImported(userEmail, companyId, vendor, rdb
            .getExternalResumeId(), rdb.getLocale().getLanguage(), CandidateVendorEnum.LIEPIN.toString()
            .equalsIgnoreCase(vendor) ? false : true);
        if (isAreadyExist) {
          failureCount++;
          singleResult.setCandidateId(null);
          singleResult.setMessage("resume already exist");
          singleResult.setStatus(-1);
          result.getFailure().add(singleResult);

          logger.debug(vendor + " resume with external id " + rdb.getExternalResumeId() + " already exist");
        } else {

          try {

            ResumeInfo resumeInfo = jobBoardProviderFactory.getProvider(vendor).getFileContent(rdb.getFileContent());
            DocumentParserAdapter parserAapter = CandidateFactory.getDocumentParserInstance(messageSource, vendor,
                rdb.getLocale());
            CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
            candidateProfileVO = parserAapter.parseProfile(candidateProfileVO, resumeInfo);
            // save resume content
            CandidateProfileExtVO extProfile = candidateProfileVO.getExtProfile();
            if (extProfile == null) {
              extProfile = new CandidateProfileExtVO();
            }

            candidateProfileVO = parserAapter.parseBackgroundWorkExp(candidateProfileVO, resumeInfo);

            candidateProfileVO = parserAapter.parseBackgroundEducation(candidateProfileVO, resumeInfo);
            candidateProfileVO = parserAapter.parseBackgroundLanguage(candidateProfileVO, resumeInfo);
            candidateProfileVO = parserAapter.parseBackgroundCertificate(candidateProfileVO, resumeInfo);
            extProfile.setAttachment(wechatResumeHelper.generateResumePDF(candidateProfileVO));
            extProfile.setResumeExtension("pdf");
            candidateProfileVO.setExtProfile(extProfile);
            candidateProfileVO.setCompanyId(companyId);
            
            candidateProfileHelper.fillPicklistOptions(candidateProfileVO,rdb.getLocale());
            candidateProfileVO = candidateProfileService.saveCandidateProfile(candidateProfileVO);

            WechatUserResumeMapping userResumeMapping = new WechatUserResumeMapping();
            userResumeMapping.setCandidateId(candidateProfileVO.getCandidateId());
            userResumeMapping.setWechatId(userEmail);
            userResumeMapping.setCompanyId(companyId);
            userResumeMapping.setLanguage(rdb.getLocale().getLanguage());
            userResumeMapping.setResumeName(getResumeName(candidateProfileVO));
            userResumeMapping.setExternalResumeId(rdb.getExternalResumeId());
            userResumeMapping.setVendorName(vendor);

            wechatUserService.saveUserResumeMapping(userResumeMapping);

            if (dpcsAgreed) {
              WechatUser wechatUser = wechatUserService.getUserInfoByEmail(userEmail, companyId);
              wechatUser.setDpcsAgreed(dpcsAgreed);
              wechatUserService.saveWechatUser(wechatUser);
            }

            successCount++;
            singleResult.setStatus(1);
            singleResult.setMessage("successfully imported");
            singleResult.setCandidateId(candidateProfileVO.getCandidateId());
            result.getSuccess().add(singleResult);
          } catch (Exception e) {
            failureCount++;
            singleResult.setStatus(0);
            singleResult.setMessage("parse resume from " + vendor + " failed");
            singleResult.setCandidateId(null);
            result.getFailure().add(singleResult);

            logger.error("parse resume from " + vendor + " failed with exception : " + e.getMessage());
          }
        }
      }
    }
    result.setFailureCount(failureCount);
    result.setSuccessCount(successCount);
    return result;

  }

  private String getResumeName(CandidateProfileVO profile) {
    String name = "";
    List<CandidateBgWorkExprVO> workExprs = profile.getWorkExprs();
    if (workExprs == null || workExprs.size() == 0) {
      name = "My Resume";
    } else {
      for (CandidateBgWorkExprVO expr : workExprs) {
        if (expr.getIsPresent()) {
          name = expr.getEmployer() + "-" + expr.getJobTitle();
          break;
        }
      }
      if (StringUtils.isEmpty(name)) {
        name = workExprs.get(0).getEmployer() + "-" + workExprs.get(0).getJobTitle();
      }
    }
    return name;
  }

}
