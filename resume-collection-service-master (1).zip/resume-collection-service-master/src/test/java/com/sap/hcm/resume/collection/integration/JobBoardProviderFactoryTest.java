package com.sap.hcm.resume.collection.integration;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;

import com.sap.hcm.resume.collection.context.TestContext;
import com.sap.hcm.resume.collection.context.WebAppContext;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.dajie.DajieProvider;
import com.sap.hcm.resume.collection.integration.job51.Job51Provider;
import com.sap.hcm.resume.collection.integration.liepin.LiepinProvider;
import com.sap.hcm.resume.collection.integration.zhilian.ZhilianProvider;

import static org.junit.Assert.*;
import static org.mockito.Mockito.spy;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { TestContext.class, WebAppContext.class })
public class JobBoardProviderFactoryTest {
	private JobBoardProviderFactory factory;
	private JobBoardBaseProvider dajieProvider;
	private JobBoardBaseProvider zhilianProvider;
	private JobBoardBaseProvider job51Provider;
	private JobBoardBaseProvider liepinProvider;
	
	@Before
	public void setUp(){
		factory = spy(new JobBoardProviderFactory());
		dajieProvider = Mockito.mock(DajieProvider.class);
		zhilianProvider = Mockito.mock(ZhilianProvider.class);
		job51Provider = Mockito.mock(Job51Provider.class);
		liepinProvider = Mockito.mock(LiepinProvider.class);
		ReflectionTestUtils.setField(factory,"dajieProvider", dajieProvider);
		ReflectionTestUtils.setField(factory, "job51Provider", job51Provider);
		ReflectionTestUtils.setField(factory, "zhilianProvider", zhilianProvider);
		ReflectionTestUtils.setField(factory, "liepinProvider", liepinProvider);
	}
	
	@Test
	public void testGetProvider_Dajie() throws ServiceApplicationException{
		JobBoardBaseProvider provider = factory.getProvider("DAJIE");
		assertTrue(provider instanceof DajieProvider);
	}
	
	@Test
	public void testGetProvider_Zhilian() throws ServiceApplicationException{
		JobBoardBaseProvider provider = factory.getProvider("JOB51");
		assertTrue(provider instanceof Job51Provider);
	}
	
	@Test
	public void testGetProvider_Job51() throws ServiceApplicationException{
		JobBoardBaseProvider provider = factory.getProvider("ZHILIAN");
		assertTrue(provider instanceof ZhilianProvider);
	}
	
	@Test
	public void testGetProvider_Liepin() throws ServiceApplicationException{
		JobBoardBaseProvider provider = factory.getProvider("LIEPIN");
		assertTrue(provider instanceof LiepinProvider);
	}
	
	@Test(expected=ServiceApplicationException.class)
	public void testGetProvider_Others() throws ServiceApplicationException{
		JobBoardBaseProvider provider = factory.getProvider("Ryan");
	}
}
