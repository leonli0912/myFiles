package com.sap.hcm.resume.collection.entity;

import javax.sql.DataSource;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;

public class ExceptionStatisticsTest {
  
  private DataSource dataSource;
  
  private ExceptionStatistics stat;
  
  @Before
  public void setup(){
    stat = new ExceptionStatistics();
    dataSource = Mockito.mock(DataSource.class);
    ReflectionTestUtils.setField(stat, "dataSource", dataSource);
    
    ExceptionStatistics.clearSFConnTimeoutCount();
    ExceptionStatistics.clearDBConnFailedCount();
  }
  
  @Test
  public void testUpdateSFConnTimeoutCount(){
    ExceptionStatistics.updateSFConnTimeoutCount();
    Assert.assertEquals(1, stat.getSFConnTimeoutCount()); 
  }
  
  @Test
  public void testRunStat(){
    stat.run();
    Assert.assertEquals(1, stat.getDBConnFailedCount()); 
  }
}
