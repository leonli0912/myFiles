package com.sap.hcm.resume.collection.bean;

import org.junit.Assert;
import org.junit.Test;

import com.sap.hcm.resume.collection.util.BeanTestUtil;

public class CollectionBeanTest {

  @Test
  public void testGetterSetter() {
    BeanTestUtil.registerBean4Test(CandidateAttribute.class);
    BeanTestUtil.registerBean4Test(CandidateComplexAttribute.class);
    BeanTestUtil.registerBean4Test(CandidateProfileModel.class);
    BeanTestUtil.registerBean4Test(CandidateVendor.class);
    BeanTestUtil.registerBean4Test(DropdownBean.class);
    BeanTestUtil.registerBean4Test(FileBean.class);
    BeanTestUtil.registerBean4Test(FilterListItem.class);
    BeanTestUtil.registerBean4Test(ImportResultBean.class);
    BeanTestUtil.registerBean4Test(ImportResultWrapper.class);
    BeanTestUtil.registerBean4Test(KeyLabelBean.class);
    BeanTestUtil.registerBean4Test(ResumeInfo.class);
    BeanTestUtil.registerBean4Test(SimpleJsonResponse.class);
    BeanTestUtil.registerBean4Test(BusinessEntityType.class);
    BeanTestUtil.registerBean4Test(Params.class);

    BeanTestUtil.processBeanTest();
  }

  @Test
  public void testResumeInfo() {
    ResumeInfo info = new ResumeInfo();
    info.setCharset("utf-8");
    Assert.assertEquals(info.getCharset(), "utf-8");
    
    info.setAttachment(null);
    Assert.assertEquals(null, info.getAttachment());
  }
}
