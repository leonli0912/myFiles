package com.sap.hcm.resume.collection.integration.sf.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.olingo.odata2.api.edm.Edm;
import org.apache.olingo.odata2.api.edm.EdmEntityType;
import org.apache.olingo.odata2.api.edm.EdmException;
import org.apache.olingo.odata2.api.edm.EdmSimpleTypeKind;
import org.apache.olingo.odata2.api.edm.FullQualifiedName;
import org.apache.olingo.odata2.api.edm.provider.EdmProvider;
import org.apache.olingo.odata2.api.edm.provider.EntityType;
import org.apache.olingo.odata2.api.edm.provider.NavigationProperty;
import org.apache.olingo.odata2.api.edm.provider.Property;
import org.apache.olingo.odata2.api.edm.provider.SimpleProperty;
import org.apache.olingo.odata2.api.exception.ODataException;
import org.apache.olingo.odata2.core.edm.provider.EdmEntityTypeImplProv;
import org.apache.olingo.odata2.core.edm.provider.EdmImplProv;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;

import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.sf.odata.SFAuthentication;
import com.sap.hcm.resume.collection.integration.sf.odata.SFODataService;



public class SFODataServiceTest {
  
  private SFODataService sFODataService;
  
  private SFAuthentication auth;
  
  private Map<String, Edm> cachedEdm = new HashMap<String, Edm>();
  
  private Params params;
  
  private Edm edm;
  
  private static final String NAME_SPACE = "SFOData";
  
  @Before
  public void setUp() {
    sFODataService = new SFODataService();
    
    params = new Params();
    params.setCompanyId("sap");
    params.setWechatOpenId("001");
    
    auth = Mockito.mock(SFAuthentication.class);
    
    ReflectionTestUtils.setField(sFODataService, "params", params);
    ReflectionTestUtils.setField(sFODataService, "auth", auth);
    
    //set one edm into edm cache in SFODataService
    edm = Mockito.mock(EdmImplProv.class);
    cachedEdm.put("sap", edm);
    ReflectionTestUtils.setField(sFODataService, "cachedEdm", cachedEdm);
    
  }
  
  @Test
  public void testGetEdmSuccess() throws ServiceApplicationException{
    Edm result = sFODataService.getEdm();
    Assert.assertNotNull(result);
  }
  
  @Test
  public void testGetNavigationProperties() throws ServiceApplicationException, ODataException{
    String entityName = "Candidate";
    
    EntityType entityType = new EntityType();
    entityType.setName(entityName);
    
    List<NavigationProperty> naviProps = new ArrayList<NavigationProperty>();
    NavigationProperty navi = new NavigationProperty();
    navi.setName("manager");
    naviProps.add(navi);
    entityType.setNavigationProperties(naviProps);
    
    EdmProvider edmProvider = Mockito.mock(EdmProvider.class);
    Mockito.when( ((EdmImplProv) edm).getEdmProvider()).thenReturn(edmProvider);
    Mockito.when(edmProvider.getEntityType(new FullQualifiedName(NAME_SPACE, "Candidate"))).thenReturn(entityType);
    
    List<NavigationProperty> result = sFODataService.getNaviProperties(entityName);
    Assert.assertEquals(result.size(), 1);
  }
  
  @Test
  public void testGetNavigationNames() throws EdmException, ServiceApplicationException{
    String entityName = "Candidate";
    
    EntityType entityType = new EntityType();
    entityType.setName(entityName);
    List<NavigationProperty> naviProps = new ArrayList<NavigationProperty>();
    NavigationProperty navi = new NavigationProperty();
    navi.setName("manager");
    naviProps.add(navi);
    entityType.setNavigationProperties(naviProps);
    
    
    EdmEntityType edmTntityType = new EdmEntityTypeImplProv((EdmImplProv) edm, entityType, NAME_SPACE);
    Mockito.when(edm.getEntityType(NAME_SPACE, entityName)).thenReturn(edmTntityType);
    
    List<String> result = sFODataService.getNaviPropertyNames(entityName);
    Assert.assertEquals(result.get(0), "manager");
  }
  
  @Test
  public void testGetPropertyType() throws ODataException, ServiceApplicationException{
    String entityName = "Candidate";
    
    EntityType entityType = new EntityType();
    entityType.setName(entityName);
    
    List<Property> props = new ArrayList<Property>();
    SimpleProperty prop = new SimpleProperty();
    prop.setName("firstName");
    prop.setType(EdmSimpleTypeKind.Double);
    props.add(prop);
    entityType.setProperties(props);
    
    EdmProvider edmProvider = Mockito.mock(EdmProvider.class);
    Mockito.when( ((EdmImplProv) edm).getEdmProvider()).thenReturn(edmProvider);
    Mockito.when(edmProvider.getEntityType(new FullQualifiedName(NAME_SPACE, "Candidate"))).thenReturn(entityType);
    
    EdmSimpleTypeKind type = sFODataService.getPropertyType("firstName", entityName);
    Assert.assertEquals(type, EdmSimpleTypeKind.Double);
  }
  

}
