package com.sap.hcm.resume.collection.entity;

import org.junit.Assert;
import org.junit.Test;

public class ChangeLogTest {
  
  @Test
  public void testGetterSetter(){
    ChangeLog cl = new ChangeLog();
    cl.setActionType("action");
    cl.setChangeAt("2016-01-01");
    cl.setChangeContent("content");
    cl.setChangedBy("test");
    cl.setChangeId(1L);
    cl.setCompanyId("sap");
    cl.setObjectId("object");
    cl.setObjectName("name");
    cl.setObjectType("object");
    
    
    Assert.assertEquals("action", cl.getActionType());
    Assert.assertEquals("2016-01-01", cl.getChangeAt());
    Assert.assertEquals("content", cl.getChangeContent());
    Assert.assertEquals("test", cl.getChangedBy());
    Assert.assertEquals("1", cl.getChangeId().toString());
    Assert.assertEquals("sap", cl.getCompanyId());
    Assert.assertEquals("object", cl.getObjectId());
    Assert.assertEquals("name", cl.getObjectName());
    Assert.assertEquals("object", cl.getObjectType());
   }
}
