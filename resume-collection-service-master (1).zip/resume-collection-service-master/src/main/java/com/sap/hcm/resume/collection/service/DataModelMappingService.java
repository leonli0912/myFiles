package com.sap.hcm.resume.collection.service;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.sap.hcm.resume.collection.bean.CandModelMappingTypeEnum;
import com.sap.hcm.resume.collection.bean.CandidateAttribute;
import com.sap.hcm.resume.collection.bean.CandidateComplexAttribute;
import com.sap.hcm.resume.collection.bean.CandidateProfileModel;
import com.sap.hcm.resume.collection.bean.JobRequisitionAttribute;
import com.sap.hcm.resume.collection.bean.JobRequisitionModel;
import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.bean.SimpleJsonResponse;
import com.sap.hcm.resume.collection.entity.DataModelMapping;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileConstants;
import com.sap.hcm.resume.collection.entity.view.JobApplyMappingVO;
import com.sap.hcm.resume.collection.entity.view.JobRequisitionMappingVO;
import com.sap.hcm.resume.collection.entity.view.UserCompanyMappingVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.bean.ApplyDataModelMappingItem;
import com.sap.hcm.resume.collection.integration.bean.CandProfileDataModelMapping;
import com.sap.hcm.resume.collection.integration.bean.DataMappingPkOptionMapping;
import com.sap.hcm.resume.collection.integration.bean.DataModelMappingItem;
import com.sap.hcm.resume.collection.integration.bean.JobReqDataModelMapping;
import com.sap.hcm.resume.collection.integration.bean.JobReqDataModelMappingItem;
import com.sap.hcm.resume.collection.integration.sf.bean.SFPicklist;
import com.sap.hcm.resume.collection.integration.sf.bean.SFPicklistCacheEntityType;
import com.sap.hcm.resume.collection.integration.sf.bean.SFPicklistItem;
import com.sap.hcm.resume.collection.integration.sf.bean.cdm.SFCDMConverter;
import com.sap.hcm.resume.collection.integration.sf.bean.cdm.SFCDMFieldDefinition;
import com.sap.hcm.resume.collection.integration.sf.bean.cdm.SFCDMSimple;
import com.sap.hcm.resume.collection.integration.sf.service.SFPicklistCacheService;
import com.sap.hcm.resume.collection.integration.sf.service.SFPicklistService;
import com.sap.hcm.resume.collection.integration.xml.DataModelMappingXMLConverter;
import com.sap.hcm.resume.collection.util.CandidateDataModelBuilder;
import com.sap.hcm.resume.collection.util.JobRequisitionModelBuilder;

@Service
public class DataModelMappingService {

  @Autowired
  private Params params;

  @Autowired
  private SFPicklistCacheService pkCacheService;

  @Autowired
  protected CompanyInfoService compInfoService;

  @Autowired
  private SFPicklistService sfPicklistService;

  /**
   * logger instance
   */
  private Logger logger = LoggerFactory.getLogger(DataModelMappingService.class);

  @PersistenceContext
  private EntityManager entityManager;

  public List<DataModelMapping> getMappingList(int skip, int top, String companyId) {

    TypedQuery<DataModelMapping> query = entityManager.createQuery(
        "select rel from DataModelMapping rel where rel.companyId = :companyId and rel.mappingType = :mappingType",
        DataModelMapping.class);
    query.setFirstResult(skip);
    query.setMaxResults(top);
    if (!StringUtils.isEmpty(companyId)) {
      query.setParameter("companyId", companyId);
      query.setParameter("mappingType", CandModelMappingTypeEnum.CAND_PROFILE_MAPPING.getLabelKey());
    }
    List<DataModelMapping> relList = query.getResultList();
    return relList;
  }

  public DataModelMapping getMappingListDetail(Long mappingId, String companyId) {
    Query query = entityManager
        .createQuery("select rel from DataModelMapping rel where rel.companyId = :companyId and rel.mappingId = :mapId");
    if (!StringUtils.isEmpty(companyId)) {
      query.setParameter("companyId", companyId);
    }
    if (mappingId != null) {
      query.setParameter("mapId", mappingId);
    }
    DataModelMapping mappingEO = (DataModelMapping) query.getSingleResult();
    return mappingEO;
  }

  public DataModelMapping getMappingById(Long mappingId) throws ServiceApplicationException {
    return entityManager.find(DataModelMapping.class, mappingId);
  }

  public int deleteMappingById(Long mappingId) {
    int res = -1;
    try {
      DataModelMapping mapping = entityManager.find(DataModelMapping.class, mappingId);
      if (mapping != null) {
        entityManager.remove(mapping);
      }
      res = 1;
    } catch (PersistenceException e) {
      res = -1;
    }
    return res;
  }

  public CandProfileDataModelMapping getCandidateProfileDataModelMappingById(Long mappingId)
      throws ServiceApplicationException {

    DataModelMapping mapping = this.getMappingById(mappingId);
    if (mapping != null) {
      CandProfileDataModelMapping dbMapping = DataModelMappingXMLConverter.fromXML(mapping.toXML());
      return dbMapping;
    }
    return null;
  }

  public DataModelMapping saveDataModelMapping(String user, UserCompanyMappingVO sysMapping, String companyId) {

    DataModelMapping mapping = new DataModelMapping();
    if (sysMapping.getId() != null) {
      mapping = entityManager.find(DataModelMapping.class, sysMapping.getId());
    }
    mapping.setMappingId(sysMapping.getId());
    mapping.setCreateBy(user);
    mapping.setLastmodify(new Date());
    mapping.setTargetSystem(sysMapping.getTargetSystem());
    mapping.setMappingName(sysMapping.getMappingName());
    mapping.setCompanyId(companyId);
    mapping.setMappingContent(DataModelMappingXMLConverter.toXML(sysMapping.getMapping()).getBytes(
        StandardCharsets.UTF_8));
    mapping.setMappingType(CandModelMappingTypeEnum.CAND_PROFILE_MAPPING.getLabelKey());
    return entityManager.merge(mapping);
  }

  public CandProfileDataModelMapping createEmptyMapping() {
    CandidateProfileModel model = CandidateDataModelBuilder.getInstance().build();
    CandProfileDataModelMapping mapping = new CandProfileDataModelMapping();
    DataModelMappingItem item = null;
    List<CandidateAttribute> attrList = model.getAttributes();
    SortedSet<DataModelMappingItem> profileItemSet = new TreeSet<DataModelMappingItem>();
    Map<String, String> aliasMap = new HashMap<String, String>();
    int index = 0;
    for (CandidateAttribute attr : attrList) {
      if (!attr.getType().equals("complex")) {
        if (attr.getName().equals("candidateId")) {
          continue;
        }
        item = new DataModelMappingItem();
        item.setFrom(attr.getName());
        item.setTo(attr.getName());
        item.setLabel(attr.getLabel());
        item.setSeq(index++);
        profileItemSet.add(item);
      } else {
        if (CandidateProfileConstants.BG_WORKEXPR_NAME.equals(attr.getName())) {
          mapping.setWorkExprs(this.convertAttributeSet(((CandidateComplexAttribute) attr).getSubAttributes()));
        }
        if (CandidateProfileConstants.BG_LANGU_NAME.equals(attr.getName())) {
          mapping.setLanguages(this.convertAttributeSet(((CandidateComplexAttribute) attr).getSubAttributes()));
        }
        if (CandidateProfileConstants.BG_EDUC_NAME.equals(attr.getName())) {
          mapping.setEducation(this.convertAttributeSet(((CandidateComplexAttribute) attr).getSubAttributes()));
        }
        if (CandidateProfileConstants.BG_CERT_NAME.equals(attr.getName())) {
          mapping.setCertificates(this.convertAttributeSet(((CandidateComplexAttribute) attr).getSubAttributes()));
        }
        if (CandidateProfileConstants.BG_FAMI_NAME.equals(attr.getName())) {
          mapping.setFamilies(this.convertAttributeSet(((CandidateComplexAttribute) attr).getSubAttributes()));
        }
        aliasMap.put(attr.getName(), null);
      }
    }
    mapping.setProfile(profileItemSet);
    mapping.setAliases(aliasMap);
    return mapping;
  }

  private SortedSet<DataModelMappingItem> convertAttributeSet(List<CandidateAttribute> attrList) {
    SortedSet<DataModelMappingItem> itemSet = new TreeSet<DataModelMappingItem>();
    DataModelMappingItem item = null;
    int index = 0;
    for (CandidateAttribute attr : attrList) {
      item = new DataModelMappingItem();
      item.setFrom(attr.getName());
      item.setTo(attr.getName());
      item.setLabel(attr.getLabel());
      item.setSeq(index++);
      itemSet.add(item);
    }
    return itemSet;
  }

  public List<ApplyDataModelMappingItem> loadNewApplyDataModelMapping(byte[] fileContent) {

    SFCDMSimple simple = SFCDMConverter.fromXMLByFile(fileContent);
    List<SFCDMFieldDefinition> fieldDefinitionList = simple.getFieldDefinition();

    List<ApplyDataModelMappingItem> itemList = new ArrayList<ApplyDataModelMappingItem>();
    ApplyDataModelMappingItem item = null;
    for (SFCDMFieldDefinition fieldDefinition : fieldDefinitionList) {
      item = new ApplyDataModelMappingItem();
      item.setSfDmField(fieldDefinition.id);
      item.setRequired(fieldDefinition.required);
      item.setPicklist(fieldDefinition.picklistId);
      item.setDisplayDefaultValue(true);
      item.setDisplaySourceName(true);
      item.setSourceNameType("selectFromCandidateProfile");
      item.setLabel(item.getSourceField());
      itemList.add(item);
    }
    return itemList;
  }

  public JobApplyMappingVO getApplyDataModelMappingByCompanyId(String companyId) {
    JobApplyMappingVO jobApplyMappingVO = new JobApplyMappingVO();
    Query query = entityManager
        .createQuery("select rel from DataModelMapping rel where rel.companyId = :companyId and rel.mappingType = :mappingType");
    if (companyId != null) {
      query.setParameter("companyId", companyId);
    }
    query.setParameter("mappingType", CandModelMappingTypeEnum.CAND_DM_MAPPING.getLabelKey());
    try {
      DataModelMapping applyDm = (DataModelMapping) query.getSingleResult();
      jobApplyMappingVO.setCreateBy(applyDm.getCreateBy());
      jobApplyMappingVO.setId(applyDm.getMappingId());
      jobApplyMappingVO.setItemList(SFCDMConverter.fromXMLByString(applyDm.toXML()));
      jobApplyMappingVO.setMappingName(applyDm.getMappingName());
      jobApplyMappingVO.setTargetSystem(applyDm.getTargetSystem());
    } catch (NoResultException e) {
      System.out.println("Mapping not found.");
    }

    return jobApplyMappingVO;
  }

  public DataModelMapping getApplyDataModelMappingByMappingId(Long mappingId) throws ServiceApplicationException {
    return entityManager.find(DataModelMapping.class, mappingId);
  }

  public DataModelMapping saveApplyDataModelMapping(JobApplyMappingVO jobMapping, String companyId) {
    DataModelMapping applyMapping = new DataModelMapping();
    if (jobMapping.getId() != null) {
      applyMapping = entityManager.find(DataModelMapping.class, jobMapping.getId());
    }
    applyMapping.setMappingId(jobMapping.getId());
    applyMapping.setCompanyId(companyId);
    applyMapping.setCreateBy(jobMapping.getCreateBy());
    applyMapping.setLastmodify(new Date());
    applyMapping.setMappingContent(SFCDMConverter.toXML(jobMapping.getItemList()).getBytes(StandardCharsets.UTF_8));
    applyMapping.setMappingName(jobMapping.getMappingName());
    applyMapping.setMappingType(CandModelMappingTypeEnum.CAND_DM_MAPPING.getLabelKey());
    applyMapping.setTargetSystem(jobMapping.getTargetSystem());

    return entityManager.merge(applyMapping);
  }

  /**
   * create empty job requisition mapping
   * 
   * @return
   */
  public JobReqDataModelMapping createEmptyJobRequisitionMapping() {
    JobReqDataModelMapping mapping = new JobReqDataModelMapping();
    List<JobReqDataModelMappingItem> items = new ArrayList<JobReqDataModelMappingItem>();
    JobRequisitionModel model = JobRequisitionModelBuilder.getInstance().build();
    List<JobRequisitionAttribute> attrs = model.getAttributes();
    if (attrs != null && attrs.size() > 0) {
      for (JobRequisitionAttribute attr : attrs) {
        JobReqDataModelMappingItem item = new JobReqDataModelMappingItem();
        item.setSourceField(attr.getName());
        item.setFilterable(false);
        item.setLabel(attr.getLabel());
        item.setFilterable(attr.isFilterable());
        items.add(item);
      }
    }
    mapping.setItems(items);
    return mapping;
  }

  /**
   * @param mapping
   * @param companyId
   * @return
   */
  public DataModelMapping saveJobRequisitionMapping(JobRequisitionMappingVO mapping, String companyId) {
    DataModelMapping dmMapping = new DataModelMapping();
    dmMapping.setMappingId(mapping.getId());
    dmMapping.setCreateBy(mapping.getCreateBy());
    dmMapping.setLastmodify(new Date());
    dmMapping.setTargetSystem(mapping.getTargetSystem());
    dmMapping.setMappingName(mapping.getMappingName());
    dmMapping.setCompanyId(companyId);
    dmMapping.setMappingContent(mapping.getMapping().toXML().getBytes(StandardCharsets.UTF_8));
    dmMapping.setMappingType(CandModelMappingTypeEnum.JOB_REQ_MAPPING.getLabelKey());

    return entityManager.merge(dmMapping);

  }

  public List<DataModelMapping> listJobRequisitionMapping(String companyId, int skip, int top) {
    TypedQuery<DataModelMapping> query = entityManager.createQuery(
        "select mp from DataModelMapping mp where mp.companyId = :companyId and mp.mappingType = :mappingType",
        DataModelMapping.class);
    query.setFirstResult(skip);
    if (top > 0) {
      query.setMaxResults(top);
    }
    if (!StringUtils.isEmpty(companyId)) {
      query.setParameter("companyId", companyId);
    }
    query.setParameter("mappingType", CandModelMappingTypeEnum.JOB_REQ_MAPPING.getLabelKey());
    List<DataModelMapping> relList = query.getResultList();
    return relList;
  }

  public void deleteRequisitionMapping(Long mappingId) {
    // need add validation here !

    DataModelMapping dm = entityManager.find(DataModelMapping.class, mappingId);
    if (dm != null) {
      entityManager.remove(dm);
    }
  }

  /**
   * @param companyId
   * @param mappingId
   * @return
   */
  public JobRequisitionMappingVO getJobRequisitionMappingById(String companyId, Long mappingId) {
    JobRequisitionMappingVO vo = new JobRequisitionMappingVO();
    DataModelMapping dm = entityManager.find(DataModelMapping.class, mappingId);
    if (dm != null) {
      vo.setCreateBy(dm.getCreateBy());
      vo.setId(dm.getMappingId());
      vo.setMappingName(dm.getMappingName());
      vo.setTargetSystem(dm.getTargetSystem());
      if (dm.getMappingContent() != null) {
        JobReqDataModelMapping mapping = JobReqDataModelMapping.fromXML(dm.toXML());
        vo.setMapping(mapping);
      }
    }
    return vo;
  }

  /**
   * get filterable picklist for job filtering
   * 
   * @param companyId
   * @return
   */
  public Set<JobReqDataModelMappingItem> getFilterablePicklistForJobRequisition(String companyId) {
    return this.getPicklistForJobRequisition(companyId, true);
  }

  /**
   * get all picklist for job filtering
   * 
   * @param companyId
   * @return
   */
  public Set<JobReqDataModelMappingItem> getPicklistForJobRequisition(String companyId, boolean filterableOnly) {
    Set<JobReqDataModelMappingItem> pickListSet = new HashSet<JobReqDataModelMappingItem>();
    List<DataModelMapping> mappingList = this.listJobRequisitionMapping(companyId, 0, -1);
    if (mappingList != null && mappingList.size() > 0) {
      for (DataModelMapping dataModelMapping : mappingList) {
        byte[] content = dataModelMapping.getMappingContent();
        if (content != null) {
          JobReqDataModelMapping dm = JobReqDataModelMapping.fromXML(dataModelMapping.toXML());
          if (dm != null && dm.getItems() != null && dm.getItems().size() > 0) {
            for (JobReqDataModelMappingItem item : dm.getItems()) {
              if (filterableOnly) {
                // keep only filterable picklist
                if (!StringUtils.isEmpty(item.getPicklist()) && item.isFilterable()) {
                  pickListSet.add(item);
                }
              } else {
                if (!StringUtils.isEmpty(item.getPicklist())) {
                  pickListSet.add(item);
                }
              }
            }
          }
        }
      }
    }
    return pickListSet;
  }

  /**
   * get filterable fields for job requisition (including picklist and input field)
   * 
   * @param companyId
   * @return
   */
  public Set<JobReqDataModelMappingItem> getFilterableFieldsForJobRequisition(String companyId) {
    Set<JobReqDataModelMappingItem> fieldSet = new HashSet<JobReqDataModelMappingItem>();
    List<DataModelMapping> mappingList = this.listJobRequisitionMapping(companyId, 0, -1);
    if (mappingList != null && mappingList.size() > 0) {
      for (DataModelMapping dataModelMapping : mappingList) {
        byte[] content = dataModelMapping.getMappingContent();
        if (content != null) {
          JobReqDataModelMapping dm = JobReqDataModelMapping.fromXML(dataModelMapping.toXML());
          if (dm != null && dm.getItems() != null && dm.getItems().size() > 0) {
            for (JobReqDataModelMappingItem item : dm.getItems()) {
              if (!StringUtils.isEmpty(item.getSfDmField()) && item.isFilterable()) {
                fieldSet.add(item);
              }
            }
          }
        }
      }
    }

    return fieldSet;
  }

  public Set<ApplyDataModelMappingItem> getPicklistForJobApplication(String companyId)
      throws ServiceApplicationException {
    Set<ApplyDataModelMappingItem> pickListSet = new HashSet<ApplyDataModelMappingItem>();
    JobApplyMappingVO jobApplyMappingVO = this.getApplyDataModelMappingByCompanyId(companyId);
    if (jobApplyMappingVO == null) {
      throw new ServiceApplicationException("Get job application data model mapping failed");
    }
    if (jobApplyMappingVO.getItemList() != null) {
      for (ApplyDataModelMappingItem applyDataModelMappingItem : jobApplyMappingVO.getItemList()) {
        if (!StringUtils.isEmpty(applyDataModelMappingItem.getPicklist())) {
          pickListSet.add(applyDataModelMappingItem);
        }
      }
    }
    return pickListSet;
  }

  /**
   * @param mapping
   * @return
   * @throws ServiceApplicationException
   */
  public CandProfileDataModelMapping getProfileMapping(DataModelMapping mapping) throws ServiceApplicationException {
    CandProfileDataModelMapping dataModelMapping = null;
    if (mapping != null) {
      DataModelMapping userCompanyMapping = entityManager.find(DataModelMapping.class, mapping.getMappingId());
      if (userCompanyMapping == null) {
        String errorMsg = "data model mapping not found. companyId=%1$s, mappingName=%2$s, mappingId=%3$s";
        errorMsg = String.format(errorMsg, mapping.getCompanyId(), mapping.getMappingName(), mapping.getMappingId());
        logger.error(errorMsg);
        throw new ServiceApplicationException(errorMsg);
      }
      dataModelMapping = DataModelMappingXMLConverter.fromXML(userCompanyMapping.toXML());
      if (dataModelMapping == null) {
        logger.error("Parse mapping content to xml failed. mappingId: " + mapping.getMappingId());
        throw new ServiceApplicationException("Parse mapping content to xml failed. mappingId: "
            + mapping.getMappingId());
      }
    } else {
      logger.error("DataModelMapping is null");
      throw new ServiceApplicationException("DataModelMapping is null");
    }

    return dataModelMapping;
  }

  public SimpleJsonResponse renewCandidateProfilePicklistCache() throws ServiceApplicationException {
    // remove all picklist cache for a company
    String companyId = params.getCompanyId();
    if (companyId == null) {
      throw new ServiceApplicationException("company id is not supplied");
    }
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(0);
    rsp.setMessage("success");
    pkCacheService.deletePicklistCache(companyId, SFPicklistCacheEntityType.CANDIDATE.name());

    Long mappingId = compInfoService.getCompanyInfo(params.getCompanyId()).getDmMappingId();
    if (mappingId != null) {
      CandProfileDataModelMapping candMapping = this.getCandidateProfileDataModelMappingById(mappingId);
      List<SFPicklist> picklistSet = candMapping.picklists();
      if (picklistSet != null && picklistSet.size() > 0) {
        for (SFPicklist pkBean : picklistSet) {
          try {
            this.getPicklistFromSFAndSaveIt(pkBean.getPicklistName(), SFPicklistCacheEntityType.CANDIDATE);
          } catch (ServiceApplicationException e) {
            if (e.getCode() == 1) {
              continue;
            } else {
              rsp.setCode(-1);
              rsp.setMessage(e.getMessage());
            }
          }
        }
      }
    }

    return rsp;
  }

  public SimpleJsonResponse renewJobRequisitionPicklistCache() throws ServiceApplicationException {

    String companyId = params.getCompanyId();
    if (companyId == null) {
      throw new ServiceApplicationException("company id is not supplied");
    }
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(0);
    rsp.setMessage("success");

    // remove all picklist cache for a company
    pkCacheService.deletePicklistCache(companyId, SFPicklistCacheEntityType.JOB_REQUISITION.name());

    Set<JobReqDataModelMappingItem> picklistSet = this.getPicklistForJobRequisition(companyId, false);
    if (picklistSet != null && picklistSet.size() > 0) {
      for (JobReqDataModelMappingItem pkBean : picklistSet) {
        try {
          this.getPicklistFromSFAndSaveIt(pkBean.getPicklist(), SFPicklistCacheEntityType.JOB_REQUISITION);
        } catch (ServiceApplicationException e) {
          if (e.getCode() == 1) {
            continue;
          } else {
            rsp.setCode(-1);
            rsp.setMessage(e.getMessage());
          }
        }
      }
    }

    return rsp;
  }

  public SimpleJsonResponse renewJobApplicationPicklistCache() throws ServiceApplicationException {
    // remove all picklist cache for a JOB_APPLICATION
    String companyId = params.getCompanyId();
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(0);
    rsp.setMessage("success");
    pkCacheService.deletePicklistCache(companyId, SFPicklistCacheEntityType.JOB_APPLICATION.name());

    Set<ApplyDataModelMappingItem> picklistSet = this.getPicklistForJobApplication(companyId);
    if (picklistSet != null && picklistSet.size() > 0) {
      for (ApplyDataModelMappingItem pkBean : picklistSet) {
        try {
          this.getPicklistFromSFAndSaveIt(pkBean.getPicklist(), SFPicklistCacheEntityType.JOB_APPLICATION);
        } catch (ServiceApplicationException e) {
          if (e.getCode() == 1) {
            continue;
          } else {
            rsp.setCode(-1);
            rsp.setMessage(e.getMessage());
          }
        }
      }
    }

    return rsp;
  }

  private SimpleJsonResponse getPicklistFromSFAndSaveIt(String picklist, SFPicklistCacheEntityType type)
      throws ServiceApplicationException {
    List<SFPicklistItem> itemList = null;
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    try {
      itemList = sfPicklistService.loadPickListOption(picklist);
    } catch (Exception e1) {
      throw new ServiceApplicationException(1, "Load Picklist from SF failed with:" + picklist);
    }
    try {

      if (itemList != null && itemList.size() > 0) {
        int rcode = pkCacheService.savePickListCache(itemList, picklist, params.getCompanyId(), type.name());
        if (rcode < 0) {
          throw new ServiceApplicationException("failed to cache the picklist: " + picklist);
        }
      }
    } catch (Exception e) {
      // failed to load the picklist option
      throw new ServiceApplicationException("failed to cache the picklist: " + picklist);
    }
    return rsp;
  }

  /**
   * @param mappingId
   * @throws ServiceApplicationException
   */
  public DataMappingPkOptionMapping getPicklistOptionMappingFromCandProfMapping(Long mappingId)
      throws ServiceApplicationException {
    DataMappingPkOptionMapping picklistOptionMapping = null;
    CandProfileDataModelMapping profileMapping = this.getCandidateProfileDataModelMappingById(mappingId);
    if (profileMapping != null) {
      picklistOptionMapping = profileMapping.getPicklistOptionMapping();
    }
    return picklistOptionMapping;
  }
}
