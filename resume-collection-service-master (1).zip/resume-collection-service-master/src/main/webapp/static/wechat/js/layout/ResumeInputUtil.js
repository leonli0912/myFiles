sap.ui.define([
               'sap/m/MessageBox'], function(MessageBox){
	"use strict";

	var ResumeInputUtil = function(){};

	ResumeInputUtil.prototype.getCandidateData = function(candidateId){
		var candidateDataModel = new sap.ui.model.json.JSONModel();
		if (candidateId) {
			candidateDataModel.loadData("cv/candidatePreview?candidateId=" + candidateId, null, false);
		} else {
			candidateDataModel.loadData("cv/candidatePreviewEmpty", null, false);
		}
		var oDataWrapper = candidateDataModel.getData();
		var oData = oDataWrapper.candidateProfileVO;
		var oRequiredFieldsData = oDataWrapper.fieldVOList;
		if(oData){
			var profile = {};
			for(var key in oData){
				if(!key){continue;}
				if(key == "workExprs" || key == "education" || key == "languages"
					|| key == "certificates" || key == "families"){
						continue;
				}else if(key == "extProfile"){
					var extPro = oData[key];
					for(var extKey in extPro){
						if(extKey){
							profile[extKey] = extPro[extKey];
						}
					}
				}else{
					profile[key] = oData[key];
					delete oData[key];
				}
			}
			oData["profile"] = profile;
		}
		oData["applyReqFieldList"] = oRequiredFieldsData;
		candidateDataModel.setData(oData);
		return candidateDataModel;
	}

	ResumeInputUtil.prototype.getDM = function(){
		var candidateProfileData = null;
		 var candidateProfileMappingId = g_company_info.cdmId;
		 if(candidateProfileMappingId){
			 var candidateProfileModel = new sap.ui.model.json.JSONModel();
			 candidateProfileModel.loadData("dm/" + candidateProfileMappingId, null, false);
			 candidateProfileData = candidateProfileModel.getData();
		 }
		 return candidateProfileData;
	}
	
	ResumeInputUtil.prototype.getApplicationDM = function(){
		var jobApplicationData = null;
		var jobApplicationModel = new sap.ui.model.json.JSONModel();
		jobApplicationModel.loadData("appl/loadJobApplicationDmConf", null, false);
		jobApplicationData = jobApplicationModel.getData().itemList;
		return jobApplicationData;
	}

	ResumeInputUtil.prototype.getFullDM = function(){
		 var fullMapping = {};
		 var candidateProfileData = this.getDM();
		 if(candidateProfileData){
			 var types = {
				 						"profile":"profile",
			 							"workExprs":"workExprs",
										"education":"education",
										"languages":"languages",
										"certificates":"certificates",
										"families":"families"
									};

			 //process mapping profile
			 for(var type in types){
				 var mapping = this.getMappingByName(candidateProfileData, types[type]);
				 fullMapping[type] = mapping;

				 fullMapping[type].ui_visible = true;
				 if(!candidateProfileData.aliases[type] && type != "profile"){
					 fullMapping[type].ui_visible = false;
				 }
			 }
		 }
		 return fullMapping;
	}

	ResumeInputUtil.prototype.buildPreviewPage = function(oControler,oPanel,itemData,propName){
		var pickListData = oControler.getView().getModel("picklistModel").getData();
		var profileData = oControler.getView().getModel().getData()[propName];
		oPanel.destroyContent();
		var pModel = oControler.getView().getModel("pi18n");

		for(var i in itemData){
			var item = itemData[i];
			if(!item.to || item.from == "attachment" || item.from == "contactEmail"){
				continue;
			}

			var oHbox = new sap.m.HBox({
				width:"100%",
				justifyContent:"SpaceBetween"
			});

			var label = pModel.getResourceBundle().getText(item.label);
			var oLabel = new sap.m.Label({
				text:label
			});
			oLabel.addStyleClass("matrixLayoutCellLabel");

			if(propName == "profile"){
					var oText = new sap.m.Text({
						text:"{/profile/"+item.from+"}"
					});

			}else{
					var oText = new sap.m.Text({
						text:"{"+item.from+"}"
					});

			}
			oText.addStyleClass("sapUiSmallMarginEnd matrixLayoutCellText");

			oHbox.addItem(oLabel);
			oHbox.addItem(oText);

			oPanel.addContent(oHbox);

		}
		return oPanel;
	}

	ResumeInputUtil.prototype.getMappingByName = function(candidateProfileData, propName){
		var mapping = {};
		var data = candidateProfileData[propName];
		if(data){
			for(var i = 0;i < data.length; i++){
			  if(data[i].from && data[i].to){
				 	mapping[data[i].from] = data[i];
			   }
			}
			return mapping;
		}
	}

	ResumeInputUtil.prototype.updateInputItems = function(mapping, listName, oModel, oView){
		 var inputList = oView.byId(listName);
		 var listItemNo = inputList.getMaxItemsCount();
		 var item = "";
		 var label = "";
		 var content = "";
		 var inputs = [];

		 while(listItemNo--){
			    item = inputList.getItems()[listItemNo];
			    if(item instanceof sap.m.CustomListItem){
			    	content = item.getContent()[1];
			    }else if("candidateWorkExpInputList" == listName &&
			    		item.getId().indexOf("endDateNow") > -1){
			    	item = item.getContent()[0];
			    	content = item.getItems()[0];
			    }else{
			    	content = item.getContent()[0];
			    }

			 	if(content instanceof sap.m.Select){
			 		var bindingPath = content.getBindingInfo("selectedKey").parts[0].path;
			 	}else{
			 		var bindingPath = content.getBindingInfo("value").parts[0].path;
			 	}
			 	var from = bindingPath.match("[a-zA-Z0-9\-_]+$");

			 	if(mapping[from]){
					label = oModel.getResourceBundle().getText(mapping[from].label);
					if(mapping[from].required == true){
						inputList.getItems()[listItemNo].setLabel("*" + label);
						inputs.push(content);
					}else{
						if(inputList.getItems()[listItemNo] instanceof sap.m.CustomListItem){
							//Do nothing
						}else{
							inputList.getItems()[listItemNo].setLabel(label);
						}

					}
				}else{
					inputList.getItems()[listItemNo].setVisible(false);
				}
				label = "";
			}

		 return inputs;
	}

	ResumeInputUtil.prototype.clearInputItemsErrorState = function(oView, listName, errorStyle){
		var inputList = oView.byId(listName);
		var listItemNo = inputList.getMaxItemsCount();

		 while(listItemNo--){
			 inputList.getItems()[listItemNo].removeStyleClass(errorStyle);
		 }
	}

	ResumeInputUtil.prototype.buildGenericProfilePage = function(profileItemType, panel, oModel, locale){
		var dmMappingData = this.getDM();
		var pickListModel = new sap.ui.model.json.JSONModel();
		pickListModel.loadData("cv/picklists?locale="+locale, null, false);
		var pickListData = pickListModel.getData();
		var items = null;
		var requiredInputs = [];
		panel.destroyContent();

		items = dmMappingData[profileItemType];

		for(var i = 0; i < items.length; i++){
			if(items[i].to){
				var item = items[i];
				var oInput = null;

				switch(item.fieldType){
					case "PLAIN_TEXT":
						if(item.from == "contactEmail"){break;}
						oInput = new sap.m.Input({
							type:"Text",
							value:"{path: '/"+item.from + "'," +
								  "type: 'sap.ui.model.type.String'}"
						});
						if(item.from.toLowerCase().indexOf("mail") > 0){
							oInput = new sap.m.Input({
								type:"Email",
								value:{path: "/"+item.from,
									   type: 'typeEMail'
									}
							});
						}else if(item.from.toLowerCase().indexOf("phone") > 0){
							oInput = new sap.m.Input({
								type:"Tel",
								value:"{path: '/"+item.from + "'," +
									  "type: 'sap.ui.model.type.String'," +
									  "constraints:{minLength: 8, maxLength: 11}}"
							});
						}
						break;
					case "LONG_TEXT":
						oInput = new sap.m.TextArea({
							value:"{/"+item.from+"}"
						});
						break;
					case "DATE":
						oInput = new sap.m.DatePicker({
							type: "Date",
							displayFormat: "yyyy/MM/dd",
							valueFormat: "yyyy/MM/dd",
							placeholder: "yyyy/MM/dd",
							value:"{path: '/"+item.from + "'," +
							      "type: 'sap.ui.model.type.String'}"
						});
						break;
					case "PICKLIST":
						oInput = new sap.m.Select({
							selectedKey:"{path: '/"+item.from + "'," +
						      		    "type: 'sap.ui.model.type.String'}"
						});
						var itemList = pickListData[item.picklist]
						if(itemList != null){
							for (var j=0; j < itemList.length; j++) {
								var oItem = new sap.ui.core.Item({
									key: itemList[j].label,
									text: itemList[j].label
								});
								oInput.addItem(oItem);
							}
						}
						break;
				};
		        if(oInput){
		          oInput.addStyleClass("sapUiSmallMarginEnd matrixLayoutCellText");
		
		  				var oInputItemList = new sap.m.InputListItem({
		  					content: oInput
		  				});
		  				oInputItemList.addStyleClass("inputListItemClass");
		
		
		  				if(item.required){
		  					var label = oModel.getResourceBundle().getText(item.label);
		  					oInputItemList.setLabel("*" + label);
		  					requiredInputs.push(oInput);
		  				}else{
		  					oInputItemList.setLabel(oModel.getResourceBundle().getText(item.label));
		  				}
		  				panel.addContent(oInputItemList);
		        }
			}
		}
		return requiredInputs;
	};
	
	ResumeInputUtil.prototype.buildGenericAdditionalFieldInput = function(panel, oModel, locale){
		panel.destroyContent();
		var oDataWrapper = oModel.getData();
		var oFieldVOList = oDataWrapper.applyReqFieldList;
		for (var i=0; i<oFieldVOList.length; i++) {
			var oField = oFieldVOList[i];
			if (oField.picklist) {

				var pickListModel = new sap.ui.model.json.JSONModel();
				pickListModel.loadData("cv/jobApplPicklists?locale="+locale, null, false);
				var pickListData = pickListModel.getData();
				
//				var jobMappingModel = new sap.ui.model.json.JSONModel();
//				jobMappingModel.loadData("appl/picklistOptions?&picklist="+oField.picklist,null,false);
//				var picklistItems = jobMappingModel.getData();
				
				oInput = new sap.m.Select({
					selectedKey:"{path: 'allData>/applyReqFieldList/"+ i +"/fieldValue'," +
				      		    "type: 'sap.ui.model.type.String'}"
				});
				var picklistItems = pickListData[oField.picklist];
				for (var j=0; j < picklistItems.length; j++) {
					var oItem = new sap.ui.core.Item({
						key: picklistItems[j].label,
						text: picklistItems[j].label
					});
					oInput.addItem(oItem);
				}
			} else {
				var oInput = new sap.m.Input({
					type:"Text",
					value:"{allData>/applyReqFieldList/"+ i +"/fieldValue}"
				});
			}

			oInput.addStyleClass("sapUiSmallMarginEnd matrixLayoutCellText");
			var oInputItemList = new sap.m.InputListItem({
				content: oInput,
				label: "*{allData>/applyReqFieldList/"+ i +"/fieldLabel}"
			});
			oInputItemList.addStyleClass("inputListItemClass");
			panel.addContent(oInputItemList);
		}
	};
	
	ResumeInputUtil.prototype.buildGenericAdditionalFieldPreview = function(){
		var oHbox = new sap.m.HBox({
			width:"100%",
			justifyContent:"SpaceBetween"
		});
		var oLabel = new sap.m.Label({
			text:"{fieldLabel}"
		});
		oLabel.addStyleClass("matrixLayoutCellLabel");
		var oText = new sap.m.Text({
			text:"{fieldValue}"
		});
		oText.addStyleClass("sapUiSmallMarginEnd matrixLayoutCellText");
		oHbox.addItem(oLabel);
		oHbox.addItem(oText);
		return oHbox;
	};
	
	ResumeInputUtil.prototype.integrateExtProfile = function(jsonData){
		var oProfileData = jsonData.profile;
		var oExtProfileData = jsonData.extProfile;
		var oTargetProfile = {};
		for(var key in oProfileData){
			for (var extKey in oExtProfileData) {
				if (extKey == key) {
					oExtProfileData[extKey] = oProfileData[key];
					break;
				}
			}
			oTargetProfile[key] = oProfileData[key];
		}
		oTargetProfile.workExprs = jsonData.workExprs;
		oTargetProfile.education = jsonData.education;
		oTargetProfile.languages = jsonData.languages;
		oTargetProfile.certificates = jsonData.certificates;
		oTargetProfile.families = jsonData.families;
		oTargetProfile.extProfile = oExtProfileData;
		
		var integrateJsonData = {};
		integrateJsonData.candidateProfileVO = oTargetProfile;
		integrateJsonData.fieldVOList = jsonData.applyReqFieldList;
		
		return integrateJsonData;
	};

	ResumeInputUtil.prototype.validateRequiredInputs = function(requiredInputs, oModel){
		if (requiredInputs.length == 0){
			return true;
		}
		var canContinue = true;
		jQuery.each(requiredInputs, function (i, input) {
			if(input instanceof sap.m.Input || input instanceof sap.m.DatePicker || input instanceof sap.m.TextArea){
				if (!input.getValue()){
					input.getParent().addStyleClass("inputListItemErrorClass");
					canContinue = false;
				}
			}else if(input instanceof sap.m.Select){
				if(!input.getSelectedKey()){
					input.getParent().addStyleClass("inputListItemErrorClass");
					canContinue = false;
				}
			}
		});
		if(!canContinue){
			MessageBox.alert(oModel.getResourceBundle().getText("ERROR_MSG_CANDIDATE_INPUT_EMPTY"));
		}

		return canContinue;
	};

	return ResumeInputUtil;
});
