
package com.sap.hcm.resume.collection.bean;

public enum ExceptionTypeEnum {
  
  ERROR("error"),
  WARNING("warning");
  
  private String labelKey;
  
  public String getLabelKey() {
    return labelKey;
  }

  public void setLabelKey(String labelKey) {
    this.labelKey = labelKey;
  }

  ExceptionTypeEnum(String labelKey){
    this.labelKey = labelKey;
  }
  
  
}
