sap.ui.define(['jquery.sap.global','sap/ui/core/Control'],
	function(jQuery, Control) {
		var Color = Control.extend("static.js.Color",{
			metadata:{
				properties:{
					hex: {type:"string"},
					width:{type:"string"}
				},
				events:{
					press:{
						enableEventBubbling:false,
						parameters : {
							hex : {type : "string"}
						}
					}
				}
			},

			renderer:function(rm, oControl){
				rm.write("<div class='color-holder'");
				rm.writeControlData(oControl);

				rm.addStyle("width", oControl.getWidth());
				rm.addStyle("height", oControl.getWidth());
				rm.addStyle("background-color", oControl.getHex());
				rm.writeStyles();
				rm.write(">");


				rm.write("</div>");
			},

			onclick: function(){
				var hex = this.getHex();
				this.firePress({
						hex:hex
				});
			}
		});

		return Color;
	}
);
