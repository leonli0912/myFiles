package com.sap.hcm.resume.collection.integration;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import org.apache.commons.io.IOUtils;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.message.BasicHeader;

public class MockHttpEntity implements HttpEntity{
  
  private String contentType;
  
  private InputStream inputStream;
 
  private String content;
  
  public MockHttpEntity(String contentType, String content){
    this.contentType = contentType;
    this.content = content;
  }
  
  public MockHttpEntity(String contentType, InputStream inputStream){
    this.contentType = contentType;
    this.inputStream = inputStream;
  }
  
  @Override
  public boolean isRepeatable() {
    return false;
  }

  @Override
  public boolean isChunked() {
    return false;
  }

  @Override
  public long getContentLength() {
    return 0;
  }

  @Override
  public Header getContentType() {
    return new BasicHeader("Content-Type", contentType);
  }

  @Override
  public Header getContentEncoding() {
    return new BasicHeader("encoding", "UTF-8");
  }

  @Override
  public InputStream getContent() throws IOException, IllegalStateException {
    if(this.content != null){
      return IOUtils.toInputStream(this.content);
    }
    if(this.inputStream != null){
      return inputStream;
    }
    return null;
  }
  

  @Override
  public void writeTo(OutputStream outstream) throws IOException {
    
  }

  @Override
  public boolean isStreaming() {
    return false;
  }

  @Override
  public void consumeContent() throws IOException {
    
  }

}
