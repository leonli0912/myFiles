package com.sap.hcm.resume.collection.bean;

import org.junit.Assert;
import org.junit.Test;


public class JobRequisitionModelTest {
  
  @Test
  public void testGetterSetter(){
    JobRequisitionModel model = new JobRequisitionModel();
    model.setAttributes(null);
    Assert.assertEquals(model.getAttributes(), null);
  }
}
