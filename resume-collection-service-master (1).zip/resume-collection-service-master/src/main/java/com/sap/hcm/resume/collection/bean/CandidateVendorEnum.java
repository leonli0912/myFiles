package com.sap.hcm.resume.collection.bean;

public enum CandidateVendorEnum {
	
	ZHILIAN("智联招聘"),
	JOB51("51Job"),
	LIEPIN("猎聘网"),
	DAJIE("大街网");
	
	private String vendorName;

	/**
	 * @return the vendorName
	 */
	public String getVendorName() {
		return vendorName;
	}
	
	CandidateVendorEnum(String vendorName){
		this.vendorName = vendorName;
	}
	
	public static CandidateVendorEnum fromVendorCode(String vendorCode){
		for(CandidateVendorEnum vendorEnum : CandidateVendorEnum.values()){
			if(vendorEnum.name().equals(vendorCode)){
				return vendorEnum;
			}
		}
		return null;
	}
	
	
}
