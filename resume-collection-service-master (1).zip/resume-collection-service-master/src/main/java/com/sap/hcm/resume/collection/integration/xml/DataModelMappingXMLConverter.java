package com.sap.hcm.resume.collection.integration.xml;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.Collection;

import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.bean.CandProfileDataModelMapping;
import com.sap.hcm.resume.collection.integration.bean.DataMappingApplyStatus;
import com.sap.hcm.resume.collection.integration.bean.DataMappingApplyStatusList;
import com.sap.hcm.resume.collection.integration.bean.DataMappingOverwrite;
import com.sap.hcm.resume.collection.integration.bean.DataMappingPicklist;
import com.sap.hcm.resume.collection.integration.bean.DataMappingPicklistOption;
import com.sap.hcm.resume.collection.integration.bean.DataMappingPkOptionMapping;
import com.sap.hcm.resume.collection.integration.bean.DataModelMappingItem;
import com.sap.hcm.resume.collection.integration.bean.JobReqDataModelMapping;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.security.NullPermission;
import com.thoughtworks.xstream.security.PrimitiveTypePermission;

public class DataModelMappingXMLConverter {
  private static XStream stream = new XStream();

  private DataModelMappingXMLConverter() {

  }

  static {
    stream.autodetectAnnotations(true);
    stream.processAnnotations(CandProfileDataModelMapping.class);
    stream.processAnnotations(DataModelMappingItem.class);
    stream.processAnnotations(DataMappingPkOptionMapping.class);
    stream.processAnnotations(DataMappingPicklist.class);
    stream.processAnnotations(DataMappingPicklistOption.class);
    stream.processAnnotations(JobReqDataModelMapping.class);
    stream.processAnnotations(DataMappingApplyStatusList.class);
    stream.processAnnotations(DataMappingApplyStatus.class);
    stream.processAnnotations(DataMappingOverwrite.class);
    
    // add permissions, allow some basics
    stream.addPermission(NullPermission.NULL);
    stream.addPermission(PrimitiveTypePermission.PRIMITIVES);
    stream.allowTypeHierarchy(Collection.class);
    // allow any type from the same package
    stream.allowTypesByWildcard(new String[] {
        CandProfileDataModelMapping.class.getPackage().getName()+".*"
    });
  }

  public static String toXML(CandProfileDataModelMapping mapping) {
    return stream.toXML(mapping);
  }

  public static CandProfileDataModelMapping fromXML(String xml) {
    return (CandProfileDataModelMapping) stream.fromXML(xml);
  }

  public static CandProfileDataModelMapping fromByte(byte[] content) {
    return fromXML(new String(content, StandardCharsets.UTF_8));
  }

  public static JobReqDataModelMapping fromJobReqXML(String xml) {
    return (JobReqDataModelMapping) stream.fromXML(xml);
  }

  public static JobReqDataModelMapping fromJobReqByte(byte[] bytes, String charsetName)
      throws ServiceApplicationException {
    String content = null;
    try {
      content = new String(bytes, charsetName);
    } catch (UnsupportedEncodingException e) {
      throw new ServiceApplicationException(e.getMessage());
    }
    return fromJobReqXML(content);
  }

  public static DataMappingApplyStatusList fromApplyStatusReqXML(String xml) {
    return (DataMappingApplyStatusList) stream.fromXML(xml);
  }

  /**
   * @param optionMapping
   * @return
   */
  public static String toOptionXML(DataMappingPkOptionMapping optionMapping) {
    return stream.toXML(optionMapping);
  }

  /**
   * @param xml
   * @return
   */
  public static DataMappingPkOptionMapping fromOptionXML(String xml) {
    return (DataMappingPkOptionMapping) stream.fromXML(xml);
  }

}
