package com.sap.hcm.resume.collection.integration.sf.bean;

import java.io.Serializable;

public class SFPicklistItem implements Serializable{
    
    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 4427703933673419208L;

    private Long optionId;
    
    private String label;
    
    private String locale;

    /**
     * @return the optionId
     */
    public Long getOptionId() {
        return optionId;
    }

    /**
     * @param optionId the optionId to set
     */
    public void setOptionId(Long optionId) {
        this.optionId = optionId;
    }

    /**
     * @return the label
     */
    public String getLabel() {
        return label;
    }

    /**
     * @param label the label to set
     */
    public void setLabel(String label) {
        this.label = label;
    }

    /**
     * @return the locale
     */
    public String getLocale() {
        return locale;
    }

    /**
     * @param locale the locale to set
     */
    public void setLocale(String locale) {
        this.locale = locale;
    }
    
}
