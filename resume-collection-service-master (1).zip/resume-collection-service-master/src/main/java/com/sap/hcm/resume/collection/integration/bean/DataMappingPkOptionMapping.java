package com.sap.hcm.resume.collection.integration.bean;

import java.io.Serializable;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

@XStreamAlias("picklist-option-mapping")
public class DataMappingPkOptionMapping implements Serializable{
    
    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = -7900323442699114832L;

    @XStreamImplicit(itemFieldName="picklist")
    private List<DataMappingPicklist> picklists;

    public List<DataMappingPicklist> getPicklists() {
        return picklists;
    }

    public void setPicklists(List<DataMappingPicklist> picklists) {
        this.picklists = picklists;
    }
    
}
