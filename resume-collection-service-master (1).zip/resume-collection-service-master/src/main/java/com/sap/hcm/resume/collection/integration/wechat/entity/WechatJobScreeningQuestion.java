package com.sap.hcm.resume.collection.integration.wechat.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "WECHAT_JOB_SCREENING_QUESTION")
public class WechatJobScreeningQuestion {
  @Id
  @Column(name = "job_req_id")
  private String jobReqId;

  @Id
  @Column(name = "question_locale")
  private String questionLocale;

  @Id
  @Column(name = "question_order")
  private Long questionOrder;

  @Id
  @Column(name = "company_id")
  private String companyId;

  @Column(name = "question_id")
  private String questionId;

  @Column(name = "question_name")
  private String questionName;

  @Column(name = "rating_scale")
  private String ratingScale;

  @Column(name = "question_type")
  private String questionType;

  @Column(name = "required")
  private boolean required;
  
  @Column(name="max_length")
  private String maxLength;

  public String getJobReqId() {
    return jobReqId;
  }

  public void setJobReqId(String jobReqId) {
    this.jobReqId = jobReqId;
  }

  public String getCompanyId() {
    return companyId;
  }

  public void setCompanyId(String companyId) {
    this.companyId = companyId;
  }

  public String getQuestionId() {
    return questionId;
  }

  public void setQuestionId(String questionId) {
    this.questionId = questionId;
  }

  public String getQuestionName() {
    return questionName;
  }

  public void setQuestionName(String questionName) {
    this.questionName = questionName;
  }

  public String getRatingScale() {
    return ratingScale;
  }

  public void setRatingScale(String ratingScale) {
    this.ratingScale = ratingScale;
  }

  public String getQuestionType() {
    return questionType;
  }

  public void setQuestionType(String questionType) {
    this.questionType = questionType;
  }

  public boolean isRequired() {
    return required;
  }

  public void setRequired(boolean required) {
    this.required = required;
  }

  public String getQuestionLocale() {
    return questionLocale;
  }

  public void setQuestionLocale(String questionLocale) {
    this.questionLocale = questionLocale;
  }

  public Long getQuestionOrder() {
    return questionOrder;
  }

  public void setQuestionOrder(Long questionOrder) {
    this.questionOrder = questionOrder;
  }

  /**
   * @return the maxLength
   */
  public String getMaxLength() {
    return maxLength;
  }

  /**
   * @param maxLength the maxLength to set
   */
  public void setMaxLength(String maxLength) {
    this.maxLength = maxLength;
  }
}
