
package com.sap.hcm.resume.collection.security;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.web.servlet.ModelAndView;

/**
 * @author I324117
 * SAP
 */
public class ValidateCsrfTokenInterceptorTest {
private ValidateCsrfTokenInterceptor csrfInterceptor;
  
  @Before
  public void setUp(){
    csrfInterceptor = new ValidateCsrfTokenInterceptor();
  }

  @Test
  public void testPreHandleSuccess() throws Exception{
    MockHttpServletRequest request = new MockHttpServletRequest();
    request.setMethod("POST");
    request.addHeader(CsrfTokenManager.CSRF_PARAM_NAME, "123");
    MockHttpServletResponse response = new MockHttpServletResponse();
    Object handler = new Object();
    MockHttpSession session = new MockHttpSession();
    session.setAttribute(CsrfTokenManager.CSRF_PARAM_NAME, "123");
    request.setSession(session);
    assertEquals(true,csrfInterceptor.preHandle(request, response, handler));
  }
  
  @Test
  public void testPreHandleFail() throws Exception{
    MockHttpServletRequest request = new MockHttpServletRequest();
    request.setMethod("POST");
    request.addHeader(CsrfTokenManager.CSRF_PARAM_NAME, "123");
    MockHttpServletResponse response = new MockHttpServletResponse();
    Object handler = new Object();
    MockHttpSession session = new MockHttpSession();
    session.setAttribute(CsrfTokenManager.CSRF_PARAM_NAME, null);
    request.setSession(session);
    ModelAndView modelAndView = new ModelAndView();
    csrfInterceptor.postHandle(request, response, handler, modelAndView);
//    Exception ex = Exception();
//    csrfInterceptor.afterCompletion(request, response, handler, ex);
    assertEquals(false,csrfInterceptor.preHandle(request, response, handler));
  }
}
