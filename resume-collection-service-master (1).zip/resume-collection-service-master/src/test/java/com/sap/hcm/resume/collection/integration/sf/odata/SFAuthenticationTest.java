package com.sap.hcm.resume.collection.integration.sf.odata;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.sap.cloud.account.Account;
import com.sap.cloud.account.Tenant;
import com.sap.cloud.account.TenantContext;
import com.sap.core.connectivity.api.configuration.ConnectivityConfiguration;
import com.sap.core.connectivity.api.configuration.DestinationConfiguration;
import com.sap.hcm.resume.collection.bean.CompanyIdInfo;
import com.sap.hcm.resume.collection.bean.Params;

@RunWith(PowerMockRunner.class)
@PrepareForTest(SFAuthentication.class)
public class SFAuthenticationTest {

  private TenantContext tenantContext;

  private ConnectivityConfiguration connectivityConfig;

  private Params params;

  private CompanyIdInfo companyIdInfo;

  private SFAuthentication spy = null;

  @Before
  public void setup() {
    spy = PowerMockito.spy(new SFAuthentication());

    tenantContext = PowerMockito.mock(TenantContext.class);
    connectivityConfig = PowerMockito.mock(ConnectivityConfiguration.class);
    params = PowerMockito.mock(Params.class);
    companyIdInfo = PowerMockito.mock(CompanyIdInfo.class);

    ReflectionTestUtils.setField(spy, "tenantContext", tenantContext);
    ReflectionTestUtils.setField(spy, "connectivityConfig", connectivityConfig);
    ReflectionTestUtils.setField(spy, "params", params);
    ReflectionTestUtils.setField(spy, "companyIdInfo", companyIdInfo);
  }

  @Test
  public void testGetAuthenticationConnectivityNull() {
    ReflectionTestUtils.setField(spy, "connectivityConfig", null);
    String authString = spy.getAuthentication();
    Assert.assertEquals(null, authString);
  }

  @Test
  public void testGetAuthenticationBasicSuccessCompanyIdNotNull() {
    PowerMockito.when(companyIdInfo.getCompanyId()).thenReturn("testCompanyId");
    Tenant tenant = PowerMockito.mock(Tenant.class);
    Account account = PowerMockito.mock(Account.class);
    PowerMockito.when(tenantContext.getTenant()).thenReturn(tenant);
    PowerMockito.when(tenant.getAccount()).thenReturn(account);
    PowerMockito.when(account.getId()).thenReturn("testHcpTenantId");
    DestinationConfiguration destConfig = PowerMockito.mock(DestinationConfiguration.class);
    PowerMockito.when(destConfig.getProperty("Authentication")).thenReturn(SFODataConstants.AUTH_TYPE_BASIC);
    PowerMockito.when(destConfig.getProperty("URL")).thenReturn("testURL");
    PowerMockito.when(destConfig.getProperty("User")).thenReturn("testUser@testCompany");
    PowerMockito.when(destConfig.getProperty("Password")).thenReturn("testPassword");
    PowerMockito.when(connectivityConfig.getConfiguration("testCompanyId", SFODataConstants.SF_DESTINATION_NAME))
        .thenReturn(destConfig);

    String authString = spy.getAuthentication();

    Assert.assertEquals("Basic dGVzdFVzZXJAdGVzdENvbXBhbnk6dGVzdFBhc3N3b3Jk", authString);
  }

  @Test
  public void testGetAuthenticationBasicSuccessCompanyIdNull() {
    PowerMockito.when(companyIdInfo.getCompanyId()).thenReturn(null);
    PowerMockito.when(params.getCompanyId()).thenReturn("testCompanyId");
    Tenant tenant = PowerMockito.mock(Tenant.class);
    Account account = PowerMockito.mock(Account.class);
    PowerMockito.when(tenantContext.getTenant()).thenReturn(tenant);
    PowerMockito.when(tenant.getAccount()).thenReturn(account);
    PowerMockito.when(account.getId()).thenReturn("testHcpTenantId");
    DestinationConfiguration destConfig = PowerMockito.mock(DestinationConfiguration.class);
    PowerMockito.when(destConfig.getProperty("Authentication")).thenReturn(SFODataConstants.AUTH_TYPE_BASIC);
    PowerMockito.when(destConfig.getProperty("URL")).thenReturn("testURL");
    PowerMockito.when(destConfig.getProperty("User")).thenReturn("testUser@testCompany");
    PowerMockito.when(destConfig.getProperty("Password")).thenReturn("testPassword");
    PowerMockito.when(connectivityConfig.getConfiguration("testCompanyId", SFODataConstants.SF_DESTINATION_NAME))
        .thenReturn(destConfig);

    String authString = spy.getAuthentication();

    Assert.assertEquals("Basic dGVzdFVzZXJAdGVzdENvbXBhbnk6dGVzdFBhc3N3b3Jk", authString);
  }

  @Test
  public void testGetAuthenticationDestinationNotFound() {
    PowerMockito.when(companyIdInfo.getCompanyId()).thenReturn(null);
    PowerMockito.when(params.getCompanyId()).thenReturn("testCompanyId");
    Tenant tenant = PowerMockito.mock(Tenant.class);
    Account account = PowerMockito.mock(Account.class);
    PowerMockito.when(tenantContext.getTenant()).thenReturn(tenant);
    PowerMockito.when(tenant.getAccount()).thenReturn(account);
    PowerMockito.when(account.getId()).thenReturn("testHcpTenantId");
    PowerMockito.when(connectivityConfig.getConfiguration("testCompanyId", SFODataConstants.SF_DESTINATION_NAME))
        .thenReturn(null);

    String authString = spy.getAuthentication();

    Assert.assertEquals(null, authString);
  }

  @Test
  public void testGetAuthenticationOAuthSuccess() throws Exception {
    PowerMockito.when(companyIdInfo.getCompanyId()).thenReturn("testCompanyId");
    Tenant tenant = PowerMockito.mock(Tenant.class);
    Account account = PowerMockito.mock(Account.class);
    PowerMockito.when(tenantContext.getTenant()).thenReturn(tenant);
    PowerMockito.when(tenant.getAccount()).thenReturn(account);
    PowerMockito.when(account.getId()).thenReturn("testHcpTenantId");
    DestinationConfiguration destConfig = PowerMockito.mock(DestinationConfiguration.class);
    PowerMockito.when(destConfig.getProperty("Authentication")).thenReturn(SFODataConstants.AUTH_TYPE_OAUTH);
    PowerMockito.when(destConfig.getProperty("URL")).thenReturn("testURL");
    PowerMockito.when(destConfig.getProperty("clientKey")).thenReturn("testClientKey");
    PowerMockito.when(destConfig.getProperty("companyId")).thenReturn("testCompanyId");
    PowerMockito.when(destConfig.getProperty("privateKey")).thenReturn("testPrivateKey");
    PowerMockito.when(destConfig.getProperty("tokenServiceURL")).thenReturn("http://host/token");
    PowerMockito.when(destConfig.getProperty("tokenServiceUser")).thenReturn("testTokenServiceUser");
    PowerMockito.when(connectivityConfig.getConfiguration("testCompanyId", SFODataConstants.SF_DESTINATION_NAME))
        .thenReturn(destConfig);
    // mock http connection
    URL url = PowerMockito.mock(URL.class);
    PowerMockito.whenNew(URL.class).withArguments("http://host/idp").thenReturn(url);
    HttpURLConnection huc = PowerMockito.mock(HttpURLConnection.class);
    PowerMockito.when(url.openConnection()).thenReturn(huc);
    PowerMockito.when(huc.getResponseCode()).thenReturn(200);
    OutputStream out = PowerMockito.mock(OutputStream.class);
    PowerMockito.when(huc.getOutputStream()).thenReturn(out);
    InputStream in = new ByteArrayInputStream("mockedSMALAssertion".getBytes());
    // mock SMAL assertion
    PowerMockito.when(huc.getInputStream()).thenReturn(in);
    // mock access token
    String accessPayload = "company_id=testCompanyId&client_id=testClientKey&grant_type=urn:ietf:params:oauth:grant-type:saml2-bearer&assertion=mockedSMALAssertion";
    PowerMockito.doReturn("{\"access_token\"=\"testAccessToken\"}").when(spy, "getPostResponse", "http://host/token",
        accessPayload);

    String authString = spy.getAuthentication();
    
    IOUtils.closeQuietly(in);
    IOUtils.closeQuietly(out);

    Assert.assertEquals("Bearer testAccessToken", authString);
  }

  @Test
  public void testGetServiceURL() {
    PowerMockito.when(companyIdInfo.getCompanyId()).thenReturn("testCompanyId");
    Tenant tenant = PowerMockito.mock(Tenant.class);
    Account account = PowerMockito.mock(Account.class);
    PowerMockito.when(tenantContext.getTenant()).thenReturn(tenant);
    PowerMockito.when(tenant.getAccount()).thenReturn(account);
    PowerMockito.when(account.getId()).thenReturn("testHcpTenantId");
    DestinationConfiguration destConfig = PowerMockito.mock(DestinationConfiguration.class);
    PowerMockito.when(destConfig.getProperty("Authentication")).thenReturn(SFODataConstants.AUTH_TYPE_BASIC);
    PowerMockito.when(destConfig.getProperty("URL")).thenReturn("http://testhost/odata");
    PowerMockito.when(destConfig.getProperty("User")).thenReturn("testUser@testCompany");
    PowerMockito.when(destConfig.getProperty("Password")).thenReturn("testPassword");
    PowerMockito.when(connectivityConfig.getConfiguration("testCompanyId", SFODataConstants.SF_DESTINATION_NAME))
        .thenReturn(destConfig);
    String serviceUrl = spy.getServiceURL();
    Assert.assertEquals("http://testhost/odata/", serviceUrl);
  }

}
