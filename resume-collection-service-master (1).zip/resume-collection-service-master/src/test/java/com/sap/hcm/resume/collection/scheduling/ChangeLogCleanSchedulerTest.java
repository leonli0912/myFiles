package com.sap.hcm.resume.collection.scheduling;
import static org.junit.Assert.fail;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;

import com.sap.hcm.resume.collection.context.TestContext;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.service.CandidateProfileService;
import com.sap.hcm.resume.collection.service.ChangeLogService;
import com.sap.hcm.resume.collection.service.ExceptionLogService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { TestContext.class })
public class ChangeLogCleanSchedulerTest {

  @Autowired
  private ChangeLogService changeLogService;

  @Autowired
  private CandidateProfileService candidateProfileService;

  @Autowired
  private ExceptionLogService exceptionLogService;
  
  private ChangeLogCleanScheduler changeLogCleanScheduler;
  
  @Before
  public void setUp() {
    reset(changeLogService);
    reset(candidateProfileService);
    reset(exceptionLogService);
    changeLogCleanScheduler = new ChangeLogCleanScheduler();
    ReflectionTestUtils.setField(changeLogCleanScheduler, "changeLogService", changeLogService);
    ReflectionTestUtils.setField(changeLogCleanScheduler, "candidateProfileService", candidateProfileService);
    ReflectionTestUtils.setField(changeLogCleanScheduler, "exceptionLogService", exceptionLogService);
  }
  
  @Test
  public void testWorkSuccess() throws ServiceApplicationException {
    try {
      when(changeLogService.deleteOverdueChangeLog()).thenReturn(new Integer(1));
      when(exceptionLogService.deleteOverdueExceptionLog()).thenReturn(new Integer(2));
      when(candidateProfileService.deleteOverdueCandidate()).thenReturn(new Integer(3));
      changeLogCleanScheduler.work();
    } catch(Exception e) {
      fail();
    }
  }
  
  @Test
  public void testWorkChangeLogIsZero() throws ServiceApplicationException {
    try {
      when(changeLogService.deleteOverdueChangeLog()).thenReturn(new Integer(0));
      when(exceptionLogService.deleteOverdueExceptionLog()).thenReturn(new Integer(2));
      when(candidateProfileService.deleteOverdueCandidate()).thenReturn(new Integer(3));
      changeLogCleanScheduler.work();
    } catch(Exception e) {
      fail();
    }
  }
  
  @Test
  public void testWorkExceptionLogIsZero() throws ServiceApplicationException {
    try {
      when(changeLogService.deleteOverdueChangeLog()).thenReturn(new Integer(1));
      when(exceptionLogService.deleteOverdueExceptionLog()).thenReturn(new Integer(0));
      when(candidateProfileService.deleteOverdueCandidate()).thenReturn(new Integer(3));
      changeLogCleanScheduler.work();
    } catch(Exception e) {
      fail();
    }
  }
  
  @Test
  public void testWorkCandidateIsZero() throws ServiceApplicationException {
    try {
      when(changeLogService.deleteOverdueChangeLog()).thenReturn(new Integer(1));
      when(exceptionLogService.deleteOverdueExceptionLog()).thenReturn(new Integer(2));
      when(candidateProfileService.deleteOverdueCandidate()).thenReturn(new Integer(0));
      changeLogCleanScheduler.work();
    } catch(Exception e) {
      fail();
    }
  }
  
  @Test
  public void testWorkDeleteChangeLogException() throws ServiceApplicationException {
    try {
      when(changeLogService.deleteOverdueChangeLog()).thenThrow(new ServiceApplicationException("time out"));
      when(exceptionLogService.deleteOverdueExceptionLog()).thenReturn(new Integer(2));
      when(candidateProfileService.deleteOverdueCandidate()).thenReturn(new Integer(3));
      changeLogCleanScheduler.work();
    } catch(Exception e) {
      fail();
    }
  }
  
  @Test
  public void testWorkDeleteExceptionLogException() throws ServiceApplicationException {
    try {
      when(changeLogService.deleteOverdueChangeLog()).thenReturn(new Integer(1));
      when(exceptionLogService.deleteOverdueExceptionLog()).thenThrow(new ServiceApplicationException("time out"));
      when(candidateProfileService.deleteOverdueCandidate()).thenReturn(new Integer(3));
      changeLogCleanScheduler.work();
    } catch(Exception e) {
      fail();
    }
  }
}
