
package com.sap.hcm.resume.collection.bean;

public enum FunctionTypeEnum {
  JOB_APPLY("Job Apply");
  
  private String labelKey;
  
  public String getLabelKey() {
    return labelKey;
  }

  public void setLabelKey(String labelKey) {
    this.labelKey = labelKey;
  }

  FunctionTypeEnum(String labelKey){
    this.labelKey = labelKey;
  }
}
