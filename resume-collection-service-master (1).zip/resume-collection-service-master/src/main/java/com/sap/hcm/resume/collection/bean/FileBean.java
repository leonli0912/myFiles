package com.sap.hcm.resume.collection.bean;

public class FileBean {
	
	// file type
	private String fileType;
	
	// file content
	private String fileContent;

	public String getFileType() {
		return fileType;
	}

	public void setFileType(String fileType) {
		this.fileType = fileType;
	}

	public String getFileContent() {
		return fileContent;
	}

	public void setFileContent(String fileContent) {
		this.fileContent = fileContent;
	}
	
}
