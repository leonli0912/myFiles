package com.sap.hcm.resume.collection.entity;

import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.stereotype.Repository;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@Repository
@Entity
@Table(name = "COMPANY_INFO")
@JsonIgnoreProperties(value = "uiusers")
public class CompanyInfo implements Serializable {

  /**
   * serialVersionUID
   */
  private static final long serialVersionUID = 3076344025960353297L;

  @Id
  @Column(name = "COMPANY_ID", length = 50)
  private String companyId;

  @Column(name = "COMPANY_NAME", length = 100)
  private String companyName;

  @Column(name = "SHORT_DESCRPTION", length = 500)
  private String shortDescription;

  @Column(name = "LONG_DESCRIPTION", length = 2000)
  private String longDescription;

  @Column(name = "PHONE", length = 20)
  private String phone;

  @Column(name = "CONTACT_EMAIL", length = 100)
  private String contactEmail;

  @Column(name = "WEBSITE", length = 100)
  private String website;

  @Column(name = "COUNTRY", length = 50)
  private String country;

  @Column(name = "LOGO_ID")
  private Long logoId;

  @Column(name = "SHARE_PIC_ID")
  private Long sharePicId;

  @Column(name = "TWO_DIMENSION_CODE")
  private Long twoDimensionCode;

  @Column(name = "EMAIL_POSTFIX", length = 50)
  private String emailPostfix;

  @Column(name = "APP_ID", length = 100)
  private String appId;

  @Column(name = "APP_SECRET", length = 100)
  private String appSecret;

  @Column(name = "WECHAT_SERVER_URL", length = 100)
  private String wechatServerUrl;

  @Column(name = "JOB_STATUSES", length = 255)
  private String jobStatuses;

  @Column(name = "DPCS")
  @Lob
  private byte[] dpcs;

  /**
   * refer to Candidate Profile DM
   */
  @Column(name = "DM_MAPPING_ID")
  private Long dmMappingId;

  /**
   * refer to Job Requisition DM
   */
  @Column(name = "JOBREQ_MAPPING_ID")
  private Long jobReqMappingId;

  /**
   * apply status mapping for setting status item id
   */
  @Column(name = "SF_STATUS_MAPPING", length = 2000)
  private String applyStatusMapping;

  @Temporal(TemporalType.DATE)
  @Column(name = "CREATE_AT")
  private Date createAt;

  @Temporal(TemporalType.DATE)
  @Column(name = "LAST_MODIFY")
  private Date lastModify;

  @Temporal(TemporalType.DATE)
  @Column(name = "LAST_JOB_SYNC_DATE")
  private Date lastJobSyncDate;

  @Column(name = "ENABLE_JOB_SYNC")
  private boolean enableJobSync;

  @Column(name = "TRIGGER_EXPRESSION")
  private String triggerExpression;

  /**
   * @return the applyStatusMapping
   */
  public String getApplyStatusMapping() {
    return applyStatusMapping;
  }

  /**
   * @param applyStatusMapping
   *          the applyStatusMapping to set
   */
  public void setApplyStatusMapping(String applyStatusMapping) {
    this.applyStatusMapping = applyStatusMapping;
  }

  /**
   * @return the dpcs
   * @throws UnsupportedEncodingException
   */
  public String getDpcs() throws UnsupportedEncodingException {
    if (dpcs == null) {
      return "";
    }
    return new String(dpcs, "UTF-8");
  }

  /**
   * @param dpcs
   *          the dpcs to set
   * @throws UnsupportedEncodingException
   */
  public void setDpcs(String dpcs) throws UnsupportedEncodingException {
    if (dpcs == null) {
      dpcs = "";
    }
    this.dpcs = dpcs.getBytes("UTF-8");
  }

  /**
   * @return the companyId
   */
  public String getCompanyId() {
    return companyId;
  }

  /**
   * @param companyId
   *          the companyId to set
   */
  public void setCompanyId(String companyId) {
    this.companyId = companyId;
  }

  /**
   * @return the companyName
   */
  public String getCompanyName() {
    return companyName;
  }

  /**
   * @param companyName
   *          the companyName to set
   */
  public void setCompanyName(String companyName) {
    this.companyName = companyName;
  }

  /**
   * @return the shortDescription
   */
  public String getShortDescription() {
    return shortDescription;
  }

  /**
   * @param shortDescription
   *          the shortDescription to set
   */
  public void setShortDescription(String shortDescription) {
    this.shortDescription = shortDescription;
  }

  /**
   * @return the longDescription
   */
  public String getLongDescription() {
    return longDescription;
  }

  /**
   * @param longDescription
   *          the longDescription to set
   */
  public void setLongDescription(String longDescription) {
    this.longDescription = longDescription;
  }

  /**
   * @return the phone
   */
  public String getPhone() {
    return phone;
  }

  /**
   * @param phone
   *          the phone to set
   */
  public void setPhone(String phone) {
    this.phone = phone;
  }

  public String getWechatServerUrl() {
    return wechatServerUrl;
  }

  public void setWechatServerUrl(String wechatServerUrl) {
    this.wechatServerUrl = wechatServerUrl;
  }

  /**
   * @return the contactEmail
   */
  public String getContactEmail() {
    return contactEmail;
  }

  /**
   * @param contactEmail
   *          the contactEmail to set
   */
  public void setContactEmail(String contactEmail) {
    this.contactEmail = contactEmail;
  }

  /**
   * @return the website
   */
  public String getWebsite() {
    return website;
  }

  /**
   * @param website
   *          the website to set
   */
  public void setWebsite(String website) {
    this.website = website;
  }

  /**
   * @return the country
   */
  public String getCountry() {
    return country;
  }

  /**
   * @param country
   *          the country to set
   */
  public void setCountry(String country) {
    this.country = country;
  }

  /**
   * @return the logoId
   */
  public Long getLogoId() {
    return logoId;
  }

  /**
   * @param logoId
   *          the logoId to set
   */
  public void setLogoId(Long logoId) {
    this.logoId = logoId;
  }

  public Long getSharePicId() {
    return sharePicId;
  }

  public void setSharePicId(Long sharePicId) {
    this.sharePicId = sharePicId;
  }

  public Long getTwoDimensionCode() {
    return twoDimensionCode;
  }

  public void setTwoDimensionCode(Long twoDimensionCode) {
    this.twoDimensionCode = twoDimensionCode;
  }

  /**
   * @return the emailPostfix
   */
  public String getEmailPostfix() {
    return emailPostfix;
  }

  /**
   * @param emailPostfix
   *          the emailPostfix to set
   */
  public void setEmailPostfix(String emailPostfix) {
    this.emailPostfix = emailPostfix;
  }

  public String getAppId() {
    return appId;
  }

  public void setAppId(String appId) {
    this.appId = appId;
  }

  public String getAppSecret() {
    return appSecret;
  }

  public void setAppSecret(String appSecret) {
    this.appSecret = appSecret;
  }

  /**
   * @return the createAt
   */
  public Date getCreateAt() {
    return createAt;
  }

  /**
   * @param createAt
   *          the createAt to set
   */
  public void setCreateAt(Date createAt) {
    this.createAt = createAt;
  }

  /**
   * @return the dmMappingId
   */
  public Long getDmMappingId() {
    return dmMappingId;
  }

  /**
   * @param dmMappingId
   *          the dmMappingId to set
   */
  public void setDmMappingId(Long dmMappingId) {
    this.dmMappingId = dmMappingId;
  }

  /**
   * @return the jobReqMappingId
   */
  public Long getJobReqMappingId() {
    return jobReqMappingId;
  }

  /**
   * @param jobReqMappingId
   *          the jobReqMappingId to set
   */
  public void setJobReqMappingId(Long jobReqMappingId) {
    this.jobReqMappingId = jobReqMappingId;
  }

  /**
   * @return the lastModify
   */
  public Date getLastModify() {
    return lastModify;
  }

  /**
   * @param lastModify
   *          the lastModify to set
   */
  public void setLastModify(Date lastModify) {
    this.lastModify = lastModify;
  }

  public boolean getEnableJobSync() {
    return enableJobSync;
  }

  public void setEnableJobSync(boolean enableJobSync) {
    this.enableJobSync = enableJobSync;
  }

  public String getJobStatuses() {
    return jobStatuses;
  }

  public void setJobStatuses(String jobStatuses) {
    this.jobStatuses = jobStatuses;
  }

  /**
   * @return the triggerExpression
   */
  public String getTriggerExpression() {
    return triggerExpression;
  }

  /**
   * @param triggerExpression
   *          the triggerExpression to set
   */
  public void setTriggerExpression(String triggerExpression) {
    this.triggerExpression = triggerExpression;
  }

  public Date getLastJobSyncDate() {
    return lastJobSyncDate;
  }

  public void setLastJobSyncDate(Date lastJobSyncDate) {
    this.lastJobSyncDate = lastJobSyncDate;
  }
}
