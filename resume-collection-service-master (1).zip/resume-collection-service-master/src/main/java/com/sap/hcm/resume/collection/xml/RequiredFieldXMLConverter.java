package com.sap.hcm.resume.collection.xml;

import java.util.Collection;
import java.util.List;

import com.sap.hcm.resume.collection.entity.view.JobApplicationRequiredFieldVO;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.security.NullPermission;
import com.thoughtworks.xstream.security.PrimitiveTypePermission;

/**
 * @author I324117 SAP
 */
public class RequiredFieldXMLConverter {
  private static XStream stream = new XStream();

  private RequiredFieldXMLConverter() {

  }

  static {
    stream.autodetectAnnotations(true);
    stream.processAnnotations(JobApplicationRequiredFieldVO.class);

    // add permissions, allow some basics
    stream.addPermission(NullPermission.NULL);
    stream.addPermission(PrimitiveTypePermission.PRIMITIVES);
    stream.allowTypeHierarchy(Collection.class);
    // allow any type from the same package
    stream.allowTypesByWildcard(new String[] { JobApplicationRequiredFieldVO.class.getPackage().getName() + ".*" });
  }

  public static String convertFromBgElementToXML(List<JobApplicationRequiredFieldVO> requiredFieldList) {
    return stream.toXML(requiredFieldList);
  }

  public static Object convertFromXMLToBgElement(String xml) {
    return stream.fromXML(xml);
  }

}
