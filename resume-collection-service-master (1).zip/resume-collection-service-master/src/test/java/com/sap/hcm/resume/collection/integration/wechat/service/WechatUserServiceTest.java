package com.sap.hcm.resume.collection.integration.wechat.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.mail.Address;
import javax.mail.MessagingException;
import javax.mail.SendFailedException;
import javax.mail.StoreClosedException;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;

import com.sap.cloud.account.Account;
import com.sap.cloud.account.Tenant;
import com.sap.cloud.account.TenantContext;
import com.sap.core.connectivity.api.configuration.ConnectivityConfiguration;
import com.sap.core.connectivity.api.configuration.DestinationConfiguration;
import com.sap.hcm.resume.collection.context.TestContext;
import com.sap.hcm.resume.collection.entity.Photo;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatUser;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatUserResumeMapping;
import com.sap.hcm.resume.test.MockApplicationConfig;

@RunWith(PowerMockRunner.class)
@PowerMockRunnerDelegate(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { TestContext.class })
@PrepareForTest({ Transport.class })
public class WechatUserServiceTest {

  @Resource(name = "entityManager")
  private EntityManager entityManager;

  private WechatUserService wechatUserService;

  @Resource(name = "query")
  private Query query;

  @Autowired
  private ConnectivityConfiguration connectivityConfiguration;

  @Autowired
  private TenantContext tenantContext;

  @Before
  public void setUp() {
    reset(entityManager);
    wechatUserService = new WechatUserService();
    ReflectionTestUtils.setField(wechatUserService, "entityManager", entityManager);
    ReflectionTestUtils.setField(wechatUserService, "connectivityConfiguration", connectivityConfiguration);
    ReflectionTestUtils.setField(wechatUserService, "tenantContext", tenantContext);
  }

  @Test
  public void testGetCandidateListByWechatIdSuccess() throws ServiceApplicationException {
    List<WechatUserResumeMapping> expect = new ArrayList<WechatUserResumeMapping>();

    String wechatId = "w001";
    String companyId = "sap";
    List<WechatUserResumeMapping> list = new ArrayList<WechatUserResumeMapping>();
    String sel = "select urm from WechatUserResumeMapping urm where urm.wechatId = :wechatId and urm.companyId = :companyId";
    TypedQuery<WechatUserResumeMapping> mockedTypedQuery = MockApplicationConfig.fluentMock(TypedQuery.class);
    when(entityManager.createQuery(sel, WechatUserResumeMapping.class)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("wechatId", wechatId)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("companyId", companyId)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.getResultList()).thenReturn(list);

    List<WechatUserResumeMapping> result = wechatUserService.getCandidateListByWechatId(wechatId, companyId);
    assertEquals(expect, result);
  }

  @Test(expected = ServiceApplicationException.class)
  public void testGetCandidateListByWechatIdFailed() throws ServiceApplicationException {

    String wechatId = "w001";
    String companyId = "sap";
    wechatUserService.getCandidateListByWechatId(wechatId, companyId);
  }

  @Test
  public void testGetCandidateByCandidateIdSuccess() throws ServiceApplicationException {
    WechatUserResumeMapping expect = new WechatUserResumeMapping();
    expect.setCompanyId("sap");

    Long candidateId = new Long(1);
    WechatUserResumeMapping mapping = new WechatUserResumeMapping();
    mapping.setCompanyId("sap");
    String sel = "select urm from WechatUserResumeMapping urm where urm.candidateId = :candidateId";
    when(entityManager.createQuery(sel)).thenReturn(query);
    when(query.setParameter("candidateId", candidateId)).thenReturn(query);
    when(query.getSingleResult()).thenReturn(mapping);

    WechatUserResumeMapping result = wechatUserService.getCandidateByCandidateId(candidateId);
    assertEquals(expect.getCompanyId(), result.getCompanyId());
  }

  @Test(expected = ServiceApplicationException.class)
  public void testGetCandidateByCandidateIdFailed() throws ServiceApplicationException {

    Long candidateId = new Long(1);
    wechatUserService.getCandidateByCandidateId(candidateId);
  }

  @Test
  public void testSaveWechatUserSuccess() throws ServiceApplicationException {
    WechatUser expect = new WechatUser();
    expect.setCompanyId("sap");

    WechatUser wechatUser = new WechatUser();
    wechatUser.setCompanyId("sap");
    when(entityManager.merge(wechatUser)).thenReturn(wechatUser);

    WechatUser result = wechatUserService.saveWechatUser(wechatUser);
    assertEquals(expect.getCompanyId(), result.getCompanyId());
  }

  @Test
  public void testSaveWechatUserFailedParamIsNull() throws ServiceApplicationException {
    try {
      wechatUserService.saveWechatUser(null);
    } catch (Exception ex) {
      assertEquals("invalid wechat user request", ex.getMessage());
      assertTrue(ex instanceof ServiceApplicationException);
    }
  }

  @Test
  public void testSaveWechatUserFailed() throws ServiceApplicationException {
    WechatUser wechatUser = new WechatUser();
    wechatUser.setCompanyId("sap");
    when(entityManager.merge(wechatUser)).thenThrow(Exception.class);
    try {
      wechatUserService.saveWechatUser(wechatUser);
    } catch (Exception ex) {
      assertEquals(null, ex.getMessage());
      assertTrue(ex instanceof ServiceApplicationException);
    }
  }

  @Test
  public void testSaveImgSuccess() throws ServiceApplicationException {
    Photo expect = new Photo();
    expect.setPhotoId(new Long(8));

    Photo photo = new Photo();
    photo.setPhotoId(new Long(8));
    when(entityManager.merge(photo)).thenReturn(photo);

    Photo result = wechatUserService.saveImg(photo);
    assertEquals(expect.getPhotoId(), result.getPhotoId());
  }

  @Test
  public void testCheckResumeAlreadyImportedSuccessTrue() throws ServiceApplicationException {

    String wechatId = "w001";
    String companyId = "sap";
    String vendorName = "extVendor";
    String externalResumeId = "ext001";
    String language = "zh";
    boolean isSameResumeId = true;

    String sel = "select count(urm) from WechatUserResumeMapping urm where urm.wechatId = :wechatId and urm.companyId = :companyId"
        + " and urm.vendorName = :vendorName and urm.externalResumeId = :resumeId and urm.language = :language";
    TypedQuery<Long> mockedTypedQuery = MockApplicationConfig.fluentMock(TypedQuery.class);
    when(entityManager.createQuery(sel, Long.class)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("wechatId", wechatId)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("companyId", companyId)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("vendorName", vendorName)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("resumeId", externalResumeId)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("language", language)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.getSingleResult()).thenReturn(new Long(1));

    boolean result = wechatUserService.checkResumeAlreadyImported(wechatId, companyId, vendorName, externalResumeId,
        language, isSameResumeId);
    assertTrue(result);
  }

  @Test
  public void testCheckResumeAlreadyImportedSuccessFalse() throws ServiceApplicationException {

    String wechatId = "w001";
    String companyId = "sap";
    String vendorName = "extVendor";
    String externalResumeId = "ext001";
    String language = "zh";
    boolean isSameResumeId = false;

    String sel = "select count(urm) from WechatUserResumeMapping urm where urm.wechatId = :wechatId and urm.companyId = :companyId"
        + " and urm.vendorName = :vendorName and urm.externalResumeId = :resumeId";
    TypedQuery<Long> mockedTypedQuery = MockApplicationConfig.fluentMock(TypedQuery.class);
    when(entityManager.createQuery(sel, Long.class)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("wechatId", wechatId)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("companyId", companyId)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("vendorName", vendorName)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("resumeId", externalResumeId)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.getSingleResult()).thenReturn(new Long(0));

    boolean result = wechatUserService.checkResumeAlreadyImported(wechatId, companyId, vendorName, externalResumeId,
        language, isSameResumeId);
    Assert.assertFalse(result);
  }

  @Test
  public void testGetUserInfoByWechatIdSuccess() throws ServiceApplicationException {
    WechatUser expect = new WechatUser();
    expect.setCompanyId("sap");

    String wechatId = "w001";
    String companyId = "sap";
    WechatUser wechatUser = new WechatUser();
    wechatUser.setCompanyId("sap");
    String sel = "select wu from WechatUser wu where wu.wechatId = :wechatId " + "and wu.companyId = :companyId";
    when(entityManager.createQuery(sel)).thenReturn(query);
    when(query.setParameter("wechatId", wechatId)).thenReturn(query);
    when(query.setParameter("companyId", companyId)).thenReturn(query);
    when(query.getSingleResult()).thenReturn(wechatUser);

    WechatUser result = wechatUserService.getUserInfoByEmail(wechatId, companyId);
    assertEquals(expect.getCompanyId(), result.getCompanyId());
  }

  @Test
  public void testGetUserInfoByWechatIdFailed() throws ServiceApplicationException {
    String wechatId = "w001";
    String companyId = "sap";

    WechatUser result = wechatUserService.getUserInfoByEmail(wechatId, companyId);
    assertEquals(null, result);
  }

  @Test
  public void testSaveUserResumeMappingSuccessUserExist() throws ServiceApplicationException {
    String wechatId = "w001";
    String companyId = "sap";
    Long candidateId = new Long(1);
    WechatUserResumeMapping userResumeMapping = new WechatUserResumeMapping();
    String sel = "select urm from WechatUserResumeMapping urm where urm.wechatId = :wechatId "
        + "and urm.companyId = :companyId " + "and urm.candidateId = :candidateId";
    TypedQuery<WechatUserResumeMapping> mockedTypedQuery = MockApplicationConfig.fluentMock(TypedQuery.class);
    when(entityManager.createQuery(sel, WechatUserResumeMapping.class)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("wechatId", wechatId)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("companyId", companyId)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("candidateId", candidateId)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.getSingleResult()).thenReturn(userResumeMapping);

    try {
      wechatUserService.saveUserResumeMapping(userResumeMapping);
    } catch (Exception ex) {
      fail();
    }
  }

  @Test
  public void testSaveUserResumeMappingSuccess() throws ServiceApplicationException {
    String wechatId = "w001";
    String companyId = "sap";
    Long candidateId = new Long(1);
    WechatUserResumeMapping userResumeMapping = new WechatUserResumeMapping();
    String sel = "select urm from WechatUserResumeMapping urm where urm.wechatId = :wechatId "
        + "and urm.companyId = :companyId " + "and urm.candidateId = :candidateId";
    TypedQuery<WechatUserResumeMapping> mockedTypedQuery = MockApplicationConfig.fluentMock(TypedQuery.class);
    when(entityManager.createQuery(sel, WechatUserResumeMapping.class)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("wechatId", wechatId)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("companyId", companyId)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("candidateId", candidateId)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.getSingleResult()).thenThrow(PersistenceException.class);
    Mockito.doNothing().when(entityManager).persist(userResumeMapping);

    try {
      wechatUserService.saveUserResumeMapping(userResumeMapping);
    } catch (Exception ex) {
      fail();
    }
  }

  @Test
  public void testSaveUserResumeMappingFailed() throws ServiceApplicationException {
    WechatUserResumeMapping userResumeMapping = new WechatUserResumeMapping();

    try {
      wechatUserService.saveUserResumeMapping(userResumeMapping);
      fail();
    } catch (Exception ex) {
      assertTrue(ex instanceof ServiceApplicationException);
    }
  }

  @Test
  public void testDeleteUserResumeMappingByIdSuccess() throws ServiceApplicationException {
    Integer expect = 1;

    Long candidateId = new Long(1);
    String sel = "delete from WechatUserResumeMapping urm where urm.candidateId = :candidateId";
    when(entityManager.createQuery(sel)).thenReturn(query);
    when(query.setParameter("candidateId", candidateId)).thenReturn(query);
    Mockito.doReturn(new Integer(1)).when(query).executeUpdate();

    Integer result = wechatUserService.deleteUserResumeMappingById(candidateId);
    assertEquals(expect, result);
  }

  @Test
  public void testDeleteUserResumeMappingByIdFailed() throws ServiceApplicationException {
    Integer expect = -1;

    Long candidateId = new Long(1);
    String sel = "delete from WechatUserResumeMapping urm where urm.candidateId = :candidateId";
    when(entityManager.createQuery(sel)).thenReturn(query);
    when(query.setParameter("candidateId", candidateId)).thenReturn(query);
    when(query.executeUpdate()).thenThrow(PersistenceException.class);

    Integer result = wechatUserService.deleteUserResumeMappingById(candidateId);
    assertEquals(expect, result);
  }

  @Test
  public void testSendVerificationCodeSuccessTypeIsNotMail() throws ServiceApplicationException {
    String email = "aa@bb.com";
    String verifyCode = "1234";
    Tenant tenant = Mockito.mock(Tenant.class);
    when(tenantContext.getTenant()).thenReturn(tenant);
    Account account = Mockito.mock(Account.class);
    when(tenant.getAccount()).thenReturn(account);
    when(account.getId()).thenReturn(new String("dev_default"));
    DestinationConfiguration destConfiguration = Mockito.mock(DestinationConfiguration.class);
    when(connectivityConfiguration.getConfiguration("VERIFY_INTERNAL_EMAIL")).thenReturn(destConfiguration);
    wechatUserService.sendVerificationCode(email, verifyCode);
  }

  @Test
  public void testSendVerificationCodeSuccessIsNotDevDefault() throws ServiceApplicationException {
    String email = "aa@bb.com";
    String verifyCode = "1234";
    Tenant tenant = Mockito.mock(Tenant.class);
    when(tenantContext.getTenant()).thenReturn(tenant);
    Account account = Mockito.mock(Account.class);
    when(tenant.getAccount()).thenReturn(account);
    when(account.getId()).thenReturn(new String("id"));
    DestinationConfiguration destConfiguration = Mockito.mock(DestinationConfiguration.class);
    when(connectivityConfiguration.getConfiguration("id", "VERIFY_INTERNAL_EMAIL")).thenReturn(destConfiguration);
    wechatUserService.sendVerificationCode(email, verifyCode);
  }

  @Test(expected = ServiceApplicationException.class)
  public void testSendVerificationCodeFailedWithSendFailedException() throws ServiceApplicationException,
      MessagingException {
    String email = "aa@bb.com";
    String verifyCode = "1234";
    Tenant tenant = Mockito.mock(Tenant.class);
    when(tenantContext.getTenant()).thenReturn(tenant);
    Account account = Mockito.mock(Account.class);
    when(tenant.getAccount()).thenReturn(account);
    when(account.getId()).thenReturn(new String("dev_default"));
    DestinationConfiguration destConfiguration = Mockito.mock(DestinationConfiguration.class);
    when(connectivityConfiguration.getConfiguration("VERIFY_INTERNAL_EMAIL")).thenReturn(destConfiguration);
    when(destConfiguration.getProperty("Type")).thenReturn(new String("MAIL"));
    when(destConfiguration.getProperty("mail.user")).thenReturn(new String("user"));
    when(destConfiguration.getProperty("mail.password")).thenReturn(new String("pwd"));
    when(destConfiguration.getProperty("mail.smtp.host")).thenReturn(new String("host"));
    when(destConfiguration.getProperty("mail.smtp.port")).thenReturn(new String("port"));
    when(destConfiguration.getProperty("mail.smtp.starttls.enable")).thenReturn(new String("enable"));

    PowerMockito.mockStatic(Transport.class);
    SendFailedException sfe = new SendFailedException();
    PowerMockito.doThrow(new SendFailedException()).when(Transport.class);
    Transport.send(any(MimeMessage.class));
    SendFailedException sfex = PowerMockito.mock(SendFailedException.class);
    InternetAddress internetAddress = new InternetAddress();
    internetAddress.setAddress("abc.sap.com");
    Address[] invalid = new Address[1];
    invalid[0] = internetAddress;
    PowerMockito.doReturn(invalid).when(sfex).getInvalidAddresses();
    wechatUserService.sendVerificationCode(email, verifyCode);
  }

  @Test(expected = ServiceApplicationException.class)
  public void testSendVerificationCodeFailedWithMessagingException() throws ServiceApplicationException,
      MessagingException {
    String email = "aa@bb.com";
    String verifyCode = "1234";
    Tenant tenant = Mockito.mock(Tenant.class);
    when(tenantContext.getTenant()).thenReturn(tenant);
    Account account = Mockito.mock(Account.class);
    when(tenant.getAccount()).thenReturn(account);
    when(account.getId()).thenReturn(new String("dev_default"));
    DestinationConfiguration destConfiguration = Mockito.mock(DestinationConfiguration.class);
    when(connectivityConfiguration.getConfiguration("VERIFY_INTERNAL_EMAIL")).thenReturn(destConfiguration);
    when(destConfiguration.getProperty("Type")).thenReturn(new String("MAIL"));
    when(destConfiguration.getProperty("mail.user")).thenReturn(new String("user"));
    when(destConfiguration.getProperty("mail.password")).thenReturn(new String("pwd"));
    when(destConfiguration.getProperty("mail.smtp.host")).thenReturn(new String("host"));
    when(destConfiguration.getProperty("mail.smtp.port")).thenReturn(new String("port"));
    when(destConfiguration.getProperty("mail.smtp.starttls.enable")).thenReturn(new String("enable"));

    PowerMockito.mockStatic(Transport.class);
    MessagingException sfe = new MessagingException();
    PowerMockito.doThrow(new MessagingException()).when(Transport.class);
    Transport.send(any(MimeMessage.class));
    MessagingException sfex = PowerMockito.mock(MessagingException.class);
    InternetAddress internetAddress = new InternetAddress();
    internetAddress.setAddress("abc.sap.com");
    Address[] invalid = new Address[1];
    invalid[0] = internetAddress;
    wechatUserService.sendVerificationCode(email, verifyCode);
  }

  @Test(expected = ServiceApplicationException.class)
  public void testSendVerificationCodeFailedWithOtherException() throws ServiceApplicationException, MessagingException {
    String email = "aa@bb.com";
    String verifyCode = "1234";
    Tenant tenant = Mockito.mock(Tenant.class);
    when(tenantContext.getTenant()).thenReturn(tenant);
    Account account = Mockito.mock(Account.class);
    when(tenant.getAccount()).thenReturn(account);
    when(account.getId()).thenReturn(new String("dev_default"));
    DestinationConfiguration destConfiguration = Mockito.mock(DestinationConfiguration.class);
    when(connectivityConfiguration.getConfiguration("VERIFY_INTERNAL_EMAIL")).thenReturn(destConfiguration);
    when(destConfiguration.getProperty("Type")).thenReturn(new String("MAIL"));
    when(destConfiguration.getProperty("mail.user")).thenReturn(new String("user"));
    when(destConfiguration.getProperty("mail.password")).thenReturn(new String("pwd"));
    when(destConfiguration.getProperty("mail.smtp.host")).thenReturn(new String("host"));
    when(destConfiguration.getProperty("mail.smtp.port")).thenReturn(new String("port"));
    when(destConfiguration.getProperty("mail.smtp.starttls.enable")).thenReturn(new String("enable"));

    PowerMockito.mockStatic(Transport.class);
    StoreClosedException sfe = new StoreClosedException(null);
    PowerMockito.doThrow(new StoreClosedException(null)).when(Transport.class);
    Transport.send(any(MimeMessage.class));
    StoreClosedException sfex = PowerMockito.mock(StoreClosedException.class);
    InternetAddress internetAddress = new InternetAddress();
    internetAddress.setAddress("abc.sap.com");
    Address[] invalid = new Address[1];
    invalid[0] = internetAddress;
    wechatUserService.sendVerificationCode(email, verifyCode);
  }
}
