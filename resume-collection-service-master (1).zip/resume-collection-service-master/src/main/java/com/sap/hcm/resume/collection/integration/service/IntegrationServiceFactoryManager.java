package com.sap.hcm.resume.collection.integration.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import com.sap.hcm.resume.collection.integration.bean.TargetSystem;

/**
 * @author I075908 SAP
 */
@Component
public class IntegrationServiceFactoryManager {

  private static final Logger logger = LoggerFactory.getLogger(IntegrationServiceFactoryManager.class);

//  @Autowired
//  SystemConfig sysConfig;

  @Autowired
  @Qualifier(value="sfIntegrationServiceFactory")
  @Lazy
  IntegrationServiceFactory sfFactory;

  /**
   * @return integrationServiceFactory
   */
  public IntegrationServiceFactory getFactory() {
    IntegrationServiceFactory result = null;

    TargetSystem target = TargetSystem.SF;
    switch (target) {
    case SF:
      result = sfFactory;
      break;
    case NONE:
    default:
      break;
    }

    if (result == null) {
      String msg = "The implementation of IntegrationServiceFactory was not found for target system: "
          + target.getName();
      logger.error(msg);
    }

    return result;
  }
}