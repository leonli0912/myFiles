package com.sap.hcm.resume.collection.integration.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.olingo.odata2.api.edm.Edm;
import org.apache.olingo.odata2.api.ep.EntityProviderException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.bean.SimpleJsonResponse;
import com.sap.hcm.resume.collection.context.TestContext;
import com.sap.hcm.resume.collection.context.WebAppContext;
import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.entity.DataModelMapping;
import com.sap.hcm.resume.collection.entity.view.JobRequisitionMappingVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.hcp.HCPUserProvider;
import com.sap.hcm.resume.collection.integration.bean.JobReqDataModelMapping;
import com.sap.hcm.resume.collection.integration.sf.SFOdataFormatter;
import com.sap.hcm.resume.collection.integration.sf.odata.SFODataService;
import com.sap.hcm.resume.collection.service.CompanyInfoService;
import com.sap.hcm.resume.collection.service.DataModelMappingService;
import com.sap.hcm.resume.collection.util.ChangeLogUtil;
import com.sap.hcm.resume.collection.util.MockHCPUser;
import com.sap.security.um.user.User;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { TestContext.class, WebAppContext.class })
public class JobRequisitionDataModelControllerTest {
  private JobRequisitionDataModelController controller;

  @Autowired
  private SFODataService sfODataService;

  @Autowired
  protected CompanyInfoService compInfoService;

  @Autowired
  protected HCPUserProvider hcpUserProvider;

  private DataModelMapping mapping;

  @Autowired
  private SFOdataFormatter sfOdataFormatter;

  @Autowired
  private WebApplicationContext webApplicationContext;

  @Autowired
  private ChangeLogUtil changeLogUtil;
  
  @Autowired
  private DataModelMappingService mappingService;
  
  @Autowired
  private Params params;

  @Before
  public void setUp() {
    params.setCompanyId("sap");
    
    controller = spy(new JobRequisitionDataModelController());
    ReflectionTestUtils.setField(controller, "mappingService", mappingService);
    ReflectionTestUtils.setField(controller, "sfODataService", sfODataService);
    ReflectionTestUtils.setField(controller, "hcpUserProvider", hcpUserProvider);
    ReflectionTestUtils.setField(controller, "sfOdataFormatter", sfOdataFormatter);
    ReflectionTestUtils.setField(controller, "compInfoService", compInfoService);
    ReflectionTestUtils.setField(controller, "changeLogUtil", changeLogUtil);
    ReflectionTestUtils.setField(controller, "params", params);
    buildDataModelMapping();
  }

  private void buildDataModelMapping() {
    mapping = new DataModelMapping();
    mapping.setCompanyId("sap");
    mapping.setCreateBy("Ryan");
    mapping.setMappingContent(null);
    mapping.setMappingId((long) 123);
    mapping.setMappingName("mapping");
    mapping.setMappingType("job_req_mapping");
    mapping.setTargetSystem("SF");
    mapping.setMappingContent(new String("<jobreq-model-mapping><items>"
        + "<jobreq-mapping-item><sourceField>externalJobId</sourceField><sfDmField>jobReqId</sfDmField>"
        + "<label>REQUISITION_ID</label><filterable>false</filterable></jobreq-mapping-item>"
        + "</items></jobreq-model-mapping>").getBytes());
  }

  @Test
  public void testListjobReqDMMapping() throws ServiceApplicationException {

    CompanyInfo compInfo = new CompanyInfo();
    compInfo.setJobReqMappingId((long)1);
    when(compInfoService.getCompanyInfo("sap")).thenReturn(compInfo);
    Map<String, Object> result = controller.listjobReqDMMapping(0, 20);
    assertEquals(2, result.size());
  }

  @Test
  public void testListjobReqDMMappingbyId() {
    JobRequisitionMappingVO result = controller.listjobReqDMMappingbyId((long) 123);
    assertEquals(null, result);
  }

  @Test
  public void testNewjobReqDMMapping() {
    JobReqDataModelMapping result = controller.newjobReqDMMapping();
    assertEquals(null, result);
  }

  @Test
  public void testDeleteReqMapping_Success() throws JsonProcessingException, ServiceApplicationException {
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(0);
    rsp.setMessage("success");
    
    params.setCompanyId("sap");
    
    MockHttpServletRequest mockRequest = new MockHttpServletRequest();
    User loginUser = new MockHCPUser();
    Mockito.when(hcpUserProvider.getLoginUser(mockRequest)).thenReturn(loginUser);

    Mockito.when(mappingService.getMappingById(123L)).thenReturn(mapping);
    
    CompanyInfo compInfo = new CompanyInfo();
    compInfo.setCompanyId("sap");
    compInfo.setJobReqMappingId(1L);
    Mockito.when(compInfoService.getCompanyInfo("sap")).thenReturn(compInfo);
    
    SimpleJsonResponse result = controller.deleteReqMapping(mockRequest, 123L);
    assertEquals(new ObjectMapper().writeValueAsString(rsp), new ObjectMapper().writeValueAsString(result));
  }

  @Test
  public void testSaveReqMapping_Failure() throws MalformedURLException, ServiceApplicationException,
      JsonProcessingException {
    
    params.setCompanyId(null);
    
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(-1);
    rsp.setMessage("companyId is missing");

    HttpServletRequest mockRequest = mock(HttpServletRequest.class);
    User loginUser = new MockHCPUser();
    JobRequisitionMappingVO mapping = new JobRequisitionMappingVO();
    Mockito.when(hcpUserProvider.getLoginUser(mockRequest)).thenReturn(loginUser);

    SimpleJsonResponse result = controller.saveReqMapping(mapping, mockRequest);
    assertEquals(new ObjectMapper().writeValueAsString(rsp), new ObjectMapper().writeValueAsString(result));
  }

  @Test
  public void testSaveReqMapping_ThrowException() throws ServiceApplicationException, EntityProviderException,
      IOException {
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(-1);

    HttpServletRequest mockRequest = mock(HttpServletRequest.class);
    JobRequisitionMappingVO mapping = new JobRequisitionMappingVO();
    User loginUser = new MockHCPUser();

    Mockito.when(hcpUserProvider.getLoginUser(mockRequest)).thenReturn(loginUser);
    Mockito.doThrow(new ServiceApplicationException("")).when(sfOdataFormatter).checkJobReqPicklistNavi(Mockito.any(Edm.class), Mockito.any(JobRequisitionMappingVO.class));

    SimpleJsonResponse result = controller.saveReqMapping(mapping, mockRequest);
    assertEquals(rsp.getCode(), result.getCode());
  }

  @Test
  public void testSaveReqMapping_Success() throws ServiceApplicationException, EntityProviderException, IOException {
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(0);
    rsp.setMessage("success");

    HttpServletRequest mockRequest = mock(HttpServletRequest.class);
    JobRequisitionMappingVO mapping = new JobRequisitionMappingVO();
    DataModelMapping mapping1 = new DataModelMapping();
    mapping1.setMappingId(123L);
    mapping.setMappingName("mappingName");
    mapping.setId(123L);
    User loginUser = new MockHCPUser();
    Edm edm = Mockito.mock(Edm.class);

    Mockito.when(mockRequest.getParameter("companyId")).thenReturn("sap");
    Mockito.when(hcpUserProvider.getLoginUser(mockRequest)).thenReturn(loginUser);
    Mockito.doNothing().when(sfOdataFormatter).checkJobReqPicklistNavi(edm, mapping);
    Mockito.when(mappingService.saveJobRequisitionMapping(Mockito.any(JobRequisitionMappingVO.class), Mockito.any(String.class))).thenReturn(mapping1);

    SimpleJsonResponse result = controller.saveReqMapping(mapping, mockRequest);
    assertEquals(new ObjectMapper().writeValueAsString(rsp), new ObjectMapper().writeValueAsString(result));
  }

  @Test
  public void testExportMappingById_Success() throws ServiceApplicationException {
    HttpServletResponse response = mock(HttpServletResponse.class);
    Mockito.when(mappingService.getApplyDataModelMappingByMappingId((long) 123)).thenReturn(mapping);

    ResponseEntity<byte[]> result = controller.exportMappingById((long) 123, response);
    assertEquals(HttpStatus.OK, result.getStatusCode());
  }

  @Test(expected = ServiceApplicationException.class)
  public void testExportMappingById_EmptyContent() throws ServiceApplicationException {
    HttpServletResponse response = mock(HttpServletResponse.class);
    mapping.setMappingContent(null);
    Mockito.when(mappingService.getApplyDataModelMappingByMappingId((long) 123)).thenReturn(mapping);

    controller.exportMappingById((long) 123, response);
  }

  @Test
  public void testImportMapping_Success() throws Exception {
    ClassPathResource resource = new ClassPathResource("/mapping/job_requisition_model_mapping.xml");
    InputStream is = null;
    try {
      is = resource.getInputStream();
      String fileContent = IOUtils.toString(is, StandardCharsets.UTF_8.toString());

      MockMvc mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
      ResultActions result = mockMvc.perform(MockMvcRequestBuilders.fileUpload("/jobreq/import")
          .content(this.createMultipartContent("mapping", "application/data", fileContent))
          .contentType("multipart/form-data; boundary=----WebKitFormBoundary8HC1OQgjqvtgc5tk"));
      result.andExpect(MockMvcResultMatchers.status().is(200));
      String content = result.andReturn().getResponse().getContentAsString();

      ObjectMapper om = new ObjectMapper();
      Map<?, ?> responseJson = om.readValue(content, Map.class);
      List<?> resultList = (List<?>) responseJson.get("items");
      Assert.assertEquals(resultList.size(), 21);
    } catch (IOException e) {
    } finally {
      IOUtils.closeQuietly(is);
    }
  }

  @Test
  public void testImportMapping_EmptyContent() throws Exception {
    MockMvc mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
    ResultActions result = mockMvc.perform(MockMvcRequestBuilders.fileUpload("/jobreq/import").contentType(
        "multipart/form-data; boundary=----WebKitFormBoundary8HC1OQgjqvtgc5tk"));
    result.andExpect(MockMvcResultMatchers.status().is(200));
    String content = result.andReturn().getResponse().getContentAsString();
    Assert.assertEquals("", content);
  }

  private byte[] createMultipartContent(String fileName, String contentType, String fileContent) {
    String endline = "\r\n";
    String bondary = "----WebKitFormBoundary8HC1OQgjqvtgc5tk";
    String textFile = this.encodeTextFile(bondary, "\r\n", "file", fileName, contentType, fileContent);
    StringBuilder content = new StringBuilder(textFile.toString());
    content.append(endline);
    content.append(endline);
    content.append(endline);
    content.append("--");
    content.append(bondary);
    content.append("--");
    content.append(endline);
    return content.toString().getBytes();
  }

  private String encodeTextFile(String bondary, String endline, String name, String filename, String contentType,
      String content) {

    final StringBuilder sb = new StringBuilder();
    sb.append(endline);
    sb.append("--");
    sb.append(bondary);
    sb.append(endline);
    sb.append("Content-Disposition: form-data; name=\"");
    sb.append(name);
    sb.append("\"; filename=\"");
    sb.append(filename);
    sb.append("\"");
    sb.append(endline);
    sb.append("Content-Type: ");
    sb.append(contentType);
    sb.append(endline);
    sb.append(endline);
    sb.append(content);
    return sb.toString();
  }
}
