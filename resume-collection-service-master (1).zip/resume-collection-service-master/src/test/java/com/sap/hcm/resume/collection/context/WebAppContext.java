package com.sap.hcm.resume.collection.context;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

@Configuration
@EnableWebMvc
@ComponentScan(basePackages = { "com.sap.hcm.resume.collection.controller", "com.sap.hcm.resume.collection.integration.controller",
    "com.sap.hcm.resume.collection.integration.service.ResumeService"})
public class WebAppContext extends WebMvcConfigurerAdapter {

}
