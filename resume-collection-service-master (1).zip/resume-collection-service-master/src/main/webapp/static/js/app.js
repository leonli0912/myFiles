sap.ui.localResources("static.js.layout");
sap.ui.localResources("static.js");
sap.ui.localResources("static.i18n");
sap.ui.localResources("static.i18n.wechat");

jQuery.sap.registerModulePath('com.sap.rcs', 'static/js/');
jQuery.sap.require("jquery.sap.resources");

sap.ui.require(["com/sap/rcs/UserInfoUtil"], function(UserInfoUtil){

	var userInfoUtil= new UserInfoUtil();
	var compContainer = new sap.ui.core.ComponentContainer({
		name:"com.sap.rcs"
	});

	var oShell = userInfoUtil.createShell(compContainer);
	oShell.placeAt("content");

	var sLocale = sap.ui.getCore().getConfiguration().getLanguage();
	var resModel = new sap.ui.model.resource.ResourceModel({bundleName:"static.i18n.i18n",bundleLocale:sLocale});
	oShell.setModel(resModel, "i18n");
})
