package com.sap.hcm.resume.collection.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.sap.hcm.resume.collection.entity.ChangeLog;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.util.CandidateDateUtil;

@Service
public class ChangeLogService {

  /**
   * logger instance
   */
  private static final Logger logger = LoggerFactory.getLogger(ChangeLogService.class);

  @PersistenceContext
  private EntityManager entityManager;

  public List<ChangeLog> getChangeLogList(String companyId, String changedBy, String objectType)
      throws ServiceApplicationException {

    List<ChangeLog> changeLogList = new ArrayList<ChangeLog>();
    try {
      String sel = "select cl from ChangeLog cl where cl.companyId = :companyId AND cl.objectType = :objectType";
      if (!StringUtils.isEmpty(changedBy)) {
        sel = sel + " AND cl.changedBy = :changedBy";
      }

      sel = sel + " order by cl.changeAt desc";

      TypedQuery<ChangeLog> queryChangeLog = entityManager.createQuery(sel, ChangeLog.class);
      queryChangeLog.setParameter("companyId", companyId);
      queryChangeLog.setParameter("objectType", objectType);
      if (!StringUtils.isEmpty(changedBy)) {
        queryChangeLog.setParameter("changedBy", changedBy);
      }
      changeLogList = queryChangeLog.getResultList();
    } catch (Exception ex) {
      throw new ServiceApplicationException(ex.getMessage());
    }
    return changeLogList;
  }

  public ChangeLog saveChangeLog(ChangeLog changeLog) throws ServiceApplicationException {
    changeLog.setChangeAt(CandidateDateUtil.formatDate2String(new Date(), "yyyy-MM-dd HH:mm:ss"));
    changeLog = entityManager.merge(changeLog);
    return changeLog;
  }

  public int deleteOverdueChangeLog() throws ServiceApplicationException {
    int res = -1;
    try {
      String deleteCl = "delete from ChangeLog cl where cl.changeAt < :changeAt";
      Query query = entityManager.createQuery(deleteCl);
      query.setParameter("changeAt", CandidateDateUtil.formatDate2StringMinus6Months("yyyy-MM-dd HH:mm:ss"));
      res = query.executeUpdate();
    } catch (Exception ex) {
      logger.error(ex.getMessage());
      res = -1;
    }
    return res;
  }

}
