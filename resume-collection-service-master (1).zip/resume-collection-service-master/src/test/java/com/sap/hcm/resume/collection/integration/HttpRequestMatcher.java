package com.sap.hcm.resume.collection.integration;

import org.apache.http.client.methods.HttpRequestBase;
import org.mockito.ArgumentMatcher;

public class HttpRequestMatcher extends ArgumentMatcher<HttpRequestBase>{
  
  private final String compareValue;
  
  public HttpRequestMatcher(String compareValue){
    this.compareValue = compareValue;
  }
  @Override
  public boolean matches(Object argument) {
    HttpRequestBase item= (HttpRequestBase) argument;
    if(compareValue!= null){
        if (item != null) {
            return item.getURI().toString().contains(compareValue);
        }
    }else {
        return item == null || item.getURI() == null;
    }
    return false;
  }
  
}
