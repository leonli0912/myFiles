package com.sap.hcm.resume.collection.bean;

import java.io.Serializable;

public class JobRequisitionAttribute implements Serializable{
    
    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = -247388955420046526L;

    private String name;
    
    private String type;
    
    private String label;
    
    private boolean filterable = false;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    /**
     * @return the filterable
     */
    public boolean isFilterable() {
        return filterable;
    }

    /**
     * @param filterable the filterable to set
     */
    public void setFilterable(boolean filterable) {
        this.filterable = filterable;
    }
}
