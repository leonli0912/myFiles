package com.sap.hcm.resume.collection.entity.view;


import org.junit.Assert;
import org.junit.Test;


public class CandidateBgCertificateVOTest {
  
  @Test
  public void test(){
    CandidateBgCertificateVO vo = new CandidateBgCertificateVO();
    
    vo.setDescription("test");
    vo.setEndDate("test");
    vo.setInstitution("test");
    vo.setName("test");
    vo.setScore("test");
    vo.setStartDate("test");
    
    Assert.assertEquals(vo.getDescription(), "test");
    Assert.assertEquals(vo.getEndDate(), "test");
    Assert.assertEquals(vo.getInstitution(), "test");
    Assert.assertEquals(vo.getName(), "test");
    Assert.assertEquals(vo.getScore(), "test");
    Assert.assertEquals(vo.getStartDate(), "test");
    
  }
}
