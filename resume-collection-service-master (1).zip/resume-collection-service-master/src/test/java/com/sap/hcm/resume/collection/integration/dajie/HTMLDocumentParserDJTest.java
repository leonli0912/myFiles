package com.sap.hcm.resume.collection.integration.dajie;

import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;

import org.apache.commons.io.IOUtils;
import org.jsoup.nodes.Document;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.context.MessageSource;
import org.springframework.core.io.ClassPathResource;

import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.util.CandidateFileUtil;

public class HTMLDocumentParserDJTest {
  @Test
  public void testParseProfile() throws ServiceApplicationException, IOException {
    MessageSource ms = Mockito.mock(MessageSource.class);
    ClassPathResource resume = new ClassPathResource("resumes/parser/DAJIE_TEST_CN.html");
    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    InputStream is = null;
    try {
      is = resume.getInputStream();
      Document resumeContent = CandidateFileUtil.getFileContentFromHtml(IOUtils.toByteArray(is));

      HTMLDocumentParserDJ parser = new HTMLDocumentParserDJ(ms);
      CandidateProfileVO result = parser.parseProfile(candidateProfileVO, resumeContent);
      Assert.assertEquals(result.getFirstName(), "梦璃 ");
    } catch (IOException e) {
    } finally {
      IOUtils.closeQuietly(is);
    }
  }

  @Test
  public void testParseBackgroundWorkExp() throws ServiceApplicationException, IOException {
    MessageSource ms = Mockito.mock(MessageSource.class);
    ClassPathResource resume = new ClassPathResource("resumes/parser/DAJIE_TEST_CN.html");
    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    InputStream is = null;
    try {
      is = resume.getInputStream();
      Document resumeContent = CandidateFileUtil.getFileContentFromHtml(IOUtils.toByteArray(is));

      HTMLDocumentParserDJ parser = new HTMLDocumentParserDJ(ms);
      CandidateProfileVO result = parser.parseBackgroundWorkExp(candidateProfileVO, resumeContent);
      Assert.assertEquals(2, result.getWorkExprs().size());
    } catch (IOException e) {
    } finally {
      IOUtils.closeQuietly(is);
    }
  }

  @Test
  public void testParseBackgroundEducation() throws ServiceApplicationException, IOException {
    MessageSource ms = Mockito.mock(MessageSource.class);
    ClassPathResource resume = new ClassPathResource("resumes/parser/DAJIE_TEST_CN.html");
    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    InputStream is = null;
    try {
      is = resume.getInputStream();
      Document resumeContent = CandidateFileUtil.getFileContentFromHtml(IOUtils.toByteArray(is));

      HTMLDocumentParserDJ parser = new HTMLDocumentParserDJ(ms);
      CandidateProfileVO result = parser.parseBackgroundEducation(candidateProfileVO, resumeContent);
      Assert.assertEquals(1, result.getEducation().size());
    } catch (IOException e) {
    } finally {
      IOUtils.closeQuietly(is);
    }
  }

  @Test
  public void testParseBackgroundLanguage() throws ServiceApplicationException, IOException {
    MessageSource ms = Mockito.mock(MessageSource.class);
    Mockito.when(ms.getMessage(Mockito.anyString(), Mockito.any(Object[].class), Mockito.any(Locale.class)))
        .thenReturn("ENGLISH");
    ClassPathResource resume = new ClassPathResource("resumes/parser/DAJIE_TEST_CN.html");
    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    InputStream is = null;
    try {
      is = resume.getInputStream();
      Document resumeContent = CandidateFileUtil.getFileContentFromHtml(IOUtils.toByteArray(is));

      HTMLDocumentParserDJ parser = new HTMLDocumentParserDJ(ms);
      CandidateProfileVO result = parser.parseBackgroundLanguage(candidateProfileVO, resumeContent);
      Assert.assertEquals(2, result.getLanguages().size());
    } catch (IOException e) {
    } finally {
      IOUtils.closeQuietly(is);
    }
  }

  @Test
  public void testParseBackgroundCertificate() throws ServiceApplicationException, IOException {
    MessageSource ms = Mockito.mock(MessageSource.class);
    Mockito.when(ms.getMessage(Mockito.anyString(), Mockito.any(Object[].class), Mockito.any(Locale.class)))
        .thenReturn("ENGLISH");
    ClassPathResource resume = new ClassPathResource("resumes/parser/DAJIE_TEST_CN.html");
    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    InputStream is = null;
    try {
      is = resume.getInputStream();
      Document resumeContent = CandidateFileUtil.getFileContentFromHtml(IOUtils.toByteArray(is));

      HTMLDocumentParserDJ parser = new HTMLDocumentParserDJ(ms);
      CandidateProfileVO result = parser.parseBackgroundCertificate(candidateProfileVO, resumeContent);
      Assert.assertEquals(2, result.getCertificates().size());
    } catch (IOException e) {
    } finally {
      IOUtils.closeQuietly(is);
    }
  }
}
