package com.sap.hcm.resume.collection.integration.job51;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.HttpClientUtils;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.sap.hcm.resume.collection.bean.ResumeInfo;
import com.sap.hcm.resume.collection.exception.AuthenticationFailedException;
import com.sap.hcm.resume.collection.exception.InvalidVerifyCodeException;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.JobBoardBaseProvider;
import com.sap.hcm.resume.collection.integration.bean.ResumeDownloadBean;
import com.sap.hcm.resume.collection.util.CandidateFileUtil;
import com.sap.hcm.resume.collection.util.MappingUtil;

@Component(value = "job51Provider")
@Scope(value = "session", proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Job51Provider extends JobBoardBaseProvider {
  
  public static final String LOGIN_URL = "http://my.51job.com/my/passport_login.php";
  
  public static final String GET_RESUME_AND_ACCCOUNT_URL = "http://my.51job.com/my/My_Pmc.php";
  
  public static final String DOWNLOAD_RESUME_URL = "http://i.51job.com/resume/resume_preview.php";
  
  public static final String GET_VERIFY_CODE_URL = "http://my.51job.com/my/passport_verify.php?type=3&from_domain=my.51job.com&t=1458719547552";
  
  /**
   * logger instance
   */
  private static final Logger logger = LoggerFactory.getLogger(Job51Provider.class);

  private void loginJob51(String username, String password, String verifyCode) throws ServiceApplicationException {
    
    if (StringUtils.isEmpty(verifyCode)) {
      throw new ServiceApplicationException("verify code is empty");
    } else {
      verifyCode = new String(verifyCode.getBytes(StandardCharsets.ISO_8859_1), StandardCharsets.UTF_8);
      logger.debug("verifyCode received is : " + verifyCode);
    }
    CloseableHttpClient client = this.createHttpClient();
    HttpEntity entity = null;
    try {
      
      HttpPost post = new HttpPost(LOGIN_URL);

      List<NameValuePair> list = new ArrayList<NameValuePair>();
      list.add(new BasicNameValuePair("passport_loginName", username));
      list.add(new BasicNameValuePair("passport_password", password));
      list.add(new BasicNameValuePair("passport_verify", verifyCode));
      list.add(new BasicNameValuePair("from_domain", "www.51job.com"));
      UrlEncodedFormEntity encodedFormEntity = new UrlEncodedFormEntity(list);
      post.setEntity(encodedFormEntity);

      post.addHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
      post.addHeader("Content-Type", "application/x-www-form-urlencoded");
      post.addHeader("Host", "my.51job.com");
      post.addHeader("Origin", "http://www.51job.com");
      post.addHeader("Referer", "http://www.51job.com/");
      post.addHeader("Upgrade-Insecure-Requests", "1");
      post.addHeader("User-Agent",
          "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.109 Safari/537.36");
      CloseableHttpResponse response = client.execute(post);
      if (response == null) {
        throw new ServiceApplicationException("network error, unable to connect to 51job");
      }

      setCookieStore(response);

      entity = response.getEntity();
      String input = EntityUtils.toString(entity);
      if (!input.contains("userinfo")) {
        if (input.contains("-7018")) {
          throw new AuthenticationFailedException();
        } else {
          throw new InvalidVerifyCodeException();
        }
      }
    } catch (IOException ex) {
      throw new ServiceApplicationException(ex.getMessage());
    } finally {
      EntityUtils.consumeQuietly(entity);
      HttpClientUtils.closeQuietly(client);
    }
  }

  private String getResumeId() throws ServiceApplicationException {

    String resumeId = "";
    CloseableHttpClient client = this.createHttpClient();
    HttpEntity entity = null;
    try {
      HttpGet get = new HttpGet(GET_RESUME_AND_ACCCOUNT_URL);
      get.addHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
      get.addHeader("Host", "my.51job.com");
      get.addHeader("Referer", "http://www.51job.com/?from=baidupz");
      get.addHeader("Upgrade-Insecure-Requests", "1");
      get.addHeader("User-Agent",
          "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.109 Safari/537.36");
      CloseableHttpResponse response = client.execute(get);
      setCookieStore(response);
      entity = response.getEntity();
      
      Document doc = Jsoup.parse(EntityUtils.toString(entity));
      Elements refreshIcon = doc.getElementsByClass("iconRefreshGrey");
      if(refreshIcon == null){
        throw new ServiceApplicationException("Unable to find any resume to import");
      }
      String regex = "(?<=javascript:RefreshresumeAll\\()\\d+";
      resumeId = MappingUtil.matchSingle(regex, refreshIcon.toString());
      if (StringUtils.isEmpty(resumeId)){
        throw new ServiceApplicationException("Unable to find any resume to import");
      }
    } catch (Exception e) {
      throw new ServiceApplicationException(e.getMessage());
    } finally {
      EntityUtils.consumeQuietly(entity);
      HttpClientUtils.closeQuietly(client);
    }

    return resumeId;
  }

  private ResumeDownloadBean getResumeByHttpPost(String resumeId, String locale)
      throws ServiceApplicationException {

    InputStream content = null;
    ResumeDownloadBean bean = new ResumeDownloadBean();

    CloseableHttpClient client = this.createHttpClient();
    HttpEntity entity = null;
    String url = DOWNLOAD_RESUME_URL+"?lang="+locale+"&resumeid="+resumeId+"&act=export&type=word";
    try {
      
      HttpGet get = new HttpGet(url);

      get.addHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
      CloseableHttpResponse response = client.execute(get);
      if (response == null) {
        throw new ServiceApplicationException("network error, unable to connect to 51job");
      }

      setCookieStore(response);
      entity = response.getEntity();
      content = entity.getContent();
      bean.setFileContent(IOUtils.toByteArray(content));
      if (locale.equals("c")) {
        bean.setLocale(Locale.CHINESE);
      } else {
        bean.setLocale(Locale.ENGLISH);
      }
      bean.setExternalResumeId(resumeId);

    } catch (Exception ex) {
      throw new ServiceApplicationException(ex.getMessage());
    } finally {
        IOUtils.closeQuietly(content);
        EntityUtils.consumeQuietly(entity);
        HttpClientUtils.closeQuietly(client);
    }

    return bean;
  }

  @Override
  public void preLogin() throws ServiceApplicationException {
    cookieStore.clear();
    CloseableHttpClient client = this.createHttpClient();

    try {
      HttpGet get = new HttpGet("http://www.51job.com/");
      get.addHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8");
      get.addHeader("Host", "my.51job.com");
      get.addHeader("Upgrade-Insecure-Requests", "1");
      get.addHeader("User-Agent",
          "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.109 Safari/537.36");
      CloseableHttpResponse response = client.execute(get);
      setCookieStore(response);

    } catch (Exception e) {
      throw new ServiceApplicationException("connect to 51 job failed" + e.getMessage());
    } finally {
      HttpClientUtils.closeQuietly(client);
    }

  }

  @Override
  public List<ResumeDownloadBean> getResume(HttpServletRequest request, String username, String password,
      String captcha) throws ServiceApplicationException {

    List<ResumeDownloadBean> fileNameList = new ArrayList<ResumeDownloadBean>();

    this.loginJob51(username, password, captcha);

    String resumeId = this.getResumeId();
    if (!StringUtils.isEmpty(resumeId)) {
      ResumeDownloadBean zhBean = getResumeByHttpPost(resumeId, "c");
      fileNameList.add(zhBean);

      ResumeDownloadBean enResumeBean = getResumeByHttpPost(resumeId, "e");
      fileNameList.add(enResumeBean);
    }
    return fileNameList;
  }

  @Override
  public void getVerifyCode(HttpServletRequest request) throws ServiceApplicationException {
    CloseableHttpClient client = this.createHttpClient();
    HttpEntity entity = null;
    InputStream is = null;
    try {
      HttpGet get = new HttpGet(GET_VERIFY_CODE_URL);
      get.addHeader("Accept", "image/webp,image/*,*/*;q=0.8");
      get.addHeader("Host", "my.51job.com");
      get.addHeader("Referer", "http://www.51job.com/");
      get.addHeader("User-Agent",
          "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.109 Safari/537.36");

      CloseableHttpResponse response = client.execute(get);
      setCookieStore(response);
      entity = response.getEntity();
      is = entity.getContent();
      byte[] image = CandidateFileUtil.cropImage(is, 120, 60);
      request.getSession().setAttribute("verifyCode", image);

    } catch (Exception e) {
      throw new ServiceApplicationException("failed to retrieve the verify code: " + e.getMessage());
    } finally {
      IOUtils.closeQuietly(is);
      EntityUtils.consumeQuietly(entity);
      HttpClientUtils.closeQuietly(client);
    }
  }

  @Override
  public ResumeInfo getFileContent(byte[] content) throws ServiceApplicationException {
    ResumeInfo resumeInfo = new ResumeInfo();
    resumeInfo.setResumeExtension("html");
    resumeInfo.setHtmlDocument(CandidateFileUtil.getContentFromMhtFile(content));
    return resumeInfo;
  }

}
