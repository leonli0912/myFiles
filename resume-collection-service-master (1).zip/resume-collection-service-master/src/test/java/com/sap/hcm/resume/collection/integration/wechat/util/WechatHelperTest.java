package com.sap.hcm.resume.collection.integration.wechat.util;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.utils.HttpClientUtils;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.BDDMockito;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;

import com.sap.hcm.resume.collection.context.TestContext;
import com.sap.hcm.resume.collection.context.WebAppContext;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.MockHttpEntity;
import com.sap.hcm.resume.collection.integration.wechat.entity.AccessToken;
import com.sap.hcm.resume.collection.integration.wechat.entity.OAuthAccessToken;
import com.sap.hcm.resume.collection.integration.wechat.entity.UserBascInfo;
import com.sap.hcm.resume.collection.util.HTTPConnection;

import net.sf.json.JSONObject;

@RunWith(PowerMockRunner.class)
@PowerMockRunnerDelegate(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { TestContext.class, WebAppContext.class })
@PrepareForTest({ WechatHelper.class, EntityUtils.class, JSONObject.class })
public class WechatHelperTest {

  @Resource(name = "httpConnection")
  private HTTPConnection httpConnection;

  private WechatHelper wechatHelper;

  @Before
  public void setUp() {
    reset(httpConnection);
    MockitoAnnotations.initMocks(this);
    wechatHelper = spy(new WechatHelper());
    ReflectionTestUtils.setField(wechatHelper, "httpConnection", httpConnection);

  }

  @Test
  public void testDoPostStr() throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException, IOException,
      ServiceApplicationException {
    String url = "a";
    String outStr = "b";
    HttpResponse httpResponse = Mockito.mock(HttpResponse.class);
    CloseableHttpClient httpClient = null;
    try {
      httpClient = httpConnection.createHttpClient();
      when(httpClient).thenReturn(null);
      when(httpConnection.loadAsHttpResponse(null, url, "POST", null, outStr, null)).thenReturn(httpResponse);

      PowerMockito.mockStatic(EntityUtils.class);

      BDDMockito.given(EntityUtils.toString(any(HttpEntity.class), any(String.class))).willReturn(new String("haha"));

      PowerMockito.mockStatic(JSONObject.class);
      BDDMockito.given(JSONObject.fromObject(any(String.class))).willReturn(new JSONObject());
      wechatHelper.doPostStr(url, outStr);
    } finally {
      HttpClientUtils.closeQuietly(httpClient);
    }

  }

  @Test
  public void testDoPostStrException() throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException,
      IOException, ServiceApplicationException {
    String url = "a";
    String outStr = "b";
    HttpResponse httpResponse = Mockito.mock(HttpResponse.class);
    CloseableHttpClient httpClient = null;
    try{
      httpClient = httpConnection.createHttpClient();
    
    when(httpClient).thenReturn(null);
    when(httpConnection.loadAsHttpResponse(null, url, "POST", null, outStr, null)).thenThrow(
        new ServiceApplicationException("error"));

    PowerMockito.mockStatic(EntityUtils.class);

    BDDMockito.given(EntityUtils.toString(any(HttpEntity.class), any(String.class))).willReturn(new String("haha"));

    PowerMockito.mockStatic(JSONObject.class);
    BDDMockito.given(JSONObject.fromObject(any(String.class))).willReturn(new JSONObject());
    wechatHelper.doPostStr(url, outStr);
    }finally{
      HttpClientUtils.closeQuietly(httpClient);
    }
  }

  @Test
  public void testDoGetStr() throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException,
      ServiceApplicationException, Exception, IOException {
    String url = "a";
    HttpResponse httpResponse = Mockito.mock(HttpResponse.class);
    CloseableHttpClient httpClient = null;
    try{
      httpClient = httpConnection.createHttpClient();
    when(httpClient).thenReturn(null);
    when(httpConnection.loadAsHttpResponse(null, url, "GET", null, null, null)).thenReturn(httpResponse);
    when(httpResponse.getEntity()).thenReturn(Mockito.mock(HttpEntity.class));
    PowerMockito.mockStatic(EntityUtils.class);

    BDDMockito.given(EntityUtils.toString(any(HttpEntity.class))).willReturn(new String("haha"));
    wechatHelper.doGetStr(url);
    }finally{
      HttpClientUtils.closeQuietly(httpClient);
    }
  }

  @Test
  public void testGetAccessToken() throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException,
      ServiceApplicationException, ClientProtocolException, IOException {
    String appId = "a";
    String appSecret = "b";

    String url = WechatHelper.ACCESS_TOKEN_URL.replace("APPID", appId).replace("APPSECRET", appSecret);

    CloseableHttpClient mockHttpClient = Mockito.mock(CloseableHttpClient.class);
    HttpResponse rsp = Mockito.mock(HttpResponse.class);
    CloseableHttpClient httpClient = null;
    try{
      httpClient = httpConnection.createHttpClient();
    when(httpClient).thenReturn(mockHttpClient);
    when(httpConnection.loadAsHttpResponse(mockHttpClient, url, "GET", null, null, null)).thenReturn(rsp);

    HttpEntity mockHttpEntity = new MockHttpEntity("application/json",
        IOUtils.toInputStream("{\"access_token\":\"123\"}"));
    when(rsp.getEntity()).thenReturn(mockHttpEntity);

    AccessToken token = wechatHelper.getAccessToken("sap", appId, appSecret);

    Assert.assertEquals("123", token.getAccess_token());
    }finally{
      HttpClientUtils.closeQuietly(httpClient);
    }
  }

  @Test
  public void testGetAPITicket() throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException,
      ServiceApplicationException, ClientProtocolException, IOException {
    String accessToken = "123";

    String url = WechatHelper.JSAPI_TICKET_URL.replace("ACCESS_TOKEN", accessToken);

    CloseableHttpClient mockHttpClient = Mockito.mock(CloseableHttpClient.class);
    HttpResponse rsp = Mockito.mock(HttpResponse.class);
    CloseableHttpClient httpClient = null;
    try{
      httpClient = httpConnection.createHttpClient();
    when(httpClient).thenReturn(mockHttpClient);
    when(httpConnection.loadAsHttpResponse(mockHttpClient, url, "GET", null, null, null)).thenReturn(rsp);

    HttpEntity mockHttpEntity = new MockHttpEntity("application/json", IOUtils.toInputStream("{\"ticket\":\"123\"}"));
    when(rsp.getEntity()).thenReturn(mockHttpEntity);

    String ticket = wechatHelper.getApiTicket(accessToken);
    Assert.assertEquals("123", ticket);
    }finally{
      HttpClientUtils.closeQuietly(httpClient);
    }
  }

  @Test
  public void testGetOAuthAccessToken() throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException,
      ServiceApplicationException {
    String code = "123";

    String acessTokenUrl = WechatHelper.OAUTH_ACCESS_TOKEN_URL.replace("%APPID%", WechatHelper.WECHAT_APP_ID)
        .replace("%SECRET%", WechatHelper.WECHAT_APP_SERECT).replace("%CODE%", code);

    CloseableHttpClient mockHttpClient = Mockito.mock(CloseableHttpClient.class);
    HttpResponse rsp = Mockito.mock(HttpResponse.class);
    CloseableHttpClient httpClient = null;
    try{
      httpClient = httpConnection.createHttpClient();
    when(httpClient).thenReturn(mockHttpClient);
    when(httpConnection.loadAsHttpResponse(mockHttpClient, acessTokenUrl, "GET", null, null, null)).thenReturn(rsp);

    HttpEntity mockHttpEntity = new MockHttpEntity("application/json",
        IOUtils.toInputStream("{\"access_token\":\"123\", \"expires_in\":123,\"openid\":\"123\"}"));
    when(rsp.getEntity()).thenReturn(mockHttpEntity);

    OAuthAccessToken token = wechatHelper.getOAuthAccessToken(code);

    Assert.assertEquals("123", token.getAccessToken());
    Assert.assertEquals(123, token.getExpiresIn().intValue());
    Assert.assertEquals("123", token.getOpenId());
    }finally{
      HttpClientUtils.closeQuietly(httpClient);
    }
  }

  @Test
  public void testUserBasicInfo() throws ServiceApplicationException, KeyManagementException, NoSuchAlgorithmException,
      KeyStoreException {
    String accessToken = "123";
    String openId = "123";

    String userInfoUri = WechatHelper.OAUTH_USERINFO_URL.replace("%ACCESS_TOKEN%", accessToken).replace("%OPENID%",
        openId);

    CloseableHttpClient mockHttpClient = Mockito.mock(CloseableHttpClient.class);
    HttpResponse rsp = Mockito.mock(HttpResponse.class);
    CloseableHttpClient httpClient = null;
    try{
      httpClient = httpConnection.createHttpClient();
    when(httpClient).thenReturn(mockHttpClient);
    when(httpConnection.loadAsHttpResponse(mockHttpClient, userInfoUri, "GET", null, null, null)).thenReturn(rsp);

    HttpEntity mockHttpEntity = new MockHttpEntity("application/json",
        IOUtils.toInputStream("{\"openid\":\"123\", \"nickname\":\"test\",\"sex\":\"M\"}"));
    when(rsp.getEntity()).thenReturn(mockHttpEntity);

    UserBascInfo info = wechatHelper.getUserBascInfo(accessToken, openId);

    Assert.assertEquals("123", info.getOpenid());
    Assert.assertEquals("test", info.getNickname());
    Assert.assertEquals("M", info.getSex());
    }finally{
      HttpClientUtils.closeQuietly(httpClient);
    }
  }

  @Test
  public void testSignDifferent() {
    Map<String, String> sign1 = wechatHelper.sign("123", "123");
    Map<String, String> sign2 = wechatHelper.sign("123", "456");

    Assert.assertNotEquals(sign1.get("signature"), sign2.get("signature"));
  }

  @Test
  public void testCreateMenuSuccess() throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException,
      ServiceApplicationException {
    String token = "123";
    String menuString = "123";

    String url = WechatHelper.CREATE_MENU_URL.replace("ACCESS_TOKEN", token);

    CloseableHttpClient mockHttpClient = Mockito.mock(CloseableHttpClient.class);
    HttpResponse rsp = Mockito.mock(HttpResponse.class);
    CloseableHttpClient httpClient = null;
    try{
      httpClient = httpConnection.createHttpClient();
    when(httpClient).thenReturn(mockHttpClient);
    when(httpConnection.loadAsHttpResponse(mockHttpClient, url, "POST", null, menuString, null)).thenReturn(rsp);

    HttpEntity mockHttpEntity = new MockHttpEntity("application/json", IOUtils.toInputStream("{\"errcode\":0}"));
    when(rsp.getEntity()).thenReturn(mockHttpEntity);

    String result = wechatHelper.createMenu(token, menuString);

    Assert.assertEquals("success", result);
    }finally{
      HttpClientUtils.closeQuietly(httpClient);
    }
  }

  @Test
  public void testCreateMenuFailed() throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException,
      ServiceApplicationException {
    String token = "123";
    String menuString = "123";

    String url = WechatHelper.CREATE_MENU_URL.replace("ACCESS_TOKEN", token);

    CloseableHttpClient mockHttpClient = Mockito.mock(CloseableHttpClient.class);
    HttpResponse rsp = Mockito.mock(HttpResponse.class);
    CloseableHttpClient httpClient = null;
    try{
      httpClient = httpConnection.createHttpClient();
    when(httpClient).thenReturn(mockHttpClient);
    when(httpConnection.loadAsHttpResponse(mockHttpClient, url, "POST", null, menuString, null)).thenReturn(rsp);

    HttpEntity mockHttpEntity = new MockHttpEntity("application/json",
        IOUtils.toInputStream("{\"errcode\":-1,\"errmsg\":\"failed\"}"));
    when(rsp.getEntity()).thenReturn(mockHttpEntity);

    String result = wechatHelper.createMenu(token, menuString);

      Assert.assertNotEquals("success", result);
    }finally{
      HttpClientUtils.closeQuietly(httpClient);
    }
  }
}
