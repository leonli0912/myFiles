package com.sap.hcm.resume.collection.integration.sf;

import static org.junit.Assert.assertEquals;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;

import org.apache.olingo.odata2.api.edm.provider.NavigationProperty;
import org.apache.olingo.odata2.api.exception.ODataException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.util.ReflectionTestUtils;

import com.sap.hcm.resume.collection.bean.JobAppQuestionResponse;
import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.entity.view.CandidateBgCertificateVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgEducationVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgLanguageVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgWorkExprVO;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileConstants;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileExtVO;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;
import com.sap.hcm.resume.collection.entity.view.JobApplyMappingVO;
import com.sap.hcm.resume.collection.integration.bean.ApplyDataModelMappingItem;
import com.sap.hcm.resume.collection.integration.bean.CandProfileDataModelMapping;
import com.sap.hcm.resume.collection.integration.bean.DataMappingApplyStatus;
import com.sap.hcm.resume.collection.integration.bean.DataMappingApplyStatusList;
import com.sap.hcm.resume.collection.integration.bean.DataMappingOverwrite;
import com.sap.hcm.resume.collection.integration.bean.DataModelMappingItem;
import com.sap.hcm.resume.collection.integration.sf.bean.SFPicklist;
import com.sap.hcm.resume.collection.integration.sf.bean.SFPicklistItem;
import com.sap.hcm.resume.collection.integration.sf.odata.SFODataEntityType;
import com.sap.hcm.resume.collection.integration.sf.odata.SFODataService;
import com.sap.hcm.resume.collection.integration.sf.service.SFPicklistCacheService;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJob;
import com.sap.hcm.resume.collection.integration.xml.DataModelMappingXMLConverter;
import com.sap.hcm.resume.collection.service.CandidateProfileService;
import com.sap.hcm.resume.collection.util.CandidateProfileHelper;
import com.thoughtworks.xstream.core.util.Base64Encoder;

@RunWith(PowerMockRunner.class)
public class SFODataFormatterTest {

  private CandidateProfileVO candidateProfileVO;

  private CandProfileDataModelMapping dataModelMapping;

  private SFOdataFormatter sfODataFormatter;
  
  private SFODataService sfODataService;
  
  private SFPicklistCacheService sfPicklistCacheService;
  
  private CandidateProfileHelper candidateProfileHelper;
  
  private CandidateProfileService candidateProfileService;

  private Map<String, SFPicklist> pickListMap;
  
  @Autowired
  private Params params;


  @Before
  public void setUp() throws ODataException {
    
    sfODataFormatter = PowerMockito.spy(new SFOdataFormatter());
    
    dataModelMapping = new CandProfileDataModelMapping();
    candidateProfileVO = new CandidateProfileVO();
    pickListMap = new HashMap<String, SFPicklist>();
    candidateProfileService = Mockito.mock(CandidateProfileService.class);
    
    params = Mockito.spy(Params.class);
    params.setLocale(Locale.ENGLISH);
    sfODataService = Mockito.mock(SFODataService.class);
    sfPicklistCacheService = Mockito.mock(SFPicklistCacheService.class);
    candidateProfileHelper = Mockito.spy(CandidateProfileHelper.class);
    ReflectionTestUtils.setField(sfODataFormatter, "sfODataService", sfODataService);
    ReflectionTestUtils.setField(sfODataFormatter, "sfPicklistCacheService", sfPicklistCacheService);
    ReflectionTestUtils.setField(sfODataFormatter, "candidateProfileHelper", candidateProfileHelper);
    ReflectionTestUtils.setField(sfODataFormatter, "candidateProfileService", candidateProfileService);
    ReflectionTestUtils.setField(sfODataFormatter, "params", params);
    
    mockDataModelMapping();
    mockCandidateProfileVO();
    mockPickListMap();
    mockDataMappingOverwrite();
  }

  @Test
  @PrepareForTest({ DataModelMappingXMLConverter.class })
  public void testGetSFJobApplicationOdataFormat() throws Exception {
    Map<String, Object> result = null;

    List<String> navPropList = new ArrayList<String>();
    navPropList.add("sfStatus");
    Mockito.when(sfODataService.getNaviPropertyNames(SFODataEntityType.JOBAPPLICATION.getName())).thenReturn(navPropList);

    // mock company info
    CompanyInfo info = Mockito.mock(CompanyInfo.class);
    Mockito.when(info.getApplyStatusMapping()).thenReturn("xml");

    // mock apply status list
    PowerMockito.mockStatic(DataModelMappingXMLConverter.class);
    DataMappingApplyStatusList applyStatusList = new DataMappingApplyStatusList();
    DataMappingApplyStatus statusItem = new DataMappingApplyStatus();
    statusItem.setStatusSetId("testSFStatusSetId");
    statusItem.setStatusSetItemId("testStatusSetItemId");
    List<DataMappingApplyStatus> statusItemList = new ArrayList<DataMappingApplyStatus>();
    statusItemList.add(statusItem);
    applyStatusList.setStatusSetItem(statusItemList);
    PowerMockito.when(DataModelMappingXMLConverter.fromApplyStatusReqXML("xml")).thenReturn(applyStatusList);

    WechatJob wechatJob = new WechatJob();
    wechatJob.setSfStatusSetId("testSFStatusSetId");

    // mock JobApplyMappingVO
    JobApplyMappingVO jobApplyMappingVO = new JobApplyMappingVO();
    List<ApplyDataModelMappingItem> mappingItemList = new ArrayList<ApplyDataModelMappingItem>();
    ApplyDataModelMappingItem item1 = new ApplyDataModelMappingItem();
    item1.setSourceNameType("selectFromCandidateProfile");
    item1.setSourceField("attachment");
    item1.setSfDmField("sfAttachment");
    mappingItemList.add(item1);
    ApplyDataModelMappingItem item2 = new ApplyDataModelMappingItem();
    item2.setSourceNameType("selectFromCandidateProfile");
    item2.setSourceField("firstName");
    item2.setSfDmField("sfFirstName");
    mappingItemList.add(item2);
    jobApplyMappingVO.setItemList(mappingItemList);
    ApplyDataModelMappingItem item3 = new ApplyDataModelMappingItem();
    item3.setSourceNameType("inputExtraField");
    item3.setSourceField("jobAppStatus");
    item3.setSfDmField("sfStatus");
    item3.setPicklist("sfStatus");
    item3.setDefaultValue("Open");
    mappingItemList.add(item3);
    jobApplyMappingVO.setItemList(mappingItemList);
    
    //mock pickup map
    Mockito.when(candidateProfileHelper.readPicklistFromDB(Mockito.any(List.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(pickListMap);
    //PowerMockito.doReturn(pickListMap).when(sfODataFormatter, "readPicklistFromDB", Mockito.any(List.class), Mockito.any(String.class));
    
    List<JobAppQuestionResponse> questionResponses = new ArrayList<JobAppQuestionResponse>();
    result = sfODataFormatter.getSFJobApplicationOdataFormat(dataModelMapping, candidateProfileVO, jobApplyMappingVO,
        info, wechatJob,questionResponses);

    Assert.assertNotNull(result);
    Assert.assertNotNull(result.get("sfStatus"));
    Assert.assertEquals("testStatusSetItemId", result.get("appStatusSetItemId"));
    Assert.assertEquals("TestFirstName", result.get("sfFirstName"));
    @SuppressWarnings("unchecked")
    Map<String, Object> attachmentMap = (Map<String, Object>) result.get("sfAttachment");
    Assert.assertEquals("TestLastName_TestFirstName.doc", attachmentMap.get("fileName"));

  }

 
  @Test
  public void testGetSFOdataFormat() throws Exception {
    
    NavigationProperty languageNavi = new NavigationProperty();
    languageNavi.setName(CandidateProfileConstants.BG_LANGU_NAME);
    languageNavi.setToRole("Language");
    NavigationProperty workExp = new NavigationProperty();
    workExp.setName(CandidateProfileConstants.BG_WORKEXPR_NAME);
    workExp.setToRole("WorkExp");
    NavigationProperty education = new NavigationProperty();
    education.setName(CandidateProfileConstants.BG_EDUC_NAME);
    education.setToRole("Education");
    NavigationProperty certification = new NavigationProperty();
    certification.setName(CandidateProfileConstants.BG_CERT_NAME);
    certification.setToRole("Certificate");

    List<NavigationProperty> navProps = new ArrayList<NavigationProperty>();
    navProps.add(languageNavi);
    navProps.add(workExp);
    navProps.add(education);
    navProps.add(certification);

    
    Mockito.when(sfODataService.getNaviProperties(SFODataEntityType.CANDIDATE
        .getName())).thenReturn(navProps);
    
    //mock pickup map
    Mockito.when(candidateProfileHelper.readPicklistFromDB(Mockito.any(List.class), Mockito.any(String.class), Mockito.any(String.class))).thenReturn(pickListMap);
    //PowerMockito.doReturn(pickListMap).when(sfODataFormatter, "readPicklistFromDB", Mockito.any(List.class), Mockito.any(String.class));
    
    Map<String, Object> result = sfODataFormatter.getSFOdataFormat(dataModelMapping, candidateProfileVO);
    
    Assert.assertNotNull(result);

    // verify languages
//    @SuppressWarnings("unchecked")
//    ArrayList<Map<String, String>> languages = (ArrayList<Map<String, String>>) result.get("languages");
//    assertEquals(2, languages.size());
//    for (Map<String, String> language : languages) {
//      if (language.get("sfName").equals("English")) {
//        assertEquals("3", language.get("sfReadingProf"));
//        assertEquals("2", language.get("sfWritingProf"));
//      }
//      if (language.get("sfName").equals("Japanese")) {
//        assertEquals("3", language.get("sfSpeakingProf"));
//        assertEquals("1", language.get("sfWritingProf"));
//      }
//    }

    // verify education
    @SuppressWarnings("unchecked")
    ArrayList<Map<String, String>> educationList = (ArrayList<Map<String, String>>) result.get("education");
    assertEquals("Doctor", educationList.get(0).get("sfDegree"));
    assertEquals("TestSchool", educationList.get(0).get("sfSchool"));

    // verify work experience
    @SuppressWarnings("unchecked")
    ArrayList<Map<String, String>> workExprs = (ArrayList<Map<String, String>>) result.get("workExprs");
    assertEquals(2, workExprs.size());

    // verify certificate
    @SuppressWarnings("unchecked")
    ArrayList<Map<String, String>> certificates = (ArrayList<Map<String, String>>) result.get("certificates");
    assertEquals("PMI", certificates.get(0).get("sfInstitution"));

    // verify profile fields
    assertEquals("TestFirstNameTestLastName", result.get("sfFirstName"));
    assertEquals("TestLastName", result.get("sfLastName"));

    // verify default value
    assertEquals("China", result.get("sfNationality"));

    // verify attachment
    @SuppressWarnings("unchecked")
    Map<String, String> attachment = (Map<String, String>) result.get("sfAttachment");
    Base64Encoder encoder = new Base64Encoder();
    byte[] bytes = "DefaultAttachmentValue".getBytes(StandardCharsets.UTF_8);
    String fileContent = encoder.encode(bytes);// "DefaultAttachmentValue".getBytes(StandardCharsets.UTF_8)
    assertEquals(fileContent, attachment.get("fileContent"));
  }

  private void mockCandidateProfileVO() {
    // mock profile data
    candidateProfileVO.setFirstName("TestFirstName");
    candidateProfileVO.setLastName("TestLastName");
    candidateProfileVO.setCandidateId(123L);
    candidateProfileVO.setNationality(null); // use default value
    // mock ext profile data
    CandidateProfileExtVO extVO = new CandidateProfileExtVO();
    byte[] defaultAttachment = "DefaultAttachmentValue".getBytes(StandardCharsets.UTF_8);
    extVO.setAttachment(defaultAttachment);
    extVO.setResumeExtension("doc");
    candidateProfileVO.setExtProfile(extVO);

    // mock language
    CandidateBgLanguageVO language1 = new CandidateBgLanguageVO();
    language1.setName("English");
    language1.setReadingProf("Excellent");
    language1.setSpeakingProf("Good");
    language1.setWritingProf("Good");
    CandidateBgLanguageVO language2 = new CandidateBgLanguageVO();
    language2.setName("Japanese");
    language2.setReadingProf("Good");
    language2.setSpeakingProf("Excellent");
    language2.setWritingProf("Ordinary");
    List<CandidateBgLanguageVO> languages = new ArrayList<CandidateBgLanguageVO>();
    languages.add(language1);
    languages.add(language2);
    candidateProfileVO.setLanguages(languages);

    // mock workExpr
    CandidateBgWorkExprVO workExpr1 = new CandidateBgWorkExprVO();
    workExpr1.setStartDate("2012/10/20");
    workExpr1.setEndDate("NOW");
    workExpr1.setSalary("25000");
    CandidateBgWorkExprVO workExpr2 = new CandidateBgWorkExprVO();
    workExpr2.setStartDate("2006/11/23");
    workExpr2.setEndDate("2012/10/10");
    workExpr2.setSalary("15000");
    List<CandidateBgWorkExprVO> workExprs = new ArrayList<CandidateBgWorkExprVO>();
    workExprs.add(workExpr1);
    workExprs.add(workExpr2);
    candidateProfileVO.setWorkExprs(workExprs);

    // mock education
    CandidateBgEducationVO education = new CandidateBgEducationVO();
    education.setSchool("TestSchool");
    education.setDegree("Doctor");
    List<CandidateBgEducationVO> educationList = new ArrayList<CandidateBgEducationVO>();
    educationList.add(education);
    candidateProfileVO.setEducation(educationList);

    // mock certificate
    CandidateBgCertificateVO certificate = new CandidateBgCertificateVO();
    certificate.setName("PMP");
    certificate.setInstitution("PMI");
    List<CandidateBgCertificateVO> certificateList = new ArrayList<CandidateBgCertificateVO>();
    certificateList.add(certificate);
    candidateProfileVO.setCertificates(certificateList);
  }

  private void mockDataModelMapping() {
    // mock aliases
    Map<String, String> aliases = new LinkedHashMap<String, String>();
    aliases.put("languages", "languages");
    aliases.put("education", "education");
    aliases.put("workExprs", "workExprs");
    aliases.put("certificates", "certificates");
    dataModelMapping.setAliases(aliases);

    mockProfileItems();
    mockLanguageMappingItems();
    mockWorkExpMappingItems();
    mockEducationMappingItems();
    mockCertificateMappingItems();
  }

  private void mockProfileItems() {
    SortedSet<DataModelMappingItem> profileItems = new TreeSet<DataModelMappingItem>();
    DataModelMappingItem firstName = new DataModelMappingItem();
    firstName.setFrom("firstName"); // candidate vo property
    firstName.setTo("sfFirstName"); // sf odata entity property
    firstName.setPicklist(null);
    firstName.setRequired(true);
    firstName.setSeq(0);
    profileItems.add(firstName);
    DataModelMappingItem lastName = new DataModelMappingItem();
    lastName.setFrom("lastName");
    lastName.setTo("sfLastName");
    lastName.setPicklist(null);
    lastName.setRequired(true);
    lastName.setSeq(1);
    profileItems.add(lastName);
    DataModelMappingItem nationality = new DataModelMappingItem();
    nationality.setFrom("nationality");
    nationality.setTo("sfNationality");
    nationality.setDefaultValue("China");
    nationality.setPicklist(null);
    nationality.setRequired(false);
    nationality.setSeq(2);
    profileItems.add(nationality);
    DataModelMappingItem dummy = new DataModelMappingItem();
    dummy.setTo(null);
    dummy.setSeq(3);
    profileItems.add(dummy);
    // mock ext profile items
    DataModelMappingItem attachment = new DataModelMappingItem();
    attachment.setFrom("attachment");
    attachment.setTo("sfAttachment");
    attachment.setPicklist(null);
    attachment.setRequired(false);
    attachment.setSeq(4);
    profileItems.add(attachment);

    dataModelMapping.setProfile(profileItems);
  }

  private void mockLanguageMappingItems() {
    SortedSet<DataModelMappingItem> languageItems = new TreeSet<DataModelMappingItem>();
    DataModelMappingItem name = new DataModelMappingItem();
    name.setRequired(false);
    name.setFrom("name");
    name.setTo("sfName");
    name.setSeq(0);
    languageItems.add(name);
    DataModelMappingItem speakingProf = new DataModelMappingItem();
    speakingProf.setRequired(false);
    speakingProf.setFrom("speakingProf");
    speakingProf.setTo("sfSpeakingProf");
    speakingProf.setPicklist("sfSpeakingProf");
    speakingProf.setSeq(1);
    languageItems.add(speakingProf);
    DataModelMappingItem readingProf = new DataModelMappingItem();
    readingProf.setRequired(false);
    readingProf.setFrom("readingProf");
    readingProf.setTo("sfReadingProf");
    readingProf.setPicklist("sfReadingProf");
    readingProf.setSeq(2);
    languageItems.add(readingProf);
    DataModelMappingItem writingProf = new DataModelMappingItem();
    writingProf.setRequired(false);
    writingProf.setFrom("writingProf");
    writingProf.setTo("sfWritingProf");
    writingProf.setPicklist("sfWritingProf");
    writingProf.setSeq(3);
    languageItems.add(writingProf);
    dataModelMapping.setLanguages(languageItems);
  }

  private void mockWorkExpMappingItems() {
    SortedSet<DataModelMappingItem> workExprItems = new TreeSet<DataModelMappingItem>();
    DataModelMappingItem startDate = new DataModelMappingItem();
    startDate.setRequired(false);
    startDate.setFrom("startDate");
    startDate.setTo("sfWorkExpStartDate");
    startDate.setSeq(0);
    workExprItems.add(startDate);
    DataModelMappingItem endDate = new DataModelMappingItem();
    endDate.setRequired(false);
    endDate.setFrom("endDate");
    endDate.setTo("sfWorkExpEndDate");
    endDate.setSeq(1);
    workExprItems.add(endDate);
    DataModelMappingItem salary = new DataModelMappingItem();
    salary.setRequired(false);
    salary.setFrom("salary");
    salary.setTo("sfSalary");
    salary.setSeq(2);
    workExprItems.add(salary);
    dataModelMapping.setWorkExprs(workExprItems);
  }

  private void mockEducationMappingItems() {
    SortedSet<DataModelMappingItem> educationItems = new TreeSet<DataModelMappingItem>();
    DataModelMappingItem school = new DataModelMappingItem();
    school.setRequired(false);
    school.setFrom("school");
    school.setTo("sfSchool");
    school.setSeq(0);
    educationItems.add(school);
    DataModelMappingItem degree = new DataModelMappingItem();
    degree.setRequired(false);
    degree.setFrom("degree");
    degree.setTo("sfDegree");
    degree.setSeq(1);
    educationItems.add(degree);
    dataModelMapping.setEducation(educationItems);
  }

  private void mockCertificateMappingItems() {
    SortedSet<DataModelMappingItem> certificateItems = new TreeSet<DataModelMappingItem>();
    DataModelMappingItem name = new DataModelMappingItem();
    name.setRequired(false);
    name.setFrom("name");
    name.setTo("sfName");
    name.setSeq(0);
    certificateItems.add(name);
    DataModelMappingItem institution = new DataModelMappingItem();
    institution.setRequired(false);
    institution.setFrom("institution");
    institution.setTo("sfInstitution");
    institution.setSeq(1);
    certificateItems.add(institution);
    dataModelMapping.setCertificates(certificateItems);
  }

  private void mockDataMappingOverwrite() {
    DataMappingOverwrite overwrite = new DataMappingOverwrite();
    List<String> rules = new ArrayList<String>();
    String rule = "firstName = firstName + lastName";
    rules.add(rule);
    overwrite.setRules(rules);
    dataModelMapping.setDataMappingOverwrites(overwrite);
  }

  private void mockPickListMap() {
    pickListMap = new HashMap<String, SFPicklist>();

    // mock languages
    List<SFPicklistItem> valueList = new ArrayList<SFPicklistItem>();
    SFPicklistItem ordinary = new SFPicklistItem();
    ordinary.setLabel("Ordinary");
    ordinary.setOptionId(1L);
    valueList.add(ordinary);
    SFPicklistItem good = new SFPicklistItem();
    good.setLabel("Good");
    good.setOptionId(2L);
    valueList.add(good);
    SFPicklistItem excellent = new SFPicklistItem();
    excellent.setLabel("Excellent");
    excellent.setOptionId(3L);
    valueList.add(excellent);

    SFPicklist speaking = new SFPicklist();
    speaking.setPicklistName("readingPL");
    speaking.setSFPropertyName("readingLevel");
    speaking.setValueList(valueList);
    SFPicklist reading = new SFPicklist();
    reading.setPicklistName("readingPL");
    reading.setSFPropertyName("readingLevel");
    reading.setValueList(valueList);
    SFPicklist writing = new SFPicklist();
    writing.setPicklistName("readingPL");
    writing.setSFPropertyName("readingLevel");
    writing.setValueList(valueList);

    pickListMap.put("sfSpeakingProf", speaking);
    pickListMap.put("sfReadingProf", reading);
    pickListMap.put("sfWritingProf", writing);

    // mock jobApp status
    List<SFPicklistItem> statusOptionList = new ArrayList<SFPicklistItem>();
    SFPicklistItem open = new SFPicklistItem();
    open.setLabel("Open");
    open.setOptionId(1L);
    statusOptionList.add(open);
    SFPicklistItem applied = new SFPicklistItem();
    applied.setLabel("Applied");
    applied.setOptionId(2L);
    statusOptionList.add(applied);

    SFPicklist status = new SFPicklist();
    status.setPicklistName("statusPL");
    status.setSFPropertyName("statusValue");
    status.setValueList(statusOptionList);
    pickListMap.put("sfStatus", status);
  }
}
