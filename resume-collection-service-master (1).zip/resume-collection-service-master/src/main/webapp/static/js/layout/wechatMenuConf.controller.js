sap.ui.define([ "sap/ui/core/mvc/Controller", "sap/ui/model/json/JSONModel", "sap/m/MessageToast" ], function(
		Controller, JSONModel, MessageToast) {
	"use strict";

	return Controller.extend("static.js.layout.wechatMenuConf", {

		_menu_id : null,
		_wechat_message_logo_upload : "photo/picture/upload?_id=" + g_company_id + "_wechatMessage",
		_wechat_job_share_logo_upload : "photo/picture/upload?_id=" + g_company_id + "_wechatShare",
		
		onInit : function() {

			var jsonModel = new sap.ui.model.json.JSONModel("wechatmenu/load?companyId=" + g_company_id);
			this.getView().byId("wechatMessageLogoUploader").setUploadUrl(
					this._wechat_message_logo_upload + "&height=275&width=600&sizeLimit=true");
			this.getView().byId("wechatShareLogoUploader").setUploadUrl(
					this._wechat_job_share_logo_upload + "&sizeLimit=false");
			var that = this;
			jsonModel.attachRequestCompleted(function() {
				var viewData = jsonModel.getData();
				that._menu_id = viewData.menuId;
				var wechatMessageLogoId = viewData.wechatMessageLogoId;
				if (wechatMessageLogoId) {
					that.getView().byId("portrait").setVisible(true);
					that.getView().byId("noPortrait").setVisible(false);
					var oData = {
						wechatMessageLogo : "photo/" + wechatMessageLogoId + "?random=" + that.generateRandomValue()
					}
				} else {
					that.getView().byId("portrait").setVisible(false);
					that.getView().byId("noPortrait").setVisible(true);
				}
				
				var wechatShareLogoId = viewData.wechatShareLogoId;
				if (wechatShareLogoId) {
					that.getView().byId("portrait1").setVisible(true);
					that.getView().byId("noPortrait1").setVisible(false);
					var uData = {
							wechatShareLogo : "photo/" + wechatShareLogoId + "?random=" + that.generateRandomValue()
					}
				} else {
					that.getView().byId("portrait1").setVisible(false);
					that.getView().byId("noPortrait1").setVisible(true);
				}
				
				jsonModel.setData(oData, true);
				jsonModel.setData(uData, true);
				that.getView().setModel(jsonModel);
			});

		},

		onCollapseAll : function() {
			var oTreeTable = this.getView().byId("TreeTableBasic");
			oTreeTable.collapseAll();
		},

		onExpandFirstLevel : function() {
			var oTreeTable = this.getView().byId("TreeTableBasic");
			oTreeTable.expandToLevel(1);
		},

		addMenu : function() {
			var data = this.getView().getModel().getData();
			if (data.wechatMenuContent) {
				if (data.wechatMenuContent.wechatMenuItem.length >= 3) {
					MessageToast.show("You can have at most 3 Menus");
				} else {
					var newMenu = {
						name : "New Menu",
						wechatSubMenuItem : []
					};
					data.wechatMenuContent.wechatMenuItem.push(newMenu);
					this.getView().getModel().setData(data);
				}
			} else {
				data["wechatMenuContent"] = {
					"wechatMenuItem" : [ {
						name : "New Menu",
						wechatSubMenuItem : []
					} ]
				};
				this.getView().getModel().setData(data);
			}
		},

		addSubMenu : function(oEvent) {
			var rowId = oEvent.getSource().getBindingContext().getPath();
			var rows = rowId.match(/\d+/g);
			var rowNo = rows[rows.length - 1];

			var oModel = this.getView().getModel();
			var oData = oModel.getData();

			if (oData.wechatMenuContent.wechatMenuItem[rowNo].wechatSubMenuItem.length >= 5) {
				MessageToast.show("You can have at most 5 sub Menus");
			} else {
				var newSubMenu = {
					name : "New Sub Menu",
					url : "",
					type : "",
					key : ""
				};
				oData.wechatMenuContent.wechatMenuItem[rowNo].wechatSubMenuItem.push(newSubMenu);
				this.getView().getModel().setData(oData);
			}

		},

		generateRandomValue : function(){
			var array = new Uint32Array(1);
			window.crypto.getRandomValues(array);
			return array[0];
		},
		
		deleteMenu : function(oEvent) {
			var rowId = oEvent.getSource().getBindingContext().getPath();
			var rows = rowId.match(/\d+/g);
			var menuNo = "";
			var subMenuNo = "";

			var oModel = this.getView().getModel();
			var oData = oModel.getData();

			/* The selected row is submenu */
			if (rows.length > 1) {
				menuNo = rows[rows.length - 2];
				subMenuNo = rows[rows.length - 1];
				oData.wechatMenuContent.wechatMenuItem[menuNo].wechatSubMenuItem.splice(parseInt(subMenuNo), 1);
			} else {
				menuNo = rows[rows.length - 1];
				oData.wechatMenuContent.wechatMenuItem.splice(parseInt(menuNo), 1);
			}

			this.getView().getModel().setData(oData);
		},

		onTypeChange : function(oEvent) {
			var selectedKey = oEvent.getSource().getSelectedKey();
			var row = oEvent.getSource().getParent();
			var rowIdxStr = row.getBindingContext().sPath;
			var rowIdxArray = rowIdxStr.match(/\d+/g);
			var rowIdx = rowIdxArray[rowIdxArray.length - 1];
			var menuIdx;
			var subMenuIdx;
			if (rowIdxArray.length > 1) {
				menuIdx = rowIdxArray[0];
				subMenuIdx = rowIdxArray[1];
				var data = row.getBindingContext().getModel().getData();
				if (selectedKey == "click") {
					data.wechatMenuContent.wechatMenuItem[menuIdx].wechatSubMenuItem[subMenuIdx].displayKey = true;
					data.wechatMenuContent.wechatMenuItem[menuIdx].wechatSubMenuItem[subMenuIdx].displayLink = false;
				} else if (selectedKey == "view") {
					data.wechatMenuContent.wechatMenuItem[menuIdx].wechatSubMenuItem[subMenuIdx].displayKey = false;
					data.wechatMenuContent.wechatMenuItem[menuIdx].wechatSubMenuItem[subMenuIdx].displayLink = true;
				}
				row.getBindingContext().getModel().setData(data);
			}
		},

		onSave : function() {
			var oModel = this.getView().getModel();
			var oData = oModel.getData();
			// var viewData = {
			// menuId : this._menu_id,
			// companyId : g_company_id,
			// wechatMenuContent : oData.wechatMenuContent
			// };
			oData.companyId = g_company_id;
			var that = this;
			jQuery.ajax({
				url : "wechatmenu/save",
				method : "POST",
				data : JSON.stringify(oData),
				contentType : 'application/json;charset=UTF-8'
			}).success(function(data) {
				if (data) {
					MessageToast.show("Wechat Menu Saved Successfully");
				} else {
					MessageToast.show("error happened, please try again later");
				}
			})

		},

		onCancel : function() {

			window.close();
		},

		onGenerate : function() {
			var that = this;
			jQuery.ajax({
				url : "server/wechat/menu_create/" + g_company_id,
				method : "GET",
			}).success(function(data) {
				if (data.code == 0) {
					MessageToast.show("Wechat Menu Created Successfully");
				} else {
					MessageToast.show("Error happened, please try again later");
				}
			})
		},

		doLogoUpload : function(oEvent) {
			this.getView().byId("portrait").setBusy(true);
		},

		handleUploadComplete : function(oEvent) {
			this.getView().byId("portrait").setBusy(false);
			var rsp = oEvent.getParameter("response");
			this.getView().byId("noPortrait").setVisible(false);
			this.getView().byId("portrait").setVisible(true);
			if (rsp) {
				rsp = rsp.match(/{.*}/)[0];
				if (rsp) {
					var code = parseInt(JSON.parse(rsp).code);
					if (code == 0) {
						var imageData = JSON.parse(rsp).message;
						var viewData = this.getView().getModel().getData();
						viewData.wechatMessageLogo = "photo/temp/" + imageData + "?random=" + this.generateRandomValue();
						this.getView().getModel().setData(viewData);
					}
				}
			}
		},
		
		doShareLogoUpload : function(oEvent) {
			this.getView().byId("portrait1").setBusy(true);
		},

		handleShareLogoUploadComplete : function(oEvent) {
			this.getView().byId("portrait1").setBusy(false);
			var rsp = oEvent.getParameter("response");
			this.getView().byId("noPortrait1").setVisible(false);
			this.getView().byId("portrait1").setVisible(true);
			if (rsp) {
				rsp = rsp.match(/{.*}/)[0];
				if (rsp) {
					var code = parseInt(JSON.parse(rsp).code);
					if (code == 0) {
						var imageData = JSON.parse(rsp).message;
						var viewData = this.getView().getModel().getData();
						viewData.wechatShareLogo = "photo/temp/" + imageData + "?random=" + this.generateRandomValue();
						this.getView().getModel().setData(viewData);
					}
				}
			}
		}
	});

});
