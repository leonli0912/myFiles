package com.sap.hcm.resume.collection.controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.sap.hcm.resume.collection.bean.ActionType;
import com.sap.hcm.resume.collection.bean.LogObjectType;
import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.bean.SimpleJsonResponse;
import com.sap.hcm.resume.collection.entity.ChangeLog;
import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.entity.Photo;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.service.ChangeLogService;
import com.sap.hcm.resume.collection.service.JobSchedulerService;
import com.sap.hcm.resume.collection.service.PhotoService;
import com.sap.hcm.resume.collection.util.CandidateFileUtil;
import com.sap.hcm.resume.collection.util.ChangeLogUtil;

@Controller
@RequestMapping(value = "company")
public class CompanyInfoController extends ControllerBase {

  private final static String COMPANY_LOGO = "_logo";

  /**
   * logger instance
   */
  private static final Logger logger = LoggerFactory.getLogger(CompanyInfoController.class);

  @Autowired
  private PhotoService photoService;

  @Autowired
  private ChangeLogUtil changeLogUtil;

  @Autowired
  private ChangeLogService changeLogService;
  
  @Autowired
  private JobSchedulerService jobSchedulerService;

  @Autowired
  private Params params;

  @RequestMapping(value = "save", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
  public @ResponseBody CompanyInfo saveCompanyInfo(HttpServletRequest request, @RequestBody CompanyInfo companyInfo)
      throws ServiceApplicationException {

    // Retrieve the company info from database to make sure all the changes are reflected.
    // Especially for candidate profile mapping and job status filter
    CompanyInfo compInfoOriginal = this.compInfoService.getCompanyInfo(companyInfo.getCompanyId());
    if (compInfoOriginal.getDmMappingId() != null) {
      companyInfo.setDmMappingId(compInfoOriginal.getDmMappingId());
    }

    if (compInfoOriginal.getJobReqMappingId() != null) {
      companyInfo.setJobReqMappingId(compInfoOriginal.getJobReqMappingId());
    }

    if (compInfoOriginal.getJobStatuses() != null) {
      companyInfo.setJobStatuses(compInfoOriginal.getJobStatuses());
    }

    // check whether user has upload the new company logo
    byte[] item = (byte[]) request.getSession().getAttribute(companyInfo.getCompanyId() + COMPANY_LOGO);
    if (item != null) {
      Photo photo = new Photo();
      if (companyInfo.getLogoId() != null) {
        photo.setPhotoId(companyInfo.getLogoId());
      }
      photo.setCategory("company_portrait");
      photo.setContent(item);
      photo = photoService.saveImg(photo);
      try {
        byte[] sharePicItem = CandidateFileUtil.extendImage(item, 200, 200);
        Photo sharePicPhoto = new Photo();
        if (companyInfo.getSharePicId() != null) {
          sharePicPhoto.setPhotoId(companyInfo.getSharePicId());
        }
        sharePicPhoto.setCategory("share_picture");
        sharePicPhoto.setContent(sharePicItem);
        sharePicPhoto = photoService.saveImg(sharePicPhoto);
        companyInfo.setSharePicId(sharePicPhoto.getPhotoId());
      } catch (IOException e) {
        throw new ServiceApplicationException("Error when extend the companyLOGO to the sharePicture");
      }
      request.getSession().removeAttribute(companyInfo.getCompanyId() + COMPANY_LOGO);
      companyInfo.setLogoId(photo.getPhotoId());
    }

    // check whether user has upload the new two-dimension code
    byte[] codeItem = (byte[]) request.getSession().getAttribute(
        companyInfo.getCompanyId() + "_twoDimension" + COMPANY_LOGO);
    if (codeItem != null) {
      Photo photo = new Photo();
      if (companyInfo.getTwoDimensionCode() != null) {
        photo.setPhotoId(companyInfo.getTwoDimensionCode());
      }
      photo.setCategory("two_dimension_code");
      photo.setContent(codeItem);
      photo = photoService.saveImg(photo);
      request.getSession().removeAttribute(companyInfo.getCompanyId() + "_twoDimension" + COMPANY_LOGO);
      companyInfo.setTwoDimensionCode(photo.getPhotoId());
    }
    try {
      companyInfo.setApplyStatusMapping(URLDecoder.decode(companyInfo.getApplyStatusMapping(), "utf-8"));
    } catch (UnsupportedEncodingException e) {
      logger.error("decode apply status mapping exception: " + e.getMessage());
      throw new ServiceApplicationException("Apply Status Mapping is invalid XML");
    }
    changeLogUtil.saveCompanyChangeHistory(ActionType.EDT, hcpUserProvider.getLoginUser(request).getName(),
        "edit company setting", companyInfo.getCompanyId(), companyInfo.getCompanyName(), companyInfo.getCompanyId());
    CompanyInfo infoResult = compInfoService.saveCompanyInfo(companyInfo);
    jobSchedulerService.resetJob(infoResult);
    return infoResult;
  }

  @RequestMapping(value = "info", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
  public @ResponseBody CompanyInfo getCompanyInfo() throws ServiceApplicationException {
    return compInfoService.getCompanyInfo(params.getCompanyId());
  }

  @RequestMapping(value = "jobStatusList", method = RequestMethod.GET, produces = "application/json;charset=UTF-8")
  public @ResponseBody SimpleJsonResponse getJobStatuses() throws ServiceApplicationException {
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(-1);
    rsp.setMessage("Job Status List is empty");
    CompanyInfo companyinfo = compInfoService.getCompanyInfo(params.getCompanyId());
    String statuses = companyinfo.getJobStatuses();
    if (statuses != null && !statuses.isEmpty()) {
      rsp.setCode(0);
      rsp.setMessage(statuses);
    }
    return rsp;
  }

  @RequestMapping(value = "saveJobStatusFilter", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
  public @ResponseBody SimpleJsonResponse saveJobStatuses(@RequestParam(value = "status") String status)
      throws ServiceApplicationException {
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(-1);
    rsp.setMessage("Save job status failed");
    CompanyInfo companyinfo = compInfoService.getCompanyInfo(params.getCompanyId());
    if (!StringUtils.isEmpty(status)) {
      companyinfo.setJobStatuses(status);
      compInfoService.saveCompanyInfo(companyinfo);
      rsp.setCode(0);
      rsp.setMessage("success");
    }
    return rsp;
  }

  @RequestMapping(value = "maintain")
  public ModelAndView maintainCompanyInfo(HttpServletRequest request) {
    ModelAndView mav = new ModelAndView();

    // verify company Id
    String resultView = this.validateCompanyAndUser(params.getCompanyId());

    if (!StringUtils.isEmpty(resultView)) {
      mav.setViewName(resultView);
      return mav;
    }
    mav.addObject(params.getCompanyId());

    mav.setViewName("maintain_company");
    return mav;
  }

  @RequestMapping(value = "logo/remove")
  public void removeCompanyLogo(HttpServletRequest request) {
    request.getSession().removeAttribute(params.getCompanyId() + COMPANY_LOGO);
  }

  @RequestMapping(value = "dpcs", method = RequestMethod.GET)
  public @ResponseBody Map<String, String> getDpcs(HttpServletRequest request) throws ServiceApplicationException {
    CompanyInfo companyInfo = compInfoService.getCompanyInfo(params.getCompanyId());
    Map<String, String> data = new HashMap<String, String>();
    String strDpcs = "";
    try {
      strDpcs = companyInfo.getDpcs();
    } catch (Exception ex) {
      logger.debug("get dpcs failed");
    }
    data.put("dpcs", strDpcs);
    return data;
  }

  @RequestMapping(value = "/changecompanyhistory", method = RequestMethod.GET)
  public @ResponseBody List<ChangeLog> showChangeCompanyHistory(HttpServletRequest request)
      throws ServiceApplicationException {
    try {
      return changeLogService.getChangeLogList(params.getCompanyId(), null,
          LogObjectType.COMPANY_SETTING.getObjectName());
    } catch (ServiceApplicationException e) {
      throw new ServiceApplicationException("get change log failed");
    }
  }

  @RequestMapping(value = "/jobsynchistory", method = RequestMethod.GET)
  public @ResponseBody List<ChangeLog> showjobSyncHistory(HttpServletRequest request)
      throws ServiceApplicationException {
    try {
      return changeLogService.getChangeLogList(params.getCompanyId(), null, LogObjectType.JOB_SYNC.getObjectName());
    } catch (ServiceApplicationException e) {
      throw new ServiceApplicationException("get job sync change log failed");
    }
  }
}
