package com.sap.hcm.resume.collection.integration.wechat.controller;

import java.io.UnsupportedEncodingException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import javax.persistence.PersistenceException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.sap.hcm.resume.collection.bean.FilterListItem;
import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.bean.SimpleJsonResponse;
import com.sap.hcm.resume.collection.controller.ControllerBase;
import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.entity.view.JobRequisitionMappingVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.bean.JobReqDataModelMappingItem;
import com.sap.hcm.resume.collection.integration.service.JobApplicationIntegrationService;
import com.sap.hcm.resume.collection.integration.sf.bean.SFPicklistCacheEntityType;
import com.sap.hcm.resume.collection.integration.sf.bean.SFPicklistItem;
import com.sap.hcm.resume.collection.integration.sf.service.SFPicklistCacheService;
import com.sap.hcm.resume.collection.integration.wechat.bean.JobDynSearchBean;
import com.sap.hcm.resume.collection.integration.wechat.bean.JobDynSearchBeanItem;
import com.sap.hcm.resume.collection.integration.wechat.bean.JobStatusEnum;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatApplyHistory;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJob;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJobVO;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatJobScreeningQuestionService;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatJobService;
import com.sap.hcm.resume.collection.service.DataModelMappingService;
import com.sap.hcm.resume.collection.service.JobRequisitionService;
import com.sap.hcm.resume.collection.util.MappingUtil;

@Controller
@RequestMapping(value = "/job")
public class JobInfoController extends ControllerBase {

  /**
   * logger
   */
  private static final Logger logger = LoggerFactory.getLogger(JobInfoController.class);

  @Autowired
  private WechatJobService wechatJobService;

  @Autowired
  private SFPicklistCacheService pklCacheService;

  @Autowired
  private DataModelMappingService dmMappingService;

  @Autowired
  private SFPicklistCacheService sfPicklistCacheService;

  @Autowired
  private JobRequisitionService jobRequisitionService;

  @Autowired
  private WechatJobScreeningQuestionService wechatJobScreeningQuestionService;

  @Autowired
  @Qualifier("sfJobApplicationService")
  private JobApplicationIntegrationService sfJobApplicationService;

  @Autowired
  private Params params;

  /**
   * new job list for dynamic job criteria search
   * 
   * @param searchBean
   * @param session
   * @return
   * @throws ServiceApplicationException
   */
  @RequestMapping(value = "/list", method = RequestMethod.POST)
  public @ResponseBody Map<String, Object> getJobInfoListNew(HttpServletRequest request,
      @RequestBody JobDynSearchBean searchBean, HttpSession session) throws ServiceApplicationException {

    String companyId = params.getCompanyId();

    searchBean.setCompanyId(companyId);

    if (!StringUtils.isEmpty(searchBean.getInputFilterValue())) {
      String inputFilterValue = "";
      try {
        inputFilterValue = java.net.URLDecoder.decode(searchBean.getInputFilterValue(), "utf-8");
      } catch (UnsupportedEncodingException e) {
        inputFilterValue = searchBean.getInputFilterValue();
      }
      searchBean.setInputFilterValue(inputFilterValue);
    }

    // filter out only the posted job
    List<JobDynSearchBeanItem> searchItems = searchBean.getItems();
    if (searchItems == null) {
      searchItems = new ArrayList<JobDynSearchBeanItem>();
    }
    JobDynSearchBeanItem searchItem = new JobDynSearchBeanItem();
    searchItem.setType("status");
    searchItem.setValues(Arrays.asList(String.valueOf(JobStatusEnum.POSTED.getCode())));
    searchItems.add(searchItem);
    searchBean.setItems(searchItems);

    // order by
    searchBean.setOrderBy("createAt desc");

    Map<String, Object> map = new HashMap<String, Object>();
    List<WechatJob> jobInfoList = wechatJobService.getJobInfoList(searchBean);

    Long totalCount = wechatJobService.getTotalCount(searchBean);

    List<WechatJobVO> jobVOList = new ArrayList<WechatJobVO>();
    for (WechatJob wechatJob : jobInfoList) {
      WechatJobVO vo = WechatJobVO.fromWechatJobEntity(wechatJob);
      jobVOList.add(vo);
    }
    map.put("jobs", jobVOList);
    map.put("count", totalCount);

    Locale locale = request.getLocale();
    if (locale == null) {
      locale = Locale.CHINA;
    }
    List<FilterListItem> filterList = wechatJobService.getFilterListByConfig(companyId, locale);
    map.put("filters", filterList);
    return map;
  }

  @RequestMapping(value = "/maintainList", method = RequestMethod.POST)
  public @ResponseBody Map<String, Object> getMaintainJobInfoListNew(HttpServletRequest request,
      @RequestBody JobDynSearchBean searchBean, HttpSession session) throws ServiceApplicationException {

    String companyId = params.getCompanyId();

    searchBean.setCompanyId(companyId);

    if (!StringUtils.isEmpty(searchBean.getInputFilterValue())) {
      String inputFilterValue = "";
      try {
        inputFilterValue = java.net.URLDecoder.decode(searchBean.getInputFilterValue(), "utf-8");
      } catch (UnsupportedEncodingException e) {
        inputFilterValue = searchBean.getInputFilterValue();
      }
      searchBean.setInputFilterValue(inputFilterValue);
    }

    if (StringUtils.isEmpty(companyId)) {
      throw new ServiceApplicationException("company id is not supplied");
    }

    Map<String, Object> map = new HashMap<String, Object>();
    List<WechatJob> jobInfoList = wechatJobService.getJobInfoList(searchBean);

    Long totalCount = wechatJobService.getTotalCount(searchBean);

    List<WechatJobVO> jobVOList = new ArrayList<WechatJobVO>();
    for (WechatJob wechatJob : jobInfoList) {
      WechatJobVO vo = WechatJobVO.fromWechatJobEntity(wechatJob);
      jobVOList.add(vo);
    }
    map.put("jobs", jobVOList);
    map.put("count", totalCount);

    Locale locale = request.getLocale();
    if (locale == null) {
      locale = Locale.CHINA;
    }
    List<FilterListItem> filterList = wechatJobService.getFilterListByConfig(companyId, locale);

    map.put("filters", filterList);
    return map;
  }

  @RequestMapping(value = "/save", method = RequestMethod.POST)
  public @ResponseBody SimpleJsonResponse saveJob(HttpServletRequest request, HttpSession session,
      @RequestBody WechatJobVO wechatJobVO) throws ServiceApplicationException {

    SimpleJsonResponse rsp = new SimpleJsonResponse();
    String companyId = params.getCompanyId();

    wechatJobVO.setCompanyId(companyId);

    if (wechatJobVO.getExternalJobId().contains("-")) {
      /* Create multiple jobs */
      String[] reqIds = wechatJobVO.getExternalJobId().split("-");
      String fromIdStr = reqIds[0];
      String toIdStr = reqIds[1];

      Long fromId = Long.parseLong(fromIdStr);
      Long toId = Long.parseLong(toIdStr);
      if (toId > fromId) {
        int successCount = 0;
        String errorMessage = null;
        for (long count = fromId; count <= toId; count++) {
          WechatJobVO newWechatJobVO = new WechatJobVO();
          BeanUtils.copyProperties(wechatJobVO, newWechatJobVO);
          newWechatJobVO.setExternalJobId(Long.toString(count));
          try {
            newWechatJobVO.setCreateAt(new Date());
            wechatJobService.saveJob(newWechatJobVO.toWechatJobEntity());
            successCount++;
          } catch (PersistenceException e) {
            errorMessage = e.getMessage();
          } catch (ServiceApplicationException sae) {
            errorMessage = sae.getMessage();
          }

        }
        if (successCount > 0) {
          rsp.setCode(0);
          rsp.setMessage(String.valueOf(successCount));
        } else {
          rsp.setCode(-1);
          rsp.setMessage("save job failed");
          logger.error("save job failed with exception : " + errorMessage);
        }
      }
    } else {
      try {
        wechatJobVO.setCreateAt(new Date());
        wechatJobService.saveJob(wechatJobVO.toWechatJobEntity());
        rsp.setCode(0);
        rsp.setMessage("success");
      } catch (PersistenceException e) {
        rsp.setCode(-1);
        rsp.setMessage("save job failed");
        logger.error("save job failed with exception : " + e.getMessage());
      } catch (ServiceApplicationException sae) {
        rsp.setCode(-1);
        rsp.setMessage("save job failed");
        logger.error("save job failed with exception : " + sae.getMessage());
      }
    }

    return rsp;
  }

  @RequestMapping(value = "/update", method = RequestMethod.POST)
  public @ResponseBody SimpleJsonResponse updateJob(HttpServletRequest request, @RequestBody WechatJobVO wechatJobVO) {
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    // String jobId = request.getParameter("jobId");
    try {
      wechatJobVO.setLastModify(new Date());
      wechatJobService.saveJob(wechatJobVO.toWechatJobEntity());
      rsp.setCode(0);
      rsp.setMessage("success");
    } catch (PersistenceException e) {
      rsp.setCode(-1);
      rsp.setMessage("update job failed");
      logger.error("update job failed with exception : " + e.getMessage());
    } catch (ServiceApplicationException sae) {
      rsp.setCode(-1);
      rsp.setMessage("update job failed");
      logger.error("update job failed with exception : " + sae.getMessage());
    }

    return rsp;
  }

  @RequestMapping(value = "/publish", method = RequestMethod.POST)
  public @ResponseBody SimpleJsonResponse publishJob(@RequestParam(value = "jobId") Long jobId) {
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    try {
      WechatJob wechatJob = wechatJobService.findJobById(jobId);
      wechatJob.setStatus(JobStatusEnum.POSTED.getCode());
      wechatJob.setLastModify(new Date());
      wechatJobService.saveJob(wechatJob);
      rsp.setCode(0);
      rsp.setMessage("success");
    } catch (PersistenceException e) {
      rsp.setCode(-1);
      rsp.setMessage("publish job failed");
      logger.error("publish job failed with exception : " + e.getMessage());
    } catch (ServiceApplicationException e) {
      rsp.setCode(-1);
      rsp.setMessage("publish job failed");
      logger.error("publish job failed with exception : " + e.getMessage());
    }

    return rsp;
  }

  @RequestMapping(value = "/batchpublish", method = RequestMethod.POST)
  public @ResponseBody SimpleJsonResponse batchPublishJob(@RequestBody List<Long> jobIdList) {
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    int successCount = 0;
    String errorMessage = null;
    for (Long jobId : jobIdList) {
      try {
        WechatJob wechatJob = wechatJobService.findJobById(jobId);
        wechatJob.setStatus(JobStatusEnum.POSTED.getCode());
        wechatJob.setLastModify(new Date());
        wechatJobService.saveJob(wechatJob);
        successCount++;
      } catch (PersistenceException e) {
        errorMessage = e.getMessage();
      } catch (ServiceApplicationException e) {
        errorMessage = e.getMessage();
      }
    }

    if (successCount > 0) {
      rsp.setCode(0);
      rsp.setMessage(String.valueOf(successCount));
    } else {
      rsp.setCode(-1);
      rsp.setMessage("batch publish job failed");
      logger.error("batch publish job failed with exception : " + errorMessage);
    }

    return rsp;
  }

  @RequestMapping(value = "/batchdelete", method = RequestMethod.DELETE)
  public @ResponseBody SimpleJsonResponse batchDeleteJob(@RequestBody List<Long> jobIdList) {
    SimpleJsonResponse rsp = new SimpleJsonResponse();

    int successCount = 0;
    String errorMessage = null;
    for (Long jobId : jobIdList) {
      try {
        wechatJobService.deleteJobById(jobId);
        successCount++;
      } catch (PersistenceException e) {
        errorMessage = e.getMessage();
      } catch (ServiceApplicationException e) {
        errorMessage = e.getMessage();
      }
    }

    if (successCount > 0) {
      rsp.setCode(0);
      rsp.setMessage(String.valueOf(successCount));
    } else {
      rsp.setCode(-1);
      rsp.setMessage("batch delete job failed");
      logger.error("batch delete job failed with exception : " + errorMessage);
    }

    return rsp;
  }

  @RequestMapping(value = "/delete", method = RequestMethod.DELETE)
  public @ResponseBody SimpleJsonResponse deleteJob(@RequestParam(value = "jobId") Long jobId) {
    SimpleJsonResponse rsp = new SimpleJsonResponse();

    try {
      wechatJobScreeningQuestionService.deleteJobScreeningQuestionAndChoice(jobId, params.getCompanyId());
      rsp.setCode(0);
      rsp.setMessage("success");
    } catch (PersistenceException e) {
      rsp.setCode(-1);
      rsp.setMessage("delete job question & choice failed");
      logger.error("delete job question & choice failed with exception : " + e.getMessage());
      return rsp;
    } catch (ServiceApplicationException e) {
      rsp.setCode(-1);
      rsp.setMessage("delete job question & choice failed");
      logger.error("delete job question & choice failed with exception : " + e.getMessage());
      return rsp;
    }

    try {
      wechatJobService.deleteJobById(jobId);
      rsp.setCode(0);
      rsp.setMessage("success");
    } catch (PersistenceException e) {
      rsp.setCode(-1);
      rsp.setMessage("delete job failed");
      logger.error("delete job failed with exception : " + e.getMessage());
    } catch (ServiceApplicationException e) {
      rsp.setCode(-1);
      rsp.setMessage("delete job failed");
      logger.error("delete job failed with exception : " + e.getMessage());
    }

    return rsp;
  }

  @RequestMapping(value = "/{jobId}", method = RequestMethod.GET)
  public @ResponseBody Map<String, Object> getJobById(HttpSession session, @PathVariable(value = "jobId") Long jobId,
      @RequestParam(value = "mode", required = false, defaultValue = "edit") String mode)
      throws ServiceApplicationException {
    Map<String, Object> map = new HashMap<String, Object>();
    List<WechatApplyHistory> applyHistoryList = new ArrayList<WechatApplyHistory>();
    String companyId = params.getCompanyId();
    String userEmail = params.getUserEmail();

    WechatJob wechatJob = wechatJobService.findJobById(jobId);
    if ("display".equals(mode)) {
      Set<JobReqDataModelMappingItem> items = dmMappingService.getPicklistForJobRequisition(companyId, false);
      if (items != null && !items.isEmpty()) {
        for (JobReqDataModelMappingItem item : items) {
          if (!StringUtils.isEmpty(item.getPicklist())) {
            String propName = MappingUtil.methodNameCapitalized(item.getSourceField());
            try {
              Method method = wechatJob.getClass().getMethod("get" + propName);
              Object obj = method.invoke(wechatJob);
              if (obj != null && obj instanceof String) {
                String optionId = (String) obj;
                String pklLabel = sfPicklistCacheService
                    .getPKLLabelByOptionId(item.getPicklist(), companyId, Long.parseLong(optionId),
                        Locale.CHINA.toString(), SFPicklistCacheEntityType.JOB_REQUISITION.name());
                Method setMethod = wechatJob.getClass().getMethod("set" + propName, String.class);
                setMethod.invoke(wechatJob, pklLabel);

              }
            } catch (Exception e) {
              continue;
            }
          }
        }
      }
    }
    WechatJobVO wechatJobOV = WechatJobVO.fromWechatJobEntity(wechatJob);
    map.put("jobInfo", wechatJobOV);
    String jobReqId = wechatJobOV.getExternalJobId();
    boolean disAppButton = true;
    if (!StringUtils.isEmpty(userEmail) && !StringUtils.isEmpty(companyId)) {
      try {
        applyHistoryList = wechatJobService.findApplyHistory(userEmail, companyId, jobReqId);
        if (applyHistoryList.isEmpty()) {
          disAppButton = true;
        } else {
          disAppButton = false;
        }

      } catch (ServiceApplicationException e) {
        e.printStackTrace();
      }
    }
    map.put("disAppButton", disAppButton);
    map.put("disAppStatus", !disAppButton);
    return map;
  }

  @RequestMapping(value = "/maintain")
  public ModelAndView maintainJobInfo(HttpSession session, HttpServletRequest request) {
    ModelAndView mav = new ModelAndView();

    String companyId = params.getCompanyId();
    // validate companyInfo
    try {
      CompanyInfo info = compInfoService.getCompanyInfo(companyId);
      if (info == null) {
        mav.setViewName("invalid_company");
        return mav;
      }
    } catch (ServiceApplicationException e) {
      mav.setViewName("invalid_company");
      return mav;
    }

    String docBase = request.getScheme() + "://" + request.getServerName() + ":" + request.getServerPort()
        + request.getContextPath() + "/";
    mav.addObject("DOCBASE", docBase);

    mav.addObject(companyId);
    mav.setViewName("maintain_job");
    // set compnayId into session
    return mav;
  }

  @RequestMapping(value = "/picklists", method = RequestMethod.GET)
  public @ResponseBody Map<String, List<SFPicklistItem>> getPicklistsFromCache(HttpServletRequest request) {
    Map<String, List<SFPicklistItem>> pkMap = new HashMap<String, List<SFPicklistItem>>();
    String localeResult = Locale.US.toString();
    String locale = request.getLocale().toString();
    if (locale.contains("_")) {
      locale = locale.split("_")[0];
    }
    List<String> picklistLocaleList = pklCacheService.getPicklistLocales(params.getCompanyId(),
        SFPicklistCacheEntityType.JOB_REQUISITION.name());
    for (String picklistLocale : picklistLocaleList) {
      if (picklistLocale.contains(locale)) {
        localeResult = picklistLocale;
      }
    }
    pkMap = pklCacheService.getPicklistOptions(params.getCompanyId(), localeResult,
        SFPicklistCacheEntityType.JOB_REQUISITION.name());
    return pkMap;
  }

  @RequestMapping(value = "/loadJob", method = RequestMethod.POST)
  public @ResponseBody Map<String, String> getJobRequisition(HttpServletRequest request)
      throws ServiceApplicationException {

    String lowDate = request.getParameter("updateFrom");
    String highDate = request.getParameter("updateTo");
    String jobReqIdStr = request.getParameter("reqId");
    return jobRequisitionService.getJobRequisition(lowDate, highDate, jobReqIdStr);
  }

  @RequestMapping("/search")
  public @ResponseBody Map<String, Object> getJobRequisition(@RequestParam(value = "condition") String condition)
      throws UnsupportedEncodingException {
    return jobRequisitionService.getJobRequisitionForSearch(condition);

  }

  
  @RequestMapping(value = "/recommendJobId")
  public @ResponseBody Map<String, Object> getRecommendJobId(HttpServletRequest request) {
    Long jobId = -1L;
    if (request.getSession().getAttribute("jobId") != null) {
      jobId = (Long) request.getSession().getAttribute("jobId");
      request.getSession().removeAttribute("jobId");
    }
    Map<String, Object> map = new HashMap<String, Object>();
    map.put("jobId", jobId);
    return map;
  }
  
  @RequestMapping(value = "/jobreq/{mappingId}", method = RequestMethod.GET)
  public @ResponseBody JobRequisitionMappingVO listjobReqDMMappingbyId(
      @PathVariable(value = "mappingId") Long mappingId) {
    return dmMappingService.getJobRequisitionMappingById(params.getCompanyId(), mappingId);
  }
}
