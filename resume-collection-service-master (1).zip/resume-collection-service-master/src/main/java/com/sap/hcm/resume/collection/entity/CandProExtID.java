package com.sap.hcm.resume.collection.entity;

import java.io.Serializable;

public class CandProExtID implements Serializable{
	
	/**
	 * serialVersionUID
	 */
    private static final long serialVersionUID = -6605165308311705641L;

	private Long candidateId;
	
	private String paramName;
	
	public CandProExtID(){
		
	}
	
	/**
	 * @return the candiateId
	 */
	public Long getCandidateId() {
		return candidateId;
	}

	/**
	 * @param candiateId the candiateId to set
	 */
	public void setCandidateId(Long candiateId) {
		this.candidateId = candiateId;
	}

	/**
	 * @return the paramName
	 */
	public String getParamName() {
		return paramName;
	}

	/**
	 * @param paramName the paramName to set
	 */
	public void setParamName(String paramName) {
		this.paramName = paramName;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
    @Override
    public int hashCode() {
	    final int prime = 31;
	    int result = 1;
	    result = prime * result + ((candidateId == null) ? 0 : candidateId.hashCode());
	    result = prime * result + ((paramName == null) ? 0 : paramName.hashCode());
	    return result;
    }

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
    @Override
    public boolean equals(Object obj) {
	    if (this == obj)
		    return true;
	    if (obj == null)
		    return false;
	    if (getClass() != obj.getClass())
		    return false;
	    CandProExtID other = (CandProExtID) obj;
	    if (candidateId == null) {
		    if (other.candidateId != null)
			    return false;
	    } else if (!candidateId.equals(other.candidateId))
		    return false;
	    if (paramName == null) {
		    if (other.paramName != null)
			    return false;
	    } else if (!paramName.equals(other.paramName))
		    return false;
	    return true;
    }
}
