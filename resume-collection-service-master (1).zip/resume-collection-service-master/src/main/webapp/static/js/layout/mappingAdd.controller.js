jQuery.sap.require("sap.m.MessageBox");
sap.ui.controller("static.js.layout.mappingAdd", {

	_currentMapping : null,

	_router: null,

	_sample_pk_option_mapping : "static/model/picklist_option_mapping_template.json",

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf resume-collection-service.mappingAdd
*/
	onInit: function() {

	    var oData = {
	    	"options":[{
	    		"key":"SF",
	    		"label":"SuccessFactor"
	    	}]
	    };
	    var oTargetSystem = this.getView().byId("targetSystem");
	    var oTargetSystemModel = new sap.ui.model.json.JSONModel();
	    oTargetSystemModel.setData(oData);
	    oTargetSystem.setModel(oTargetSystemModel);

	    this._router = sap.ui.core.UIComponent.getRouterFor(this);
		var that = this;
		this._router.attachRouteMatched(function(oEvent){
			if(oEvent.getParameter("name") === "mappingDetail" || oEvent.getParameter('name') === "newMapping"){
				that.loadMappingData(oEvent.getParameter("arguments").id);
			}
		});
	},

	checkRequired : function(list) {

		for (var i = 0; i < list.length; i++) {
			if (!list[i].required || list[i].required === "false") {
				continue;
			} else if (list[i].to === null || list[i].to === "") {
				return list[i].from + " is required";
			}
		}
		return null;
	},

	alertMsg : function(requiredMsg) {
		var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
	    sap.m.MessageBox.alert(
	    	requiredMsg,
	    	{
	    		styleClass: bCompact? "sapUiSizeCompact" : ""
	    	}
	    );
	},

	onSave : function(oEvent) {

		var requiredMsg = "";
		var mappingModel = this.getView().getModel();
		var mappingOdata = mappingModel.getData();

		var profileList = mappingOdata.profile;
		requiredMsg = this.checkRequired(profileList);
		if (requiredMsg !== null) {
			this.alertMsg(requiredMsg);
			return;
		}

		var workExprsList = mappingOdata.workExprs;
		requiredMsg = this.checkRequired(workExprsList);
		if (requiredMsg !== null) {
			this.alertMsg(requiredMsg);
			return;
		}

		var educationList = mappingOdata.education;
		requiredMsg = this.checkRequired(educationList);
		if (requiredMsg !== null) {
			this.alertMsg(requiredMsg);
			return;
		}

		var languagesList = mappingOdata.languages;
		requiredMsg = this.checkRequired(languagesList);
		if (requiredMsg !== null) {
			this.alertMsg(requiredMsg);
			return;
		}

		var certificatesList = mappingOdata.certificates;
		requiredMsg = this.checkRequired(certificatesList);
		if (requiredMsg !== null) {
			this.alertMsg(requiredMsg);
			return;
		}

		var familiesList = mappingOdata.families;
		requiredMsg = this.checkRequired(familiesList);
		if (requiredMsg !== null) {
			this.alertMsg(requiredMsg);
			return;
		}

		var targetSystemData = this.getView().byId("targetSystem").getSelectedKey();
		var mappingNameData = this.getView().byId("mappingName").getValue();

		var mappingData = mappingModel.getData();

		if(mappingData.pkOptionMappingString){
			mappingData.pkOptionMappingString = encodeURIComponent(mappingData.pkOptionMappingString);
		}
		var canProKey = ["profile", "certificates", "education", "families", "languages"];
		for(key in mappingData){
			if(canProKey.indexOf(key)!= -1){
				for (idx in mappingData[key]){
					if(mappingData[key][idx].fieldType == "PICKLIST" && !mappingData[key][idx].picklist){
						this.alertMsg("picklist id should not be empty for the field: " +  this.translateText(mappingData[key][idx].label));
						return;
					}
				} 
			}
		}
		var jsonData = {
				id : this._currentMapping ? this._currentMapping.mappingId : null,
				targetSystem : targetSystemData,
				mappingName : mappingNameData,
				mapping : mappingData
		};
		var that = this;
		var cfg = {
			type : 'POST',
			data: JSON.stringify(jsonData),
			dataType : 'json',
			contentType : 'application/json;charset=UTF-8'
		};
		this.getView().setBusy(true);
		cfg.url = "dm/save"
	    $.ajax(cfg).success(function(data) {
	    	that.getView().setBusy(false);
	    	if(data && data.code == "-1"){
	    		that.alertMsg(data.message);
	    	}else{
	    		that._router.navTo("mappingList");
	    	}

	    });

	},

	onCancel : function() {
		this._router.navTo("mappingList");
	},

	loadMappingData:function(mappingId){
		var that = this;
		if(mappingId){
			$.ajax({
				type:"GET",
				dataType:"json",
				url:"dm/list/"+mappingId
			}).success(function(data) {
				that._currentMapping = data;
				var oMappingModel = new sap.ui.model.json.JSONModel("dm/" + data.mappingId);
				that.getView().setModel(oMappingModel);
				that.getView().byId("mappingName").setValue(data.mappingName);
		    });
		}else{
			var oMappingModel = new sap.ui.model.json.JSONModel("dm/new");
			that.getView().setModel(oMappingModel);
			that.getView().byId("mappingName").setValue("");
			that._currentMapping = null;
		}
	},

	clearValue: function(oEvent){
		var p = oEvent.getSource().getParent();
		var path = p.getBindingContext().getPath();
		var pro1 = path.split("/")[1];
		var pro2 = path.split("/")[2];
		var mappingPage = this.getView().byId("mappingPage");
		var modelData = mappingPage.getModel().getData();
		modelData[pro1][pro2].to = "";
		modelData[pro1][pro2].picklist = "";
		modelData[pro1][pro2].required= false;
		modelData[pro1][pro2].fieldType= "EMPTY";
		modelData[pro1][pro2].displayPicklistId = false;
		mappingPage.getModel().setData(modelData);

	},

	translateText: function(val){
		return this.getView().getModel("i18n").getResourceBundle().getText(val);
	},

	openPicklistOptionDialog: function(oEvent){
		this.getView().byId("picklistOptionMappingDialog").open();
	},

	pickOptionDialogClose: function(){
		this.getView().byId("picklistOptionMappingDialog").close();
	},
	openEditMappingOverwriteDialog: function(oEvent){
		var dmData = this.getView().getModel().getData();
		var targetFields = [];
		if(dmData.profile){
			for(p in dmData.profile){
				if(dmData.profile[p].to){
					targetFields.push(dmData.profile[p]);
				}
			}
		}
		var oJsonModel = new sap.ui.model.json.JSONModel();
		oJsonModel.setData({targets: targetFields});
		this.getView().byId("dataMappingOverwriteDialog").setModel(oJsonModel,"ruleTarget");
		this.getView().byId("dataMappingOverwriteDialog").open();
	},
	editMappingOverwriteClose: function(){
		this.getView().byId("dataMappingOverwriteDialog").close();
	},

	addDMOverwriteRule: function(){
		var dmData = this.getView().getModel().getData();
		if(!dmData.dataMappingOverwrites || !dmData.dataMappingOverwrites.rules){
			dmData.dataMappingOverwrites = {};
			dmData.dataMappingOverwrites.rules = [];
		}
		var rule = "";
		var targetField = this.getView().byId("ruleTargetField").getSelectedKey();
		rule = targetField + " = ";
		var sourceFields = this.getView().byId("ruleSourceFields");
		if(sourceFields.getItems().length == 0){return;}
		for(var i = 0; i < sourceFields.getItems().length; i++){
			var item = sourceFields.getItems()[i];
			var f = "";
			if(item instanceof sap.m.Select){
				f = item.getSelectedKey();
			}else{
				f = "\"" + item.getValue() + "\"";
			}

			rule = rule + f;
			if(i < sourceFields.getItems().length - 1){
				rule = rule + " + ";
			}
		}
		dmData.dataMappingOverwrites.rules.push(rule);

		this.getView().getModel().setData(dmData);
	},
	addRuleSourceField: function(oEvent){
		var ruleSourceFields = this.getView().byId("ruleSourceFields");
		var eDock = sap.ui.core.Popup.Dock;
		this.getView().byId("ruleSourceAddMenu").open(null, oEvent.getSource(), eDock.BeginTop, eDock.BeginBottom, oEvent.getSource());
	},
	resetRuleSourceField: function(){
		var ruleSourceFields = this.getView().byId("ruleSourceFields");
		ruleSourceFields.destroyItems();
	},
	addRuleSourceFieldFromCandP: function(){
		var that = this;
		var ruleSourceFields = this.getView().byId("ruleSourceFields");
		var oItemTemplate = new sap.ui.core.Item({
			key:"{from}",
			text:{
				path:"label",
				formatter:function(val){
					return that.getView().getModel("i18n").getResourceBundle().getText(val);
				}
			}
		});
		var oSelect = new sap.m.Select({
			width:"8rem",
			items:{
				path:"/profile",
				template:oItemTemplate
			}
		});
		oSelect.addStyleClass("sapUiTinyMarginBegin ruleSelect");
		ruleSourceFields.addItem(oSelect);

	},
	addRuleSourceFieldFromFixV: function(){
		var oInput = new sap.m.Input({
			width:"8rem"
		});
		oInput.addStyleClass("sapUiTinyMarginBegin ruleSelect");
		var ruleSourceFields = this.getView().byId("ruleSourceFields");
		ruleSourceFields.addItem(oInput);
	},
	removeRule: function(oEvent){
		var sPath = oEvent.getSource().getBindingContext().sPath;
		var rowNo = sPath.match("\\d+$");
		var dmData = this.getView().getModel().getData();
		dmData.dataMappingOverwrites.rules.splice(rowNo,1);
		this.getView().getModel().setData(dmData);
	},
	generateSamplePklistData:function(){
		var that = this;
		$.get(this._sample_pk_option_mapping,function(data){
			if(data && data.pkOptionMappingString){
				var mappingData = that.getView().getModel().getData();
				mappingData.pkOptionMappingString = data.pkOptionMappingString;
				that.getView().getModel().setData(mappingData);
			}
		});
	},

	exportConfigure: function(oEvent){
		if(!this._currentMapping){
			this.alertMsg("save your config first");
		}else{
			window.open("dm/export/"+this._currentMapping.mappingId);
		}
	},

	importConfigure: function(oEvent){
		var sResponse = JSON.parse(oEvent.getParameter("responseRaw"));
//		var raw = oEvent.getParameter("response");
//		var result = JSON.parse(raw.replace(/<[^>]+>/gi,""));
		if(sResponse){
			if(sResponse.pkOptionMappingString){
				sResponse.pkOptionMappingString = decodeURIComponent(sResponse.pkOptionMappingString).replace(/&lt;/gi,"<").replace(/&gt;/gi,">");
			}
			oMappingModel = new sap.ui.model.json.JSONModel();
			oMappingModel.setData(sResponse);
			this.getView().setModel(oMappingModel);
		}
	},

	showValueHelp: function(oEvent){
		var bindContext = oEvent.getSource().getBindingContext();
		var rowData = bindContext.getModel().getObject(bindContext.sPath);
		this._picklist = rowData.picklist;

		if(this._picklist){
			this.openPicklistOptionsDialog(oEvent, this._picklist);
		}
	},
	openPicklistOptionsDialog: function(oEvent, picklist){

		var pickListOptionPopover = this.getView().byId("picklistOptionsPopover");
		this.getView().byId("pklLocale").setSelectedKey("zh_CN");

		//load picklist from SF
		var cfg = {
			type : 'GET',
			dataType : 'json',
			contentType : 'application/json;charset=UTF-8'
		};
		cfg.url = "sf/picklistOptions?picklist=" + picklist;
		var that = this;
		pickListOptionPopover.setBusy(true);
	    $.ajax(cfg).success(function(data) {
	    	var ojsonModel = new sap.ui.model.json.JSONModel();
	    	if(data && data.code == "-1"){
	    		ojsonModel.setData({errorMsg: data.message, options:[]});
	    	}else{
	    		ojsonModel.setData({errorMsg:"",options:data});
	    	}
	    	pickListOptionPopover.setModel(ojsonModel);
	    	pickListOptionPopover.setBusy(false);
	    });

	    pickListOptionPopover.openBy(oEvent.getSource());
	},

	pickOptionsLocaleChange: function(oEvent){
		var picklistOptionDialog = this.getView().byId("picklistOptionsPopover");
		//load picklist from SF
		var cfg = {
			type : 'GET',
			dataType : 'json',
			contentType : 'application/json;charset=UTF-8'
		};
		var locale = this.getView().byId("pklLocale").getSelectedKey();
		cfg.url = "sf/picklistOptions?picklist=" + this._picklist + "&locale="+locale;
		var that = this;
		picklistOptionDialog.setBusy(true);
    $.ajax(cfg).success(function(data) {
    	var ojsonModel = new sap.ui.model.json.JSONModel();
    	if(data && data.code == "-1"){
    		ojsonModel.setData({errorMsg: data.message, options:[]});
    	}else{
    		ojsonModel.setData({errorMsg:"",options:data});
    	}
			picklistOptionDialog.setModel(ojsonModel);
			picklistOptionDialog.setBusy(false);
	    });
	},

	pickOptionsDialogClose: function(){
		this.getView().byId("picklistOptionsPopover").close();
		this._picklist = null;
	},

	setPickListHelpVisible: function(val){
		if(val){
			val = val.replace(/^\s+/g,"").replace(/\s+$/g,"");
		}
		if(!val){
			return false;
		}
		return true;
	},

	moveup: function(oEvent){
		var source = oEvent.getSource();
		var bindPath = source.getBindingContext().sPath.replace(/^\//,"");
		if(bindPath.split("/") < 2){
			return;
		}
		var propName = bindPath.split("/")[0];
		var index = parseInt(bindPath.split("/")[1]);

		var fData = this.getView().getModel().getData();
		var arr = fData[propName];
		if(index == 0){
			return;
		}else{
				//swith the content up
				var downSeq = arr[index].seq;
				var upSeq = arr[index-1].seq;
				arr[index] = arr.splice(index-1, 1, arr[index])[0];
				arr[index].seq = downSeq;
				arr[index-1].seq = upSeq;
		}
		this.getView().getModel().setData(fData);
	},

	movedown: function(oEvent){
		var source = oEvent.getSource();
		var bindPath = source.getBindingContext().sPath.replace(/^\//,"");
		if(bindPath.split("/") < 2){
			return;
		}
		var propName = bindPath.split("/")[0];
		var index = parseInt(bindPath.split("/")[1]);

		var fData = this.getView().getModel().getData();
		var arr = fData[propName];
		if(index == arr.length-1){
			return;
		}else{
			//switch the content down
			var downSeq = arr[index+1].seq;
			var upSeq = arr[index].seq;

			arr[index+1] = arr.splice(index, 1, arr[index+1])[0];
			arr[index].seq = upSeq;
			arr[index+1].seq = downSeq;
		}
		this.getView().getModel().setData(fData);
	},
	
	onFieldTypeChange: function(oEvent){
		var selectedKey = oEvent.getSource().getSelectedKey();
		var row = oEvent.getSource().getParent();
		var rowIdxStr = row.getBindingContext().sPath;
		var rowIdxArray = rowIdxStr.match(/\d+/g);
		var rowIdxStrArray = rowIdxStr.split('/');
		var tabName = rowIdxStrArray [1];
		var rowIdx = rowIdxArray[rowIdxArray.length - 1];
		var data = row.getBindingContext().getModel().getData();
		if (selectedKey == "PICKLIST"){
			data[tabName][rowIdx].displayPicklistId = true;
		}
		else{
			data[tabName][rowIdx].displayPicklistId = false;
			data[tabName][rowIdx].picklist = "";
		}
		if(selectedKey == "EMPTY"){
			data[tabName][rowIdx].to = "";
			data[tabName][rowIdx].picklist = "";
			data[tabName][rowIdx].required= false;
			data[tabName][rowIdx].fieldType= "EMPTY";
			data[tabName][rowIdx].displayPicklistId = false;
		}
		row.getBindingContext().getModel().setData(data);
	},


/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf resume-collection-service.mappingAdd
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf resume-collection-service.mappingAdd
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf resume-collection-service.mappingAdd
*/
//	onExit: function() {
//
//	}

});
