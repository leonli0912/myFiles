package com.sap.hcm.resume.collection.integration.wechat.controller;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.util.ReflectionTestUtils;

import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.bean.SimpleJsonResponse;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.wechat.controller.WechatJobApplicationController;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatJobService;
import com.sap.hcm.resume.collection.service.JobApplicationService;

@RunWith(PowerMockRunner.class)
public class WechatJobApplicationControllerTest {

  private WechatJobService wechatJobService;

  private WechatJobApplicationController wechatJobAppController;

  private JobApplicationService jobApplicationService;

  private Params params;

  @Before
  public void setUp() {
    wechatJobAppController = new WechatJobApplicationController();
    wechatJobService = PowerMockito.mock(WechatJobService.class);
    jobApplicationService = PowerMockito.mock(JobApplicationService.class);
    params = new Params();
    params.setCompanyId("testCompany");
    params.setUserEmail("test.user@test.com");

    ReflectionTestUtils.setField(wechatJobAppController, "wechatJobService", wechatJobService);
    ReflectionTestUtils.setField(wechatJobAppController, "params", params);
    ReflectionTestUtils.setField(wechatJobAppController, "jobApplicationService", jobApplicationService);
  }

  @Test
  public void testRefreshStatusSuccess() throws ServiceApplicationException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    Long applyHistoryId = 1L;
    String applicationId = "testApplicationId";
    Mockito.when(wechatJobService.getAppId(params.getUserEmail(), params.getCompanyId(), applyHistoryId)).thenReturn(
        applicationId);
    Mockito.when(jobApplicationService.queryAppliationStatus(applicationId, request.getLocale())).thenReturn("success");

    SimpleJsonResponse status = wechatJobAppController.refreshStatus(request, applyHistoryId);
    Assert.assertEquals("success", status.getMessage());
  }

  @Test
  public void testRefreshStatusFailed() throws ServiceApplicationException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    Long applyHistoryId = 1L;
    ServiceApplicationException testException = new ServiceApplicationException("Test Exception");
    Mockito.when(wechatJobService.getAppId(params.getUserEmail(), params.getCompanyId(), applyHistoryId)).thenThrow(
        testException);

    SimpleJsonResponse status = wechatJobAppController.refreshStatus(request, applyHistoryId);
    Assert.assertEquals(-1, status.getCode());
  }

  @Test
  public void testApplyJobFailedWithCompanyIdNotFound() {
    // TODO
  }
}
