sap.ui.controller("static.wechat.js.layout.jobApplyHistory", {
	
	_jobId: null,

	onButtonPress : function() {
		var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		oRouter.navTo("personalCenter");
	},
	
/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf resume-collection-service.jobApplyHistory
*/
	onInit: function() {
		
		
		this._router = sap.ui.core.UIComponent.getRouterFor(this);
		var that = this;
		this._router.getRoute("jobApplyHistory").attachPatternMatched(function(oEvent){
			var query = oEvent.getParameter("arguments")['?query'];
			if(query && query.jobId) {
				that._jobId = query.jobId;
			}else{
				that._jobId = null;
			}
			var oModel = new sap.ui.model.json.JSONModel();
			oModel.loadData("wechatuser/applyHistory", null, false);
			if(that._jobId){
				for(var i=0; i<oModel.getData().length; i++){
					if(oModel.getData()[i].jobId == that._jobId){
						filterData = oModel.getData()[i];
						break;
					}
				}
				oModel.setData([filterData]);
			}
			that.getView().setModel(oModel);
		});
	},
	
	refreshFlash : function(oEvent){
		var oEventId = oEvent.mParameters.id;
		var delayTime = 100;
		for(var i = 45;i<=360;i+=45){
			setTimeout(function(a){
				return function(){
					$("#"+oEventId+" span").css("transform","rotate("+a+"deg)");
				}
			}(i),delayTime);
			delayTime+=100;
		}
	},
	
	refreshStatus : function(oEvent) {
		var rowId = oEvent.getSource().getBindingContext().getPath();
		var rows = rowId.match(/\d+/g);
		var rowNo = rows[rows.length - 1];
		
		var oModel = this.getView().getModel();
		var oData = oModel.getData();
		var applyHistoryId = oData[rowNo].applyHistoryId;
		var sModel = new sap.ui.model.json.JSONModel();
		sModel.loadData("wechatJobApp/refreshStatus?applyHistoryId="+ applyHistoryId, null, false);
		if(sModel.getData().code == 0){
			oData[rowNo].applyStatus = sModel.getData().message;
			oModel.setData(oData);
			this.getView().setModel(oModel);
		}
		
		this.refreshFlash(oEvent);
		
	}

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf resume-collection-service.jobApplyHistory
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf resume-collection-service.jobApplyHistory
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf resume-collection-service.jobApplyHistory
*/
//	onExit: function() {
//
//	}

});