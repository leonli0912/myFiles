sap.ui.define([
               'static/wechat/js/layout/EmailBindingDialog',
               'static/wechat/js/JobUtil',
               'sap/ui/core/mvc/Controller',
               'sap/m/MessageBox',
               'sap/m/MessageStrip'
             ], function(EmailBindingDialog,JobUtil,Controller,MessageBox,MessageStrip){
	//"use strict";
	var jobDetail = Controller.extend("static.wechat.js.layout.jobDetail", {
		_router : null,
		_jobId : null,
		_jobTitle : null,
		_extJobId : null,
	
		onRecommended : function() {
	
			document.getElementById('recommendTip').style.display = 'block';
		},
	
		initWechatConfig : function() {
			var company_id = window.location.pathname.split('/').reverse().slice(0, 1)[0];
			if (company_id.indexOf(';') > -1) {
				arr = company_id.split(";");
				company_id = arr[0];
			}
			var url = encodeURIComponent(location.href.split('#')[0]);
	
			var viewData = null;
			var imageUrl = null;
	
			var jsonModel = new sap.ui.model.json.JSONModel();
			jsonModel.loadData("wechat/getsig?" + "url=" + url);
			var that = this;
			jsonModel.attachRequestCompleted(function() {
				viewData = jsonModel.getData();
				if(viewData.imageName){
					imageUrl = window.location.origin + '/' + window.location.pathname.split('/')[1]
							+ '/wphoto/' + viewData.imageName;
				}else{
					imageUrl = window.location.origin + '/' + window.location.pathname.split('/')[1]
					+ '/static/img/SAPLogo.png';
				}
				that.registerWechatShareAction(viewData, imageUrl, that);
			});
	
		},
	
		registerWechatShareAction : function(viewData, imageUrl, that) {
			wx.config({
				debug : false,
				appId : viewData.appId,
				timestamp : viewData.timestamp,
				nonceStr : viewData.nonceStr,
				signature : viewData.signature,
				jsApiList : [ 'onMenuShareAppMessage', 'onMenuShareTimeline', 'onMenuShareQQ',
						'onMenuShareQZone', 'onMenuShareWeibo' ]
	
			});
	
			wx.ready(function() {
				wx.onMenuShareAppMessage({
	
					title : that.translateText("WELCOME_TO_JOIN") + viewData.companyName + '!', // 分享标题
					desc : viewData.companyName + that.translateText("HIRING_POSITION") + '： '
							+ that._jobTitle,
					link : window.location.origin + '/' + window.location.pathname.split('/')[1] + '/wechat/' + g_company_info.companyId + '?jobId=' + that._jobId,
					imgUrl : imageUrl,
					success : function() {
	
					},
					cancel : function() {
	
					}
				});
	
				wx.onMenuShareTimeline({
					title : viewData.companyName + that.translateText("HIRING_POSITION") + '： '
							+ that._jobTitle,
					link : window.location.origin + '/' + window.location.pathname.split('/')[1] + '/wechat/' + g_company_info.companyId + '?jobId=' + that._jobId,
					imgUrl : imageUrl,
					success : function() {
	
					},
					cancel : function() {
	
					}
				});
	
				wx.onMenuShareQQ({
					title : that.translateText("WELCOME_TO_JOIN") + viewData.companyName + '!', // 分享标题
					desc : viewData.companyName + that.translateText("HIRING_POSITION") + '： '
							+ that._jobTitle,
					link : window.location.origin + '/' + window.location.pathname.split('/')[1] + '/wechat/' + g_company_info.companyId + '?jobId=' + that._jobId,
					imgUrl : imageUrl,
					success : function() {
	
					},
					cancel : function() {
	
					}
				});
	
				wx.onMenuShareQZone({
					title : that.translateText("WELCOME_TO_JOIN") + viewData.companyName + '!', // 分享标题
					desc : viewData.companyName + that.translateText("HIRING_POSITION") + '： '
							+ that._jobTitle,
					link : window.location.origin + '/' + window.location.pathname.split('/')[1] + '/wechat/' + g_company_info.companyId + '?jobId=' + that._jobId,
					imgUrl : imageUrl,
					success : function() {
	
					},
					cancel : function() {
	
					}
				});
	
				wx.onMenuShareWeibo({
					title : that.translateText("WELCOME_TO_JOIN") + viewData.companyName + '!', // 分享标题
					desc : viewData.companyName + that.translateText("HIRING_POSITION") + '： '
							+ that._jobTitle,
					link : window.location.origin + '/' + window.location.pathname.split('/')[1] + '/wechat/' + g_company_info.companyId + '?jobId=' + that._jobId,
					imgUrl : imageUrl,
					success : function() {
	
					},
					cancel : function() {
	
					}
				});
	
			});
		},
	
		onApply : function() {
			if (!g_company_info.isLogin) {
				document.getElementById('noWechatIdImg').style.display = 'block';
			} else {
				var emailBindingDialog = new EmailBindingDialog();
				var isUserExist = emailBindingDialog.checkUserExist();
				if(!isUserExist.primaryEmail){
					var emailBindingDialog = emailBindingDialog.buildDialog(this);		
					
					this.getView().addDependent(emailBindingDialog);
					emailBindingDialog.open();
					var that = this;
					emailBindingDialog.attachAfterClose(function(){
						that._router.navTo("candidateList", {
							query : {
								jobId : that._jobId
								
							}
						});
					},this);
				}else{
					this._router.navTo("candidateList", {
						query : {
							jobId : this._jobId
							
						}
					});
				}
				
				
			}
		},
		internalApply : function(jobId) {
			var that = this;
			var oDialog = this.getView().byId("BusyDialog");
			oDialog.open();
	
			jQuery.ajax({
				url : "sf/internalJobApp?jobId=" + jobId,
				method : "POST",
				dataType : 'json',
				contentType : 'application/json;charset=UTF-8',
			}).success(function(data) {
				oDialog.close();
				if (data && data.code < 0) {
					jQuery.sap.require("sap.m.MessageToast");
					sap.m.MessageToast.show(data.message);
				} else {
					jQuery.sap.require("sap.m.MessageToast");
					that._router.navTo("jobList", true);
				}
			});
		},
		seeStatus : function() {
			if (!g_company_info.isLogin) {
				document.getElementById('noWechatIdImg').style.display = 'block';
			} else {
				this._router.navTo("jobApplyHistory", {
					query : {
						jobId : this._jobId
					}
				});
			}
		},
	
		onInit : function() {
	
			this._router = sap.ui.core.UIComponent.getRouterFor(this);
			var that = this;
	
			var cssTextRecommend = "#recommendTip{position: fixed; left:0; top:0; background: rgba(0,0,0,0.8); filter:alpha(opacity=80); width: 100%; height:100%; z-index: 100; display: none;} #recommendTip img{float:right;margin-right:10px;}";
			this.loadHtmlRecommend();
			this.loadStyleTextRecommend(cssTextRecommend);
	
			if (!g_company_info.isLogin) {
				var cssText = "#noWechatIdImg{position: fixed; left:0; top:0; background: rgba(0,0,0,0.8); filter:alpha(opacity=80); width: 100%; height:100%; z-index: 100;display:none; text-align:center;} #text{color:white;} #img{width: 16rem;margin-top:4rem;}";
				loadHtml();
				loadStyleText(cssText);
			}
	
			this._router.getRoute("jobDetail").attachPatternMatched(
					function(oEvent) {
						that._jobId = oEvent.getParameter("arguments").jobId;
						
						if (that._jobId) {
							var jobMappingModel = new sap.ui.model.json.JSONModel();
							jobMappingModel.loadData("job/" + that._jobId + "?mode=display", null, false);
							var data = jobMappingModel.getData();

							if (data && data.jobInfo) {
								var oModel = new sap.ui.model.json.JSONModel();
								var oJobInfo = data.jobInfo;
								that._jobTitle = oJobInfo.jobTitle;
								oJobInfo.jobDescription = data.jobInfo.strJobDescription;
								oJobInfo.disAppButton = data.disAppButton;
								oJobInfo.disAppStatus = data.disAppStatus;
								oModel.setData(oJobInfo);
								that.getView().setModel(oModel);

								var pickListModel = new sap.ui.model.json.JSONModel();
								pickListModel.loadData("job/picklists", null, false);
								that.getView().setModel(pickListModel, "picklistModel");

								var reqUtil = new JobUtil();
								var mappingItems = reqUtil.getMappingItems(data.jobInfo.reqMappingId);
								var oContent = that.getView().byId("jobDetailInfo");
								var wModel = that.getView().getModel("wi18n");
								reqUtil.buildPageContent(mappingItems, oContent, wModel, that);
							}
							that.initWechatConfig();
						}
						
			});
			
	
		},
		
		picklistFormatter : function(val) {
			  if(!val) return "";
			  var picklistData  = this.getView().getModel("picklistModel").getData();
			  for(var picklist in picklistData){
				  for(var i = 0; i < picklistData[picklist].length; i++){
					  if(picklistData[picklist][i].optionId == val){
						  return picklistData[picklist][i].label;
					  }
				  }
			  }
			  return val;
		},
	
		addVideoElement : function(fileName) {
			var oPanel = this.getView().byId("videoPanel");
			if (oPanel.getContent().length > 0) {
				var contentStr = oPanel.getContent()[0].getContent();
				if (contentStr === "") {
					if (fileName) {
						var newContentStr = "<video width='100%' height='100%' controls>" + "<source src="
								+ "'" + "video/" + fileName + "'" + " type='video/mp4'>"
								+ "Your browser does not support the video tag." + "</video>";
					} else {
						var newContentStr = "";
					}
				} else {
					if (fileName) {
						var newContentStr = contentStr.replace(/video\/.*(?=' type)/, "video/" + fileName);
					} else {
						var newContentStr = "";
					}
				}
	
				oPanel.getContent()[0].setContent(newContentStr);
			} else {
				if (fileName) {
					var html1 = new sap.ui.core.HTML("html2", {
						content : "<video width='100%' height='100%' controls>" + "<source src=" + "'"
								+ "video/" + fileName + "'" + " type='video/mp4'>"
								+ "Your browser does not support the video tag." + "</video>"
					});
	
					oPanel.addContent(html1);
				}
			}
		},
	
		onButtonPress : function() {
			if (!g_company_info.isLogin) {
				document.getElementById('noWechatIdImg').style.display = 'block';
			} else {
				this._router.navTo("jobList", true);
			}
		},
	
		setContentVisible : function(val) {
			if (val) {
				return true;
			}
			return false;
		},
	
		formatTextOutput : function(val) {
			return val;
		},
	
		translatEnumLabel : function(val) {
			if (!val)
				return "";
			return this.getView().getModel("wi18n").getResourceBundle().getText(val);
		},
	
		loadHtmlRecommend : function() {
			var divRecommend = document.createElement('div');
			divRecommend.id = 'recommendTip';
			var that = this;
			divRecommend.onclick = function() {
				document.getElementById('recommendTip').style.display = 'none';
				that._router.navTo("jobList", true);
			}
			var imgElementRecommend = document.createElement("img");
			imgElementRecommend.setAttribute("src", "static/wechat/img/recommend.png");
			imgElementRecommend.setAttribute("alt", '请点击右上角按钮选择"发送给朋友"将职位推荐给朋友!');
			divRecommend.appendChild(imgElementRecommend);
			document.body.appendChild(divRecommend);
		},
	
		loadStyleTextRecommend : function(cssTextRecommend) {
			var style = document.createElement('style');
			style.rel = 'stylesheet';
			style.type = 'text/css';
			try {
				style.appendChild(document.createTextNode(cssTextRecommend));
			} catch (e) {
				style.styleSheet.cssText = cssTextRecommend; // ie9以下
			}
			var head = document.getElementsByTagName("head")[0]; // head标签之间加上style样式
			head.appendChild(style);
		},
	
		translateText : function(val) {
			return this.getView().getModel("wi18n").getResourceBundle().getText(val);
		},
	
	});
	return jobDetail;
});
