package com.sap.hcm.resume.collection.integration.wechat.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;
import javax.persistence.PersistenceException;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.BDDMockito;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.ModelAndView;

import com.sap.hcm.resume.collection.bean.FilterListItem;
import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.bean.SimpleJsonResponse;
import com.sap.hcm.resume.collection.context.TestContext;
import com.sap.hcm.resume.collection.context.WebAppContext;
import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.bean.JobReqDataModelMappingItem;
import com.sap.hcm.resume.collection.integration.sf.bean.SFPicklistCacheEntityType;
import com.sap.hcm.resume.collection.integration.sf.bean.SFPicklistItem;
import com.sap.hcm.resume.collection.integration.sf.service.SFPicklistCacheService;
import com.sap.hcm.resume.collection.integration.wechat.bean.JobDynSearchBean;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatApplyHistory;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJob;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJobVO;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatJobScreeningQuestionService;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatJobService;
import com.sap.hcm.resume.collection.service.CompanyInfoService;
import com.sap.hcm.resume.collection.service.DataModelMappingService;

// @RunWith(SpringJUnit4ClassRunner.class)
@RunWith(PowerMockRunner.class)
@PowerMockRunnerDelegate(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { TestContext.class, WebAppContext.class })
@PrepareForTest({ JobInfoController.class, ServletFileUpload.class })
public class JobInfoControllerTest {

  @Resource(type = WebApplicationContext.class)
  private WebApplicationContext webApplicationContext;

  @Resource(name = "wechatJobService")
  private WechatJobService wechatJobService;

  @Resource(name = "pklCacheService")
  private SFPicklistCacheService pklCacheService;

  @Resource(name = "companyInfoService")
  private CompanyInfoService companyInfoService;

  @Resource(name = "dataModelMappingService")
  private DataModelMappingService dataModelMappingService;
  
  private WechatJobScreeningQuestionService wechatJobScreeningQuestionService;

  @Autowired
  private Params params;

  private JobInfoController jobInfoController;

  // private MockMvc mockMvc;

  @Before
  public void setUp() {
    reset(wechatJobService);
    reset(companyInfoService);
    reset(pklCacheService);
    // mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
    MockitoAnnotations.initMocks(this);
    jobInfoController = spy(new JobInfoController());
    params.setCompanyId("sap");
    params.setWechatOpenId("openid");
    wechatJobScreeningQuestionService = Mockito.mock(WechatJobScreeningQuestionService.class);
    ReflectionTestUtils.setField(jobInfoController, "wechatJobService", wechatJobService);
    ReflectionTestUtils.setField(jobInfoController, "pklCacheService", pklCacheService);
    ReflectionTestUtils.setField(jobInfoController, "sfPicklistCacheService", pklCacheService);
    ReflectionTestUtils.setField(jobInfoController, "compInfoService", companyInfoService);
    ReflectionTestUtils.setField(jobInfoController, "dmMappingService", dataModelMappingService);
    ReflectionTestUtils.setField(jobInfoController, "wechatJobScreeningQuestionService", wechatJobScreeningQuestionService);
    ReflectionTestUtils.setField(jobInfoController, "params", params);

  }

  @Test
  public void testPublishJobSuccess() throws ServiceApplicationException {

    Long jobId = 123L;
    WechatJob wechatJob = new WechatJob();
    when(wechatJobService.findJobById(jobId)).thenReturn(wechatJob);
    SimpleJsonResponse rsp = jobInfoController.publishJob(jobId);
    assertEquals(0, rsp.getCode());
  }

  @Test
  public void testPublishJobFailWithPersistenceException() throws ServiceApplicationException {

    Long jobId = 123L;
    when(wechatJobService.findJobById(jobId)).thenThrow(new PersistenceException());
    SimpleJsonResponse rsp = jobInfoController.publishJob(jobId);
    assertEquals(-1, rsp.getCode());
  }

  @Test
  public void testPublishJobFailWithServiceApplicationException() throws ServiceApplicationException {

    Long jobId = 123L;
    when(wechatJobService.findJobById(jobId)).thenThrow(new ServiceApplicationException("error"));
    SimpleJsonResponse rsp = jobInfoController.publishJob(jobId);
    assertEquals(-1, rsp.getCode());
  }

  @Test
  public void testUpdateJobSuccess() throws Exception {

    WechatJobVO wechatJobVO = new WechatJobVO();
    Mockito.when(wechatJobService.saveJob(wechatJobVO)).thenReturn(wechatJobVO);

    HttpServletRequest mockedRequest = Mockito.mock(HttpServletRequest.class);

    SimpleJsonResponse rsp = jobInfoController.updateJob(mockedRequest, wechatJobVO);
    assertEquals(0, rsp.getCode());
  }

  @Test
  public void testUpdateJobFailWithPersistenceException() throws Exception {

    WechatJobVO wechatJobVO = new WechatJobVO();
    when(wechatJobService.saveJob(any(WechatJob.class))).thenThrow(new PersistenceException());

    HttpServletRequest mockedRequest = Mockito.mock(HttpServletRequest.class);

    SimpleJsonResponse rsp = jobInfoController.updateJob(mockedRequest, wechatJobVO);
    assertEquals(-1, rsp.getCode());
  }

  @Test
  public void testUpdateJobFailWithServiceApplicationException() throws Exception {

    WechatJobVO wechatJobVO = new WechatJobVO();
    when(wechatJobService.saveJob(any(WechatJob.class))).thenThrow(new ServiceApplicationException("error"));

    HttpServletRequest mockedRequest = Mockito.mock(HttpServletRequest.class);

    SimpleJsonResponse rsp = jobInfoController.updateJob(mockedRequest, wechatJobVO);
    assertEquals(-1, rsp.getCode());
  }

  @Test
  public void testBatchPublishJobSuccess() throws ServiceApplicationException {
    List<Long> jobIdList = new ArrayList<Long>();
    jobIdList.add(123L);
    jobIdList.add(456L);
    WechatJob wechatJob = new WechatJob();
    when(wechatJobService.findJobById(123L)).thenReturn(wechatJob);
    when(wechatJobService.findJobById(456L)).thenReturn(wechatJob);
    when(wechatJobService.saveJob(wechatJob)).thenReturn(wechatJob);
    SimpleJsonResponse rsp = jobInfoController.batchPublishJob(jobIdList);
    assertEquals(0, rsp.getCode());
  }

  @Test
  public void testBatchPublishJobFailWithPersistenceException() throws ServiceApplicationException {
    List<Long> jobIdList = new ArrayList<Long>();
    jobIdList.add(123L);
    jobIdList.add(456L);
    when(wechatJobService.findJobById(123L)).thenThrow(new PersistenceException());
    when(wechatJobService.findJobById(456L)).thenThrow(new PersistenceException());
    SimpleJsonResponse rsp = jobInfoController.batchPublishJob(jobIdList);
    assertEquals(-1, rsp.getCode());
  }

  @Test
  public void testBatchPublishJobFailWithServiceException() throws ServiceApplicationException {
    List<Long> jobIdList = new ArrayList<Long>();
    jobIdList.add(123L);
    jobIdList.add(456L);
    when(wechatJobService.findJobById(123L)).thenThrow(new ServiceApplicationException("error"));
    when(wechatJobService.findJobById(456L)).thenThrow(new ServiceApplicationException("error"));
    SimpleJsonResponse rsp = jobInfoController.batchPublishJob(jobIdList);
    assertEquals(-1, rsp.getCode());
  }

  @Test
  public void testBatchDeleteJobSuccess() throws ServiceApplicationException {
    List<Long> jobIdList = new ArrayList<Long>();
    jobIdList.add(123L);
    jobIdList.add(456L);
    when(wechatJobService.deleteJobById(123L)).thenReturn(0);
    when(wechatJobService.deleteJobById(456L)).thenReturn(0);
    SimpleJsonResponse rsp = jobInfoController.batchDeleteJob(jobIdList);
    assertEquals(0, rsp.getCode());
  }

  @Test
  public void testBatchDeleteFailWithPersistenceException() throws ServiceApplicationException {
    List<Long> jobIdList = new ArrayList<Long>();
    jobIdList.add(123L);
    jobIdList.add(456L);
    when(wechatJobService.deleteJobById(123L)).thenThrow(new PersistenceException());
    when(wechatJobService.deleteJobById(456L)).thenThrow(new PersistenceException());
    SimpleJsonResponse rsp = jobInfoController.batchDeleteJob(jobIdList);
    assertEquals(-1, rsp.getCode());
  }

  @Test
  public void testBatchDeleteFailWithServiceException() throws ServiceApplicationException {
    List<Long> jobIdList = new ArrayList<Long>();
    jobIdList.add(123L);
    jobIdList.add(456L);
    when(wechatJobService.deleteJobById(123L)).thenThrow(new ServiceApplicationException("error"));
    when(wechatJobService.deleteJobById(456L)).thenThrow(new ServiceApplicationException("error"));
    SimpleJsonResponse rsp = jobInfoController.batchDeleteJob(jobIdList);
    assertEquals(-1, rsp.getCode());
  }

  @Test
  public void testDeleteJobSuccess() throws ServiceApplicationException {
    Long jobId = 123L;
    when(wechatJobScreeningQuestionService.deleteJobScreeningQuestionAndChoice(jobId, params.getCompanyId())).thenReturn(1);
    when(wechatJobService.deleteJobById(123L)).thenReturn(0);
    SimpleJsonResponse rsp = jobInfoController.deleteJob(jobId);
    assertEquals(0, rsp.getCode());
  }
  
  @Test
  public void testDeleteJobWithInterviewQuestionFailed() throws ServiceApplicationException {
    Long jobId = 123L;
    when(wechatJobScreeningQuestionService.deleteJobScreeningQuestionAndChoice(jobId, params.getCompanyId())).thenThrow(new PersistenceException());
    when(wechatJobService.deleteJobById(123L)).thenReturn(0);
    
    SimpleJsonResponse rsp = jobInfoController.deleteJob(jobId);
    assertEquals(-1, rsp.getCode());
  }
  
  @Test
  public void testDeleteJobWithInterviewQuestionFailed2() throws ServiceApplicationException {
    Long jobId = 123L;
    when(wechatJobScreeningQuestionService.deleteJobScreeningQuestionAndChoice(jobId, params.getCompanyId())).thenThrow(new ServiceApplicationException("eee"));
    when(wechatJobService.deleteJobById(123L)).thenReturn(0);
    
    SimpleJsonResponse rsp = jobInfoController.deleteJob(jobId);
    assertEquals(-1, rsp.getCode());
  }
  

  @Test
  public void testDeleteJobFailWithPersistenceException() throws ServiceApplicationException {
    Long jobId = 123L;
    when(wechatJobService.deleteJobById(123L)).thenThrow(new PersistenceException());
    SimpleJsonResponse rsp = jobInfoController.deleteJob(jobId);
    assertEquals(-1, rsp.getCode());
  }

  @Test
  public void testDeleteJobFailWithServiceException() throws ServiceApplicationException {
    Long jobId = 123L;
    when(wechatJobService.deleteJobById(123L)).thenThrow(new ServiceApplicationException("error"));
    SimpleJsonResponse rsp = jobInfoController.deleteJob(jobId);
    assertEquals(-1, rsp.getCode());
  }

  @Test
  public void testGetJobByIdSuccessWithEditMode() throws ServiceApplicationException {
    Map<String, Object> result = new HashMap<String, Object>();
    MockHttpSession session = new MockHttpSession();
    Long jobId = 123L;
    String mode = "edit";
    String companyId = "sap";
    String wechatId = "wechat123";
    String extJobId = "456";

    List<WechatApplyHistory> applyHistoryList = new ArrayList<WechatApplyHistory>();

    WechatApplyHistory wechatApplyHistory = new WechatApplyHistory();
    applyHistoryList.add(wechatApplyHistory);

    WechatJob wechatJob = new WechatJob();
    wechatJob.setExternalJobId(extJobId);
    wechatJob.setCompanyId(companyId);
    when(wechatJobService.findApplyHistory(wechatId, companyId, extJobId)).thenReturn(applyHistoryList);
    when(wechatJobService.findJobById(jobId)).thenReturn(wechatJob);

    WechatJobVO wechatJobVO = new WechatJobVO();
    wechatJobVO.setCompanyId(companyId);
    result = jobInfoController.getJobById(session, jobId, mode);
    WechatJobVO returnWechatJobVO = (WechatJobVO) result.get("jobInfo");
    assertEquals(wechatJobVO.getCompanyId(), returnWechatJobVO.getCompanyId());
  }

  @SuppressWarnings("unused")
  @Test
  public void testGetJobByIdFailWithEditMode() throws ServiceApplicationException {
    Map<String, Object> map = new HashMap<String, Object>();
    Map<String, Object> result = new HashMap<String, Object>();
    MockHttpSession session = new MockHttpSession();
    Long jobId = 123L;
    String mode = "edit";
    String companyId = "sap";
    String wechatId = "wechat123";
    String extJobId = "456";

    List<WechatApplyHistory> applyHistoryList = new ArrayList<WechatApplyHistory>();

    WechatApplyHistory wechatApplyHistory = new WechatApplyHistory();
    applyHistoryList.add(wechatApplyHistory);

    WechatJob wechatJob = new WechatJob();
    wechatJob.setCompanyId(companyId);
    wechatJob.setExternalJobId(extJobId);
    when(wechatJobService.findApplyHistory(wechatId, companyId, extJobId)).thenThrow(
        new ServiceApplicationException("error"));
    when(wechatJobService.findJobById(jobId)).thenReturn(wechatJob);

    WechatJobVO wechatJobVO = new WechatJobVO();
    wechatJobVO.setCompanyId(companyId);
    result = jobInfoController.getJobById(session, jobId, mode);
  }

  @Test
  public void testGetJobByIdSuccessWithDisplayMode() throws ServiceApplicationException {
    Map<String, Object> result = new HashMap<String, Object>();
    MockHttpSession session = new MockHttpSession();
    Long jobId = 123L;
    String mode = "display";
    String companyId = "sap";
    String wechatId = "wechat123";
    String extJobId = "456";

    List<WechatApplyHistory> applyHistoryList = new ArrayList<WechatApplyHistory>();

    WechatApplyHistory wechatApplyHistory = new WechatApplyHistory();
    applyHistoryList.add(wechatApplyHistory);

    WechatJob wechatJob = new WechatJob();
    wechatJob.setExternalJobId(extJobId);
    wechatJob.setCompanyId(companyId);
    wechatJob.setCountry("1234");
    when(wechatJobService.findApplyHistory(wechatId, companyId, extJobId)).thenReturn(applyHistoryList);
    when(wechatJobService.findJobById(jobId)).thenReturn(wechatJob);

    Set<JobReqDataModelMappingItem> items = new HashSet<JobReqDataModelMappingItem>();
    JobReqDataModelMappingItem jobReqDataModelMappingItem = new JobReqDataModelMappingItem();
    jobReqDataModelMappingItem.setSourceField("country");
    items.add(jobReqDataModelMappingItem);
    when(dataModelMappingService.getPicklistForJobRequisition(companyId, false)).thenReturn(items);
    when(
        pklCacheService.getPKLLabelByOptionId(jobReqDataModelMappingItem.getPicklist(), companyId, 1234L,
            Locale.CHINA.toString(), SFPicklistCacheEntityType.JOB_REQUISITION.name())).thenReturn("heihei");

    WechatJobVO wechatJobVO = new WechatJobVO();
    wechatJobVO.setCompanyId(companyId);
    result = jobInfoController.getJobById(session, jobId, mode);
    WechatJobVO returnWechatJobVO = (WechatJobVO) result.get("jobInfo");
    assertEquals(wechatJobVO.getCompanyId(), returnWechatJobVO.getCompanyId());
  }

  @SuppressWarnings("unused")
  @Test
  public void testGetJobByIdWithExceptionInDisplayMode() throws ServiceApplicationException {
    Map<String, Object> result = new HashMap<String, Object>();
    MockHttpSession session = new MockHttpSession();
    Long jobId = 123L;
    String mode = "display";
    String companyId = "sap";
    String wechatId = "wechat123";
    String extJobId = "456";

    List<WechatApplyHistory> applyHistoryList = new ArrayList<WechatApplyHistory>();

    WechatApplyHistory wechatApplyHistory = new WechatApplyHistory();
    applyHistoryList.add(wechatApplyHistory);

    WechatJob wechatJob = new WechatJob();
    wechatJob.setCompanyId(companyId);
    wechatJob.setCountry("1234abc");
    wechatJob.setExternalJobId(extJobId);
    when(wechatJobService.findApplyHistory(wechatId, companyId, extJobId)).thenReturn(applyHistoryList);
    when(wechatJobService.findJobById(jobId)).thenReturn(wechatJob);

    Set<JobReqDataModelMappingItem> items = new HashSet<JobReqDataModelMappingItem>();
    JobReqDataModelMappingItem jobReqDataModelMappingItem = new JobReqDataModelMappingItem();
    jobReqDataModelMappingItem.setSourceField("country");
    items.add(jobReqDataModelMappingItem);
    when(dataModelMappingService.getPicklistForJobRequisition(companyId, false)).thenReturn(items);
    when(
        pklCacheService.getPKLLabelByOptionId(jobReqDataModelMappingItem.getPicklist(), companyId, 1234L,
            Locale.CHINA.toString(), SFPicklistCacheEntityType.JOB_REQUISITION.name())).thenReturn("heihei");

    WechatJobVO wechatJobVO = new WechatJobVO();
    wechatJobVO.setCompanyId(companyId);
    result = jobInfoController.getJobById(session, jobId, mode);
  }

  @Test
  public void testGetPicklistsFromCache() throws ServiceApplicationException {
    Map<String, List<SFPicklistItem>> map = new HashMap<String, List<SFPicklistItem>>();
    Map<String, List<SFPicklistItem>> result = new HashMap<String, List<SFPicklistItem>>();
    List<SFPicklistItem> SFPicklistItemList = new ArrayList<SFPicklistItem>();
    
    List<Locale> locales = new ArrayList<Locale>();
    locales.add(Locale.CHINA);
    
    MockHttpServletRequest mockServlet = new MockHttpServletRequest();
    mockServlet.setPreferredLocales(locales);
    
    SFPicklistItem sfPicklistItem = new SFPicklistItem();
    sfPicklistItem.setLocale(Locale.CHINA.toString());
    sfPicklistItem.setLabel("test123");
    SFPicklistItemList.add(sfPicklistItem);
    map.put("key", SFPicklistItemList);
    
    List<String> localeStr = new ArrayList<String>();
    localeStr.add(Locale.CHINA.toString());
    
    when(pklCacheService.getPicklistLocales("sap", SFPicklistCacheEntityType.JOB_REQUISITION.name())).thenReturn(localeStr);
   
    when(
        pklCacheService.getPicklistOptions("sap", Locale.CHINA.toString(),
            SFPicklistCacheEntityType.JOB_REQUISITION.name())).thenReturn(map);
    result = jobInfoController.getPicklistsFromCache(mockServlet);
    assertEquals("test123", result.get("key").get(0).getLabel());
  }

  @Test
  public void testGetMaintainJobInfoPageFailWithNullCompany() throws Exception {
    MockHttpSession session = new MockHttpSession();
    MockHttpServletRequest request = new MockHttpServletRequest();
    String companyId = "sap";
    ModelAndView mav = new ModelAndView();

    mav.setViewName("invalid_company");
    when(companyInfoService.getCompanyInfo(companyId)).thenReturn(null);
    assertEquals(mav.toString(), jobInfoController.maintainJobInfo(session, request).toString());
  }

  @Test
  public void testGetMaintainJobInfoPageFailWithRetrieveCompanyError() throws Exception {
    MockHttpSession session = new MockHttpSession();
    MockHttpServletRequest request = new MockHttpServletRequest();
    String companyId = "sap";
    ModelAndView mav = new ModelAndView();

    mav.setViewName("invalid_company");
    when(companyInfoService.getCompanyInfo(companyId)).thenThrow(new ServiceApplicationException("error"));
    assertEquals(mav.toString(), jobInfoController.maintainJobInfo(session, request).toString());
  }

  @Test
  public void testGetMaintainJobInfoPageSuccess() throws Exception {
    MockHttpSession session = new MockHttpSession();
    MockHttpServletRequest request = new MockHttpServletRequest();
    String companyId = "sap";
    ModelAndView mav = new ModelAndView();
    mav.setViewName("maintain_job");
    CompanyInfo info = new CompanyInfo();
    when(companyInfoService.getCompanyInfo(companyId)).thenReturn(info);
    assertEquals(mav.getViewName(), jobInfoController.maintainJobInfo(session, request).getViewName());
  }

  @Test
  public void testSaveSingleJobSuccess() throws Exception {
    MockHttpSession session = new MockHttpSession();
    MockHttpServletRequest request = new MockHttpServletRequest();

    String companyId = "sap";
    WechatJobVO wechatJobVO = new WechatJobVO();
    wechatJobVO.setExternalJobId("123");
    WechatJob wechatJob = new WechatJob();
    when(wechatJobService.saveJob(any(WechatJob.class))).thenReturn(wechatJob);
    SimpleJsonResponse response = jobInfoController.saveJob(request, session, wechatJobVO);
    assertEquals(0, response.getCode());
  }

  @Test
  public void testSaveSingleJobErrorWithPersistenceException() throws Exception {
    MockHttpSession session = new MockHttpSession();
    MockHttpServletRequest request = new MockHttpServletRequest();

    String companyId = "sap";
    WechatJobVO wechatJobVO = new WechatJobVO();
    wechatJobVO.setExternalJobId("123");
    when(wechatJobService.saveJob(any(WechatJob.class))).thenThrow(new PersistenceException());
    SimpleJsonResponse response = jobInfoController.saveJob(request, session, wechatJobVO);
    assertEquals(-1, response.getCode());
  }

  @Test
  public void testSaveSingleJobErrorWithServiceException() throws Exception {
    MockHttpSession session = new MockHttpSession();
    MockHttpServletRequest request = new MockHttpServletRequest();

    String companyId = "sap";
    WechatJobVO wechatJobVO = new WechatJobVO();
    wechatJobVO.setExternalJobId("123");
    when(wechatJobService.saveJob(any(WechatJob.class))).thenThrow(new ServiceApplicationException("error"));
    SimpleJsonResponse response = jobInfoController.saveJob(request, session, wechatJobVO);
    assertEquals(-1, response.getCode());
  }

  @Test
  public void testSaveMultiJobSuccess() throws Exception {
    MockHttpSession session = new MockHttpSession();
    MockHttpServletRequest request = new MockHttpServletRequest();

    String companyId = "sap";
    WechatJobVO wechatJobVO = new WechatJobVO();
    wechatJobVO.setExternalJobId("123-124");
    WechatJob wechatJob = new WechatJob();
    when(wechatJobService.saveJob(any(WechatJob.class))).thenReturn(wechatJob);
    SimpleJsonResponse response = jobInfoController.saveJob(request, session, wechatJobVO);
    assertEquals(0, response.getCode());
    assertEquals("2", response.getMessage());
  }

  @Test
  public void testSaveMultiJobFailWithServiceException() throws Exception {
    MockHttpSession session = new MockHttpSession();
    MockHttpServletRequest request = new MockHttpServletRequest();

    String companyId = "sap";
    WechatJobVO wechatJobVO = new WechatJobVO();
    wechatJobVO.setExternalJobId("123-124");
    when(wechatJobService.saveJob(any(WechatJob.class))).thenThrow(new ServiceApplicationException("error"));
    SimpleJsonResponse response = jobInfoController.saveJob(request, session, wechatJobVO);
    assertEquals(-1, response.getCode());
  }

  @Test
  public void testSaveMultiJobFailWithPersistenceException() throws Exception {
    MockHttpSession session = new MockHttpSession();
    MockHttpServletRequest request = new MockHttpServletRequest();

    String companyId = "sap";
    WechatJobVO wechatJobVO = new WechatJobVO();
    wechatJobVO.setExternalJobId("123-124");
    when(wechatJobService.saveJob(any(WechatJob.class))).thenThrow(new PersistenceException());
    SimpleJsonResponse response = jobInfoController.saveJob(request, session, wechatJobVO);
    assertEquals(-1, response.getCode());
  }

  @Test
  public void testGetInfoListSuccess() throws Exception {
    MockHttpSession session = new MockHttpSession();
    MockHttpServletRequest request = new MockHttpServletRequest();

    List<Locale> localeList = new ArrayList<Locale>();
    localeList.add(null);
    request.setPreferredLocales(localeList);

    Map<String, Object> result = new HashMap<String, Object>();
    JobDynSearchBean searchBean = new JobDynSearchBean();
    searchBean.setInputFilterValue("heheda");

    String companyId = "sap";

    WechatJob wechatJob = new WechatJob();
    List<WechatJob> jobInfoList = new ArrayList<WechatJob>();
    jobInfoList.add(wechatJob);
    List<FilterListItem> filterList = new ArrayList<FilterListItem>();

    when(wechatJobService.getJobInfoList(any(JobDynSearchBean.class))).thenReturn(jobInfoList);
    when(wechatJobService.getTotalCount(any(JobDynSearchBean.class))).thenReturn(1L);
    when(wechatJobService.getFilterListByConfig(companyId, Locale.CHINA)).thenReturn(filterList);
    result = jobInfoController.getJobInfoListNew(request, searchBean, session);
    assertEquals(1L, result.get("count"));
  }

  @SuppressWarnings("unused")
  @Test
  public void testGetInfoListFailWithFilterException() throws Exception, UnsupportedEncodingException {
    MockHttpSession session = new MockHttpSession();
    MockHttpServletRequest request = new MockHttpServletRequest();

    List<Locale> localeList = new ArrayList<Locale>();
    localeList.add(null);
    request.setPreferredLocales(localeList);

    Map<String, Object> result = new HashMap<String, Object>();
    JobDynSearchBean searchBean = new JobDynSearchBean();
    searchBean.setInputFilterValue("heheda");

    PowerMockito.mockStatic(java.net.URLDecoder.class);
    BDDMockito.given(java.net.URLDecoder.decode(searchBean.getInputFilterValue(), "utf-8")).willThrow(
        new UnsupportedEncodingException());

    String companyId = "sap";

    WechatJob wechatJob = new WechatJob();
    List<WechatJob> jobInfoList = new ArrayList<WechatJob>();
    jobInfoList.add(wechatJob);
    List<FilterListItem> filterList = new ArrayList<FilterListItem>();

    when(wechatJobService.getJobInfoList(any(JobDynSearchBean.class))).thenReturn(jobInfoList);
    when(wechatJobService.getTotalCount(any(JobDynSearchBean.class))).thenReturn(1L);
    when(wechatJobService.getFilterListByConfig(companyId, Locale.CHINA)).thenReturn(filterList);
    result = jobInfoController.getJobInfoListNew(request, searchBean, session);
  }

  @Test
  public void testGetMaintainInfoListSuccess() throws Exception {
    MockHttpSession session = new MockHttpSession();
    MockHttpServletRequest request = new MockHttpServletRequest();

    List<Locale> localeList = new ArrayList<Locale>();
    localeList.add(null);
    request.setPreferredLocales(localeList);

    Map<String, Object> result = new HashMap<String, Object>();
    JobDynSearchBean searchBean = new JobDynSearchBean();
    searchBean.setInputFilterValue("heheda");

    String companyId = "sap";

    WechatJob wechatJob = new WechatJob();
    List<WechatJob> jobInfoList = new ArrayList<WechatJob>();
    jobInfoList.add(wechatJob);
    List<FilterListItem> filterList = new ArrayList<FilterListItem>();

    when(wechatJobService.getJobInfoList(any(JobDynSearchBean.class))).thenReturn(jobInfoList);
    when(wechatJobService.getTotalCount(any(JobDynSearchBean.class))).thenReturn(1L);
    when(wechatJobService.getFilterListByConfig(companyId, Locale.CHINA)).thenReturn(filterList);
    result = jobInfoController.getMaintainJobInfoListNew(request, searchBean, session);
    assertEquals(1L, result.get("count"));
  }

  @SuppressWarnings("unused")
  @Test
  public void testGetMaintainInfoListFail() throws Exception {
    MockHttpSession session = new MockHttpSession();
    MockHttpServletRequest request = new MockHttpServletRequest();

    List<Locale> localeList = new ArrayList<Locale>();
    localeList.add(null);
    request.setPreferredLocales(localeList);

    Map<String, Object> result = new HashMap<String, Object>();
    JobDynSearchBean searchBean = new JobDynSearchBean();
    searchBean.setInputFilterValue("heheda");

    PowerMockito.mockStatic(java.net.URLDecoder.class);
    BDDMockito.given(java.net.URLDecoder.decode(searchBean.getInputFilterValue(), "utf-8")).willThrow(
        new UnsupportedEncodingException());

    String companyId = "sap";

    WechatJob wechatJob = new WechatJob();
    List<WechatJob> jobInfoList = new ArrayList<WechatJob>();
    jobInfoList.add(wechatJob);
    List<FilterListItem> filterList = new ArrayList<FilterListItem>();

    when(wechatJobService.getJobInfoList(any(JobDynSearchBean.class))).thenReturn(jobInfoList);
    when(wechatJobService.getTotalCount(any(JobDynSearchBean.class))).thenReturn(1L);
    when(wechatJobService.getFilterListByConfig(companyId, Locale.CHINA)).thenReturn(filterList);
    result = jobInfoController.getMaintainJobInfoListNew(request, searchBean, session);
  }

  @Test(expected = ServiceApplicationException.class)
  public void testGetMaintainInfoListFailWithoutCompanyID() throws Exception {
    MockHttpSession session = new MockHttpSession();
    MockHttpServletRequest request = new MockHttpServletRequest();

    List<Locale> localeList = new ArrayList<Locale>();
    localeList.add(null);
    request.setPreferredLocales(localeList);

    JobDynSearchBean searchBean = new JobDynSearchBean();
    searchBean.setInputFilterValue("heheda");
    
    params.setCompanyId(null);

    jobInfoController.getMaintainJobInfoListNew(request, searchBean, session);
  }
}
