package com.sap.hcm.resume.collection.integration.wechat.entity;

import java.io.Serializable;
import java.util.Date;

public class WechatJobApplicationVO implements Serializable {
    
    private static final long serialVersionUID = 4692850049829139849L;
    
    /**
     * address
     */
    private String address;
    
    /**
     * agencyInfo
     */
    private String agencyInfo;

    /**
     * anonymizedDate
     */
    private Date anonymizedDate;
    
    /**
     * anonymizedFlag
     */
    private String anonymizedFlag;
    
    /**
     * appLocale
     */
    private String appLocale;
    
    /**
     * appStatusSetItemId
     */
    private String appStatusSetItemId;
    
    /**
     * applicationId
     */
    private String applicationId;
    
    /**
     * applicationTemplateId
     */
    private String applicationTemplateId;
    
    /**
     * candConversionProcessed
     */
    private String candConversionProcessed;
    
    /**
     * candTypeWhenHired
     */
    private String candTypeWhenHired;
    
    /**
     * candidateId
     */
    private Long candidateId;
    
    /**
     * cellPhone
     */
    private String cellPhone;
    
    /**
     * city
     */
    private String city;
    
    /**
     * contactEmail
     */
    private String contactEmail;
    
    /**
     * countryCode
     */
    private String countryCode;
    
    /**
     * dataSource
     */
    private String dataSource;
    
    /**
     * duplicateProfile
     */
    private String duplicateProfile;
    
    /**
     * exportedOn
     */
    private Date exportedOn;
    
    /**
     * firstName
     */
    private String firstName;
    
    /**
     * formerEmployee
     */
    private boolean formerEmployee;
    
    /**
     * hiredOn
     */
    private String hiredOn;
    
    /**
     * homePhone
     */
    private String homePhone;
    
    /**
     * jobAppGuid
     */
    private String jobAppGuid;
    
    /**
     * jobReqId
     */
    private String jobReqId;
    
    /**
     * lastModifiedBy
     */
    private String lastModifiedBy;
    
    /**
     * lastModifiedByProxy
     */
    private String lastModifiedByProxy;
    
    /**
     * lastModifiedDateTime
     */
    private Date lastModifiedDateTime;
    
    /**
     * lastName
     */
    private String lastName;
    
    /**
     * middleName
     */
    private String middleName;
    
    /**
     * nonApplicantStatus
     */
    private String nonApplicantStatus;
    
    /**
     * owner
     */
    private String owner;
    
    /**
     * ownershpDate
     */
    private Date ownershpDate;
    
    /**
     * profileUpdated
     */
    private String profileUpdated;
    
    /**
     * questionResponse
     */
    private String questionResponse;
    
    /**
     * rating
     */
    private String rating;
    
    /**
     * reference
     */
    private String reference;
    
    /**
     * referenceComments
     */
    private String referenceComments;
    
    /**
     * referralName
     */
    private String referralName;
    
    /**
     * referredBy
     */
    private String referredBy;
    
    /**
     * resumeUploadDate
     */
    private Date resumeUploadDate;
    
    /**
     * snapShotDate
     */
    private Date snapShotDate;
    
    /**
     * source
     */
    private String source;
    
    /**
     * status
     */
    private String status;
    
    /**
     * statusComments
     */
    private String statusComments;
    
    /**
     * timeToHire
     */
    private String timeToHire;
    
    /**
     * usersSysId
     */
    private String usersSysId;
    
    /**
     * zip
     */
    private String zip;
    
    /**
     * @return the address
     */
    public String getAddress() {
        return address;
    }

    /**
     * @param address the address to set
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * @return the agencyInfo
     */
    public String getAgencyInfo() {
        return agencyInfo;
    }

    /**
     * @param agencyInfo the agencyInfo to set
     */
    public void setAgencyInfo(String agencyInfo) {
        this.agencyInfo = agencyInfo;
    }

    /**
     * @return the anonymizedDate
     */
    public Date getAnonymizedDate() {
        return anonymizedDate;
    }

    /**
     * @param anonymizedDate the anonymizedDate to set
     */
    public void setAnonymizedDate(Date anonymizedDate) {
        this.anonymizedDate = anonymizedDate;
    }

    /**
     * @return the anonymizedFlag
     */
    public String getAnonymizedFlag() {
        return anonymizedFlag;
    }

    /**
     * @param anonymizedFlag the anonymizedFlag to set
     */
    public void setAnonymizedFlag(String anonymizedFlag) {
        this.anonymizedFlag = anonymizedFlag;
    }

    /**
     * @return the appLocale
     */
    public String getAppLocale() {
        return appLocale;
    }

    /**
     * @param appLocale the appLocale to set
     */
    public void setAppLocale(String appLocale) {
        this.appLocale = appLocale;
    }

    /**
     * @return the appStatusSetItemId
     */
    public String getAppStatusSetItemId() {
        return appStatusSetItemId;
    }

    /**
     * @param appStatusSetItemId the appStatusSetItemId to set
     */
    public void setAppStatusSetItemId(String appStatusSetItemId) {
        this.appStatusSetItemId = appStatusSetItemId;
    }

    /**
     * @return the applicationId
     */
    public String getApplicationId() {
        return applicationId;
    }

    /**
     * @param applicationId the applicationId to set
     */
    public void setApplicationId(String applicationId) {
        this.applicationId = applicationId;
    }

    /**
     * @return the applicationTemplateId
     */
    public String getApplicationTemplateId() {
        return applicationTemplateId;
    }

    /**
     * @param applicationTemplateId the applicationTemplateId to set
     */
    public void setApplicationTemplateId(String applicationTemplateId) {
        this.applicationTemplateId = applicationTemplateId;
    }

    /**
     * @return the candConversionProcessed
     */
    public String getCandConversionProcessed() {
        return candConversionProcessed;
    }

    /**
     * @param candConversionProcessed the candConversionProcessed to set
     */
    public void setCandConversionProcessed(String candConversionProcessed) {
        this.candConversionProcessed = candConversionProcessed;
    }

    /**
     * @return the candTypeWhenHired
     */
    public String getCandTypeWhenHired() {
        return candTypeWhenHired;
    }

    /**
     * @param candTypeWhenHired the candTypeWhenHired to set
     */
    public void setCandTypeWhenHired(String candTypeWhenHired) {
        this.candTypeWhenHired = candTypeWhenHired;
    }

    /**
     * @return the candidateId
     */
    public Long getCandidateId() {
        return candidateId;
    }

    /**
     * @param candidateId the candidateId to set
     */
    public void setCandidateId(Long candidateId) {
        this.candidateId = candidateId;
    }

    /**
     * @return the cellPhone
     */
    public String getCellPhone() {
        return cellPhone;
    }

    /**
     * @param cellPhone the cellPhone to set
     */
    public void setCellPhone(String cellPhone) {
        this.cellPhone = cellPhone;
    }

    /**
     * @return the city
     */
    public String getCity() {
        return city;
    }

    /**
     * @param city the city to set
     */
    public void setCity(String city) {
        this.city = city;
    }

    /**
     * @return the contactEmail
     */
    public String getContactEmail() {
        return contactEmail;
    }

    /**
     * @param contactEmail the contactEmail to set
     */
    public void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail;
    }

    /**
     * @return the countryCode
     */
    public String getCountryCode() {
        return countryCode;
    }

    /**
     * @param countryCode the countryCode to set
     */
    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    /**
     * @return the dataSource
     */
    public String getDataSource() {
        return dataSource;
    }

    /**
     * @param dataSource the dataSource to set
     */
    public void setDataSource(String dataSource) {
        this.dataSource = dataSource;
    }

    /**
     * @return the duplicateProfile
     */
    public String getDuplicateProfile() {
        return duplicateProfile;
    }

    /**
     * @param duplicateProfile the duplicateProfile to set
     */
    public void setDuplicateProfile(String duplicateProfile) {
        this.duplicateProfile = duplicateProfile;
    }

    /**
     * @return the exportedOn
     */
    public Date getExportedOn() {
        return exportedOn;
    }

    /**
     * @param exportedOn the exportedOn to set
     */
    public void setExportedOn(Date exportedOn) {
        this.exportedOn = exportedOn;
    }

    /**
     * @return the firstName
     */
    public String getFirstName() {
        return firstName;
    }

    /**
     * @param firstName the firstName to set
     */
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    /**
     * @return the formerEmployee
     */
    public boolean isFormerEmployee() {
        return formerEmployee;
    }

    /**
     * @param formerEmployee the formerEmployee to set
     */
    public void setFormerEmployee(boolean formerEmployee) {
        this.formerEmployee = formerEmployee;
    }

    /**
     * @return the hiredOn
     */
    public String getHiredOn() {
        return hiredOn;
    }

    /**
     * @param hiredOn the hiredOn to set
     */
    public void setHiredOn(String hiredOn) {
        this.hiredOn = hiredOn;
    }

    /**
     * @return the homePhone
     */
    public String getHomePhone() {
        return homePhone;
    }

    /**
     * @param homePhone the homePhone to set
     */
    public void setHomePhone(String homePhone) {
        this.homePhone = homePhone;
    }

    /**
     * @return the jobAppGuid
     */
    public String getJobAppGuid() {
        return jobAppGuid;
    }

    /**
     * @param jobAppGuid the jobAppGuid to set
     */
    public void setJobAppGuid(String jobAppGuid) {
        this.jobAppGuid = jobAppGuid;
    }

    /**
     * @return the jobReqId
     */
    public String getJobReqId() {
        return jobReqId;
    }

    /**
     * @param jobReqId the jobReqId to set
     */
    public void setJobReqId(String jobReqId) {
        this.jobReqId = jobReqId;
    }

    /**
     * @return the lastModifiedBy
     */
    public String getLastModifiedBy() {
        return lastModifiedBy;
    }

    /**
     * @param lastModifiedBy the lastModifiedBy to set
     */
    public void setLastModifiedBy(String lastModifiedBy) {
        this.lastModifiedBy = lastModifiedBy;
    }

    /**
     * @return the lastModifiedByProxy
     */
    public String getLastModifiedByProxy() {
        return lastModifiedByProxy;
    }

    /**
     * @param lastModifiedByProxy the lastModifiedByProxy to set
     */
    public void setLastModifiedByProxy(String lastModifiedByProxy) {
        this.lastModifiedByProxy = lastModifiedByProxy;
    }

    /**
     * @return the lastModifiedDateTime
     */
    public Date getLastModifiedDateTime() {
        return lastModifiedDateTime;
    }

    /**
     * @param lastModifiedDateTime the lastModifiedDateTime to set
     */
    public void setLastModifiedDateTime(Date lastModifiedDateTime) {
        this.lastModifiedDateTime = lastModifiedDateTime;
    }

    /**
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @param lastName the lastName to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    /**
     * @return the middleName
     */
    public String getMiddleName() {
        return middleName;
    }

    /**
     * @param middleName the middleName to set
     */
    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    /**
     * @return the nonApplicantStatus
     */
    public String getNonApplicantStatus() {
        return nonApplicantStatus;
    }

    /**
     * @param nonApplicantStatus the nonApplicantStatus to set
     */
    public void setNonApplicantStatus(String nonApplicantStatus) {
        this.nonApplicantStatus = nonApplicantStatus;
    }

    /**
     * @return the owner
     */
    public String getOwner() {
        return owner;
    }

    /**
     * @param owner the owner to set
     */
    public void setOwner(String owner) {
        this.owner = owner;
    }

    /**
     * @return the ownershpDate
     */
    public Date getOwnershpDate() {
        return ownershpDate;
    }

    /**
     * @param ownershpDate the ownershpDate to set
     */
    public void setOwnershpDate(Date ownershpDate) {
        this.ownershpDate = ownershpDate;
    }

    /**
     * @return the profileUpdated
     */
    public String getProfileUpdated() {
        return profileUpdated;
    }

    /**
     * @param profileUpdated the profileUpdated to set
     */
    public void setProfileUpdated(String profileUpdated) {
        this.profileUpdated = profileUpdated;
    }

    /**
     * @return the questionResponse
     */
    public String getQuestionResponse() {
        return questionResponse;
    }

    /**
     * @param questionResponse the questionResponse to set
     */
    public void setQuestionResponse(String questionResponse) {
        this.questionResponse = questionResponse;
    }

    /**
     * @return the rating
     */
    public String getRating() {
        return rating;
    }

    /**
     * @param rating the rating to set
     */
    public void setRating(String rating) {
        this.rating = rating;
    }

    /**
     * @return the reference
     */
    public String getReference() {
        return reference;
    }

    /**
     * @param reference the reference to set
     */
    public void setReference(String reference) {
        this.reference = reference;
    }

    /**
     * @return the referenceComments
     */
    public String getReferenceComments() {
        return referenceComments;
    }

    /**
     * @param referenceComments the referenceComments to set
     */
    public void setReferenceComments(String referenceComments) {
        this.referenceComments = referenceComments;
    }

    /**
     * @return the referralName
     */
    public String getReferralName() {
        return referralName;
    }

    /**
     * @param referralName the referralName to set
     */
    public void setReferralName(String referralName) {
        this.referralName = referralName;
    }

    /**
     * @return the referredBy
     */
    public String getReferredBy() {
        return referredBy;
    }

    /**
     * @param referredBy the referredBy to set
     */
    public void setReferredBy(String referredBy) {
        this.referredBy = referredBy;
    }

    /**
     * @return the resumeUploadDate
     */
    public Date getResumeUploadDate() {
        return resumeUploadDate;
    }

    /**
     * @param resumeUploadDate the resumeUploadDate to set
     */
    public void setResumeUploadDate(Date resumeUploadDate) {
        this.resumeUploadDate = resumeUploadDate;
    }

    /**
     * @return the snapShotDate
     */
    public Date getSnapShotDate() {
        return snapShotDate;
    }

    /**
     * @param snapShotDate the snapShotDate to set
     */
    public void setSnapShotDate(Date snapShotDate) {
        this.snapShotDate = snapShotDate;
    }

    /**
     * @return the source
     */
    public String getSource() {
        return source;
    }

    /**
     * @param source the source to set
     */
    public void setSource(String source) {
        this.source = source;
    }

    /**
     * @return the status
     */
    public String getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(String status) {
        this.status = status;
    }

    /**
     * @return the statusComments
     */
    public String getStatusComments() {
        return statusComments;
    }

    /**
     * @param statusComments the statusComments to set
     */
    public void setStatusComments(String statusComments) {
        this.statusComments = statusComments;
    }

    /**
     * @return the timeToHire
     */
    public String getTimeToHire() {
        return timeToHire;
    }

    /**
     * @param timeToHire the timeToHire to set
     */
    public void setTimeToHire(String timeToHire) {
        this.timeToHire = timeToHire;
    }

    /**
     * @return the usersSysId
     */
    public String getUsersSysId() {
        return usersSysId;
    }

    /**
     * @param usersSysId the usersSysId to set
     */
    public void setUsersSysId(String usersSysId) {
        this.usersSysId = usersSysId;
    }

    /**
     * @return the zip
     */
    public String getZip() {
        return zip;
    }

    /**
     * @param zip the zip to set
     */
    public void setZip(String zip) {
        this.zip = zip;
    }

}
