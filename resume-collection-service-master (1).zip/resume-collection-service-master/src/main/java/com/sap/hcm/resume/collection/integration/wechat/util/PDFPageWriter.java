package com.sap.hcm.resume.collection.integration.wechat.util;

import java.awt.Color;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType0Font;

public class PDFPageWriter {

  public static final int LINE_WIDTH = 60;

  public static final int OFFSET_Y_INITAL_VALUE = 750;

  public static final String DEFAULT_FONT = "font/WenQuanYi.ttf";

  private int offsetY;
  private PDPage page;
  private PDDocument doc;
  private PDFont font;
  private PDPageContentStream content;

  public PDFPageWriter(PDDocument doc) throws IOException {
    this.doc = doc;
    InputStream fontInputstream = null;
    try{
      fontInputstream = this.getClass().getClassLoader().getResourceAsStream(DEFAULT_FONT);
      this.font = PDType0Font.load(doc, fontInputstream);
    }finally{
      IOUtils.closeQuietly(fontInputstream);
    }
    this.createNewPage();
  }

  /**
   * @param font
   *          the font to set
   */
  public void setFont(PDFont font) {
    this.font = font;
  }

  private void createNewPage() throws IOException {
    page = new PDPage();
    doc.addPage(page);
    content = new PDPageContentStream(doc, page);
    this.offsetY = OFFSET_Y_INITAL_VALUE;
  }

  public void write(int offsetX, int offsetHeight, int fontSize, Color color, String text) throws IOException {
    if (text != null) {
      // handle the line break first
      String[] lines = text.split("\\n");
      for (String line : lines) {
        this.writeLine(offsetX, offsetHeight, fontSize, color, line);
      }
    }
  }


  /**
   * 
   * @param offsetX
   * @param offsetHeight
   * @param fontSize
   * @param text
   * @throws IOException
   */
  private void writeLine(int offsetX, int offsetHeight, int fontSize, Color color, String text) throws IOException {
    if (text != null) {
      int step = text.length() / LINE_WIDTH;
      String part = "";
      for (int i = 1; i <= step; i++) {
        part = text.substring((i - 1) * LINE_WIDTH, (i - 1) * LINE_WIDTH + LINE_WIDTH);
        this.writeSingleLine(offsetX, offsetHeight, fontSize, color, part);
      }
      part = text.substring(step * LINE_WIDTH);
      this.writeSingleLine(offsetX, offsetHeight, fontSize, color, part);
    } else {
      this.writeSingleLine(offsetX, offsetHeight, fontSize, color, "");
    }
  }

  /**
   * 
   * @param offsetX
   * @param offsetHeight
   * @param fontSize
   * @param text
   * @throws IOException
   */
  private void writeSingleLine(int offsetX, int offsetHeight, int fontSize, Color color, String text) throws IOException {
    int offY = this.deductOffsetBy(offsetHeight);
    this.content.beginText();
    this.content.setFont(font, fontSize);
    if(color != null){
      this.content.setNonStrokingColor(color);      
    }
    this.content.newLineAtOffset(offsetX, offY);
    this.content.showText(text);
    this.content.endText();
  }
  
  public void writeSplitterLine(int offsetX, int offsetHeight, Color color) throws IOException{
    int offY = this.deductOffsetBy(offsetHeight);
    this.content.setStrokingColor(color);
    this.content.setLineDashPattern(new float[]{3}, 0);
    this.content.moveTo(offsetX, offY);
    this.content.lineTo(450, offY);
    this.content.closeAndStroke();
  }

  public void close() {
    try {
      this.content.close();
    } catch (IOException e) {
      //
    }
  }

  public int deductOffsetBy(int value) throws IOException {
    if (this.offsetY <= 30) {
      this.close();
      this.createNewPage();
    } else {
      this.offsetY = this.offsetY - value;
    }
    return this.offsetY;
  }
}