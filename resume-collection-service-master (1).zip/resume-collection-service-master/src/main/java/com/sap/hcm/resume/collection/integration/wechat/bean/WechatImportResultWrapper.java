package com.sap.hcm.resume.collection.integration.wechat.bean;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * 
 * @author i065831
 *
 */
public class WechatImportResultWrapper implements Serializable{
    
    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = -7668000935479134266L;
    
    private int successCount;
    
    private List<WechatImportResult> success;
    
    private List<WechatImportResult> failure;
    
    private int failureCount;

    /**
     * @return the sucessCount
     */
    public int getSuccessCount() {
        return successCount;
    }

    /**
     * @param sucessCount the sucessCount to set
     */
    public void setSuccessCount(int successCount) {
        this.successCount = successCount;
    }

    /**
     * @return the success
     */
    public List<WechatImportResult> getSuccess() {
        if(this.success == null){
            this.success = new ArrayList<WechatImportResult>();
        }
        return this.success;
    }

    /**
     * @param success the success to set
     */
    public void setSuccess(List<WechatImportResult> success) {
        this.success = success;
    }

    /**
     * @return the failure
     */
    public List<WechatImportResult> getFailure() {
        if(this.failure == null){
           this.failure = new ArrayList<WechatImportResult>(); 
        }
        return this.failure;
    }

    /**
     * @param failure the failure to set
     */
    public void setFailure(List<WechatImportResult> failure) {
        this.failure = failure;
    }

    /**
     * @return the failureCount
     */
    public int getFailureCount() {
        return failureCount;
    }

    /**
     * @param failureCount the failureCount to set
     */
    public void setFailureCount(int failureCount) {
        this.failureCount = failureCount;
    }
}
