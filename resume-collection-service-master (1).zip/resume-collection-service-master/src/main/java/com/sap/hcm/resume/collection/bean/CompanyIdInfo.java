package com.sap.hcm.resume.collection.bean;

import org.springframework.stereotype.Component;

@Component
public class CompanyIdInfo {

  private String companyId;

  public String getCompanyId() {
    return companyId;
  }

  public void setCompanyId(String companyId) {
    this.companyId = companyId;
  }
}
