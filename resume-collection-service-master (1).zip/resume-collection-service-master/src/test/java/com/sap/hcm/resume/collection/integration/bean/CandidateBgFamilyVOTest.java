package com.sap.hcm.resume.collection.integration.bean;

import org.junit.Assert;
import org.junit.Test;

import com.sap.hcm.resume.collection.entity.view.CandidateBgFamilyVO;


public class CandidateBgFamilyVOTest {
  
  @Test
  public void testSetGetter(){
    CandidateBgFamilyVO vo = new CandidateBgFamilyVO();
    vo.setAge("1");
    vo.setName("test");
    vo.setPhone("123");
    vo.setRelationship("1");
    vo.setWork("1");
    
    Assert.assertEquals(vo.getAge(), "1");
    Assert.assertEquals(vo.getName(), "test");
    Assert.assertEquals(vo.getPhone(), "123");
    Assert.assertEquals(vo.getRelationship(), "1");
    Assert.assertEquals(vo.getWork(), "1");
  }
}
