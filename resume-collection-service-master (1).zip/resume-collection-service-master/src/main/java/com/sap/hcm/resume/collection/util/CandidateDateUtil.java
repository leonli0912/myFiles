package com.sap.hcm.resume.collection.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import com.sap.hcm.resume.collection.exception.ServiceApplicationException;

public class CandidateDateUtil {

    private static final String CHINESE_NOW = "今";
    
    private static final String CHINESE1_NOW = "至今";

    private static final String ENGLISH_NOW = "NOW";

    public static String formatStringDateToOdata(String strDate, boolean needTimeZone) throws ServiceApplicationException {

        if (strDate == null || strDate.isEmpty()) {
            return "";
        }

        SimpleDateFormat sf = new SimpleDateFormat("yyyy/MM/dd");
        long date;
        try {
          date = sf.parse(strDate).getTime();
        } catch (ParseException e) {
          throw new ServiceApplicationException("parse date failed: " + e.getMessage());
        }
        if (needTimeZone) {
          //To resolve datetime without time zone 
          long difference = 57600000;
          date = date + difference;
        }
        
        return String.valueOf(date);
    }

    public static String formatDate2String(Date date, String format) {
        String strDate = null;
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        strDate = sdf.format(date);
        return strDate;
    }
    
    public static String formatDate2StringMinus6Months(String format) {
      SimpleDateFormat sdf = new SimpleDateFormat(format);
      Date rightDate = formatDate2DateMinus6Months();
      String strDate = sdf.format(rightDate);
      return strDate;
    }
    
    public static Date formatDate2DateMinus6Months() {
      Date nowDate = new Date();
      Calendar calendar = Calendar.getInstance();
      calendar.setTime(nowDate);
      calendar.add(Calendar.MONTH, -6);
      Date rightDate = calendar.getTime();
      return rightDate;
    }

    /**
     * 
     * @param sourceFormat
     * @param targetFormat
     * @param strDate
     * @return
     * @throws ParseException
     */
    public static String formatDate(String sourceFormat, String targetFormat, String strDate) {
        String target = "";
        SimpleDateFormat sdf = new SimpleDateFormat(sourceFormat);
        SimpleDateFormat tsdf = new SimpleDateFormat(targetFormat);
        if (CHINESE_NOW.equals(strDate) || CHINESE1_NOW.equals(strDate) || ENGLISH_NOW.equalsIgnoreCase(strDate)) {
            target = "NOW";
        }else {
          try {
            Date sourceDate = sdf.parse(strDate);
            target = tsdf.format(sourceDate);
          } catch (ParseException e) {
            target = "";
          }
        }
        return target;
    }
}
