package com.sap.hcm.resume.collection.util;

public class I18nMessages {

  private I18nMessages() {

  }

  public static final String LABEL_FIRST_NAME = "LB_FIRST_NAME";

  public static final String LABEL_LAST_NAME = "LB_LAST_NAME";

  public static final String LABEL_MIDDLE_NAME = "LB_MIDDLE_NAME";

  public static final String LABEL_ENGLISH_NAME = "LB_ENGLISH_NAME";

  public static final String LABEL_PRIMARY_EMAIL = "LB_PRIMARY_EMAIL";

  public static final String LABEL_CONTACT_EMAIL = "LB_CONTACT_EMAIL";

  public static final String LABEL_GENDER = "LB_GENDER";

  public static final String LABEL_DATE_OF_BIRTH = "LB_DATE_OF_BIRTH";

  public static final String LABEL_CELLPHONE = "LB_CELLPHONE";

  public static final String LABEL_NATIONALITY = "LB_NATIONALITY";

  public static final String LABEL_ETHNICITY = "LB_ETHNICITY";

  public static final String LABEL_RESIDENCE = "LB_RESIDENCE";

  public static final String LABEL_HOUSEHOLD = "LB_HOUSEHOLD";

  public static final String LABEL_IDENTITY_CARD = "LB_IDENTITY_CARD";

  public static final String LABEL_PASSPORT = "LB_PASSPORT";

  public static final String LABEL_ADDRESS = "LB_ADDRESS";

  public static final String LABEL_ZIPCODE = "LB_ZIPCODE";

  public static final String LABEL_PHONE = "LB_PHONE";

  public static final String LABEL_ADDRESS1 = "LB_ADDRESS1";

  public static final String LABEL_ZIPCODE1 = "LB_ZIPCODE1";

  public static final String LABEL_PHONE1 = "LB_PHONE1";

  public static final String LABEL_COUNTRY = "LB_COUNTRY";

  public static final String LABEL_MARRIAGE = "LB_MARRIAGE";

  public static final String LABEL_MIN_ANNUAL_SALARY = "LB_MIN_ANN_SAL";

  public static final String LABEL_PEREFER_LOCATION = "LB_PEREFER_LOCATION";

  public static final String LABEL_VETERANSTATUS = "LB_VETERANSTATUS";

  public static final String LABEL_CURRENCY = "LB_CURRENCY";

  public static final String LABEL_ATTACHMENT = "LB_ATTACHMENT";

  public static final String LABEL_STATE = "LB_STATE";

  public static final String LABEL_START_DATE = "LB_STARTDATE";

  public static final String LABEL_END_DATE = "LB_ENDDATE";

  public static final String LABEL_IS_PRESENT = "LB_ISPRESENT";

  public static final String LABEL_EMPLOYER = "LB_EMPLOYER";

  public static final String LABEL_JOB_TITLE = "LB_JOB_TITLE";

  public static final String LABEL_DEPARTEMNT = "LB_DEPARTMENT";

  public static final String LABEL_DESCRIPTION = "LB_DESCRIPTION";

  public static final String LABEL_EXIT_REASON = "LB_EXIT_REASON";

  public static final String LABEL_SALARY_START = "LB_SALARY_START";

  public static final String LABEL_SALARY_END = "LB_SALARY_END";

  public static final String LABEL_PRESENT_EMPLOYER = "LB_PRESENT_EMPLOYER";

  public static final String LABEL_MAJOR = "LB_MAJOR";

  public static final String LABEL_SCHOOL = "LB_SCHOOL";

  public static final String LABEL_DEGREE = "LB_DEGREE";

  public static final String LABEL_SCHOOL_STATE = "LB_SCHOOL_STATE";

  public static final String LABEL_GPA = "LB_GPA";

  public static final String LABEL_NAME = "LB_NAME";

  public static final String LABEL_SPEAKING_PROF = "LB_SPEACKING_PROF";

  public static final String LABEL_READING_PROF = "LB_READING_PROF";

  public static final String LABEL_WRITING_PROF = "LB_WRITING_PROF";

  public static final String LABEL_RELATIONSHIP = "LB_RELATIONSHIP";

  public static final String LABEL_AGE = "LB_AGE";

  public static final String LABEL_WORK = "LB_WORK";

  public static final String LABEL_INSTITUTION = "LB_INSTITUTION";

  public static final String LABEL_SCORE = "LB_SCORE";

  public static final String LABEL_START_WORK_DATE = "LB_START_WORK_DATE";

  public static final String LABEL_CURRENT_COMPANY = "LB_CURRENT_COMPANY";

  public static final String LABEL_CANDIDATE_SOURCE = "LB_CANDIDATE_SOURCE";

  public static final String LABEL_CUSTOM01 = "LB_CUSTOM01";

  public static final String LABEL_CUSTOM02 = "LB_CUSTOM02";

  public static final String LABEL_CUSTOM03 = "LB_CUSTOM03";

  public static final String LABEL_CUSTOM04 = "LB_CUSTOM04";

  public static final String LABEL_CUSTOM05 = "LB_CUSTOM05";

  public static final String LABEL_BUSINESS_TYPE = "LB_BUSINESS_TYPE";

  public static final String LABLE_PINYIN = "LB_PINYIN";
  
  public static final String LABLE_REQIRED_FIELD = "LB_REQIRED_FIELD";
}
