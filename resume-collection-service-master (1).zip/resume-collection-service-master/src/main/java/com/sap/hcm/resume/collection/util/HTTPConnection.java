package com.sap.hcm.resume.collection.util;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Properties;

import javax.net.ssl.SSLContext;

import org.apache.commons.io.IOUtils;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.CookieStore;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.config.CookieSpecs;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.client.utils.HttpClientUtils;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContextBuilder;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.cookie.Cookie;
import org.apache.http.cookie.CookieSpecProvider;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.cookie.BasicClientCookie;
import org.apache.http.impl.cookie.BestMatchSpecFactory;
import org.apache.http.impl.cookie.BrowserCompatSpecFactory;
import org.apache.http.util.EntityUtils;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;

import com.sap.hcm.resume.collection.exception.ServiceApplicationException;

/**
 * HTTP connection
 * 
 * @author i065831
 *
 */
@Component
@Scope(value = "session", proxyMode = ScopedProxyMode.TARGET_CLASS)
public class HTTPConnection {

  private CookieStore cookieStore = new BasicCookieStore();

  private HttpClientContext context = null;

  private Properties basicAuthPro = null;

  public HTTPConnection() {

  }

  public HTTPConnection(Properties authPro) {
    this.basicAuthPro = authPro;
  }

  public String load(String callURL, String method, Header[] headers, String postBody, UrlEncodedFormEntity formEntity)
      throws ServiceApplicationException {
    String output = "";
    InputStream is = null;
    HttpEntity entity = null;
    CloseableHttpClient httpClient = null;
    try {
      httpClient = this.createHttpClient();
      HttpResponse response = this.loadAsHttpResponse(httpClient, callURL, method, headers, postBody, formEntity);
      if (response != null && response.getEntity() != null) {

        // set cookie
        this.setCookieStore(response);
        entity = response.getEntity();
        is = entity.getContent();
        output = IOUtils.toString(is, StandardCharsets.UTF_8.name());
      }

    } catch (IOException | KeyManagementException | NoSuchAlgorithmException | KeyStoreException e) {
      throw new ServiceApplicationException(e.getMessage());
    } finally {
      IOUtils.closeQuietly(is);
      EntityUtils.consumeQuietly(entity);
      this.closeHttpClient(httpClient);
    }
    return output;

  }
  
  public CloseableHttpClient createHttpClient() throws KeyManagementException, NoSuchAlgorithmException, KeyStoreException{

    HttpClientBuilder httpClientBuilder = HttpClientBuilder.create().useSystemProperties();
      
      SSLContext sslContext = new SSLContextBuilder().loadTrustMaterial(null, new TrustStrategy() {
        public boolean isTrusted(X509Certificate[] chain, String authType) {
          return true;
        }
      }).build();
      SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslContext);
      httpClientBuilder.setSSLSocketFactory(sslsf);
      httpClientBuilder.setHostnameVerifier(SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);

      // read properties
      String user = null;
      String pass = null;
      if (this.basicAuthPro != null) {
        user = this.basicAuthPro.getProperty("server.connect.user");
        pass = this.basicAuthPro.getProperty("server.connect.pass");
      }

      // set up basic authentication
      if (user != null && pass != null) {
        CredentialsProvider credenticalProvider = new BasicCredentialsProvider();
        // Create the authentication scope
        AuthScope scope = new AuthScope(AuthScope.ANY_HOST, AuthScope.ANY_PORT, AuthScope.ANY_REALM);
        UsernamePasswordCredentials credentials = new UsernamePasswordCredentials(user, pass);
        credenticalProvider.setCredentials(scope, credentials);
        httpClientBuilder.setDefaultCredentialsProvider(credenticalProvider);
      }

      // create the httpclient
      return httpClientBuilder.build();
  }
  
  
  public void closeHttpClient(CloseableHttpClient httpClient){
    HttpClientUtils.closeQuietly(httpClient);
  }
  
  public HttpResponse loadAsHttpResponse(CloseableHttpClient httpclient, String callURL, String method, Header[] headers, String postBody,
      UrlEncodedFormEntity formEntity) throws ServiceApplicationException {

    // read url
    callURL = callURL.replaceAll("\'", "%27");
    callURL = callURL.replaceAll(" ", "%20");
    
    HttpResponse response = null;
    
    try{
      
      context = HttpClientContext.create();
      Registry<CookieSpecProvider> registry = RegistryBuilder.<CookieSpecProvider> create()
          .register(CookieSpecs.BEST_MATCH, new BestMatchSpecFactory())
          .register(CookieSpecs.BROWSER_COMPATIBILITY, new BrowserCompatSpecFactory()).build();
      context.setCookieSpecRegistry(registry);
      context.setCookieStore(cookieStore);

      HttpRequestBase request = null;
      if ("GET".equals(method)) {
        request = new HttpGet(callURL);
      } else if ("PUT".equals(method)) {
        request = new HttpPut(callURL);
        if (postBody != null) {
          HttpEntity entity = new StringEntity(postBody);
          ((HttpPut) request).setEntity(entity);
        }

      } else if ("POST".equals(method)) {

        request = new HttpPost(callURL);
        if (postBody != null) {
          HttpEntity entity = new StringEntity(postBody, "UTF-8");
          ((HttpPost) request).setEntity(entity);
        }
        if (formEntity != null) {
          ((HttpPost) request).setEntity(formEntity);
        }
      } else {
        request = new HttpGet(callURL);
      }

      if (headers != null && headers.length > 0) {
        request.setHeaders(headers);
      }

      RequestConfig.Builder configBuilder = RequestConfig.custom().setConnectionRequestTimeout(50000)
          .setConnectTimeout(50000).setSocketTimeout(50000);
      request.setConfig(configBuilder.build());
      response = httpclient.execute(request, context);
    } catch (IOException e) {
      throw new ServiceApplicationException(e.getMessage());
    }
    return response;

  }

  /**
   * add cookie
   * 
   * @param paramCookie
   */
  public void addCookie(Cookie paramCookie) {
    this.cookieStore.addCookie(paramCookie);
  }

  /**
   * clean cookie
   */
  public void cleanCookie() {
    this.cookieStore.clear();
  }

  public void setCookieStore(HttpResponse httpResponse) {

    Header[] headers = httpResponse.getHeaders("Set-Cookie");
    if (headers != null && headers.length > 0) {
      for (int i = 0; i < headers.length; i++) {
        String setCookie = headers[i].getValue();
        try {
          BasicClientCookie cookie = this.parseRawCookie(setCookie);
          if (!cookie.isExpired(new Date())) {
            this.cookieStore.addCookie(cookie);
          }
        } catch (Exception e) {
          // do nothing
        }
      }
    }
    this.cookieStore.clearExpired(new Date());
  }

  /**
   * parse cookie
   * 
   * @param rawCookie
   * @return
   * @throws Exception
   */
  BasicClientCookie parseRawCookie(String rawCookie) throws Exception {
    String[] rawCookieParams = rawCookie.split(";");

    String[] rawCookieNameAndValue = rawCookieParams[0].split("=");
    if (rawCookieNameAndValue.length != 2) {
      throw new Exception("Invalid cookie: missing name and value.");
    }

    String cookieName = rawCookieNameAndValue[0].trim();
    String cookieValue = rawCookieNameAndValue[1].trim();
    BasicClientCookie cookie = new BasicClientCookie(cookieName, cookieValue);
    for (int i = 1; i < rawCookieParams.length; i++) {
      String rawCookieParamNameAndValue[] = rawCookieParams[i].trim().split("=");

      String paramName = rawCookieParamNameAndValue[0].trim();

      if (paramName.equalsIgnoreCase("secure")) {
        cookie.setSecure(true);
      } else {
        if (rawCookieParamNameAndValue.length != 2) {
          throw new Exception("Invalid cookie: attribute not a flag or missing value.");
        }

        String paramValue = rawCookieParamNameAndValue[1].trim();

        if (paramName.equalsIgnoreCase("expires")) {
          Date expiryDate = new SimpleDateFormat("EEE, dd-MMM-yyyy hh:mm:ss z", Locale.US).parse(paramValue);
          cookie.setExpiryDate(expiryDate);
        } else if (paramName.equalsIgnoreCase("max-age")) {
          long maxAge = Long.parseLong(paramValue);
          Date expiryDate = new Date(System.currentTimeMillis() + maxAge);
          cookie.setExpiryDate(expiryDate);
        } else if (paramName.equalsIgnoreCase("domain")) {
          cookie.setDomain(paramValue);
        } else if (paramName.equalsIgnoreCase("path")) {
          cookie.setPath(paramValue);
        } else if (paramName.equalsIgnoreCase("comment")) {
          cookie.setComment(paramValue);
        } else {
          throw new Exception("Invalid cookie: invalid attribute name.");
        }
      }
    }

    return cookie;
  }
}
