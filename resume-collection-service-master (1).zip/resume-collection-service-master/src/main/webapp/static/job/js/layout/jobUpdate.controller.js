sap.ui.define([ 'sap/m/MessageBox', 'static/job/js/layout/JobBaseEditController', 'sap/ui/model/json/JSONModel' ],
		function(MessageBox, JobBaseEditController, JSONModel) {
			"use strict";

			var jobUpdateController = JobBaseEditController.extend("static.job.js.layout.jobUpdate", {

				_jobId : null,
				/**
				 * Called when a controller is instantiated and its View
				 * controls (if available) are already created. Can be used to
				 * modify the View before it is displayed, to bind event
				 * handlers and do other one-time initialization.
				 * 
				 * @memberOf resume-collection-service.jp
				 */
				onInit : function() {
					this._router = sap.ui.core.UIComponent.getRouterFor(this);
					var that = this;

					this._router.attachRoutePatternMatched(this.prepareData, this);

					// attach handlers for validation errors
					sap.ui.getCore().attachValidationError(function(evt) {
						var control = evt.getParameter("element");
						if (control && control.setValueState) {
							control.setValueState("Error");
						}
					});
					sap.ui.getCore().attachValidationSuccess(function(evt) {
						var control = evt.getParameter("element");
						if (control && control.setValueState) {
							control.setValueState("None");
						}
					});
				},

				prepareData : function(oEvent) {
					this._jobId = oEvent.getParameter("arguments").jobId;
					var that = this;
					if (this._jobId) {
						$.get("job/" + this._jobId, function(data) {
							if (data && data.jobInfo) {
								var oModel = new sap.ui.model.json.JSONModel();
								oModel.setData(data.jobInfo);
								that.getView().setModel(oModel);
								that.addVideoElement(data.jobInfo.jobDescVideoName);
							}
						});
					}

					// call setup data in parent controller
					this.setupData(oEvent);
				},

				doUpload : function(oEvent) {

					var oFileUploader = this.getView().byId("fileUploader");
					oFileUploader.setUploadUrl("job/uploadVideo?jobId=" + this._jobId);
					oFileUploader.upload();
					oFileUploader.clear();

				},

				onUpdate : function() {
					// this._router =
					// sap.ui.core.UIComponent.getRouterFor(this);
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					var that = this;
					var jsonData = that.getView().getModel().getData();
					if (this.validate()) {
						var cfg = {
							type : 'POST',
							data : JSON.stringify(jsonData),
							dataType : 'json',
							contentType : 'application/json;charset=UTF-8'
						};
						cfg.url = "job/update?jobId=" + this._jobId;
						$.ajax(cfg).success(function(data) {
							if (data.code === 0) {
								sap.m.MessageBox.success(that.translatEnumLabel("JOB_UPDATED_SUCCESSFULLY"), {
									styleClass : bCompact ? "sapUiSizeCompact" : "",
									onClose : function(oAction) {
										if (oAction === "OK") {
											that._router.navTo("maintainJob", true);
										}
									}
								});
							} else {
								sap.m.MessageBox.error(data.message, {
									styleClass : bCompact ? "sapUiSizeCompact" : ""
								});
							}
						});
					}
				},
				onCancel : function() {

					var oHistory = sap.ui.core.routing.History.getInstance();
					var sPreviousHash = oHistory.getPreviousHash();

					if (sPreviousHash !== undefined) {
						window.history.go(-1);
					} else {
						var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
						oRouter.navTo("maintainJob", true);
					}
				},

				handleSelectionChange : function(oEvent) {
					var changedItem = oEvent.getParameter("changedItem");
					var isSelected = oEvent.getParameter("selected");

					var state = "Selected";
					if (!isSelected) {
						state = "Deselected"
					}

				},

				handleSelectionFinish : function(oEvent) {
					var selectedItems = oEvent.getParameter("selectedItems");
					var messageText = "Event 'selectionFinished': [";

					for (var i = 0; i < selectedItems.length; i++) {
						messageText += "'" + selectedItems[i].getText() + "'";
						if (i != selectedItems.length - 1) {
							messageText += ",";
						}
					}

					messageText += "]";

					alert(messageText);

				},

				translatEnumLabel : function(val) {
					return this.getView().getModel("wi18n").getResourceBundle().getText(val);
				},

				alertMsg : function(requiredMsg) {
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					sap.m.MessageBox.alert(requiredMsg, {
						styleClass : bCompact ? "sapUiSizeCompact" : ""
					});
				},

			});

			return jobUpdateController;
		});
