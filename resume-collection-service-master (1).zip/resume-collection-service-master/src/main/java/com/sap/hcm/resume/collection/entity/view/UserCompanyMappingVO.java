package com.sap.hcm.resume.collection.entity.view;

import java.io.Serializable;

import com.sap.hcm.resume.collection.integration.bean.CandProfileDataModelMapping;
import com.sap.hcm.resume.collection.integration.sf.bean.SFAuthenticationBean;

public class UserCompanyMappingVO implements Serializable{
    
    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = -6463902564910609753L;

    private Long id;
    
    private String mappingName;
    
    private String targetSystem;
        
    private CandProfileDataModelMapping mapping;
    
    private SFAuthenticationBean integrationBean;

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the mappingName
     */
    public String getMappingName() {
        return mappingName;
    }

    /**
     * @param mappingName the mappingName to set
     */
    public void setMappingName(String mappingName) {
        this.mappingName = mappingName;
    }

    /**
     * @return the targetSystem
     */
    public String getTargetSystem() {
        return targetSystem;
    }

    /**
     * @param targetSystem the targetSystem to set
     */
    public void setTargetSystem(String targetSystem) {
        this.targetSystem = targetSystem;
    }

    /**
     * @return the mapping
     */
    public CandProfileDataModelMapping getMapping() {
        return mapping;
    }

    /**
     * @param mapping the mapping to set
     */
    public void setMapping(CandProfileDataModelMapping mapping) {
        this.mapping = mapping;
    }

    /**
     * @return the integrationBean
     */
    public SFAuthenticationBean getIntegrationBean() {
        return integrationBean;
    }

    /**
     * @param integrationBean the integrationBean to set
     */
    public void setIntegrationBean(SFAuthenticationBean integrationBean) {
        this.integrationBean = integrationBean;
    }
    
    
    
}
