package com.sap.hcm.resume.collection.integration.controller;

import java.io.File;
import java.net.MalformedURLException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.olingo.odata2.api.edm.Edm;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sap.hcm.resume.collection.bean.ActionType;
import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.bean.SimpleJsonResponse;
import com.sap.hcm.resume.collection.controller.ControllerBase;
import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.entity.DataModelMapping;
import com.sap.hcm.resume.collection.entity.view.JobRequisitionMappingVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.bean.JobReqDataModelMapping;
import com.sap.hcm.resume.collection.integration.sf.SFOdataFormatter;
import com.sap.hcm.resume.collection.integration.sf.odata.SFODataService;
import com.sap.hcm.resume.collection.integration.xml.DataModelMappingXMLConverter;
import com.sap.hcm.resume.collection.service.DataModelMappingService;
import com.sap.hcm.resume.collection.util.ChangeLogUtil;
import com.sap.hcm.resume.collection.util.MappingUtil;
import com.sap.security.um.user.User;

@Controller
@RequestMapping(value = "jobreq")
public class JobRequisitionDataModelController extends ControllerBase {

  private final Logger logger = LoggerFactory.getLogger(JobRequisitionDataModelController.class);

  @Autowired
  private DataModelMappingService mappingService;

  @Autowired
  private SFODataService sfODataService;

  @Autowired
  private SFOdataFormatter sfOdataFormatter;

  @Autowired
  private ChangeLogUtil changeLogUtil;

  @Autowired
  private Params params;

  @RequestMapping(value = "/listMapping", method = RequestMethod.GET)
  public @ResponseBody Map<String, Object> listjobReqDMMapping(
      @RequestParam(value = "skip", required = false, defaultValue = "0") int skip,
      @RequestParam(value = "top", required = false, defaultValue = "20") int top) throws ServiceApplicationException {
    Map<String, Object> containerMap = new HashMap<String, Object>();
    List<DataModelMapping> mList = mappingService.listJobRequisitionMapping(params.getCompanyId(), skip, top);

    CompanyInfo compInfo = this.compInfoService.getCompanyInfo(params.getCompanyId());
    containerMap.put("entries", mList);
    containerMap.put("active", compInfo.getJobReqMappingId());

    return containerMap;
  }

  @RequestMapping(value = "/listMapping/{mappingId}", method = RequestMethod.GET)
  public @ResponseBody JobRequisitionMappingVO listjobReqDMMappingbyId(
      @PathVariable(value = "mappingId") Long mappingId) {
    return mappingService.getJobRequisitionMappingById(params.getCompanyId(), mappingId);
  }

  @RequestMapping(value = "/new", method = RequestMethod.GET)
  public @ResponseBody JobReqDataModelMapping newjobReqDMMapping() {
    return mappingService.createEmptyJobRequisitionMapping();
  }

  @RequestMapping(value = "/{mappingId}/delete", method = RequestMethod.DELETE)
  public @ResponseBody SimpleJsonResponse deleteReqMapping(HttpServletRequest request,
      @PathVariable(value = "mappingId") Long mappingId) {
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(-1);
    rsp.setMessage("error");
    try {
      String mappingName = mappingService.getMappingById(mappingId).getMappingName();
      mappingService.deleteRequisitionMapping(mappingId);
      rsp.setCode(0);
      rsp.setMessage("success");
      
      String companyId = params.getCompanyId();
      CompanyInfo info = compInfoService.getCompanyInfo(companyId);
      if(info.getJobReqMappingId() != null && mappingId.equals(info.getJobReqMappingId())){
        //delete active mapping
        info.setJobReqMappingId(null);
        compInfoService.saveCompanyInfo(info);
      }
      
      changeLogUtil.saveCompanyChangeHistory(ActionType.DEL, hcpUserProvider.getLoginUser(request).getName(),
          "delete job requisition mapping", companyId, mappingName, mappingId.toString());
    } catch (Exception e) {
      rsp.setMessage("server error");
      logger.error("server error: " + e.getMessage());
    }
    return rsp;
  }

  @RequestMapping(value = "/saveReqMapping", method = RequestMethod.POST)
  public @ResponseBody SimpleJsonResponse saveReqMapping(@RequestBody JobRequisitionMappingVO mapping,
      HttpServletRequest request) throws ServiceApplicationException, MalformedURLException {
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    ActionType actionType = null;
    String content = null;
    if (mapping.getId() == null) {
      actionType = ActionType.ADD;
      content = "add job requisition mapping";
    } else {
      actionType = ActionType.EDT;
      content = "edit job requisition mapping";
    }
    String companyId = params.getCompanyId();
    User user = hcpUserProvider.getLoginUser(request);
    if (user != null) {
      mapping.setCreateBy(user.getName());
    }
    if (companyId == null) {
      rsp.setCode(-1);
      rsp.setMessage("companyId is missing");
      return rsp;
    }
    try {
      Edm edm = sfODataService.getEdm();
      sfOdataFormatter.checkJobReqPicklistNavi(edm, mapping);
      String mappingId = mappingService.saveJobRequisitionMapping(mapping, companyId).getMappingId().toString();
      rsp.setCode(0);
      rsp.setMessage("success");
      changeLogUtil.saveCompanyChangeHistory(actionType, user.getName(), content, companyId, mapping.getMappingName(),
          mappingId);
    } catch (Exception e) {
      rsp.setCode(-1);
      rsp.setMessage("server error");
      logger.error("server error: " + e.getMessage());
    }

    mappingService.renewJobRequisitionPicklistCache();
    return rsp;
  }

  @RequestMapping(value = "/renewPicklistCache")
  public @ResponseBody SimpleJsonResponse renewPicklistCache()
      throws ServiceApplicationException, MalformedURLException {
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp = mappingService.renewJobRequisitionPicklistCache();
    return rsp;
  }

  @RequestMapping(value = "/{mappingId}/export", method = RequestMethod.GET)
  public ResponseEntity<byte[]> exportMappingById(@PathVariable(value = "mappingId") Long mappingId,
      HttpServletResponse response) throws ServiceApplicationException {
    DataModelMapping mapping = mappingService.getApplyDataModelMappingByMappingId(mappingId);
    byte[] mappingContent = mapping.getMappingContent();
    if (mappingContent != null) {
      HttpHeaders headers = new HttpHeaders();
      headers.setContentType(MediaType.APPLICATION_XML);
      headers.setContentDispositionFormData("attachment", "job_requisition_model_mapping.xml");
      return new ResponseEntity<byte[]>(mappingContent, headers, HttpStatus.OK);
    } else {
      throw new ServiceApplicationException("file content is empty");
    }
  }

  @RequestMapping(value = "/import", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
  public @ResponseBody String importMapping(HttpServletRequest request, HttpServletResponse response)
      throws ServiceApplicationException {
    String mappingTxt = "";

    DiskFileItemFactory dff = new DiskFileItemFactory();
    dff.setSizeThreshold(50 * 1024 * 1024);
    dff.setRepository(new File("temp"));
    ServletFileUpload upload = new ServletFileUpload(dff);
    String encoding = request.getCharacterEncoding();
    upload.setHeaderEncoding(encoding);
    upload.setFileSizeMax(1000 * 1024 * 1024);

    List<FileItem> items;
    try {
      items = upload.parseRequest(request);
    } catch (FileUploadException e1) {
      throw new ServiceApplicationException("process upload file failed: " + e1.getMessage());
    }
    if (items != null && items.size() > 0) {
      for (FileItem item : items) {
        String filename = item.getName();
        String regex = ".*\\.xml";
        // check the file is xml file
        if (filename != null && MappingUtil.matchSingle(regex, filename) != null) {
          try {
            JobReqDataModelMapping mappingItem = DataModelMappingXMLConverter.fromJobReqByte(item.get(),
                StandardCharsets.UTF_8.name());
            ObjectMapper om = new ObjectMapper();
            mappingTxt = om.writeValueAsString(mappingItem);
          } catch (Exception e) {
            logger.error("process upload file failed: " + e.getMessage());
            throw new ServiceApplicationException("process upload file failed");
          }
        }
      }
    }
    return mappingTxt;
  }

  @RequestMapping(value = "active/{mappingId}", method = RequestMethod.GET)
  public @ResponseBody SimpleJsonResponse activeMapping(HttpServletRequest request,
      @PathVariable(value = "mappingId") Long mappingId) throws ServiceApplicationException {
    SimpleJsonResponse rsp = new SimpleJsonResponse();

    String companyId = params.getCompanyId();

    CompanyInfo info = compInfoService.getCompanyInfo(companyId);
    info.setJobReqMappingId(mappingId);
    compInfoService.saveCompanyInfo(info);

    rsp.setCode(0);
    rsp.setMessage("success");
    return rsp;
  }
}
