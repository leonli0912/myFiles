package com.sap.hcm.resume.collection.scheduling;

import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.service.CandidateProfileService;
import com.sap.hcm.resume.collection.service.ChangeLogService;
import com.sap.hcm.resume.collection.service.ExceptionLogService;

@Component
public class ChangeLogCleanScheduler {

  private static final Logger logger = LoggerFactory.getLogger(ChangeLogCleanScheduler.class);

  @Autowired
  private ChangeLogService changeLogService;

  @Autowired
  private CandidateProfileService candidateProfileService;

  @Autowired
  private ExceptionLogService exceptionLogService;

  /* 业务实现 */
  public void work() {
    logger.debug("Start cleaning of overdue change log on " + new Date());
    int deletedChangeLogResultCount = 0;
    try {
      deletedChangeLogResultCount = changeLogService.deleteOverdueChangeLog();
    } catch (ServiceApplicationException e) {
      logger.debug("Clean change log error with exception: " + e.getMessage());
    }
    if (deletedChangeLogResultCount > 0) {
      logger.debug(deletedChangeLogResultCount + " overdue change logs were deleted successfully");
    }
    logger.debug("End cleaning of overdue change log on " + new Date());

    logger.debug("Start cleaning of overdue change log on " + new Date());
    int deletedExceptionLogResultCount = 0;
    try {
      deletedExceptionLogResultCount = exceptionLogService.deleteOverdueExceptionLog();
    } catch (ServiceApplicationException e) {
      logger.debug("Clean exception log error with exception: " + e.getMessage());
    }
    if (deletedExceptionLogResultCount > 0) {
      logger.debug(deletedExceptionLogResultCount + " overdue exception logs were deleted successfully");
    }
    logger.debug("End cleaning of overdue exception log on " + new Date());

    logger.debug("Start cleaning of overdue candidate profile on " + new Date());
    int deletedOverdueCandidateResultCount = candidateProfileService.deleteOverdueCandidate();
    if (deletedOverdueCandidateResultCount > 0) {
      logger.debug(deletedOverdueCandidateResultCount + " overdue candidate Profiles were deleted successfully");
    }
    logger.debug("End cleaning of overdue candidate profile on " + new Date());
  }
}
