package com.sap.hcm.resume.collection.entity.view;

import java.io.Serializable;

import com.sap.hcm.resume.collection.annotation.ProfileAttribute;
import com.sap.hcm.resume.collection.util.I18nMessages;
import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("family")
public class CandidateBgFamilyVO implements CandidateBgBase, Serializable{

	/**
	 * serialVersionUID
	 */
    private static final long serialVersionUID = 42759757134348702L;
    
    @ProfileAttribute(name="name", type=String.class, label=I18nMessages.LABEL_NAME)
    private String name;
    
    @ProfileAttribute(name="relationship", type=String.class, label=I18nMessages.LABEL_RELATIONSHIP)
    private String relationship;
    
    @ProfileAttribute(name="age", type=String.class, label=I18nMessages.LABEL_AGE)
    private String age;
    
    @ProfileAttribute(name="work", type=String.class, label=I18nMessages.LABEL_WORK)
    private String work;
    
    @ProfileAttribute(name="phone", type=String.class, label=I18nMessages.LABEL_PHONE)
    private String phone;

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the relationship
	 */
	public String getRelationship() {
		return relationship;
	}

	/**
	 * @param relationship the relationship to set
	 */
	public void setRelationship(String relationship) {
		this.relationship = relationship;
	}

	/**
	 * @return the age
	 */
	public String getAge() {
		return age;
	}

	/**
	 * @param age the age to set
	 */
	public void setAge(String age) {
		this.age = age;
	}

	/**
	 * @return the work
	 */
	public String getWork() {
		return work;
	}

	/**
	 * @param work the work to set
	 */
	public void setWork(String work) {
		this.work = work;
	}

	/**
	 * @return the phone
	 */
	public String getPhone() {
		return phone;
	}

	/**
	 * @param phone the phone to set
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}
    
}
