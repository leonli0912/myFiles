package com.sap.hcm.resume.collection.bean;

import org.junit.Assert;
import org.junit.Test;

public class JobReqScreeningQuestionChoiceTest {
  
  @Test
  public void testGetterSetter(){
    JobReqScreeningQuestionChoice choice = new JobReqScreeningQuestionChoice();
    choice.setChoiceKey("key");
    choice.setLocale("en");
    choice.setOptionId(123L);
    choice.setOptionLabel("label");
    choice.setOptionValue(123);
    
    Assert.assertEquals("key", choice.getChoiceKey());
    Assert.assertEquals("en", choice.getLocale());
    Assert.assertEquals("123", String.valueOf(choice.getOptionId()));
    Assert.assertEquals("label", choice.getOptionLabel());
    Assert.assertEquals(123, choice.getOptionValue(),0);
  }
}
