sap.ui.localResources("static.job.js.layout");
sap.ui.localResources("static.job.js");
sap.ui.localResources("static.i18n");
sap.ui.localResources("static.js");

jQuery.sap.registerModulePath('com.sap.rcs.job', 'static/job/js/');
jQuery.sap.registerModulePath('com.sap.rcs', 'static/js/');

sap.ui.require(["com/sap/rcs/UserInfoUtil"], function(UserInfoUtil){
		var userInfoUtil= new UserInfoUtil();
		var compContainer = new sap.ui.core.ComponentContainer({
			name:"com.sap.rcs.job"
		});
		var oShell = userInfoUtil.createShell(compContainer);
		oShell.placeAt("content");
});
