package com.sap.hcm.resume.collection.controller;

import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.io.IOException;

import javax.annotation.Resource;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.context.TestContext;
import com.sap.hcm.resume.collection.context.WebAppContext;
import com.sap.hcm.resume.collection.entity.Photo;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.service.PhotoService;

;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { TestContext.class, WebAppContext.class })
public class WechatPhotoControllerTest {
  private WechatPhotoController wechatPhotoController;

  @Resource(name = "photoService")
  private PhotoService photoService;
  
  @Autowired
  private Params params;
  
  private MockMvc mockMvc;
  
  @Resource(type = WebApplicationContext.class)
  private WebApplicationContext webApplicationContext;

  @Before
  public void setUp() {
    reset(photoService);
    params.setWechatOpenId("001");
    MockitoAnnotations.initMocks(this);
    wechatPhotoController = spy(new WechatPhotoController());
    ReflectionTestUtils.setField(wechatPhotoController, "photoService", photoService);
    ReflectionTestUtils.setField(wechatPhotoController, "params", params);
    
    mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
    
  }

  @Test
  public void testGetPhotoWithNull() throws ServiceApplicationException, IOException {
    Long photoId = 123L;
    MockHttpServletRequest request = new MockHttpServletRequest();
    MockHttpServletResponse response = new MockHttpServletResponse();
    Photo photo = null;
    when(photoService.getPhoto(photoId)).thenReturn(photo);
    wechatPhotoController.getPhoto(request, response, photoId);
  }
  
  @Test
  public void testGetPhotoById() throws Exception{
    Long photoId = 1L;
    Photo p = new Photo();
    p.setContent("content".getBytes());
    
    Mockito.when(photoService.getPhoto(photoId)).thenReturn(p);
    ResultActions result = mockMvc.perform(MockMvcRequestBuilders.get("/wphoto/1")).andExpect(MockMvcResultMatchers.status().is(200));
    String content = result.andReturn().getResponse().getContentAsString();
    Assert.assertEquals(content, "content");
  }
  
  @Test
  public void testGetPhotoFromSession() throws Exception{
    MockHttpSession session = new MockHttpSession();
    session.putValue("photo_1", "content".getBytes());
    mockMvc.perform(MockMvcRequestBuilders.get("/wphoto/temp/photo_1").session(session)).andExpect(MockMvcResultMatchers.status().is(200));
  }
    
  @Test
  public void testUploadPhotoFromCompanyMaintain() throws Exception{
    mockMvc.perform(MockMvcRequestBuilders.fileUpload("/wphoto/picture/upload")
        .contentType("multipart/form-data; boundary=----WebKitFormBoundary8HC1OQgjqvtgc5tk")
         .param("sizeLimit", "true")
        .content(this.createMultipartContent("image", "image/jpeg", "content")))
        .andExpect(MockMvcResultMatchers.status().is(200));
  }
  
  private byte[] createMultipartContent(String fileName, String contentType, String fileContent){
    String endline = "\r\n";
    String bondary = "----WebKitFormBoundary8HC1OQgjqvtgc5tk";
    String textFile = this.encodeTextFile(bondary, "\r\n", "file",fileName,
        contentType, fileContent);
    StringBuilder content = new StringBuilder(textFile.toString());
    content.append(endline);
    content.append(endline);
    content.append(endline);
    content.append("--");
    content.append(bondary);
    content.append("--");
    content.append(endline);
    return content.toString().getBytes();
}

private String encodeTextFile(String bondary, String endline, String name, 
  String filename, String contentType, String content) {

  final StringBuilder sb = new StringBuilder();
  sb.append(endline);
  sb.append("--");
  sb.append(bondary);
  sb.append(endline);
  sb.append("Content-Disposition: form-data; name=\"");
  sb.append(name);
  sb.append("\"; filename=\"");
  sb.append(filename);
  sb.append("\"");
  sb.append(endline);
  sb.append("Content-Type: ");
  sb.append(contentType);
  sb.append(endline);
  sb.append(endline);
  sb.append(content);
  return sb.toString();
}

}
