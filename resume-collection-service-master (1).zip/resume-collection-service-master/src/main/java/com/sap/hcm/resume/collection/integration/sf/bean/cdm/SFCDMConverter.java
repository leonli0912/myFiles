package com.sap.hcm.resume.collection.integration.sf.bean.cdm;

import java.io.ByteArrayInputStream;
import java.io.UnsupportedEncodingException;
import java.util.Collection;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.bean.ApplyDataModelMappingItem;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.security.NullPermission;
import com.thoughtworks.xstream.security.PrimitiveTypePermission;

/**
 * Successfactors candidate data model converter
 * 
 * @author i065831
 */
public class SFCDMConverter {

  private static final Logger logger = LoggerFactory.getLogger(SFCDMConverter.class);

  private static XStream stream = new XStream();

  static {
    stream.autodetectAnnotations(true);
    stream.processAnnotations(SFCDMSimple.class);
    stream.processAnnotations(SFCDMFieldDefinition.class);
    stream.processAnnotations(SFCDMFieldLabel.class);
    stream.processAnnotations(SFCDMFieldEnum.class);
    stream.processAnnotations(SFCDMFieldEnumLabel.class);
    stream.processAnnotations(ApplyDataModelMappingItem.class);

    // add permissions, allow some basics
    stream.addPermission(NullPermission.NULL);
    stream.addPermission(PrimitiveTypePermission.PRIMITIVES);
    stream.allowTypeHierarchy(Collection.class);
    // allow any type from the same package
    stream.allowTypesByWildcard(new String[] { SFCDMSimple.class.getPackage().getName() + ".*" });
  }

  public static String toXML(List<ApplyDataModelMappingItem> itemList) {
    return stream.toXML(itemList);
  }

  public static SFCDMSimple fromXMLByFile(byte[] fileContent) {
    return (SFCDMSimple) stream.fromXML(new ByteArrayInputStream(fileContent));
  }

  @SuppressWarnings("unchecked")
  public static List<ApplyDataModelMappingItem> fromXMLByString(String content) {
    List<ApplyDataModelMappingItem> result = null;

    Object listObj = stream.fromXML(content);
    if (listObj != null && listObj instanceof List<?> && !((List<?>) listObj).isEmpty()) {
      Object item = ((List<?>) listObj).get(0);
      if (item != null && item instanceof ApplyDataModelMappingItem) {
        result = (List<ApplyDataModelMappingItem>) listObj;
      }
    }
    if (result == null) {
      logger.error("failed to deserialize xml content to List<ApplyDataModelMappingItem> object.");
    }
    return result;
  }

  public static List<ApplyDataModelMappingItem> fromXMLByByte(byte[] bytes, String charsetName)
      throws ServiceApplicationException {
    String content;
    try {
      content = new String(bytes, charsetName);
    } catch (UnsupportedEncodingException e) {
      logger.error(e.getMessage());
      throw new ServiceApplicationException(e.getMessage());
    }
    return fromXMLByString(content);

  }
}
