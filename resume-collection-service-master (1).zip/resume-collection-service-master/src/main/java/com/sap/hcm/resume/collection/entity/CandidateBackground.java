package com.sap.hcm.resume.collection.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Lob;
import javax.persistence.Table;

/**
 * candidate background table
 * @author i065831
 *
 */
@Entity
@IdClass(CandBackgroundID.class)
@Table(name="CANDIDATE_BACKGROUND")
public class CandidateBackground implements Serializable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 1529644198664741195L;

	@Id
	@Column(name = "candidate_id")
	private Long candidateId;
	
	@Id
	@Column(name = "bg_type", length = 20)
	private String backgroundType;

    @Column(name="company_id", length=100)
    private String companyId;
	
	@Lob
	@Column(name="content")
	private byte[] content;


	/**
	 * @return the candidateId
	 */
	public Long getCandidateId() {
		return candidateId;
	}

	/**
	 * @param candidateId the candidateId to set
	 */
	public void setCandidateId(Long candidateId) {
		this.candidateId = candidateId;
	}

	/**
	 * @return the backgroundType
	 */
	public String getBackgroundType() {
		return backgroundType;
	}

	/**
	 * @param backgroundType the backgroundType to set
	 */
	public void setBackgroundType(String backgroundType) {
		this.backgroundType = backgroundType;
	}

	/**
     * @return the companyId
     */
    public String getCompanyId() {
      return companyId;
    }
  
    /**
     * @param companyId the companyId to set
     */
    public void setCompanyId(String companyId) {
      this.companyId = companyId;
    }

  /**
	 * @return the content
	 */
	public byte[] getContent() {
		return content;
	}

	/**
	 * @param content the content to set
	 */
	public void setContent(byte[] content) {
		this.content = content;
	}

	
}
