package com.sap.hcm.resume.collection.exception;

import org.junit.Assert;
import org.junit.Test;

public class ServiceSystemExceptionTest {
  
  @Test
  public void testValidException(){
    ServiceSystemException exp = new ServiceSystemException("test");
    ServiceSystemException exp1 = new ServiceSystemException("test", new ServiceApplicationException("test"));
    Assert.assertNotNull(exp);
    Assert.assertNotNull(exp1);
  }
}
