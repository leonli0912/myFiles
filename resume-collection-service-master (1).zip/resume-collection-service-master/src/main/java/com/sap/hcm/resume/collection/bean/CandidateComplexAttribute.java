package com.sap.hcm.resume.collection.bean;

import java.io.Serializable;
import java.util.List;

public class CandidateComplexAttribute extends CandidateAttribute implements Serializable{
	
	/**
	 * serialVersionUID
	 */
    private static final long serialVersionUID = 1617753870151730097L;
    
	private List<CandidateAttribute> subAttributes;

	/**
	 * @return the subAttributes
	 */
	public List<CandidateAttribute> getSubAttributes() {
		return subAttributes;
	}

	/**
	 * @param subAttributes the subAttributes to set
	 */
	public void setSubAttributes(List<CandidateAttribute> subAttributes) {
		this.subAttributes = subAttributes;
	}
}
