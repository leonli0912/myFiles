package com.sap.hcm.resume.collection.bean;

/**
 * mapping type
 * @author i065831
 *
 */
public enum CandModelMappingTypeEnum {
    
    CAND_PROFILE_MAPPING("candidate_profile_mapping"),
    CAND_DM_MAPPING("candidate_dm_mapping"),
    JOB_REQ_MAPPING("job_req_mapping");
    
    private String labelKey;
    
    CandModelMappingTypeEnum(String labelKey){
      this.labelKey = labelKey;
    }

    public String getLabelKey() {
      return labelKey;
    }

    public void setLabelKey(String labelKey) {
      this.labelKey = labelKey;
    }
    
    
}
