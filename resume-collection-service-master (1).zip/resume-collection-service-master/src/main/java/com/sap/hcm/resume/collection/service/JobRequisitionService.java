package com.sap.hcm.resume.collection.service;

import java.io.UnsupportedEncodingException;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.service.JobRequisitionIntegrationService;

@Component
public class JobRequisitionService {

  @Autowired
  private Params params;

  @Autowired
  private CompanyInfoService compInfoService;

  @Autowired
  @Qualifier(value = "jobRequisitionIntergrationServiceProxy")
  private JobRequisitionIntegrationService integrationService;

  public Map<String, String> getJobRequisition(String lowDate, String highDate, String jobReqIdStr)
      throws ServiceApplicationException {

    CompanyInfo compInfo = compInfoService.getCompanyInfo(params.getCompanyId());
    if (compInfo == null) {
      throw new ServiceApplicationException("no valid company found");
    }
    return integrationService.getJobRequisition(String.valueOf(compInfo.getJobReqMappingId()), lowDate, highDate,
        jobReqIdStr);
  }

  public void syncJobRequisition(String companyId) throws ServiceApplicationException {
    integrationService.syncJobRequisition(companyId);
  }

  public Map<String, Object> getJobRequisitionForSearch(String condition) throws UnsupportedEncodingException {
    return integrationService.getJobRequisitionForSearch(condition);

  }
}
