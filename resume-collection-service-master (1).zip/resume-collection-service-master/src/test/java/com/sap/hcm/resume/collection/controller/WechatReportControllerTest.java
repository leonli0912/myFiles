package com.sap.hcm.resume.collection.controller;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.servlet.ModelAndView;

import com.sap.hcm.resume.collection.bean.KeyLabelBean;
import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.entity.ExceptionLog;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatJobService;
import com.sap.hcm.resume.collection.service.CompanyInfoService;
import com.sap.hcm.resume.collection.service.ExceptionLogService;


public class WechatReportControllerTest {
  
  private WechatReportController wechatReportController;
  
  private CompanyInfoService compInfoService;
  
  private WechatJobService jobService;
  
  private ExceptionLogService exceptionLogService;
  
  private Params params;
  
  @Before
  public void setup(){
    wechatReportController = new WechatReportController();
    compInfoService = Mockito.mock(CompanyInfoService.class);
    jobService = Mockito.mock(WechatJobService.class);
    exceptionLogService = Mockito.mock(ExceptionLogService.class);
    
    params = new Params();
    params.setCompanyId("sap");
    params.setWechatOpenId("openid");
    
    ReflectionTestUtils.setField(wechatReportController, "compInfoService", compInfoService);
    ReflectionTestUtils.setField(wechatReportController, "jobService", jobService);
    ReflectionTestUtils.setField(wechatReportController, "exceptionLogService", exceptionLogService);
    ReflectionTestUtils.setField(wechatReportController, "params", params);
  }
  
  @Test
  public void testGoToReportPage() throws ServiceApplicationException{
    CompanyInfo compInfo = new CompanyInfo();
    compInfo.setCompanyId("test");
    
    Mockito.when(compInfoService.getCompanyInfo(params.getCompanyId())).thenReturn(compInfo);
    
    ModelAndView mv = wechatReportController.goToReportPage();
    Assert.assertEquals("report", mv.getViewName());
  }
  
  @Test
  public void testGoToReportPageFailed() throws ServiceApplicationException{
    CompanyInfo compInfo = new CompanyInfo();
    compInfo.setCompanyId("test");
    
    Mockito.when(compInfoService.getCompanyInfo(params.getCompanyId())).thenThrow(new ServiceApplicationException("test"));
    
    ModelAndView mv = wechatReportController.goToReportPage();
    Assert.assertEquals("invalid_company", mv.getViewName());
  }
  
  @Test
  public void testViewDataByYear(){
    List<KeyLabelBean> list = new ArrayList<KeyLabelBean>();
    Mockito.when(jobService.getApplyHistoryStaticsByYear(params.getCompanyId())).thenReturn(list);
    
    List<KeyLabelBean> result = wechatReportController.viewDataByYear();
    Assert.assertEquals(result.size(), 0);
  }
  
  @Test
  public void testGetWechatUserNumber(){
    Mockito.when(jobService.getTotalWechatUserNumber(params.getCompanyId())).thenReturn(1L);
    Long result = wechatReportController.getWechatUserNumber();
    
    Assert.assertEquals(1, result.intValue());
  }
  
  @Test
  public void testGetExceptionLog() throws ServiceApplicationException{
    List<ExceptionLog> expList = new ArrayList<ExceptionLog>();
    ExceptionLog log = new ExceptionLog();
    log.setCompanyId("test");
    expList.add(log);
    
    Mockito.when(this.exceptionLogService.findExceptionLog(params.getCompanyId())).thenReturn(expList);
    
    List<ExceptionLog> resultList = this.wechatReportController.getExceptionLog();
    Assert.assertEquals(resultList.size(), 1);
  }
  
  @Test
  public void testViewDataByMonth(){
    List<KeyLabelBean> list = new ArrayList<KeyLabelBean>();
    Mockito.when(jobService.getApplyHistoryStaticsByMonth(params.getCompanyId(), "2016")).thenReturn(list);
    
    List<KeyLabelBean> result = wechatReportController.viewDataByMonth( "2016");
    Assert.assertEquals(result.size(), 0);
  }
}
