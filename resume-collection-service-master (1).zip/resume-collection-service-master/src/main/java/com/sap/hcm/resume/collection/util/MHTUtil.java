package com.sap.hcm.resume.collection.util;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;

import javax.mail.BodyPart;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.internet.MimeMessage;

import org.apache.commons.io.IOUtils;

import com.sap.hcm.resume.collection.exception.ServiceApplicationException;

public class MHTUtil {

  public static InlineHtml extractHtmlFromMht(byte[] resource) throws ServiceApplicationException {
    InputStream bis = new ByteArrayInputStream(resource);
    StringBuilder sb = new StringBuilder();
    String charsetName = null;
    InputStreamReader isr = null;
    InputStream bpis = null;
    BufferedReader br = null;
    Session mailSession = Session.getDefaultInstance(System.getProperties(), null);

    try {
      MimeMessage msg = new MimeMessage(mailSession, bis);
      Object content = msg.getContent();
      if (content instanceof Multipart) {
        BodyPart bp = ((Multipart) content).getBodyPart(0);
        bpis = bp.getInputStream();
        byte[] fileContent = IOUtils.toByteArray(bpis);
        charsetName = CandidateFileUtil.getCharsetNameFromByte(fileContent);
        isr = new InputStreamReader(new ByteArrayInputStream(fileContent), charsetName);
        br = new BufferedReader(isr);
        String line = null;
        while ((line = br.readLine()) != null) {
          sb.append(line).append(System.lineSeparator());
        }
      }
    } catch (MessagingException | IOException e) {
      throw new ServiceApplicationException(e.getMessage());
    } finally {
      IOUtils.closeQuietly(br);
      IOUtils.closeQuietly(isr);
      IOUtils.closeQuietly(bpis);
      IOUtils.closeQuietly(bis);
    }

    return new InlineHtml(charsetName, sb.toString());
  }

  public static InlineHtml extractHtmlFromMht(File mhtFile) throws ServiceApplicationException {
    StringBuilder sb = new StringBuilder();
    String charsetName = null;
    FileInputStream fis = null;
    InputStreamReader isr = null;
    BufferedReader br = null;
    InputStream is = null;
    Session mailSession = Session.getDefaultInstance(System.getProperties(), null);

    try {
      fis = new FileInputStream(mhtFile);
      MimeMessage msg = new MimeMessage(mailSession, fis);
      Object content = msg.getContent();
      if (content instanceof Multipart) {
        BodyPart bp = ((Multipart) content).getBodyPart(0);
        is = bp.getInputStream();
        charsetName = getInlineHtmlCharset(bp.getContentType());
        isr = new InputStreamReader(is, charsetName);
        br = new BufferedReader(isr);
        String line = null;
        while ((line = br.readLine()) != null) {
          sb.append(line).append(System.lineSeparator());
        }
      }
    } catch (MessagingException | IOException e) {
      throw new ServiceApplicationException(e.getMessage());
    } finally {
      IOUtils.closeQuietly(br);
      IOUtils.closeQuietly(isr);
      IOUtils.closeQuietly(is);
      IOUtils.closeQuietly(fis);
    }

    return new InlineHtml(charsetName, sb.toString());
  }

  /**
   * @param contentType
   * @return
   * @throws ServiceApplicationException
   */
  public static String getInlineHtmlCharset(String contentType) throws ServiceApplicationException {
    String result = null;

    String[] strArray = contentType.split(";");
    if (strArray.length > 1) {
      String[] fileCharset = strArray[1].split("=");
      result = fileCharset[1].replace("\"", "");
    }

    if (result == null) {
      result = StandardCharsets.UTF_8.name();
      // logger.error("inline html of mht file does not contain a valid content type.");
    }
    return result;
  }
}

class InlineHtml {

  private String charsetName;

  private String content;

  public InlineHtml(String charsetName, String content) {
    this.charsetName = charsetName;
    this.content = content;
  }

  public String getCharsetName() {
    return charsetName;
  }

  public void setCharsetName(String charsetName) {
    this.charsetName = charsetName;
  }

  public String getContent() {
    return content;
  }

  public void setContent(String content) {
    this.content = content;
  }

}