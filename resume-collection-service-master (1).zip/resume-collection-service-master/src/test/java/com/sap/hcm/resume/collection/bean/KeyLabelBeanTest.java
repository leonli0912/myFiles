package com.sap.hcm.resume.collection.bean;

import org.junit.Assert;
import org.junit.Test;


public class KeyLabelBeanTest {
  
  @Test
  public void testEquals(){
    KeyLabelBean bean1 = new KeyLabelBean();
    bean1.setAdditionalText("test");
    
    KeyLabelBean bean2 = new KeyLabelBean();
    bean2.setAdditionalText("test");
    
    Assert.assertEquals(bean1, bean2);
    
    bean1.setKey("1");
    bean2.setKey("1");
    Assert.assertEquals(bean1, bean2);
    
    bean1.setLabel("2");
    bean2.setLabel("2");
    Assert.assertEquals(bean1, bean2);
    
    Assert.assertEquals(bean1.equals(bean1), true);
    
    Assert.assertEquals(bean1.hashCode(), bean2.hashCode());
  }
  
  @Test
  public void testNotEquals(){
    KeyLabelBean bean1 = null;
    KeyLabelBean bean2 = new KeyLabelBean();
    Assert.assertNotEquals(bean1, bean2);
    
    Assert.assertNotEquals(bean2.equals(null), true);
    
    Assert.assertNotEquals(bean2, new String(""));
    
    bean1 = new KeyLabelBean();
    bean1.setKey("1");
    Assert.assertNotEquals(bean1, bean2);
        
    bean1.setLabel("test");
    Assert.assertNotEquals(bean1, bean2);
    
    bean1.setAdditionalText("test");
    Assert.assertNotEquals(bean1, bean2);
    
    bean1.setAdditionalText(null);
    bean2.setAdditionalText("test");
    Assert.assertNotEquals(bean1.equals(bean2), true);
    
    bean1.setAdditionalText("test");
    bean2.setAdditionalText("test");
    bean1.setKey(null);
    bean2.setKey("1");
    Assert.assertNotEquals(bean1.equals(bean2), true);
    
    bean1.setAdditionalText("test");
    bean2.setAdditionalText("test");
    bean1.setKey("1");
    bean2.setKey("1");
    bean1.setLabel(null);
    bean2.setLabel("test");
    Assert.assertNotEquals(bean1.equals(bean2), true);
    
    bean1.setAdditionalText("test");
    bean2.setAdditionalText("test");
    bean1.setKey("1");
    bean2.setKey("1");
    bean1.setLabel("test2");
    bean2.setLabel("test");
    Assert.assertNotEquals(bean1.equals(bean2), true);
  }
}
