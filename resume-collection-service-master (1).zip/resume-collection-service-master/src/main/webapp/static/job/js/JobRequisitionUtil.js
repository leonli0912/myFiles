sap.ui.define([], function(){
	"use strict";

  var JobRequisitionUtil = function(){
  };

  JobRequisitionUtil.prototype.getMappingItems = function(dmMappingId){
    var reqMappingURL = "job/jobreq/"+dmMappingId;
    var reqMappingModel = new sap.ui.model.json.JSONModel();
		reqMappingModel.loadData(reqMappingURL,null,false);
    var mappingEntry = reqMappingModel.getData();
    var mappingItems = [];
    if(mappingEntry){
      var mapping = mappingEntry.mapping;
      for(var i in mapping.items){
        var item = mapping.items[i];
        if(item.sfDmField){
          mappingItems.push(item);
        }
      }
    }
    return mappingItems;
  }

  JobRequisitionUtil.prototype.buildPageContent = function(oController, mappingItems, oForm){
	oForm.destroyFormContainers();
	var oContainer = new sap.ui.layout.form.FormContainer();
	
    for(var i in mappingItems){
      var item = mappingItems[i];
      
      var oElement = new sap.ui.layout.form.FormElement();

      var oLabel = new sap.m.Label({
        text:{path: 'wi18n>' + item.label},
        design:"Bold"
      });

      oElement.setLabel(oLabel);
      
      if(item.sourceField == "jobDescription"){
        var oText = new sap.m.Text({
          text:{path:"/strJobDescription"}
        });
      }else{
    	  if(item.picklist){
    		  var oText = new sap.m.Text({
    	          text:{path:"/"+item.sourceField,formatter:jQuery.proxy(oController.picklistFormatter,oController)}
    	        });
    	  }else{
			  var oText = new sap.m.Text({
				text:{path:"/"+item.sourceField}
			  });
		  }
      }

      oElement.addField(oText);
      oContainer.addFormElement(oElement);

    }
    oForm.addFormContainer(oContainer);
  }

  return JobRequisitionUtil;
});
