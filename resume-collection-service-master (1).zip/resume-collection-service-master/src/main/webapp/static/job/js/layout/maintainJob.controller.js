jQuery.sap.require("sap.m.MessageBox");
sap.ui.controller("static.job.js.layout.maintainJob", {

	_jobId : null,
	_isGrowing : false,
	_filterApplied : false,
	_sortBy : "lastModify",
	_ascOrDesc : "desc",
	_BATCH_PUBLISH : "batchPublish",
	_BATCH_DELETE : "batchDelete",
	/**
	 * Called when a controller is instantiated and its View controls (if
	 * available) are already created. Can be used to modify the View before it
	 * is displayed, to bind event handlers and do other one-time
	 * initialization.
	 *
	 * @memberOf resume-collection-service.jobList
	 */
	press : function(oEvent) {

		var rowId = oEvent.getSource().getBindingContext().getPath();
		var rows = rowId.match(/\d+/g);
		var rowNo = rows[rows.length - 1];
		var jobId = oEvent.getSource().getBindingContext().getModel().getData().jobs[rowNo].jobId;
		var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		oRouter.navTo("jobDisplay", {
			jobId : jobId,
		});
	},

	selectAllPress : function() {
		var jobList = this.getView().byId("jobList");
		var jobListItems = jobList.getItems();
		var selectedJobListItems = jobList.getSelectedItems();
		var is_same = (jobListItems.length == selectedJobListItems.length)
				&& jobListItems.every(function(element, index) {
					return element === selectedJobListItems[index];
				});
		for ( var idx in jobListItems) {
			jobList.setSelectedItem(jobListItems[idx], !is_same);
		}

	},

	clearSelected : function(){
		var jobList = this.getView().byId("jobList");
		var selectedJobListItems = jobList.getSelectedItems();
		for ( var idx in selectedJobListItems) {
			jobList.setSelectedItem(selectedJobListItems[idx], false);
		}
	},

	batchOperation : function(type) {
		var jobList = this.getView().byId("jobList");
		var selItems = jobList.getSelectedItems();
		if (selItems.length > 0) {
			var jobIdArr = [];
			for ( var idx in selItems) {
				var sPath = selItems[idx].getBindingContext().sPath;
				var rowNo = sPath.match("\\d+$")[0];
				var jobId = selItems[idx].getBindingContext().getModel().getData().jobs[rowNo].jobId;
				jobIdArr.push(jobId);
			}
			if(type === this._BATCH_PUBLISH){
				this.jobBatchPublish(jobIdArr);
			}
			else if (type === this._BATCH_DELETE){
				this.jobBatchDelete(jobIdArr);
			}

		} else {
			if(type === this._BATCH_PUBLISH){
				var selectMsg = this.translatEnumLabel("SELECT_THE_JOB_TO_PUBLISH");
			}
			else if (type === this._BATCH_DELETE){
				var selectMsg = this.translatEnumLabel("SELECT_THE_JOB_TO_DELETE");
			}

			sap.m.MessageBox.information(selectMsg, {
				styleClass : "sapUiSizeCompact"
			});
		}
	},

	onBatchPublish : function() {
		this.batchOperation(this._BATCH_PUBLISH);
	},

	onBatchDelete : function() {
		this.batchOperation(this._BATCH_DELETE);
	},

	onInit : function() {
		var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		var that = this;
		oRouter.attachRouteMatched(function(oEvent) {
			that._applyFilter();
		});
	},
	onMenuAction : function(oEvent) {
		var oItemId = oEvent.getParameter("item").getId();
		if (oItemId.search("sortWithModify") >= 0) {
			this._sortBy = "lastModify";
			this.getView().byId("menuButton").setText(
					this.getView().getModel("wi18n").getResourceBundle().getText("SORT_BY_LAST_MODIFY"));
		} else if (oItemId.search("sortWithId") >= 0) {
			this._sortBy = "externalJobId";
			this.getView().byId("menuButton").setText(
					this.getView().getModel("wi18n").getResourceBundle().getText("SORT_BY_JOB_ID"));
		}
		this._applyFilter();
	},
	ascOrDescPress : function() {
		if (this.getView().byId("ascOrDesc").getIcon() == "sap-icon://sort-ascending") {
			this._ascOrDesc = "desc";
			this.getView().byId("ascOrDesc").setIcon("sap-icon://sort-descending");
		} else {
			this._ascOrDesc = "asc";
			this.getView().byId("ascOrDesc").setIcon("sap-icon://sort-ascending");
		}
		this._applyFilter();
	},

	pressMenu : function(oEvent) {

		var rowId = oEvent.getSource().getBindingContext().getPath();
		var rows = rowId.match(/\d+/g);
		var rowNo = rows[rows.length - 1];
		_jobId = oEvent.getSource().getBindingContext().getModel().getData().jobs[rowNo].jobId;
		var oButton = oEvent.getSource();

		// create menu only once
		if (!this._menu || this._filterApplied) {
			this._menu = sap.ui.xmlfragment("static.job.js.layout.menu", this);
			this.getView().getModel().setData(oEvent.getSource().getBindingContext().getModel().getData());
			this.getView().removeDependent();
			this.getView().addDependent(this._menu);
			this._filterApplied = false;
		}
		this._menu.bindContext(rowId);
		var eDock = sap.ui.core.Popup.Dock;
		this._menu.open(this._bKeyboard, oButton, eDock.BeginTop, eDock.BeginBottom, oButton);
	},

	jobPublish : function(oEvent) {
		var that = this;
		var cfg = {
			type : 'POST',
			dataType : 'json',
			contentType : 'application/json;charset=UTF-8'
		};
		cfg.url = "job/publish?jobId=" + _jobId;
		$.ajax(cfg).success(function(data) {
			if (data && data.code === 0) {
				that._applyFilter();
			} else {
				sap.m.MessageBox.information(data.message, {
					styleClass : "sapUiSizeCompact"
				}

				);
			}
		});
	},

	jobBatchPublish : function(jobIdList) {
		var that = this;
		var cfg = {
			type : 'POST',
			data : JSON.stringify(jobIdList),
			dataType : 'json',
			contentType : 'application/json;charset=UTF-8'
		};
		cfg.url = "job/batchpublish";
		$.ajax(cfg).success(function(data) {
			if (data && data.code === 0) {
				sap.m.MessageBox.success(data.message + " " + that.translatEnumLabel("JOB_PUBLISHED_SUCCESSFULLY"), {
					styleClass : "sapUiSizeCompact",
					onClose : function(oAction) {
						if (oAction === "OK") {
							that._applyFilter();
						}
					}
				});

			} else {
				sap.m.MessageBox.information(data.message, {
					styleClass : "sapUiSizeCompact"
				}

				);
			}
		});
	},

	jobBatchDelete : function(jobIdList) {
		var that = this;
		sap.m.MessageBox.confirm(this.getView().getModel("wi18n").getResourceBundle().getText("BATCH_DELETE_MSG"), {
			onClose : function(command) {

				if (command == "OK") {
					var cfg = {
						type : 'DELETE',
						data : JSON.stringify(jobIdList),
						dataType : 'json',
						contentType : 'application/json;charset=UTF-8'
					};
					cfg.url = "job/batchdelete";
					$.ajax(cfg).success(
							function(data) {
								if (data && data.code === 0) {
									sap.m.MessageBox.success(data.message + " "
											+ that.translatEnumLabel("JOB_DELETED_SUCCESSFULLY"), {
										styleClass : "sapUiSizeCompact",
										onClose : function(oAction) {
											if (oAction === "OK") {
												that._applyFilter();
												that.clearSelected();
											}
										}
									});

								} else {
									sap.m.MessageBox.information(data.message, {
										styleClass : "sapUiSizeCompact"
									}

									);
								}
							});
				}
			}
		})
	},

	jobDelete : function() {
		var that = this;
		sap.m.MessageBox.confirm(this.getView().getModel("wi18n").getResourceBundle().getText("DELETEMSG"), {
			onClose : function(command) {

				if (command == "OK") {
					var cfg = {
						type : 'DELETE',
						dataType : 'json',
						contentType : 'application/json;charset=UTF-8'
					};
					cfg.url = "job/delete?jobId=" + _jobId;
					$.ajax(cfg).success(function(data) {
						that._applyFilter();
					});
				}
			}
		})
	},

	_applyFilter : function(oFilter, inputFilterValue) {
		var requestBody = this._getFilterRequestBody();

		// load picklist from SF
		var cfg = {
			url : "job/maintainList",
			type : 'POST',
			dataType : 'json',
			data : JSON.stringify(requestBody),
			contentType : 'application/json;charset=UTF-8'
		};

		var that = this;
		var filterList = this.getView().byId("jobList");
		filterList._oGrowingDelegate.resetToDefaultThreshold();
		filterList.setBusy(true);
		$.ajax(cfg).success(function(data) {
			that._filterApplied = true;
			filterList.setBusy(false);

			var dataModel = that.getView().getModel();
			if (dataModel == null) {
				dataModel = new sap.ui.model.json.JSONModel();
			}
			dataModel.setData(data);
			that.getView().setModel(dataModel);
		}).error(function(data) {
			filterList.setBusy(false);
		});
	},

	handleFacetFilterReset : function(oEvent) {
		var oFacetFilter = sap.ui.getCore().byId(oEvent.getParameter("id"));
		var aFacetFilterLists = oFacetFilter.getLists();
		for (var i = 0; i < aFacetFilterLists.length; i++) {
			aFacetFilterLists[i].setSelectedKeys();
		}
		var inputFilterValue = this.getView().byId("searchField").getValue();
		this._applyFilter([], inputFilterValue);
	},

	handleListClose : function(oEvent) {
		// Get the Facet Filter lists and construct a (nested)
		// filter for the binding
		var oFacetFilter = oEvent.getSource().getParent();
		var mFacetFilterLists = oFacetFilter.getLists().filter(function(oList) {
			return oList.getSelectedItems().length;
		});
		// Build the nested filter with ORs between the
		// values of each group and
		// ANDs between each group
		var oFilter = new sap.ui.model.Filter(mFacetFilterLists.map(function(oList) {
			return new sap.ui.model.Filter(oList.getSelectedItems().map(function(oItem) {
				return new sap.ui.model.Filter(oList.getKey(), "EQ", oItem.getKey());
			}), false);
		}), true);
		var inputFilterValue = this.getView().byId("searchField").getValue();
		this._applyFilter(oFilter, inputFilterValue);
	},

	showSearchResult : function(oEvent) {
		var inputFilterValue = oEvent.mParameters.query;
		var mFacetFilterLists = this.getView().byId("jobFacetFilter").getLists().filter(function(oList) {
			return oList.getSelectedItems().length;
		});

		// Build the nested filter with ORs between the
		// values of each group and
		// ANDs between each group
		var oFilter = new sap.ui.model.Filter(mFacetFilterLists.map(function(oList) {
			return new sap.ui.model.Filter(oList.getSelectedItems().map(function(oItem) {
				return new sap.ui.model.Filter(oList.getKey(), "EQ", oItem.getKey());
			}), false);
		}), true);
		this._applyFilter(oFilter, inputFilterValue);
	},

	dateFormat : function(val) {
		jQuery.sap.require("sap.ui.core.format.DateFormat");
		var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
			pattern : "yyyy-MM-dd"
		});
		return oDateFormat.format(new Date(val));
	},

	dateTimeFormat : function(val) {
		jQuery.sap.require("sap.ui.core.format.DateFormat");
		var oDateFormat = sap.ui.core.format.DateFormat.getDateTimeInstance({
			pattern : "yyyy-MM-dd HH:mm:ss"
		});
		return oDateFormat.format(new Date(val));
	},
	translatWechatLabel : function(val) {
		if (!val)
			return "";
		return this.getView().getModel("wi18n").getResourceBundle().getText(val);
	},

	translatLabel : function(val) {
		if (!val)
			return "";
		return this.getView().getModel("wi18n").getResourceBundle().getText(val);
	},
	translatEnumLabel : function(val) {
		if (!val)
			return "";
		return this.getView().getModel("wi18n").getResourceBundle().getText(val);
	},

	onPublishNewJob : function() {
		this._router = sap.ui.core.UIComponent.getRouterFor(this);
		var that = this;
		that._router.navTo("jobPublish", true);
	},

	onLoadJob : function() {
		this._router = sap.ui.core.UIComponent.getRouterFor(this);
		var that = this;
		that._router.navTo("loadJob", true);
	},

	_getFilter : function() {
		var mFacetFilterLists = this.getView().byId("jobFacetFilter").getLists().filter(function(oList) {
			return oList.getSelectedItems().length;
		});

		// Build the nested filter with ORs between the
		// values of each group and
		// ANDs between each group
		var oFilter = new sap.ui.model.Filter(mFacetFilterLists.map(function(oList) {
			return new sap.ui.model.Filter(oList.getSelectedItems().map(function(oItem) {
				return new sap.ui.model.Filter(oList.getKey(), "EQ", oItem.getKey());
			}), false);
		}), true);
		return oFilter;
	},

	listUpdateStart : function(oEvent) {

		var actual = oEvent.getParameter("actual");
		var total = oEvent.getParameter("total");

		if (actual === 0 || this._isGrowing) {
			return;
		}

		var requestBody = this._getFilterRequestBody(actual);

		// load picklist from SF
		var cfg = {
			url : "job/maintainList",
			type : 'POST',
			dataType : 'json',
			data : JSON.stringify(requestBody),
			contentType : 'application/json;charset=UTF-8'
		};

		var that = this;
		var filterList = this.getView().byId("jobList");
		this._isGrowing = true;
		$.ajax(cfg).success(function(data) {
			that._isGrowing = false;
			var deltaData = data.jobs;
			var existData = filterList.getModel().getData();
			Array.prototype.push.apply(existData.jobs, deltaData);
			filterList.getModel().setData(existData);

		}).error(function(data) {

		});
	},

	_getFilterRequestBody : function(skip, top) {
		var filterList = this.getView().byId("jobList");
		var oFilter = this._getFilter();
		var oFValue = {};
		if (oFilter.aFilters !== undefined) {
			for (var j = 0; j < oFilter.aFilters.length; j++) {
				for (var i = 0; i < oFilter.aFilters[j].aFilters.length; i++) {
					var path = oFilter.aFilters[j].aFilters[i].sPath;
					if (oFValue[path]) {
						oFValue[path].push(oFilter.aFilters[j].aFilters[i].oValue1);
					} else {
						oFValue[path] = [];
						oFValue[path].push(oFilter.aFilters[j].aFilters[i].oValue1);
					}
				}
			}
		}

		var inputFilterValue = this.getView().byId("searchField").getValue();
		inputFilterValue = encodeURI(inputFilterValue);
		var requstBody = {
			companyId : "",
			inputFilterValue : inputFilterValue,
			skip : skip | 0,
			top : top | filterList.getGrowingThreshold(),
			items : [],
			orderBy : this._sortBy + " " + this._ascOrDesc
		};
		// set up filter values
		for (key in oFValue) {
			requstBody.items.push({
				type : key,
				values : oFValue[key]
			})
		}

		return requstBody;
	}
/**
 * Similar to onAfterRendering, but this hook is invoked before the controller's
 * View is re-rendered (NOT before the first rendering! onInit() is used for
 * that one!).
 *
 * @memberOf resume-collection-service.jobList
 */
// onBeforeRendering: function() {
//
// },
/**
 * Called when the View has been rendered (so its HTML is part of the document).
 * Post-rendering manipulations of the HTML could be done here. This hook is the
 * same one that SAPUI5 controls get after being rendered.
 *
 * @memberOf resume-collection-service.jobList
 */
// onAfterRendering: function() {
//
// },
/**
 * Called when the Controller is destroyed. Use this one to free resources and
 * finalize activities.
 *
 * @memberOf resume-collection-service.jobList
 */
// onExit: function() {
//
// }
});
