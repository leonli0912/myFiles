package com.sap.hcm.resume.collection.entity;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicLong;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Service;

/** 
 * 
 * This class is to caluculate:
 * 
 * 1.  SF OData API connection Timeout count in last 1 minute
 * 2.  Database connection failure count in last 1 minute
 * 
 * **/
@Service
@ManagedResource(objectName = "com.sap.hcm.resume.collection.entity:type=ExceptionStatistics", description = "Service Exception Statistics")
public class ExceptionStatistics implements Runnable {

  private static int precision = 60; // Precision = Interval/Frequency = (60 sec * 1 min)/ 1 sec

  private static AtomicLong sfConnTimeoutCount = new AtomicLong(0);

  private static AtomicLong dbConnFailedCount = new AtomicLong(0);
  
  private static LinkedBlockingQueue<Long> sfConnTimeoutQueue = new LinkedBlockingQueue<Long>(precision);
  
  private static LinkedBlockingQueue<Long> dbConnFailedQueue = new LinkedBlockingQueue<Long>(precision);

  @Autowired
  private DataSource dataSource;
  
  private Logger logger = LoggerFactory.getLogger(ExceptionStatistics.class);
  
  public static void updateSFConnTimeoutCount() {
    long count = sfConnTimeoutCount.getAndIncrement();
    if (count > Long.MAX_VALUE-1000000000) {
      clearSFConnTimeoutCount();
    }
  }
  
  private void updateDBConnFailedCount() {
    long count = dbConnFailedCount.getAndIncrement();
    if (count > Long.MAX_VALUE-1000000000) {
        clearDBConnFailedCount();
    }
  }
  
  @ManagedAttribute(description = "SuccessFactors OData API connection failure count")
  public long getSFConnTimeoutCount() {
    long currentTotalCount = sfConnTimeoutCount.get();
    long lastTotalCount = 0;
    if (sfConnTimeoutQueue.size() == precision) {
      lastTotalCount = sfConnTimeoutQueue.peek();
    }
    return (currentTotalCount - lastTotalCount);
  }
  
  @ManagedAttribute(description = "HCP Database connection failure count")
  public long getDBConnFailedCount() {
    long currentTotalCount = dbConnFailedCount.get();
    long lastTotalCount = 0;
    if (dbConnFailedQueue.size() == precision) {
      lastTotalCount = dbConnFailedQueue.peek();
    }
    return (currentTotalCount - lastTotalCount);
  }

  public static void clearSFConnTimeoutCount() {
    sfConnTimeoutCount.set(0);
    sfConnTimeoutQueue.clear();
  }
  
  public static void clearDBConnFailedCount() {
    dbConnFailedCount.set(0);
    dbConnFailedQueue.clear();
  }
  
  private void checkDBConnection(){
    Connection conn = null;
    try {
      if(dataSource != null){
        conn = dataSource.getConnection();
        if(conn == null || conn.isClosed()){
          updateDBConnFailedCount();
          logger.error("Ooops, Database connection is not existed or closed!");
        }
      }
    } catch (SQLException e) {
      updateDBConnFailedCount();
      logger.error("Ooops, Database connection is failed!");
    } catch(Exception e){
      logger.error(e.getMessage());
    }finally{
      if(conn != null){
        try {
          conn.close();
        } catch (SQLException e) {
          e.printStackTrace();
        }
      }
    }
  }

  @Override
  public void run() {
    if(sfConnTimeoutQueue.size() == precision) {
      sfConnTimeoutQueue.poll();
      sfConnTimeoutQueue.offer(sfConnTimeoutCount.get());
    } else {
      sfConnTimeoutQueue.offer(sfConnTimeoutCount.get());
    }
    
    checkDBConnection();
    
    if(dbConnFailedQueue.size() == precision){
      dbConnFailedQueue.poll();
      dbConnFailedQueue.offer(dbConnFailedCount.get());
    }else{
      dbConnFailedQueue.offer(dbConnFailedCount.get());
    }
  }
}

