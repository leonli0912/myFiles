package com.sap.hcm.resume.collection.entity.view;

import java.io.Serializable;
import java.util.List;

import com.sap.hcm.resume.collection.integration.bean.ApplyDataModelMappingItem;

public class JobApplyMappingVO implements Serializable{
    


    /**
   * serialVersionUID
   */
  private static final long serialVersionUID = -3599139115718362763L;

    private Long id;
    
    private String mappingName;
    
    private String targetSystem;
        
    private List<ApplyDataModelMappingItem> itemList;
    
    private String createBy;

    /**
     * @return the id
     */
    public Long getId() {
        return id;
    }

    /**
     * @param id the id to set
     */
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * @return the mappingName
     */
    public String getMappingName() {
        return mappingName;
    }

    /**
     * @param mappingName the mappingName to set
     */
    public void setMappingName(String mappingName) {
        this.mappingName = mappingName;
    }

    /**
     * @return the targetSystem
     */
    public String getTargetSystem() {
        return targetSystem;
    }

    /**
     * @param targetSystem the targetSystem to set
     */
    public void setTargetSystem(String targetSystem) {
        this.targetSystem = targetSystem;
    }

    public List<ApplyDataModelMappingItem> getItemList() {
      return itemList;
    }

    public void setItemList(List<ApplyDataModelMappingItem> itemList) {
      this.itemList = itemList;
    }

    public String getCreateBy() {
      return createBy;
    }

    public void setCreateBy(String createBy) {
      this.createBy = createBy;
    }
    

}
