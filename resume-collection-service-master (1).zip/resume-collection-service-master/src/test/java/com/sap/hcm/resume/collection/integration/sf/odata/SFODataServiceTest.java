package com.sap.hcm.resume.collection.integration.sf.odata;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import javax.ws.rs.HttpMethod;

import org.apache.commons.io.IOUtils;
import org.apache.olingo.odata2.api.edm.Edm;
import org.apache.olingo.odata2.api.edm.EdmEntityContainer;
import org.apache.olingo.odata2.api.edm.EdmEntitySet;
import org.apache.olingo.odata2.api.ep.EntityProvider;
import org.apache.olingo.odata2.api.ep.EntityProviderException;
import org.apache.olingo.odata2.api.ep.EntityProviderReadProperties;
import org.apache.olingo.odata2.api.ep.EntityProviderReadProperties.EntityProviderReadPropertiesBuilder;
import org.apache.olingo.odata2.api.ep.entry.ODataEntry;
import org.apache.olingo.odata2.api.ep.feed.ODataFeed;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.test.util.ReflectionTestUtils;

import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.sf.bean.QueryInfo;
import com.sap.hcm.resume.collection.integration.sf.bean.QueryOptionEnum;

@RunWith(PowerMockRunner.class)
@PrepareForTest({ SFODataService.class, EntityProvider.class, EntityProviderReadProperties.class,
    EntityProviderReadPropertiesBuilder.class })
public class SFODataServiceTest {
  private SFAuthentication auth = null;

  private Params params = null;

  private SFODataService spy = null;

  private InputStream in = null;

  private InputStream errIn = null;

  private HttpURLConnection huc = null;

  @Rule
  ExpectedException thrown = ExpectedException.none();

  @Before
  public void setup() {
    spy = PowerMockito.spy(new SFODataService());
    auth = PowerMockito.mock(SFAuthentication.class);
    params = PowerMockito.mock(Params.class);
    ReflectionTestUtils.setField(spy, "auth", auth);
    ReflectionTestUtils.setField(spy, "params", params);
    // mock authentication
    PowerMockito.when(params.getCompanyId()).thenReturn("testCompanyId");
    PowerMockito.when(auth.getServiceURL()).thenReturn("http://testhost/odata/v2/");
    PowerMockito.when(auth.getAuthentication()).thenReturn("testAuthString");
  }

  @After
  public void cleanup() {
    IOUtils.closeQuietly(in);
    IOUtils.closeQuietly(errIn);
    if (huc != null) {
      huc.disconnect();
    }
  }

  private void prepareEdmMockData() throws Exception {
    // mock http connection for edm
    String edmUrl = "http://testhost/odata/v2/$metadata";
    URL url = PowerMockito.mock(URL.class);
    PowerMockito.whenNew(URL.class).withArguments(edmUrl).thenReturn(url);
    huc = PowerMockito.mock(HttpURLConnection.class);
    PowerMockito.when(url.openConnection()).thenReturn(huc);
    PowerMockito.when(huc.getResponseCode()).thenReturn(200);
    in = PowerMockito.mock(InputStream.class);
    PowerMockito.when(huc.getInputStream()).thenReturn(in);
  }

  @Test
  public void testGetEdmSuccess() throws Exception {
    prepareEdmMockData();
    // mock olingo method and edm
    Edm edm = PowerMockito.mock(Edm.class);
    PowerMockito.mockStatic(EntityProvider.class);
    PowerMockito.when(EntityProvider.readMetadata(in, false)).thenReturn(edm);

    Edm testEdm = spy.getEdm();
    Assert.assertEquals(edm, testEdm);
  }

  @Test
  public void testGetEdmWithEntityProviderException() throws Exception {
    prepareEdmMockData();
    // mock olingo method and edm
    PowerMockito.mockStatic(EntityProvider.class);
    EntityProviderException ex = PowerMockito.mock(EntityProviderException.class);
    PowerMockito.when(ex.getMessage()).thenReturn("TestExMessage");
    PowerMockito.when(EntityProvider.readMetadata(in, false)).thenThrow(ex);

    thrown.expect(ServiceApplicationException.class);
    thrown.expectMessage("TestExMessage");
    spy.getEdm();
  }

  @Test
  public void testGetEdmWithConnResponse404() throws Exception {
    prepareEdmMockData();
    // mock http connection response code and error InputStream
    PowerMockito.when(huc.getResponseCode()).thenReturn(404);
    errIn = PowerMockito.mock(InputStream.class);
    PowerMockito.when(huc.getErrorStream()).thenReturn(errIn);

    thrown.expect(RuntimeException.class);
    thrown.expectMessage(org.hamcrest.core.StringStartsWith.startsWith("Http Connection failed with status"));
    spy.getEdm();
  }

  @Test
  public void testReadEntrySuccess() throws Exception {
    String contentType = SFODataService.APPLICATION_JSON;
    String testEntitySetName = "testEntitySetName";
    String testKeyValue = "testKeyValue";
    String expectedQueryStr = "http://testhost/odata/v2/testEntitySetName('testKeyValue')";
    // mock http connection
    huc = PowerMockito.mock(HttpURLConnection.class);
    PowerMockito.doReturn(huc).when(spy, "connect", expectedQueryStr, contentType, HttpMethod.GET);
    in = PowerMockito.mock(InputStream.class);
    PowerMockito.when(huc.getInputStream()).thenReturn(in);
    // mock edm data
    Edm edm = PowerMockito.mock(Edm.class);
    EdmEntityContainer container = PowerMockito.mock(EdmEntityContainer.class);
    EdmEntitySet entitySet = PowerMockito.mock(EdmEntitySet.class);
    PowerMockito.doReturn(edm).when(spy, "getEdm");
    PowerMockito.when(edm.getDefaultEntityContainer()).thenReturn(container);
    PowerMockito.when(container.getEntitySet(testEntitySetName)).thenReturn(entitySet);
    // mock olingo provider
    ODataEntry expectedResult = PowerMockito.mock(ODataEntry.class);
    EntityProviderReadPropertiesBuilder builder = PowerMockito.mock(EntityProviderReadPropertiesBuilder.class);
    EntityProviderReadProperties props = PowerMockito.mock(EntityProviderReadProperties.class);
    PowerMockito.mockStatic(EntityProvider.class);
    PowerMockito.mockStatic(EntityProviderReadProperties.class);
    PowerMockito.mockStatic(EntityProviderReadPropertiesBuilder.class);
    PowerMockito.when(EntityProviderReadProperties.init()).thenReturn(builder);
    PowerMockito.when(builder.build()).thenReturn(props);
    PowerMockito.when(EntityProvider.readEntry(contentType, entitySet, in, props)).thenReturn(expectedResult);

    // call real method
    QueryInfo testQueryInfo = new QueryInfo(testEntitySetName, testKeyValue);
    ODataEntry result = spy.readEntry(contentType, testQueryInfo);
    Assert.assertEquals(expectedResult, result);
  }

//  @Test
  public void testReadFeedSuccess() throws Exception {
    String contentType = SFODataService.APPLICATION_JSON;
    String testEntitySetName = "testEntitySetName";
    String testKeyValue = "testKeyValue";
    String testNavPropName = "testNavPropName";
    String testNavEntitySetName = "testNavEntitySetName";
    String expectedQueryStr = "http://testhost/odata/v2/testEntitySetName('testKeyValue')/testNavPropName?$top=5&$skip=5";
    // mock http connection
    huc = PowerMockito.mock(HttpURLConnection.class);
    PowerMockito.doReturn(huc).when(spy, "connect", expectedQueryStr, contentType, HttpMethod.GET);
    in = PowerMockito.mock(InputStream.class);
    PowerMockito.when(huc.getInputStream()).thenReturn(in);
    // mock edm data
    Edm edm = PowerMockito.mock(Edm.class);
    EdmEntityContainer container = PowerMockito.mock(EdmEntityContainer.class);
    EdmEntitySet entitySet = PowerMockito.mock(EdmEntitySet.class);
    PowerMockito.doReturn(edm).when(spy, "getEdm");
    PowerMockito.when(edm.getDefaultEntityContainer()).thenReturn(container);
    PowerMockito.when(container.getEntitySet(testEntitySetName)).thenReturn(entitySet);
    // mock olingo provider
    ODataFeed expectedResult = PowerMockito.mock(ODataFeed.class);
    EntityProviderReadPropertiesBuilder builder = PowerMockito.mock(EntityProviderReadPropertiesBuilder.class);
    EntityProviderReadProperties props = PowerMockito.mock(EntityProviderReadProperties.class);
    PowerMockito.mockStatic(EntityProvider.class);
    PowerMockito.mockStatic(EntityProviderReadProperties.class);
    PowerMockito.mockStatic(EntityProviderReadPropertiesBuilder.class);
    PowerMockito.when(EntityProviderReadProperties.init()).thenReturn(builder);
    PowerMockito.when(builder.build()).thenReturn(props);
    PowerMockito.when(EntityProvider.readFeed(contentType, entitySet, in, props)).thenReturn(expectedResult);

    // call real method
    QueryInfo testQueryInfo = new QueryInfo(testEntitySetName, testKeyValue, testNavPropName, testNavEntitySetName);
    testQueryInfo.addQueryOption(QueryOptionEnum.TOP, "5");
    testQueryInfo.addQueryOption(QueryOptionEnum.SKIP, "5");
    ODataFeed result = spy.readFeed(contentType, testQueryInfo);
    Assert.assertEquals(expectedResult, result);
  }

//  @Test
  public void testReadFeedAsStringSuccess() throws Exception {
    String contentType = SFODataService.APPLICATION_JSON;
    String testEntitySetName = "testEntitySetName";
    String testKeyValue = "testKeyValue";
    String testNavPropName = "testNavPropName";
    String testNavEntitySetName = "testNavEntitySetName";
    String expectedQueryStr = "http://testhost/odata/v2/testEntitySetName('testKeyValue')/testNavPropName?$top=5&$skip=5";
    String expectedResult = "expectedResult";
    // mock http connection
    huc = PowerMockito.mock(HttpURLConnection.class);
    PowerMockito.doReturn(huc).when(spy, "connect", expectedQueryStr, contentType, HttpMethod.GET);
    in = new ByteArrayInputStream(expectedResult.getBytes(StandardCharsets.UTF_8));
    PowerMockito.when(huc.getInputStream()).thenReturn(in);

    // call real method
    QueryInfo testQueryInfo = new QueryInfo(testEntitySetName, testKeyValue, testNavPropName, testNavEntitySetName);
    testQueryInfo.addQueryOption(QueryOptionEnum.TOP, "5");
    testQueryInfo.addQueryOption(QueryOptionEnum.SKIP, "5");
    String result = spy.readFeedAsString(contentType, testQueryInfo);
    Assert.assertEquals(expectedResult, result);
  }

  @Test
  public void testCreateEntrySuccess() throws Exception {
    // TODO
  }

  @Test
  public void testReplaceEntrySuccess() throws Exception {
    // TODO
  }
}
