package com.sap.hcm.resume.collection.integration.job51;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.context.MessageSource;

import com.sap.hcm.resume.collection.entity.view.CandidateBgCertificateVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgEducationVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgLanguageVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgWorkExprVO;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileExtVO;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.util.CandidateDateUtil;
import com.sap.hcm.resume.collection.util.CandidateFileUtil;
import com.sap.hcm.resume.collection.util.MappingUtil;

public class EnglishDocumentParser51 extends AbstractDocumentParser51 {

  public EnglishDocumentParser51(MessageSource messageSource) {
    super(messageSource);
  }

  @Override
  public CandidateProfileVO parseProfile(CandidateProfileVO candidateProfileVO, Document content)
      throws ServiceApplicationException {
    CandidateProfileExtVO extProfile = new CandidateProfileExtVO();
    try {

      // name, phone, email, gender, dob, residence
      Elements basicInfo = content.getElementsByClass("box1");
      if (basicInfo.size() > 0) {
        Element basic1 = basicInfo.get(0);

        String name = basic1.getElementsByClass("name").text();
        if (!StringUtils.isEmpty(name)) {
          String[] nameParts = name.split(",");
          if (nameParts.length == 1) {
            candidateProfileVO.setFirstName(nameParts[0]);
          }
          if (nameParts.length == 2) {
            candidateProfileVO.setFirstName(nameParts[1]);
            candidateProfileVO.setLastName(nameParts[0]);
          }
          candidateProfileVO.setMiddleName("");
        }

        Elements info = basic1.select(">tbody table>tbody");
        Elements rows = info.get(0).children();
        if (rows != null && rows.size() > 2) {
          Element phoneAndEmailRow = rows.get(1);
          String cellPhone = phoneAndEmailRow.child(1).text();
          candidateProfileVO.setCellPhone(cellPhone);
          String email = phoneAndEmailRow.child(2).text();
          candidateProfileVO.setPrimaryEmail(email);
          candidateProfileVO.setContactEmail(email);

          String genderRowText = rows.get(2).text();
          String[] genderRows = genderRowText.split("\\|");
          if (genderRows.length > 2) {
            String gender = genderRows[0];
            if ("female".equalsIgnoreCase(gender)) {
              candidateProfileVO.setGender("Female");
            } else {
              candidateProfileVO.setGender("Male");
            }

            String ageRaw = genderRows[1];
            String dob = this.calculateDob(ageRaw);
            candidateProfileVO.setDateOfBirth(dob);

            String residenceRaw = genderRows[2];
            String residence = residenceRaw.replace("Living in", "").trim();
            candidateProfileVO.setResidence(residence);
          }
        }
      }

      // get basic info
      Element basicInfoBox = this.getBlock("Basic Info.", content);
      if (basicInfoBox != null) {
        String basicInfoRaw = CandidateFileUtil.formatHtmlText(basicInfoBox.html(), false, false);
        String[] rows = basicInfoRaw.split("\\n");
        for (int i = 0; i < rows.length; i++) {
          if (rows[i].contains("Hukou")) {
            String hukou = this.getColonRightValue(rows[i]);
            candidateProfileVO.setHousehold(hukou);
          }
          if (rows[i].contains("Marital")) {
            String maritalSts = this.getColonRightValue(rows[i]);
            if ("Married".equalsIgnoreCase(maritalSts)) {
              candidateProfileVO.setMarriage("Y");
            } else {
              candidateProfileVO.setMarriage("N");
            }
          }
          if (rows[i].startsWith("Address")) {
            String addressRaw = this.getColonRightValue(rows[i]);
            if (addressRaw.indexOf("(") >= 0) {
              String address = MappingUtil.matchSingle("[^\\(]+", addressRaw);
              candidateProfileVO.setAddress(address);

              String zipCodeRaw = MappingUtil.matchSingle("(?<=\\()[\\s\\S]+(?=\\))", addressRaw);
              String zipCode = this.getColonRightValue(zipCodeRaw);
              candidateProfileVO.setZipcode(zipCode);
            } else {
              candidateProfileVO.setAddress(addressRaw);
            }
          }
        }
      }

    } catch (Exception e) {
      throw new ServiceApplicationException("Profile parse error" + e.getMessage());
    }
    candidateProfileVO.setExtProfile(extProfile);
    return candidateProfileVO;
  }

  @Override
  public CandidateProfileVO parseBackgroundWorkExp(CandidateProfileVO candidateProfileVO, Document content)
      throws ServiceApplicationException {
    List<CandidateBgWorkExprVO> candidateBgWorkExprVOList = new ArrayList<CandidateBgWorkExprVO>();
    try {
      Element block = this.getBlock("Work Experience", content);
      if (block != null) {
        Element tbodyElement = block.select(">tbody table>tbody").first();
        Elements workExpList = tbodyElement.children();

        for (Element element : workExpList) {
          CandidateBgWorkExprVO candidateBgWorkExprVO = new CandidateBgWorkExprVO();
          String workExp = CandidateFileUtil.formatHtmlText(element.html(), false, false);
          String regex = "\\d{4}/\\d{1,2}-(\\d{4}/\\d{1,2}|Present)";
          String date = MappingUtil.matchSingle(regex, workExp);
          String[] dates = date.split("-");
          String startDate = CandidateDateUtil.formatDate("yyyy/MM", "yyyy/MM/dd", dates[0]);
          candidateBgWorkExprVO.setStartDate(startDate);
          if (dates[1].equals("Present")) {
            candidateBgWorkExprVO.setEndDate("NOW");
            candidateBgWorkExprVO.setIsPresent(true);
          } else {
            String endDate = CandidateDateUtil.formatDate("yyyy/MM", "yyyy/MM/dd", dates[1]);
            candidateBgWorkExprVO.setEndDate(endDate);
            candidateBgWorkExprVO.setIsPresent(false);
          }
          Elements strongElements = element.getElementsByTag("strong");
          String jobTitle = strongElements.get(0).text();
          candidateBgWorkExprVO.setJobTitle(jobTitle);
          Elements depElement = strongElements.get(0).parent().children();
          for (int i = 0; i < depElement.size(); i++) {
            if ("|".equals(depElement.get(i).text())) {
              candidateBgWorkExprVO.setDepartment(depElement.get(i + 1).text());
            }
          }
          regex = "(?<=\\d{4}/\\d{1,2}.{0,300}(\r\n|\n))\\S*?(?=\\[)";
          String employer = MappingUtil.matchSingle(regex, workExp);
          candidateBgWorkExprVO.setEmployer(employer);
          if (candidateBgWorkExprVO.getIsPresent() != null && candidateBgWorkExprVO.getIsPresent() == true) {
            candidateBgWorkExprVO.setPresentEmployer(employer);
          }

          regex = "(?<=" + employer + ".{0,100}(\r\n|\n)).*";
          String employerInfoLine = MappingUtil.matchSingle(regex, workExp);
          if (!employerInfoLine.contains("Description")) {
            if (!StringUtils.isEmpty(employerInfoLine) && employerInfoLine.contains("|")) {
              String[] employerInfoList = employerInfoLine.split("\\|");
              String employerInfo = employerInfoList[0];
              regex = "\\d+\\speople";
              String num = MappingUtil.matchSingle(regex, employerInfo);
              if (StringUtils.isEmpty(num)) {
                candidateBgWorkExprVO.setBusinessType(employerInfoList[0]);
              }
            } else {
              regex = "\\d+\\speople";
              String num = MappingUtil.matchSingle(regex, employerInfoLine);
              if (!StringUtils.isEmpty(num)) {
                candidateBgWorkExprVO.setBusinessType(employerInfoLine);
              }
            }
          }
          regex = "(?<=Description:).*";
          String description = MappingUtil.matchSingle(regex, workExp).trim();
          candidateBgWorkExprVO.setDescription(description);
          regex = "(?<=Leaving Reason:).*";
          String exitReason = MappingUtil.matchSingle(regex, workExp).trim();
          if (!StringUtils.isEmpty(exitReason)) {
            candidateBgWorkExprVO.setExitReason(exitReason);
          }
          candidateBgWorkExprVOList.add(candidateBgWorkExprVO);
        }
      }
      candidateProfileVO.setWorkExprs(candidateBgWorkExprVOList);
    } catch (Exception e) {
      throw new ServiceApplicationException("Profile work experience parse error" + e.getMessage());
    }

    return candidateProfileVO;
  }

  @Override
  public CandidateProfileVO parseBackgroundEducation(CandidateProfileVO candidateProfileVO, Document content)
      throws ServiceApplicationException {
    List<CandidateBgEducationVO> candidateBgEducationVOList = new ArrayList<CandidateBgEducationVO>();
    try {
      Element block = this.getBlock("Education", content);
      if (block != null) {
        Element tbodyElement = block.select(">tbody table>tbody").first();
        Elements educationList = tbodyElement.children();
        for (Element element : educationList) {
          CandidateBgEducationVO candidateBgEducationVO = new CandidateBgEducationVO();
          String education = CandidateFileUtil.formatHtmlText(element.html(), false, false);
          String regex = "\\d{4}/\\d{1,2}-(\\d{4}/\\d{1,2}|Present)";
          String date = MappingUtil.matchSingle(regex, education);
          String[] dates = date.split("-");
          String startDate = CandidateDateUtil.formatDate("yyyy/MM", "yyyy/MM/dd", dates[0]);
          candidateBgEducationVO.setStartDate(startDate);
          if (dates[1].equals("Present")) {
            String endDate = CandidateDateUtil.formatDate2String(new Date(), "yyyy/MM/dd");
            candidateBgEducationVO.setEndDate(endDate);
          } else {
            String endDate = CandidateDateUtil.formatDate("yyyy/MM", "yyyy/MM/dd", dates[1]);
            candidateBgEducationVO.setEndDate(endDate);
          }
          Elements strongElements = element.getElementsByTag("strong");
          String school = strongElements.get(0).text();
          candidateBgEducationVO.setSchool(school);
          regex = "(?<=" + school + ".{0,100}(\r\n|\n)).*";
          String schoolInfoLine = MappingUtil.matchSingle(regex, education);
          if (!StringUtils.isEmpty(schoolInfoLine) && schoolInfoLine.contains("|")) {
            String[] schoolInfoList = schoolInfoLine.split("\\|");
            candidateBgEducationVO.setDegree(schoolInfoList[0]);
            candidateBgEducationVO.setMajor(schoolInfoList[1]);
          }
          candidateBgEducationVOList.add(candidateBgEducationVO);
        }
        candidateProfileVO.setEducation(candidateBgEducationVOList);
      }
    } catch (Exception e) {
      throw new ServiceApplicationException("Profile education parse error" + e.getMessage());
    }
    return candidateProfileVO;
  }

  @Override
  public CandidateProfileVO parseBackgroundLanguage(CandidateProfileVO candidateProfileVO, Document content)
      throws ServiceApplicationException {
    List<CandidateBgLanguageVO> candidateBgLanguageVOList = new ArrayList<CandidateBgLanguageVO>();
    try {
      Element block = this.getBlock("Skills & Speciality", content);
      if (block != null) {
        Elements tbodyElements = block.select(">tbody tr").get(1).child(0).children();
        for (int i = 0; i < tbodyElements.size(); i++) {
          if (tbodyElements.get(i).text().toString().contains("Skills/Languages")) {
            Elements languageTable = tbodyElements.get(i).select(">tbody table>tbody").get(0).getElementsByTag("table");
            for (int j = 0; j < languageTable.size(); j++) {
              CandidateBgLanguageVO candidateBgLanguageVO = new CandidateBgLanguageVO();
              String language = languageTable.get(j).getElementsByTag("strong").text();
              if (!StringUtils.isEmpty(language)) {
                candidateBgLanguageVO.setName(language);
                String languageText = CandidateFileUtil.formatHtmlText(languageTable.get(j).html(), false, false);
                String fluency = languageText.replace(language, "").trim();
                candidateBgLanguageVO.setReadingProf(fluency);
                candidateBgLanguageVO.setSpeakingProf(fluency);
                candidateBgLanguageVO.setWritingProf(fluency);
                candidateBgLanguageVOList.add(candidateBgLanguageVO);
              }
            }
          }
        }
      }
      candidateProfileVO.setLanguages(candidateBgLanguageVOList);
    } catch (Exception e) {
      throw new ServiceApplicationException("Profile language parse error" + e.getMessage());
    }

    return candidateProfileVO;
  }

  @Override
  public CandidateProfileVO parseBackgroundCertificate(CandidateProfileVO candidateProfileVO, Document content)
      throws ServiceApplicationException {
    List<CandidateBgCertificateVO> candidateBgCertificateVOList = new ArrayList<CandidateBgCertificateVO>();
    try {
      Element block = this.getBlock("Skills & Speciality", content);
      if (block != null) {
        Elements tbodyElements = block.select(">tbody tr").get(1).child(0).children();
        for (int i = 0; i < tbodyElements.size(); i++) {
          if (tbodyElements.get(i).text().toString().contains("Certifications")) {
            Elements certificateTable = tbodyElements.get(i).select(">tbody").get(0).getElementsByTag("table");
            for (int j = 0; j < certificateTable.size(); j++) {
              CandidateBgCertificateVO candidateBgCertificateVO = new CandidateBgCertificateVO();
              String certificate = certificateTable.get(j).getElementsByTag("strong").text();
              candidateBgCertificateVO.setName(certificate);
              String certificateText = CandidateFileUtil.formatHtmlText(certificateTable.get(j).html(), false, false);
              String regex = "\\d{4}/\\d{1,2}";
              String date = MappingUtil.matchSingle(regex, certificateText);
              if (!StringUtils.isEmpty(date)) {
                candidateBgCertificateVO.setStartDate(CandidateDateUtil.formatDate("yyyy/MM", "yyyy/MM/dd", date));
                candidateBgCertificateVO.setEndDate(CandidateDateUtil.formatDate("yyyy/MM", "yyyy/MM/dd", date));
              }
              regex = "(?<=\\().*(?=\\))";
              String score = MappingUtil.matchSingle(regex, certificateText);
              if (!StringUtils.isEmpty(score)) {
                candidateBgCertificateVO.setScore(score);
              }
              candidateBgCertificateVOList.add(candidateBgCertificateVO);
            }
          }
        }
      }
      candidateProfileVO.setCertificates(candidateBgCertificateVOList);
    } catch (Exception e) {
      throw new ServiceApplicationException("Profile certificate parse error with: " + e.getMessage());
    }
    return candidateProfileVO;
  }

}
