sap.ui.define([
               'sap/ui/core/mvc/Controller',
               'sap/m/MessageBox',
               'static/js/ColorPicker'
             ], function(Controller, MessageBox, ColorPicker){

		var companyMaintainController = Controller.extend("static.js.layout.companyMaintain",{

			_company_info : "company/info",

			_company_logo_upload : "photo/picture/upload?_id=logo",

			_company_twoDimension_upload : "photo/picture/upload?_id=twoDimension",

			_company_info_save : "company/save",

			_company_logo_remove : "company/logo/remove",

			_sample_apply_status_mapping : "static/model/apply_status_mapping_template.json",

			/**
			 * Called when a controller is instantiated and its View controls (if
			 * available) are already created. Can be used to modify the View before it
			 * is displayed, to bind event handlers and do other one-time
			 * initialization.
			 *
			 * @memberOf static.js.layout.templateConfig
			 */
			onInit : function() {

				this.loadCompanyInfo();
				this.getView().byId("logoUploader").setUploadUrl(
						this._company_logo_upload + "&height=100&width=200&sizeLimit=true");
				this.getView().byId("twoDimensionUploader").setUploadUrl(
						this._company_twoDimension_upload + "&sizeLimit=false");

				this.getView().byId("addMappingLink")
						.setHref("import?from=cmpinfocan#/mappings");
				this.getView().byId("addReqMappingLink").setHref(
						"import?from=cmpinfojob#/mappings");
				this.getView().byId("addJobApplicationMappingLink").setHref(
						"import#/mappings/app_new");
				this.getView().byId("companyInfoChangeHistoryLink").setHref(
						"import#/companyInfoChangeLog");
				this.getView().byId("jobSyncHistoryLink").setHref(
				"import#/jobInfoSyncLog");
				// attach handlers for validation errors
				var that = this;
				sap.ui.getCore().attachValidationError(function (evt) {
					var control = evt.getParameter("element");
					if(control && control.setValueState){
						control.setValueState("Error");
					}
				});

				sap.ui.getCore().attachValidationSuccess(function (evt) {
					var control = evt.getParameter("element");
					if(control && control.setValueState){
						control.setValueState("None");
					}
				});
			},

			handleUploadComplete : function(oEvent) {
				this.getView().byId("portrait").setBusy(false);
				//var rsp = oEvent.getParameter("response");
				var rsp = JSON.parse(oEvent.getParameter("responseRaw"));
					if (rsp) {
						var code = rsp.code;
						if (code == 0) {
							var imageData = rsp.message;
							var viewData = this.getView().getModel().getData();
							viewData.logoId = "photo/temp/" + imageData + "?random=" + this.generateRandomValue();
							this.getView().getModel().setData(viewData);
						}
					}

			},

			doLogoUpload : function(oEvent) {
				this.getView().byId("portrait").setBusy(true);
			},

			twoDimensionUploadComplete : function(oEvent) {
				this.getView().byId("twoDimension").setBusy(false);
				var rsp = JSON.parse(oEvent.getParameter("responseRaw"));
					if (rsp) {
						var code = rsp.code;
						if (code == 0) {
							var imageData = rsp.message;
							var viewData = this.getView().getModel().getData();
							viewData.twoDimensionCode = "photo/temp/" + imageData + "?random=" + this.generateRandomValue();
							this.getView().getModel().setData(viewData);
						}
					}

			},

			doTwoDimensionUpload : function(oEvent) {
				this.getView().byId("twoDimension").setBusy(true);
			},

			loadCompanyInfo : function() {
				var jsonModel = new sap.ui.model.json.JSONModel(this._company_info);
				this.getView().setModel(jsonModel);
				jsonModel.attachRequestCompleted(function(){
					var oData = jsonModel.getData();
					if(oData && !oData.triggerExpression){
						oData.triggerExpression = "0 0 0 * * ?";
						jsonModel.setData(oData);
					}
				})
			},

			displayImage : function(val){
				if(val){
					val = "" + val;
					if(val.match(/^\d+$/)){
						return "photo/" + val + "?random=" + this.generateRandomValue();
					}else{
						return val;
					}
				}else{
					return "static/img/image_placeholder.png";
				}
			},
			loadJobStatusSetting : function(locale) {
				this.getView().byId("JobStatusList").setBusy(true);
				var jobStatusPickListNameModel = new sap.ui.model.json.JSONModel("sf/picklistName?propName="
						+ "status" + "&entityTypeName=" + "JobRequisition");
				var that = this;

				jobStatusPickListNameModel.attachRequestCompleted(function() {

					if(jobStatusPickListNameModel.getData().code == -1005){
						that.getView().byId("JobStatusList").setBusy(false);
						var errorMsg = jobStatusPickListNameModel.getData().message;
						that.alertMsg(errorMsg);
					}else{
						var jobStatusPickListName = jobStatusPickListNameModel.getData().message;
						var jobStatusModel = new sap.ui.model.json.JSONModel("sf/picklistOptions?"
								+ "picklist=" + jobStatusPickListName + "&locale=" + locale);

						jobStatusModel.attachRequestCompleted(function() {
							var jobStatusData = jobStatusModel.getData();
							var _status_id_list = new Array();
							for (var idx = jobStatusData.length - 1; idx >= 0; idx--) {
								if ($.inArray(jobStatusData[idx].optionId, _status_id_list) > -1) {
									jobStatusData.splice(idx, 1);
								} else {
									_status_id_list.push(jobStatusData[idx].optionId);
								}
							}

							jobStatusModel.getData().push({optionId:"EMPTY",label:that.translateText("LB_COMPANY_INFO_JOB_STATUS_EMPTY")});

							var selectedJobStatusModel = new sap.ui.model.json.JSONModel("company/jobStatusList");

							that.getView().byId("JobStatusList").setModel(jobStatusModel, "jbsList");
							selectedJobStatusModel.attachRequestCompleted(function() {
								var selectedJobStatusData = selectedJobStatusModel.getData();
								if (selectedJobStatusData.code == 0) {
									var JobStatusArray = selectedJobStatusData.message.split(",");

									var listCtrl = that.getView().byId("JobStatusList");
									var itemList = listCtrl.getItems();
									for (idx in itemList) {
										if ($.inArray(itemList[idx].getName(), JobStatusArray) > -1) {
											itemList[idx].setSelected(true);
										}else{
											itemList[idx].setSelected(false);
										}
									}
								}
								that.getView().byId("JobStatusList").setBusy(false);
							});
						});
					}

				});

			},

			goToHome : function() {
				location.href=g_context_path + "index";
			},

			_validateCronExpression : function(expression) {
				var exItems = expression.split(" ");
				if (exItems.length < 6) {
					return false;
				}
				// seconds
				var seconds = exItems[0];
				var secondsItems = null;
				if (seconds != "*") {
					if (seconds.indexOf(",") >= 0) {
						secondsItems = seconds.split(",");
					} else if (seconds.indexOf("-") >= 0) {
						secondsItems = seconds.split("-");
					} else if (seconds.indexOf("/") >= 0) {
						secondsItems = seconds.split("/");
					}

					if (secondsItems != null) {
						if (secondsItems.length != 2) {
							return false;
						}
						if (!(/[0-9]/.test(secondsItems[0])) || !(/[0-9]/.test(secondsItems[1]))) {
							return false;
						}
						if (parseInt(secondsItems[0]) < 0 || parseInt(secondsItems[0]) > 59) {
							return false;
						}
						if (parseInt(secondsItems[1]) < 0 || parseInt(secondsItems[1]) > 59) {
							return false;
						}
					} else {
						if (!(/[0-9]/.test(seconds))) {
							return false;
						}
						if (parseInt(seconds) < 0 || parseInt(seconds) > 59) {
							return false;
						}
					}
				}

				// minutes
				var minutes = exItems[1];
				var minutesItems = null;
				if (minutes != "*") {
					if (minutes.indexOf(",") >= 0) {
						minutesItems = minutes.split(",");
					} else if (minutes.indexOf("-") >= 0) {
						minutesItems = minutes.split("-");
					} else if (minutes.indexOf("/") >= 0) {
						minutesItems = minutes.split("/");
					}

					if (minutesItems != null) {
						if (minutesItems.length != 2) {
							return false;
						}
						if (!(/[0-9]/.test(minutesItems[0])) || !(/[0-9]/.test(minutesItems[1]))) {
							return false;
						}
						if (parseInt(minutesItems[0]) < 0 || parseInt(minutesItems[0]) > 59) {
							return false;
						}
						if (parseInt(minutesItems[1]) < 0 || parseInt(minutesItems[1]) > 59) {
							return false;
						}
					} else {
						if (!(/[0-9]/.test(minutes))) {
							return false;
						}
						if (parseInt(minutes) < 0 || parseInt(minutes) > 59) {
							return false;
						}
					}
				}

				// hours
				var hours = exItems[2];
				var hoursItems = null;
				if (hours != "*") {
					if (hours.indexOf(",") >= 0) {
						hoursItems = hours.split(",");
					} else if (hours.indexOf("-") >= 0) {
						hoursItems = hours.split("-");
					} else if (hours.indexOf("/") >= 0) {
						hoursItems = hours.split("/");
					}

					if (hoursItems != null) {
						if (hoursItems.length != 2) {
							return false;
						}
						if (!(/[0-9]/.test(hoursItems[0])) || !(/[0-9]/.test(hoursItems[1]))) {
							return false;
						}
						if (parseInt(hoursItems[0]) < 0 || parseInt(hoursItems[0]) > 23) {
							return false;
						}
						if (parseInt(hoursItems[1]) < 0 || parseInt(hoursItems[1]) > 23) {
							return false;
						}
					} else {
						if (!(/[0-9]/.test(hours))) {
							return false;
						}
						if (parseInt(hours) < 0 || parseInt(hours) > 23) {
							return false;
						}
					}
				}

				// days
				var days = exItems[3];
				var daysItems = null;
				if (days != "*" && days != "?" && days != "L" && days != "W" && days != "C") {
					if (days.indexOf(",") >= 0) {
						daysItems = days.split(",");
					} else if (days.indexOf("-") >= 0) {
						daysItems = days.split("-");
					} else if (days.indexOf("/") >= 0) {
						daysItems = days.split("/");
					}

					if (daysItems != null) {
						if (daysItems.length != 2) {
							return false;
						}
						if (!(/[0-9]/.test(daysItems[0])) || !(/[0-9]/.test(daysItems[1]))) {
							return false;
						}
						if (parseInt(daysItems[0]) < 1 || parseInt(daysItems[0]) > 31) {
							return false;
						}
						if (parseInt(daysItems[1]) < 1 || parseInt(daysItems[1]) > 31) {
							return false;
						}
					} else {
						if (!(/[0-9]/.test(days))) {
							return false;
						}
						if (parseInt(days) < 1 || parseInt(days) > 31) {
							return false;
						}
					}
				}

				// months
				var months = exItems[4];
				var monthsItems = null;
				if (months != "*") {
					if (months.indexOf(",") >= 0) {
						monthsItems = months.split(",");
					} else if (months.indexOf("-") >= 0) {
						monthsItems = months.split("-");
					} else if (months.indexOf("/") >= 0) {
						monthsItems = months.split("/");
					}

					if (monthsItems != null) {
						if (monthsItems.length != 2) {
							return false;
						}
						if (!(/[0-9]/.test(monthsItems[0])) || !(/[0-9]/.test(monthsItems[1]))) {
							return false;
						}
						if (parseInt(monthsItems[0]) < 1 || parseInt(monthsItems[0]) > 12) {
							return false;
						}
						if (parseInt(monthsItems[1]) < 1 || parseInt(monthsItems[1]) > 12) {
							return false;
						}
					} else {
						if (!(/[0-9]/.test(months))) {
							return false;
						}
						if (parseInt(months) < 1 || parseInt(months) > 12) {
							return false;
						}
					}
				}

				// weeks
				var weeks = exItems[5];
				var weeksItems = null;
				if (weeks != "*" && weeks != "?" && weeks != "L" && weeks != "C") {
					if (weeks.indexOf(",") >= 0) {
						weeksItems = weeks.split(",");
					} else if (weeks.indexOf("-") >= 0) {
						weeksItems = weeks.split("-");
					} else if (weeks.indexOf("/") >= 0) {
						weeksItems = weeks.split("/");
					} else if (weeks.indexOf("#") >= 0) {
						weeksItems = weeks.split("#");
					}

					if (weeksItems != null) {
						if (weeksItems.length != 2) {
							return false;
						}
						if (!(/[0-9]/.test(weeksItems[0])) || !(/[0-9]/.test(weeksItems[1]))) {
							return false;
						}
						if (parseInt(weeksItems[0]) < 1 || parseInt(weeksItems[0]) > 7) {
							return false;
						}
						if (parseInt(weeksItems[1]) < 1 || parseInt(weeksItems[1]) > 7) {
							return false;
						}
					} else {
						if (!(/[0-9]/.test(weeks))) {
							return false;
						}
						if (parseInt(weeks) < 1 || parseInt(weeks) > 7) {
							return false;
						}
					}
				}

				// years
				if (exItems.length == 7) {
					var years = exItems[6];
					var yearsItems = null;
					if (years != "*") {
						if (years.indexOf(",") >= 0) {
							yearsItems = years.split(",");
						} else if (years.indexOf("-") >= 0) {
							yearsItems = years.split("-");
						} else if (years.indexOf("/") >= 0) {
							yearsItems = years.split("/");
						}

						if (yearsItems != null) {
							if (yearsItems.length != 2) {
								return false;
							}
							if (!(/[0-9]/.test(yearsItems[0])) || !(/[0-9]/.test(yearsItems[1]))) {
								return false;
							}
							if (years.indexOf(",") >= 0) {
								if (parseInt(yearsItems[0]) < 1970 || parseInt(yearsItems[0]) > 2099) {
									return false;
								}
								if (parseInt(yearsItems[1]) < 1970 || parseInt(yearsItems[1]) > 2099) {
									return false;
								}
							} else {
								if (parseInt(yearsItems[0]) < 1970 || parseInt(yearsItems[0]) > 2099) {
									return false;
								}
								if (parseInt(yearsItems[1]) <= parseInt(yearsItems[0])) {
									return false;
								}
							}
						} else {
							if (!(/[0-9]/.test(years))) {
								return false;
							}
							if (parseInt(years) < 1970 || parseInt(years) > 2099) {
								return false;
							}
						}
					}
				}

				return true;
			},

			_validate : function() {
				var view = this.getView();
				var expression = view.byId("triggerExpression").getValue();
				if (!this._validateCronExpression(expression)) {
					sap.m.MessageToast.show("Sync Job Trigger Expression is invalid");
					return false;
				}

				var inputs = [ view.byId("companyName"), view.byId("website"), view.byId("telphone"), view.byId("email"), view.byId("emailPostFix") ];

				// check that inputs are not empty
				// this does not happen during data binding as this is only triggered by
				// changes
				// jQuery.each(inputs, function(i, input) {
					// if (!input.getValue()) {
						// input.setValueState("Error");
					// }
				// });

				// check states of inputs
				var canContinue = true;
				jQuery.each(inputs, function(i, input) {
					if ("Error" === input.getValueState()) {
						canContinue = false;
						return false;
					}
				});
				return canContinue;
			},
			saveCompanyInfo : function() {
				var inputValid = this._validate();
				if(inputValid)
				{

					var viewData = this.getView().getModel().getData();

					if(viewData.logoId && !(""+viewData.logoId).match(/^\d+$/)){
						delete viewData.logoId;
					}
					if(viewData.twoDimensionCode && !(""+viewData.twoDimensionCode).match(/^\d+$/)){
						delete viewData.twoDimensionCode;
					}
					viewData.applyStatusMapping = encodeURIComponent(viewData.applyStatusMapping);

					var that = this;
					jQuery.ajax({
						url : this._company_info_save,
						method : "POST",
						data : JSON.stringify(viewData),
						contentType : 'application/json;charset=UTF-8'
					}).success(function(data) {
						jQuery.sap.require("sap.m.MessageToast");
						if (data && data.companyId) {
							that.loadCompanyInfo();
							sap.m.MessageToast.show(that.translateText("LB_COMPANY_INFO_SAVED_SUCCESS"));
						} else {
							sap.m.MessageToast.show("error happened, please try again later");
						}
					})
				}
			},

			formatAccountSel : function(val) {
				if (val) {
					return 0;
				}
				return 1;
			},

			cacheODataMetadata : function(oEvent) {
				// ready
				jQuery.sap.require("sap.m.MessageBox");
				this.getView().byId("metadataRefreshing").setVisible(true);
				this.getView().byId("metadataRefreshingTip").setVisible(true);
				var that = this;
				jQuery.ajax({
					url : "sf/refreshMetadata",
					method : "GET",
					contentType : 'application/json;charset=UTF-8'
				}).success(function(data) {
					that.getView().byId("metadataRefreshing").setVisible(false);
					that.getView().byId("metadataRefreshingTip").setVisible(false);
					if (data && data.code == 0) {
						sap.m.MessageBox.success(that.translateText("LB_ODATA_METADATA_CACHED"));
					} else {
						var bCompact = !!that.getView().$().closest(".sapUiSizeCompact").length;
						sap.m.MessageBox.alert(
							data.message,
							{
								styleClass: bCompact? "sapUiSizeCompact" : ""
							});
					}
				})

			},

			openApplyStatusDialog : function() {
				this.getView().byId("applyStatusMappingDialog").open();
			},

			applyStatusDialogClose: function(){
				this.getView().byId("applyStatusMappingDialog").close();
			},

			generateSampleApplyStatusData:function(){
				var that = this;
				$.get(this._sample_apply_status_mapping,function(data){
					if(data && data.applyStatusMapping){
						var mappingData = that.getView().getModel().getData();
						mappingData.applyStatusMapping = data.applyStatusMapping;
						that.getView().getModel().setData(mappingData);
					}
				});
			},

			translateText: function(val){
				return this.getView().getModel("i18n").getResourceBundle().getText(val);
			},

			typeEMail : sap.ui.model.SimpleType.extend("email", {
				parseValue: function (oValue) {
					//parsing step takes place before validating step, value can be altered
					return oValue;
				},
				validateValue: function (oValue) {
					// The following Regex is NOT a completely correct one and only used for demonstration purposes.
					// RFC 5322 cannot even checked by a Regex and the Regex for RFC 822 is very long and complex.
					var mailregex = /^\w+[\w-+\.]*\@\w+([-\.]\w+)*\.[a-zA-Z]{2,}$/;
					if (!oValue.match(mailregex)) {
						throw new sap.ui.model.ValidateException("'" + oValue + "' is not a valid email address");
					}
				},
				formatValue: function (oValue) {
					return oValue;
				}
			}),

			generateRandomValue : function(){
				return Math.random();
			},

			alertMsg : function(requiredMsg) {
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					sap.m.MessageBox.alert(
						requiredMsg,
						{
							styleClass: bCompact? "sapUiSizeCompact" : ""
						}
					);
			},

			changeStatusLanguage: function(oEvent){
				var selItem = oEvent.getParameter("selectedItem");
				if(selItem.getKey() == "EN"){
					this.loadJobStatusSetting("en_US");
				}else{
					this.loadJobStatusSetting("en_US");
				}
			},
			uploadDpcsComplete: function(oEvent){
				var sResponse = JSON.parse(oEvent.getParameter("responseRaw"));
				var oModel = this.getView().getModel();
				var oData = oModel.getData();
				oData.dpcs = sResponse.dpcs;
				oModel.setData(oData);
				this.getView().setModel(oModel);
			},

			/**
			 * Similar to onAfterRendering, but this hook is invoked before the
			 * controller's View is re-rendered (NOT before the first rendering!
			 * onInit() is used for that one!).
			 *
			 * @memberOf resume-collection-service.templateConfig
			 */
			onBeforeRendering : function() {
			},

			openJobStatusFilterDialog: function(){
				this.getView().byId("jobStatusFilterDialog").open();
				this.loadJobStatusSetting("en_US");
			},

			closeJobStatusFilterDialog: function(){
				this.getView().byId("jobStatusFilterDialog").close();
			},

			saveJobStatusFilter : function(){
				var listCtrl = this.getView().byId("JobStatusList");
				var statusList = listCtrl.getItems();
				var jobStatuses = '';
				for (index in statusList) {
					if(statusList[index].getSelected()){
						if (jobStatuses.length != 0) {
							jobStatuses = jobStatuses + ",";
						}
						jobStatuses = jobStatuses + statusList[index].getName();
					}
				}
				var that = this;
				jQuery.ajax({
					url : "company/saveJobStatusFilter?status=" + jobStatuses,
					method : "POST",
				}).success(function(data) {
					if(data && data.code == "0"){
						that.closeJobStatusFilterDialog();
					}else{
						that.alertMsg("save failed");
					}
				})
			},
			showCronExpressionGuide : function(oEvent) {
				// create popover
				if (!this._oPopover) {
					this._oPopover = sap.ui.xmlfragment("static.js.layout.jobSyncCronExpressionGuide", this);
					this.getView().addDependent(this._oPopover);
				}
				this._oPopover.openBy(oEvent.getSource());

			},
			handleClosePress : function(oEvent) {
				this._oPopover.close();
			},
			/**
			 * Called when the View has been rendered (so its HTML is part of the
			 * document). Post-rendering manipulations of the HTML could be done here.
			 * This hook is the same one that SAPUI5 controls get after being rendered.
			 *
			 * @memberOf resume-collection-service.templateConfig
			 */
			// onAfterRendering: function() {
			//
			// },
			/**
			 * Called when the Controller is destroyed. Use this one to free resources
			 * and finalize activities.
			 *
			 * @memberOf resume-collection-service.templateConfig
			 */
			onExit : function() {

			}

		});

		return companyMaintainController;
});
