package com.sap.hcm.resume.collection.bean;

import java.util.List;

/**
 * @author I075908 SAP
 */
public class JobReqScreeningQuestion {
  private String questionId;

  private String questionName;

  private String questionOrder;

  private String questionType;

  private List<JobReqScreeningQuestionChoice> choices;
  
  private boolean required;
  
  private String maxLength;

  public String getQuestionId() {
    return questionId;
  }

  public void setQuestionId(String questionId) {
    this.questionId = questionId;
  }

  public String getQuestionName() {
    return questionName;
  }

  public void setQuestionName(String questionName) {
    this.questionName = questionName;
  }

  public String getQuestionOrder() {
    return questionOrder;
  }

  public void setQuestionOrder(String questionOrder) {
    this.questionOrder = questionOrder;
  }

  public String getQuestionType() {
    return questionType;
  }

  public void setQuestionType(String questionType) {
    this.questionType = questionType;
  }

  public List<JobReqScreeningQuestionChoice> getChoices() {
    return choices;
  }

  public void setChoices(List<JobReqScreeningQuestionChoice> choices) {
    this.choices = choices;
  }

  /**
   * @return the required
   */
  public boolean isRequired() {
    return required;
  }

  /**
   * @param required the required to set
   */
  public void setRequired(boolean required) {
    this.required = required;
  }

  /**
   * @return the maxLength
   */
  public String getMaxLength() {
    return maxLength;
  }

  /**
   * @param maxLength the maxLength to set
   */
  public void setMaxLength(String maxLength) {
    this.maxLength = maxLength;
  }

}
