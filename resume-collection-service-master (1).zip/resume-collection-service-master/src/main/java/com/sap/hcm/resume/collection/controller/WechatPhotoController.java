package com.sap.hcm.resume.collection.controller;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.bean.SimpleJsonResponse;
import com.sap.hcm.resume.collection.entity.Photo;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.service.PhotoService;
import com.sap.hcm.resume.collection.util.CandidateFileUtil;

@Controller
@RequestMapping(value = "wphoto")
public class WechatPhotoController {
  private final static String LOGO = "_logo";

  @Autowired
  private PhotoService photoService;

  @Autowired
  private Params params;

  @RequestMapping(value = "{photoId}", method = RequestMethod.GET)
  public @ResponseBody void getPhoto(HttpServletRequest request, HttpServletResponse response,
      @PathVariable(value = "photoId") Long photoId) throws IOException {

    Photo photo = photoService.getPhoto(photoId);
    try {
      response.setContentType("image/jpeg");
      OutputStream ops = response.getOutputStream();
      if (photo != null) {
        ops.write(photo.getContent());
        ops.close();
      }
    } catch (IOException e) {
      throw new IOException("get OutputStream of photo failed with Id: " + photoId);
    }

  }

  @RequestMapping(value = "temp/{photoId}", method = RequestMethod.GET)
  public @ResponseBody void getTempPhoto(HttpServletRequest request, HttpServletResponse response,
      @PathVariable(value = "photoId") String photoId) throws IOException {

    byte[] item = (byte[]) request.getSession().getAttribute(photoId);
    if (item != null) {
      try {
        response.setContentType("image/jpeg");
        OutputStream ops = response.getOutputStream();
        ops.write(item);
        ops.close();
      } catch (Exception ex) {
        throw new IOException(ex.getMessage());
      }
    }

  }

  @RequestMapping(value = "picture/upload", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
  public @ResponseBody SimpleJsonResponse uploadCompanyLogo(HttpServletRequest request, HttpServletResponse response,
      @RequestParam(value = "sizeLimit", required = true) boolean sizeLimit,
      @RequestParam(value = "height", required = false) Integer height,
      @RequestParam(value = "width", required = false) Integer width) throws ServiceApplicationException, IOException {
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(-1);
    boolean isMultipart = ServletFileUpload.isMultipartContent(request);
    String id = params.getWechatOpenId();

    if (StringUtils.isEmpty(id)) {
      throw new ServiceApplicationException("session timout");
    }

    if (!isMultipart) {
      throw new ServiceApplicationException("Not a multipart request");
    }
    List<FileItem> items = CandidateFileUtil.handleFileUploadRequest(request);
    if (items != null && items.size() > 0) {
      for (FileItem item : items) {
        if (item.isFormField()) {
          continue;
        } else {
          InputStream is = null;
          try {
            if (!StringUtils.isEmpty(width) && !StringUtils.isEmpty(height)) {
              is = item.getInputStream();
              byte[] newitem = CandidateFileUtil.cropImage(is, width, height);
              request.getSession().setAttribute(id + LOGO, newitem);
            } else {
              is = item.getInputStream();
              byte[] newitem = new byte[is.available()];
              is.read(newitem);
              request.getSession().setAttribute(id + LOGO, newitem);
            }
            rsp.setCode(0);
            rsp.setMessage(id + LOGO);
          } catch (Exception ex) {
            throw new IOException(ex.getMessage());
          } finally {
            IOUtils.closeQuietly(is);
          }
        }
      }
    }

    return rsp;
  }
}
