package com.sap.hcm.resume.collection.integration.wechat.bean;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class WechatBeanTest {
  @Test
  public void TestGetWechatMenuItem() {
    WechatMenuItem menu = new WechatMenuItem();
    menu.setName("heheda");
    assertEquals("heheda", menu.getName());
  }

  @Test
  public void TestGetWechatSubMenuItem() {
    WechatSubMenuItem menu = new WechatSubMenuItem();
    menu.setName("heheda");
    assertEquals("heheda", menu.getName());
    menu.setUrl("url");
    assertEquals("url", menu.getUrl());
    menu.setType("haha");
    assertEquals("haha", menu.getType());
  }

  @Test
  public void TestWechatImportResultWrapper() {
    WechatImportResultWrapper wrapper = new WechatImportResultWrapper();
    wrapper.setFailure(null);
    wrapper.setSuccess(null);
  }

  @Test
  public void TestWechatImportResult() {
    WechatImportResult wrapper = new WechatImportResult();
    wrapper.setStatus(123);
    wrapper.setMessage("456");
    wrapper.setCandidateId(789L);
    assertEquals(123, wrapper.getStatus());
    assertEquals("456", wrapper.getMessage());

    assertEquals("789", Long.toString(wrapper.getCandidateId()));
  }

  @Test
  public void TestJobDynSearchBean() {
    JobDynSearchBean bean = new JobDynSearchBean();
    bean.setSkip(123);
    bean.setTop(456);
    assertEquals(123, bean.getSkip());
    assertEquals(456, bean.getTop());
  }

  @Test
  public void TestJobDynSearchBeanItem() {
    JobDynSearchBeanItem bean = new JobDynSearchBeanItem();
    bean.setValues(null);
  }
}
