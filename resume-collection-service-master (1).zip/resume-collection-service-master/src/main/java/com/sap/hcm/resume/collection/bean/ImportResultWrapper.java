package com.sap.hcm.resume.collection.bean;

import java.io.Serializable;
import java.util.List;

/**
 * import result wrapper
 * @author i065831
 *
 */
public class ImportResultWrapper implements Serializable{
    
    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = -1002663349170762804L;

    private List<ImportResultBean> results;

    /**
     * @return the results
     */
    public List<ImportResultBean> getResults() {
        return results;
    }

    /**
     * @param results the results to set
     */
    public void setResults(List<ImportResultBean> results) {
        this.results = results;
    }
    
}
