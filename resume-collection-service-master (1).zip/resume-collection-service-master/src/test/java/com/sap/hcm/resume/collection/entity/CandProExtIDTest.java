package com.sap.hcm.resume.collection.entity;


import org.junit.Assert;
import org.junit.Test;

public class CandProExtIDTest {
  
  @Test
  public void testIdenticalCandProExtID(){
    CandProExtID id1 = new CandProExtID();
    id1.setCandidateId(1L);
    id1.setParamName("test");
    
    CandProExtID id2 = new CandProExtID();
    id2.setCandidateId(1L);
    id2.setParamName("test");
    
    Assert.assertEquals(id1.equals(id2), true);
    
    Assert.assertEquals(id1.getCandidateId().toString(), "1");
    Assert.assertEquals(id1.getParamName(), "test");
  }
  
  @Test
  public void testNotIdenticalCandProExtID(){
    CandProExtID id1 = new CandProExtID();
    id1.setCandidateId(1L);
    id1.setParamName("test");
    
    CandProExtID id2 = new CandProExtID();
    id2.setCandidateId(1L);
    id2.setParamName("test2");
    
    Assert.assertEquals(id1.equals(id2), false);
  }
  
  @Test
  public void testEquals(){
    CandProExtID bean1 = new CandProExtID();
    bean1.setParamName("type");
    
    CandProExtID bean2 = new CandProExtID();
    bean2.setParamName("type");
    
    Assert.assertEquals(bean1, bean2);
    
    bean1.setCandidateId(1L);
    bean2.setCandidateId(1L);
    Assert.assertEquals(bean1, bean2);
    
    Assert.assertEquals(bean1.equals(bean1), true);
    
    Assert.assertEquals(bean1.hashCode(), bean2.hashCode());
  }
  
  @Test
  public void testNotEquals(){
    CandProExtID bean1 = null;
    CandProExtID bean2 = new CandProExtID();
    Assert.assertNotEquals(bean1, bean2);
    
    Assert.assertNotEquals(bean2.equals(null), true);
    
    Assert.assertNotEquals(bean2, new String(""));
    
    bean1 = new CandProExtID();
    bean1.setParamName("type");;
    Assert.assertNotEquals(bean1, bean2);
        
    bean1.setCandidateId(1L);
    Assert.assertNotEquals(bean1, bean2);


    bean1.setParamName(null);
    bean2.setParamName("test");
    bean1.setCandidateId(1L);
    bean2.setCandidateId(1L);
    Assert.assertNotEquals(bean1.equals(bean2), true);
    
    bean1.setParamName("test");
    bean2.setParamName("test");
    bean1.setCandidateId(null);
    bean2.setCandidateId(1L);
    Assert.assertNotEquals(bean1.equals(bean2), true);
        
    bean1.setParamName("test");
    bean2.setParamName("test");
    bean1.setCandidateId(2L);
    bean2.setCandidateId(1L);
    Assert.assertNotEquals(bean1.equals(bean2), true);
  }
}
