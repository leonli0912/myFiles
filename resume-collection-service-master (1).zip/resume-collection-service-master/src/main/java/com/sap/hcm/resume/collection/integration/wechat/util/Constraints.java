package com.sap.hcm.resume.collection.integration.wechat.util;

public class Constraints {
        
    public static final String SESSION_KEY_VERIFICATION_CODE = "verifyCode";
    
    public static final String SESSION_KEY_SELECTED_COMPANY_ID = "selectedCompanyId";
    
    public static final String SESSION_KEY_WECHAT_ACCESS_TOKEN = "wechatAccessToken";
    
    public static final String SESSION_KEY_WECHAT_JS_SIGNATURE = "wechatJsSignature";
    
    public static final String SESSION_KEY_WECHAT_TIMESTAMP= "wechatTimestamp";
    
    public static final String SESSION_KEY_WECHAT_NONCESTR = "wechatNonceStr";
}