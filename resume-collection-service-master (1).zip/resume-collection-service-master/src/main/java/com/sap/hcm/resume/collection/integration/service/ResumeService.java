package com.sap.hcm.resume.collection.integration.service;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.fileupload.FileItem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.sap.hcm.resume.collection.bean.ImportResultBean;
import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.bean.ResumeInfo;
import com.sap.hcm.resume.collection.entity.DataModelMapping;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileExtVO;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;
import com.sap.hcm.resume.collection.factory.CandidateFactory;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJob;
import com.sap.hcm.resume.collection.parser.DocumentParserAdapter;
import com.sap.hcm.resume.collection.service.CandidateService;
import com.sap.hcm.resume.collection.service.CompanyInfoService;
import com.sap.hcm.resume.collection.service.JobApplicationService;
import com.sap.hcm.resume.collection.util.CandidateFileUtil;
import com.sap.hcm.resume.collection.util.MappingUtil;

@Service
public class ResumeService {

  @Autowired
  protected CompanyInfoService compInfoService;

  @Autowired
  private MessageSource messageSource;

  @Autowired
  private CandidateService candidateService;

  @Autowired
  private JobApplicationService jobApplicationService;
  
  @Autowired
  private Params params;

  public ImportResultBean processFile(FileItem item, HttpServletRequest request, String vendor, String template,
      DataModelMapping mapping, String jobId, String statusSetId) {
    ImportResultBean importResultBean = new ImportResultBean();
    try {
      importResultBean.setFileName(item.getName());
      importResultBean.setFileSize(MappingUtil.convertFileSize(item.getSize()));
      // parse the file content
      ResumeInfo resumeInfo = CandidateFileUtil.getFileContent(item.get());
      DocumentParserAdapter parser = CandidateFactory.getResumeParserInstance(messageSource, vendor, template);
      CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
      candidateProfileVO = parser.parseProfile(candidateProfileVO, resumeInfo);

      // handle other Ext profile
      CandidateProfileExtVO extProfile = candidateProfileVO.getExtProfile();
      if(extProfile == null){
        extProfile = new CandidateProfileExtVO();
      }
      extProfile.setResumeExtension(resumeInfo.getResumeExtension());
      extProfile.setAttachment(resumeInfo.getAttachment());
      extProfile.setCandidateSource(vendor);
      extProfile.setCandidateType("Non-WeChat");
      extProfile = CandidateFileUtil.handleSpecialFields(extProfile, candidateProfileVO);
      candidateProfileVO.setExtProfile(extProfile);
      candidateProfileVO.setCompanyId(params.getCompanyId());
      
      candidateProfileVO = parser.parseBackgroundWorkExp(candidateProfileVO, resumeInfo);
      candidateProfileVO = parser.parseBackgroundEducation(candidateProfileVO, resumeInfo);
      candidateProfileVO = parser.parseBackgroundCertificate(candidateProfileVO, resumeInfo);
      candidateProfileVO = parser.parseBackgroundLanguage(candidateProfileVO, resumeInfo);
      
      
      WechatJob wechatJob = new WechatJob();
      wechatJob.setExternalJobId(jobId);
      wechatJob.setSfStatusSetId(statusSetId);
      wechatJob.setCompanyId(params.getCompanyId());

      // check whether the candidate has been inserted before
      Long candidateId = candidateService.getCandidateId(candidateProfileVO.getPrimaryEmail());
      // this candidate has not been inserted before
      if (candidateId == null) {
        // insert candidate into SF
        candidateProfileVO = candidateService.insertCandidate(candidateProfileVO, mapping);
      } else {
        candidateProfileVO.getExtProfile().setExternalCandidateId(candidateId);
      }
      
      if (!StringUtils.isEmpty(jobId)) {
        // apply job to successfactors
        jobApplicationService.insertJobApplication(candidateProfileVO, mapping, wechatJob,null);
      } else {
        importResultBean.setImportStatus("success");
        importResultBean
            .setReason(messageSource.getMessage("LB_RESUME_IMPORT_TO_SF_SUCCESS", null, request.getLocale()));
        return importResultBean;
      }

      importResultBean.setCandidateId(candidateProfileVO.getCandidateId());
      importResultBean.setImportStatus("success");
      importResultBean.setReason(messageSource.getMessage("LB_RESUME_IMPORT_APPLY_JOB_SUCCESS", null,
          request.getLocale()));

      return importResultBean;
    } catch (Exception e) {
      importResultBean.setImportStatus("error");
      importResultBean.setReason(e.getMessage());
      return importResultBean;
    }
  }
}
