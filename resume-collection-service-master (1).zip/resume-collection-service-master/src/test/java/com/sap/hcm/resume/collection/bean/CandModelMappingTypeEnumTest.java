package com.sap.hcm.resume.collection.bean;


import org.junit.Assert;
import org.junit.Test;

public class CandModelMappingTypeEnumTest {
  
  @Test
  public void testMappingTypeLabel(){
    CandModelMappingTypeEnum mappingType = CandModelMappingTypeEnum.CAND_PROFILE_MAPPING;
    mappingType.setLabelKey("abc");
    
    Assert.assertEquals("abc", mappingType.getLabelKey());
  }
}
