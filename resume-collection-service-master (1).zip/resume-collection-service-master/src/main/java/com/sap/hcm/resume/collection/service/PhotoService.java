package com.sap.hcm.resume.collection.service;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Service;

import com.sap.hcm.resume.collection.entity.Photo;

@Service
public class PhotoService {

	@PersistenceContext
	private EntityManager entityManager;

	public Photo getPhoto(Long photoId) {
		Photo photo = null;

		photo = entityManager.find(Photo.class, photoId);

		return photo;

	}
	
	public Photo saveImg(Photo photo) {
        photo = entityManager.merge(photo);
        return photo;
    }
}
