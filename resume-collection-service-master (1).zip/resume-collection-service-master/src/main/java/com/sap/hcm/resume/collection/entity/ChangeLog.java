package com.sap.hcm.resume.collection.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

@Entity
@Table(name = "CHANGE_LOG")
public class ChangeLog implements Serializable {

  /**
   * serialVersionUID
   */
  private static final long serialVersionUID = 6688970952892796445L;

  @Id
  @GeneratedValue(strategy = GenerationType.TABLE, generator = "change_seq")
  @TableGenerator(initialValue = 1, table = "SEQUENCE", name = "change_seq", pkColumnName = "SEQ_NAME", valueColumnName = "SEQ_COUNT", pkColumnValue = "CHANGE_PK", allocationSize = 1)
  @Column(name = "CHANGE_ID")
  private Long changeId;

  @Column(name = "CHANGE_AT", length = 30)
  private String changeAt;

  @Column(name = "ACTION_TYPE")
  private String actionType;

  @Column(name = "CHANGED_BY")
  private String changedBy;

  @Column(name = "OBJECT_TYPE")
  private String objectType;

  @Column(name = "CHANGE_CONTENT", length = 2000)
  private String changeContent;

  @Column(name = "OBJECT_NAME")
  private String objectName;

  @Column(name = "OBJECT_ID")
  private String objectId;

  @Column(name = "COMPANY_ID")
  private String companyId;

  public Long getChangeId() {
    return changeId;
  }

  public void setChangeId(Long changeId) {
    this.changeId = changeId;
  }

  public String getActionType() {
    return actionType;
  }

  public void setActionType(String actionType) {
    this.actionType = actionType;
  }

  public String getChangedBy() {
    return changedBy;
  }

  public void setChangedBy(String changedBy) {
    this.changedBy = changedBy;
  }

  public String getObjectType() {
    return objectType;
  }

  public void setObjectType(String objectType) {
    this.objectType = objectType;
  }

  public String getChangeContent() {
    return changeContent;
  }

  public void setChangeContent(String changeContent) {
    this.changeContent = changeContent;
  }

  public String getObjectName() {
    return objectName;
  }

  public void setObjectName(String objectName) {
    this.objectName = objectName;
  }

  public String getObjectId() {
    return objectId;
  }

  public void setObjectId(String objectId) {
    this.objectId = objectId;
  }

  public String getCompanyId() {
    return companyId;
  }

  public void setCompanyId(String companyId) {
    this.companyId = companyId;
  }

  public String getChangeAt() {
    return changeAt;
  }

  public void setChangeAt(String changeAt) {
    this.changeAt = changeAt;
  }
}
