package com.sap.hcm.resume.collection.entity.view;

import java.io.Serializable;

import com.sap.hcm.resume.collection.annotation.ProfileAttribute;
import com.sap.hcm.resume.collection.util.I18nMessages;
import com.thoughtworks.xstream.annotations.XStreamAlias;

/**
 * candidate background
 * @author i065831
 *
 */

@XStreamAlias("work-experience")
public class CandidateBgWorkExprVO implements CandidateBgBase, Serializable{
	
	/**
	 * serialVersionUID
	 */
    private static final long serialVersionUID = 6373627406323631652L;
    
    @ProfileAttribute(name="startDate", type=String.class, label=I18nMessages.LABEL_START_DATE)
	private String startDate;
	
    @ProfileAttribute(name="endDate", type=String.class, label=I18nMessages.LABEL_END_DATE)
	private String endDate;
	
    @ProfileAttribute(name="isPresent", type=Boolean.class, label=I18nMessages.LABEL_IS_PRESENT)
	private Boolean isPresent;
	
    @ProfileAttribute(name="employer", type=String.class, label=I18nMessages.LABEL_EMPLOYER)
	private String employer;
	
    @ProfileAttribute(name="jobTitle", type=String.class, label=I18nMessages.LABEL_JOB_TITLE)
	private String jobTitle;
	
    @ProfileAttribute(name="department", type=String.class, label=I18nMessages.LABEL_DEPARTEMNT)
	private String department;
	
    @ProfileAttribute(name="description", type=String.class, label=I18nMessages.LABEL_DESCRIPTION)
	private String description;
    
    @ProfileAttribute(name="exitReason", type=String.class, label=I18nMessages.LABEL_EXIT_REASON)
	private String exitReason;
    
    @ProfileAttribute(name="salary", type=String.class, label=I18nMessages.LABEL_SALARY_START)
	private String salary;
    
    @ProfileAttribute(name="salaryEnd", type=String.class, label=I18nMessages.LABEL_SALARY_END)
	private String salaryEnd;
    
    @ProfileAttribute(name="presentEmployer", type=String.class, label=I18nMessages.LABEL_PRESENT_EMPLOYER)
    private String presentEmployer;
    
    @ProfileAttribute(name="businessType", type=String.class, label=I18nMessages.LABEL_BUSINESS_TYPE)
    private String businessType;

    /**
	 * @return the businessType
	 */
	public String getBusinessType() {
		return businessType;
	}

	/**
	 * @param businessType the businessType to set
	 */
	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}
    
	/**
     * @return the presentEmployer
     */
    public String getPresentEmployer() {
        return presentEmployer;
    }

	/**
     * @param presentEmployer the presentEmployer to set
     */
    public void setPresentEmployer(String presentEmployer) {
        this.presentEmployer = presentEmployer;
    }

    /**
	 * @return the startDate
	 */
	public String getStartDate() {
		return startDate;
	}

	/**
	 * @param startDate the startDate to set
	 */
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	/**
	 * @return the endDate
	 */
	public String getEndDate() {
		return endDate;
	}

	/**
	 * @param endDate the endDate to set
	 */
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	/**
	 * @return the isPresent
	 */
	public Boolean getIsPresent() {
		return isPresent;
	}

	/**
	 * @param isPresent the isPresent to set
	 */
	public void setIsPresent(Boolean isPresent) {
		this.isPresent = isPresent;
	}


	/**
	 * @return the employer
	 */
	public String getEmployer() {
		return employer;
	}

	/**
	 * @param employer the employer to set
	 */
	public void setEmployer(String employer) {
		this.employer = employer;
	}

	/**
	 * @return the jobTitle
	 */
	public String getJobTitle() {
		return jobTitle;
	}

	/**
	 * @param jobTitle the jobTitle to set
	 */
	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	/**
	 * @return the department
	 */
	public String getDepartment() {
		return department;
	}

	/**
	 * @param department the department to set
	 */
	public void setDepartment(String department) {
		this.department = department;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}
	
	/**
	 * @return the exitReason
	 */
	public String getExitReason() {
		return exitReason;
	}

	/**
	 * @param exitReason the exitReason to set
	 */
	public void setExitReason(String exitReason) {
		this.exitReason = exitReason;
	}

	/**
	 * @return the salary
	 */
	public String getSalary() {
		return salary;
	}

	/**
	 * @param salary the salary to set
	 */
	public void setSalary(String salary) {
		this.salary = salary;
	}

	/**
	 * @return the salaryEnd
	 */
	public String getSalaryEnd() {
		return salaryEnd;
	}

	/**
	 * @param salaryEnd the salaryEnd to set
	 */
	public void setSalaryEnd(String salaryEnd) {
		this.salaryEnd = salaryEnd;
	}
}
