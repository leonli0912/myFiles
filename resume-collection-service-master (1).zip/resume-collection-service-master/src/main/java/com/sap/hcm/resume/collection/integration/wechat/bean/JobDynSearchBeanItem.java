package com.sap.hcm.resume.collection.integration.wechat.bean;

import java.io.Serializable;
import java.util.List;

/**
 * job search bean item
 * @author i065831
 *
 */
public class JobDynSearchBeanItem implements Serializable{
    
    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 1156109481867002140L;

    public List<String> values;
    
    public String type;

    /**
     * @return the values
     */
    public List<String> getValues() {
        return values;
    }

    /**
     * @param values the values to set
     */
    public void setValues(List<String> values) {
        this.values = values;
    }

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }
}
