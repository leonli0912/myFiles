package com.sap.hcm.resume.collection.entity.view;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.sap.hcm.resume.collection.annotation.ProfileAttribute;
import com.sap.hcm.resume.collection.util.I18nMessages;

@JsonIgnoreProperties("attachment")
public class CandidateProfileExtVO implements Serializable {

  /**
   * serialVersionUID
   */
  private static final long serialVersionUID = 8902767891181146935L;

  @ProfileAttribute(name = "state", type = String.class, label = I18nMessages.LABEL_STATE)
  private String state;

  @ProfileAttribute(name = "attachment", type = Byte[].class, label = I18nMessages.LABEL_ATTACHMENT)
  private byte[] attachment;

  private String resumeExtension;

  @ProfileAttribute(name = "startWorkDate", type = String.class, label = I18nMessages.LABEL_START_WORK_DATE)
  private String startWorkDate;
  
  @ProfileAttribute(name = "currentCompany", type = String.class, label = I18nMessages.LABEL_CURRENT_COMPANY)
  private String currentCompany;

  /**
   * 51job, zhipin, liepin, etc.
   */
  private String candidateSource;

  /**
   * Wechat, Non-wechat
   */
  private String candidateType;

  /**
   * Chinese pronunciation
   */
  @ProfileAttribute(name = "pinyin", type = String.class, label = I18nMessages.LABLE_PINYIN)
  private String pinyin;
  
  private byte[] requiredFields;
  
  private Long externalCandidateId;

  @ProfileAttribute(name = "custom01", type = String.class, label = I18nMessages.LABEL_CUSTOM01)
  private byte[] custom01;

  @ProfileAttribute(name = "custom02", type = String.class, label = I18nMessages.LABEL_CUSTOM02)
  private byte[] custom02;

  @ProfileAttribute(name = "custom03", type = String.class, label = I18nMessages.LABEL_CUSTOM03)
  private byte[] custom03;

  @ProfileAttribute(name = "custom04", type = String.class, label = I18nMessages.LABEL_CUSTOM04)
  private byte[] custom04;

  @ProfileAttribute(name = "custom05", type = String.class, label = I18nMessages.LABEL_CUSTOM05)
  private byte[] custom05;

  /**
   * @return the attachment
   */
  public byte[] getAttachment() {
    return attachment;
  }

  /**
   * @param attachment
   *          the attachment to set
   */
  public void setAttachment(byte[] attachment) {
    this.attachment = attachment;
  }

  public String getResumeExtension() {
    return resumeExtension;
  }

  public void setResumeExtension(String resumeName) {
    this.resumeExtension = resumeName;
  }

  public String getState() {
    return state;
  }

  public void setState(String state) {
    this.state = state;
  }

  public String getStartWorkDate() {
    return startWorkDate;
  }

  public void setStartWorkDate(String startWorkDate) {
    this.startWorkDate = startWorkDate;
  }
  
  public String getCurrentCompany() {
    return currentCompany;
  }
  
  public void setCurrentCompany(String currentCompany) {
    this.currentCompany = currentCompany;
  }

  public String getCandidateSource() {
    return candidateSource;
  }

  public void setCandidateSource(String candidateSource) {
    this.candidateSource = candidateSource;
  }

  public String getCandidateType() {
    return candidateType;
  }

  public void setCandidateType(String candidateType) {
    this.candidateType = candidateType;
  }

  /**
   * @return the pinyin
   */
  public String getPinyin() {
    return pinyin;
  }

  /**
   * @param pinyin
   *          the pinyin to set
   */
  public void setPinyin(String pinyin) {
    this.pinyin = pinyin;
  }

  public byte[] getRequiredFields() {
    return requiredFields;
  }

  public void setRequiredFields(byte[] requiredFields) {
    this.requiredFields = requiredFields;
  }

  public Long getExternalCandidateId() {
    return externalCandidateId;
  }

  public void setExternalCandidateId(Long externalCandidateId) {
    this.externalCandidateId = externalCandidateId;
  }

  public byte[] getCustom01() {
    return custom01;
  }

  public void setCustom01(byte[] custom01) {
    this.custom01 = custom01;
  }

  public byte[] getCustom02() {
    return custom02;
  }

  public void setCustom02(byte[] custom02) {
    this.custom02 = custom02;
  }

  public byte[] getCustom03() {
    return custom03;
  }

  public void setCustom03(byte[] custom03) {
    this.custom03 = custom03;
  }

  public byte[] getCustom04() {
    return custom04;
  }

  public void setCustom04(byte[] custom04) {
    this.custom04 = custom04;
  }

  public byte[] getCustom05() {
    return custom05;
  }

  public void setCustom05(byte[] custom05) {
    this.custom05 = custom05;
  }
}
