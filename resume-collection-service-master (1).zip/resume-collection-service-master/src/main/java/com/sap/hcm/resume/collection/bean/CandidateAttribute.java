package com.sap.hcm.resume.collection.bean;

import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


/**
 * candidate attribute
 * @author i065831
 *
 */
@JsonIgnoreProperties(value={"isExt"})
public class CandidateAttribute implements Serializable{
	
	/**
	 * serialVersionUID
	 */
    private static final long serialVersionUID = -4359520598429871625L;

	private String name;
	
	private String type;
	
	private Boolean isExt = false;
	
	private String label;
	

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}
	
	/**
	 * @return the isExt
	 */
	public Boolean getIsExt() {
		return isExt;
	}

	/**
	 * @param isExt the isExt to set
	 */
	public void setIsExt(Boolean isExt) {
		this.isExt = isExt;
	}

    /**
     * @return the label
     */
    public String getLabel() {
        return label;
    }

    /**
     * @param label the label to set
     */
    public void setLabel(String label) {
        this.label = label;
    }
	
}
