package com.sap.hcm.resume.collection.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MappingUtil {

  public final static String matchSingle(String regex, String text) {

    Pattern pattern = Pattern.compile(regex);
    Matcher matcher = pattern.matcher(text);
    if (matcher.find()) {
      return matcher.group();
    }
    return "";
  }

  public static String removeScriptTag(String html) {

    return html.replaceAll("<script[^>]*?>[\\s\\S]*?</script>", "");
  }

  public static String removeStyleTag(String html) {

    return html.replaceAll("<style[^>]*?>[\\s\\S]*?</style>", "");
  }

  public static String removeTdTag(String html, boolean keepEnter) {

    html = html.replaceAll("</p>\\s*?</td>", "");
    if (keepEnter) {
      return html.replaceAll("<td[^>]*?>", "").replaceAll("</td>", "")
          .replaceAll("[\\t]", "");
    } else {
      return html.replaceAll("<td[^>]*?>", "").replaceAll("</td>", "")
          .replaceAll("[\\t\\r\\n]", "");
    }
  }

  public static String removeTrTag(String html) {

    return html.replaceAll("</tr>", System.lineSeparator());
  }

  public static String removePTag(String html) {

    return html.replaceAll("</p>", System.lineSeparator());
  }

  public static String removeBrTag(String html) {

    return html.replaceAll("<br>", System.lineSeparator()).replaceAll(
        "<br[^<>]*>", System.lineSeparator());
  }

  public static String removeBracketTag(String html) {

    return html.replaceAll("<[^<>].*?>", "");
  }

  public static String removeSpaceTag(String html) {
    return html.replaceAll("&nbsp;", "");
  }

  public static String replaceSpaceTag(String html) {
    return html.replaceAll("&nbsp;", " ");
  }

  public static String convertFileSize(long size) {

    long kb = 1024;
    long mb = kb * 1024;
    long gb = mb * 1024;

    if (size >= gb) {
      return String.format("%.1f GB", (float) size / gb);
    } else if (size >= mb) {
      float f = (float) size / mb;
      return String.format(f > 100 ? "%.0f MB" : "%.1f MB", f);
    } else if (size >= kb) {
      float f = (float) size / kb;
      return String.format(f > 100 ? "%.0f KB" : "%.1f KB", f);
    } else
      return String.format("%d B", size);
  }

  public static String methodNameCapitalized(String methodName) {

    StringBuilder sb = new StringBuilder(methodName);
    sb.setCharAt(0, Character.toUpperCase(sb.charAt(0)));
    return sb.toString();
  }
}
