package com.sap.hcm.resume.collection.integration.sf.service;

import java.util.List;
import java.util.Map;

import org.apache.olingo.odata2.api.commons.HttpContentType;
import org.apache.olingo.odata2.api.ep.entry.ODataEntry;
import org.apache.olingo.odata2.api.ep.feed.ODataFeed;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import com.sap.hcm.resume.collection.entity.DataModelMapping;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.bean.CandProfileDataModelMapping;
import com.sap.hcm.resume.collection.integration.service.CandidateIntegrationService;
import com.sap.hcm.resume.collection.integration.sf.SFOdataFormatter;
import com.sap.hcm.resume.collection.integration.sf.bean.QueryInfo;
import com.sap.hcm.resume.collection.integration.sf.bean.QueryOptionEnum;
import com.sap.hcm.resume.collection.integration.sf.odata.SFODataConstants;
import com.sap.hcm.resume.collection.integration.sf.odata.SFODataEntityType;
import com.sap.hcm.resume.collection.integration.sf.odata.SFODataService;
import com.sap.hcm.resume.collection.integration.xml.DataModelMappingXMLConverter;

/**
 * @author I075908 SAP
 */
@Service(value = "sfCandidateService")
@Lazy
public class SFCandidateService implements CandidateIntegrationService {
  
  /**
   * logger instance
   */
  private Logger logger = LoggerFactory.getLogger(SFCandidateService.class);

  @Autowired
  private SFODataService sfODataService;

  @Autowired
  private SFOdataFormatter odataFormatter;
  
  public Long getCandidateId(String primaryEmail) throws ServiceApplicationException {
    Long candidateId = null;
    QueryInfo queryInfo = new QueryInfo(SFODataEntityType.CANDIDATE.getName());
    String filter = "primaryEmail eq '" + primaryEmail + "'";
    String select = "candidateId";
    queryInfo.addQueryOption(QueryOptionEnum.FILTER, filter);
    queryInfo.addQueryOption(QueryOptionEnum.SELECT, select);
    ODataFeed odFeed = sfODataService.readFeed(SFODataConstants.APPLICATION_JSON, queryInfo);
    if (odFeed == null) {
      throw new ServiceApplicationException("Failed to read candidate feed.");
    }
    List<ODataEntry> odEnties = odFeed.getEntries();
    if (odEnties == null || odEnties.isEmpty()) {
      return candidateId;
    }
    ODataEntry oDataEntry = odEnties.get(0);
    Map<String, Object> map = oDataEntry.getProperties();
    candidateId = (Long) map.get("candidateId");
    return candidateId;
  }

  public CandidateProfileVO insertCandidate(CandidateProfileVO candidateProfileVO, DataModelMapping mapping)
      throws ServiceApplicationException {
    try {
      // retrieve mapping information
      CandProfileDataModelMapping dataModelMapping = null;
      if (mapping != null) {
        dataModelMapping = DataModelMappingXMLConverter.fromXML(mapping.toXML());
      } else {
        throw new ServiceApplicationException("mapping not found");
      }

      if (dataModelMapping == null) {
        throw new ServiceApplicationException("mapping content not found with ID: " + mapping.getMappingId());
      }

      Map<String, Object> data = odataFormatter.getSFOdataFormat(dataModelMapping, candidateProfileVO);

      ODataEntry odataEntry = sfODataService.createEntry(HttpContentType.APPLICATION_JSON, "Candidate", data, false);

      // get candidateId
      Map<String, Object> candidateIdMap = odataEntry.getProperties();
      Long candidateIdLong = (Long) candidateIdMap.get("candidateId");
      candidateProfileVO.getExtProfile().setExternalCandidateId(candidateIdLong);

      if (candidateIdLong == null) {
        throw new ServiceApplicationException("This candidate can not be inserted into SF System");
      }

      return candidateProfileVO;

    } catch (Exception e) {
      if (e instanceof ServiceApplicationException) {
        logger.error(e.getMessage());
        throw new ServiceApplicationException(e.getMessage());
      }
      logger.error("Insert candidate failed with error : " + e.getMessage());
      throw new ServiceApplicationException("Insert candidate failed");
    }

  }

}
