package com.sap.hcm.resume.collection.integration.bean;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("property-alias")
public class MappingPropertyAlias implements Serializable{
    
    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 1L;

    private String propName;
    
    private String alias;

    /**
     * @return the propName
     */
    public String getPropName() {
        return propName;
    }

    /**
     * @param propName the propName to set
     */
    public void setPropName(String propName) {
        this.propName = propName;
    }

    /**
     * @return the alias
     */
    public String getAlias() {
        return alias;
    }

    /**
     * @param alias the alias to set
     */
    public void setAlias(String alias) {
        this.alias = alias;
    }
    
}
