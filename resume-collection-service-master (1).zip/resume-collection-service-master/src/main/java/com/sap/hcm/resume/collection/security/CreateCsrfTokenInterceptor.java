package com.sap.hcm.resume.collection.security;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.util.StringUtils;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

/**
 * @author I324117 SAP
 */
public class CreateCsrfTokenInterceptor extends HandlerInterceptorAdapter {

  @Override
  public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
    if (StringUtils.isEmpty(request.getSession().getAttribute(CsrfTokenManager.CSRF_PARAM_NAME))) {
      request.getSession().setAttribute(CsrfTokenManager.CSRF_PARAM_NAME,
          CsrfTokenManager.createTokenForSession(request.getSession()));
    }
    return true;
  }

}
