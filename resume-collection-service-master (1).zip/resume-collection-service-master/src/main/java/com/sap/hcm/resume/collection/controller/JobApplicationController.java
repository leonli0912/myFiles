/**
 * 
 */
package com.sap.hcm.resume.collection.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sap.hcm.resume.collection.bean.JobReqScreeningQuestion;
import com.sap.hcm.resume.collection.bean.JobReqScreeningQuestionChoice;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJob;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJobScreeningQuestion;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJobScreeningQuestionAndChoice;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJobScreeningQuestionChoice;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatJobScreeningQuestionService;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatJobService;

/**
 * @author I075908 SAP
 */
@Controller
@RequestMapping(value = "/question")
public class JobApplicationController extends ControllerBase{

  @Autowired
  private WechatJobScreeningQuestionService questionService;
  
  @Autowired
  private WechatJobService wechatJobService;

  /**
   * list all screening questions with choices filtered by jobReqId and locale
   * 
   * @param jobReqId
   * @param locale
   *          - applicant's locale, could be selectable, e.g. "en_US"
   * @return
   * @throws ServiceApplicationException 
   */
  @RequestMapping(value = "/list", method = RequestMethod.GET)
  @ResponseBody
  public List<JobReqScreeningQuestion> getQuestionsByJobReqId(@RequestParam("jobId") Long jobId) throws ServiceApplicationException {
    List<JobReqScreeningQuestion> result = new ArrayList<JobReqScreeningQuestion>();

    if (jobId == null) {
      return result;
    }
    
    WechatJob job = wechatJobService.findJobById(jobId);
    if(job == null){
      return result;
    }
    String jobReqId = job.getExternalJobId();
    
    // TODO - move the code into a service, need to refact the entire job app related service and entity, move them out
    // of wechat package into smirs base module, meantime we need to separate SF services - Haibin
    List<WechatJobScreeningQuestionAndChoice> questionList = questionService
        .findJobScreeningQuestionAndChoice(jobReqId);
    
    if(questionList == null){
      return result;
    }
    
    //check whether 
    for (WechatJobScreeningQuestionAndChoice question : questionList) {
      // get screening question
      WechatJobScreeningQuestion screeningQuestion = question.getWechatJobScreeningQuestion();
      JobReqScreeningQuestion questionVO = new JobReqScreeningQuestion();
      questionVO.setQuestionId(screeningQuestion.getQuestionId());
      questionVO.setQuestionName(screeningQuestion.getQuestionName());
      questionVO.setQuestionOrder(screeningQuestion.getQuestionOrder().toString());
      questionVO.setQuestionType(screeningQuestion.getQuestionType());
      questionVO.setRequired(screeningQuestion.isRequired());
      questionVO.setMaxLength(screeningQuestion.getMaxLength());
      // get mapping choices of screening question
      List<JobReqScreeningQuestionChoice> choicesVOList = new ArrayList<JobReqScreeningQuestionChoice>();
      List<WechatJobScreeningQuestionChoice> choices = question.getJobScreeningQuestionChoiceList();
      for (WechatJobScreeningQuestionChoice choice : choices) {
        JobReqScreeningQuestionChoice choiceVO = new JobReqScreeningQuestionChoice();
        choiceVO.setChoiceKey(choice.getJobReqQuestionChoiceKey());
        choiceVO.setOptionId(choice.getOptionId());
        choiceVO.setOptionValue(choice.getOptionValue());
        choiceVO.setLocale(choice.getChoiceLocale());
        choiceVO.setOptionLabel(choice.getOptionLabel());
        choicesVOList.add(choiceVO);
      }
      questionVO.setChoices(choicesVOList);
      result.add(questionVO);
    }

    return result;
  }
}
