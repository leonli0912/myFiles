package com.sap.hcm.resume.collection.exception;

import org.junit.Assert;
import org.junit.Test;

public class InvalidVerifyCodeExceptionTest {
  
  @Test
  public void testExceptionCode(){
    InvalidVerifyCodeException except = new InvalidVerifyCodeException();
    Assert.assertEquals(except.getCode(), -1002);
  }
}
