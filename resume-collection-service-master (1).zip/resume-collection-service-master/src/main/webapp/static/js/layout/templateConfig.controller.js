jQuery.sap.require("sap.m.MessageBox");
sap.ui.controller("static.js.layout.templateConfig", {

	apiUrl : "jobboards/country",

	_oPopover:null,

	_paramPopover:null,

	_oSorterJobReqId:true,

	_oSorterJobTitle:true,

	_additionalParams:[
	],

	_JobInfoParamPopover:null,

	_statusSetId:null,

/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf static.js.layout.templateConfig
*/
	onInit : function() {
		
		
		var oModel = new sap.ui.model.json.JSONModel(this.apiUrl);
		this.viewId = this.getView().getId();
		var that = this;
		oModel.attachRequestCompleted(function(oEvent) {
			var oCountryList = that.getView().byId("countryCollection");
			oModel.getData().options.reverse().push({
				key:"",
				label:""
			});
			oModel.getData().options.reverse();
			oCountryList.setModel(oModel);
		});

	},

	showTip: function(){
		var tipMsg = this.translateText("LB_INTEGRATEION_TIP");
		this.infoMsg(tipMsg);
	},
	getVendor : function(oEvent) {

		var country = oEvent.getSource().getSelectedKey();
		if (country) {
			this.apiUrl = "jobboards/" + country;
			var oModel = new sap.ui.model.json.JSONModel(this.apiUrl + "/vendor");
			var oVendorList = this.getView().byId("vendorCollection");
			oVendorList.setModel(oModel);
			var that = this;
			oModel.attachRequestCompleted(function(oEvent) {

				var vendor = oEvent.getSource().getData().options[0].key;
				var vendorUrl = oEvent.getParameters().url;
				apiUrl = vendorUrl.replace(/vendor/, vendor);
				that.setTemplate(apiUrl + "/template");
			});
		} else {
			var oVendorList = this.getView().byId("vendorCollection");
			var oTemplateList = this.getView().byId("templateCollection");
			var oModel = new sap.ui.model.json.JSONModel();
			oVendorList.setModel(oModel);
			oTemplateList.setModel(oModel);
		}
	},

	getTemplate : function(oEvent) {

		var vendor = oEvent.getSource().getSelectedKey();
		this.setTemplate(this.apiUrl + "/" + vendor + "/template");
	},

	setTemplate : function(apiUrl) {
		var oModel = new sap.ui.model.json.JSONModel(apiUrl);
		var oTemplateList = this.getView().byId("templateCollection");
		oTemplateList.setModel(oModel);
	},

	previewTemplate :function(oEvent){
		var oTemplateList = this.getView().byId("templateCollection");
		var selIndex = oTemplateList.getSelectedIndex();
		if(selIndex == -1){
			return;
		}
		var selOption = oTemplateList.getModel().getData().options[selIndex];

		if (!this._oPopover) {
		      this._oPopover = sap.ui.xmlfragment("static.js.layout.resumePreview", this);
		      this.getView().addDependent(this._oPopover);
		}
		var oJsonModel = new sap.ui.model.json.JSONModel();
	      oJsonModel.setData({
	    	  data:{
	    		  title:selOption.key,
	    		  path:selOption.additionalText
	    	  }
	      });
	      this._oPopover.setModel(oJsonModel);
	      this._oPopover.bindElement("/data");
		this._oPopover.openBy(oEvent.getSource());

	},
	doUpload : function(oEvent) {

		var vendorSelected = this.getView().byId("vendorCollection").getSelectedKey();
		var templateSelected = this.getView().byId("templateCollection").getSelectedKey();
		var oFileUploader = this.getView().byId("fileUploader");
		var jobId = this.getView().byId("jobReqId").getText();

		var oMappingModel = new sap.ui.model.json.JSONModel();

		oMappingModel.loadData("company/info",null,false);
		var oMappingData = oMappingModel.getData();
		var mappingIdSelected = oMappingData.dmMappingId;

		if(!mappingIdSelected){
			this.alertMsg(this.getView().getModel("i18n").getResourceBundle().getText("CHOOSE_THE_MAPPING_FIRST"));
			return;
		}

		if (vendorSelected) {
			oFileUploader.setUploadUrl("upload?vendor=" + vendorSelected + "&template="+templateSelected+"&jobId=" + jobId + "&statusSetId=" + this._statusSetId);
			oFileUploader.upload();
		    oFileUploader.clear();
		    var oImportResultList = this.getView().byId("importResultList");
		    oImportResultList.setBusy(true);
		} else {
			oFileUploader.clear();
			this.alertMsg(this.getView().getModel("i18n").getResourceBundle().getText("CHOOSE_THE_TEMPLATE_FIRST"));
		}

	},

	uploadComplete : function(oEvent) {
//		var sResponse = oEvent.getParameter("response");
		var sResponse = JSON.parse(oEvent.getParameter("responseRaw"));
	    var oImportResultList = this.getView().byId("importResultList");
	    oImportResultList.setBusy(false);
	    var oModel = new sap.ui.model.json.JSONModel();
			if(sResponse.code && sResponse.code == -1005){
				this.alertMsg(sResponse.message);
			}else{
		    var jsonData = sResponse["results"];
		    oModel.setData(jsonData);
		    oImportResultList.setModel(oModel);
		}
	},
	createNewMapping : function(){
		var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		oRouter.navTo("mappingList");
	},

	formatStatus: function(val){
		if(val){
			if(val == "success"){
				return "Success";
			}
			if(val == "error"){
				return "Error";
			}
		}
		return "Success";
	},

	integrationChecked:function(oEvent){
		var selected = oEvent.getParameter("state");
		if(selected){
			this.getView().byId("integrationPanel").setExpanded(true);
		}else{
			this.getView().byId("integrationPanel").setExpanded(false);
		}
	},

	integrationExpand:function(oEvent){
		var expanded = oEvent.getParameter("expand");
		if(expanded){
			this.getView().byId("mappingSelected").setState(true);
		}else{
			this.getView().byId("mappingSelected").setState(false);
		}
	},

	openJobInfoParams:function(oEvent){
		if (!this._JobInfoParamPopover) {
		      this._JobInfoParamPopover = sap.ui.xmlfragment("jobInfoParamsFrag","static.js.layout.jobInfoParams", this);
		      this.getView().addDependent(this._JobInfoParamPopover);
		}
		this._JobInfoParamPopover.openBy(oEvent.getSource());
	},

	findJobInfoParams : function() {
		var condition = sap.ui.core.Fragment.byId("jobInfoParamsFrag", "condition").getValue();
		condition = encodeURI(condition);
		condition = encodeURI(condition);

		var oJobInfoList = sap.ui.core.Fragment.byId("jobInfoParamsFrag", "jobInfoList");
		oJobInfoList.setBusy(true);

		var jsonModel = new sap.ui.model.json.JSONModel("job/search?condition=" + condition);
		this._JobInfoParamPopover.setModel(jsonModel);
		jsonModel.attachRequestCompleted(function(oEvent) {
			oJobInfoList.setBusy(false);
		});
		this.sortByJobReqId();
	},

	selectJobInfoParams : function(oEvent) {

		var bindPath = oEvent.getSource().getBindingContext().sPath;
		var selObj = oEvent.getSource().getModel().getObject(bindPath);
		this.getView().byId("jobReqId").setText(selObj.jobReqId);
		this.getView().byId("jobTitle").setText(selObj.jobTitle);
		this._statusSetId = selObj.statusSetId;
		this.getView().byId("deleteJobItem").setVisible(true);

		//close the popover
		this._JobInfoParamPopover.close();
	},

	closeJobInfoParams:function(oEvent){

		//close the popover
		this._JobInfoParamPopover.close();
	},

	deleteItem : function() {
		this.getView().byId("jobReqId").setText("");
		this.getView().byId("jobTitle").setText("");
		this.getView().byId("deleteJobItem").setVisible(false);
		this._statusSetId = null;
	},

/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf resume-collection-service.templateConfig
*/
	onBeforeRendering: function() {
	},

	sortByJobReqId : function(){

		var btnJobReqId = sap.ui.core.Fragment.byId("jobInfoParamsFrag","sortJobReqId");
		var btnJobTitle = sap.ui.core.Fragment.byId("jobInfoParamsFrag","sortJobTitle");

		if (this._oSorterJobReqId) {
			this._oSorterJobReqId = false;
			btnJobReqId.setIcon("sap-icon://sort-ascending");
		} else {
			this._oSorterJobReqId = true;
			btnJobReqId.setIcon("sap-icon://sort-descending");
		}
		var jobList = sap.ui.core.Fragment.byId("jobInfoParamsFrag","jobInfoList");
		var fnCompare = function(a,b){
			if ( parseInt(a) > parseInt(b) ){
				return 1;
			}else if (parseInt(a) == parseInt(b)){
				return 0;
			}else{
				return -1;
			}
		}

		var oSorter = new sap.ui.model.Sorter("jobReqId",this._oSorterJobReqId);
		oSorter.fnCompare = fnCompare;

		jobList.getBinding("items").sort(oSorter);
	},

	sortByJobTitle : function(){

		var btnJobReqId = sap.ui.core.Fragment.byId("jobInfoParamsFrag","sortJobReqId");
		var btnJobTitle = sap.ui.core.Fragment.byId("jobInfoParamsFrag","sortJobTitle");

		if (this._oSorterJobTitle) {
			this._oSorterJobTitle = false;
			btnJobTitle.setIcon("sap-icon://sort-ascending");
		} else {
			this._oSorterJobTitle = true;
			btnJobTitle.setIcon("sap-icon://sort-descending");
		}
		var jobList = sap.ui.core.Fragment.byId("jobInfoParamsFrag","jobInfoList");

		var oSorter = new sap.ui.model.Sorter("jobTitle",this._oSorterJobTitle);

		jobList.getBinding("items").sort(oSorter);
	},

	translateText: function(val){
		return this.getView().getModel("i18n").getResourceBundle().getText(val);
	},

	alertMsg : function(requiredMsg) {
		var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			sap.m.MessageBox.alert(
				requiredMsg,
				{
					styleClass: bCompact? "sapUiSizeCompact" : ""
				}
			);
	},

	infoMsg : function(requiredMsg) {
		var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			sap.m.MessageBox.information(
				requiredMsg,
				{
					styleClass: bCompact? "sapUiSizeCompact" : ""
				}
			);
	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf resume-collection-service.templateConfig
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf resume-collection-service.templateConfig
*/
	onExit: function() {
		if (this._oPopover) {
		   this._oPopover.destroy();
		}
		if (this._paramPopover) {
		   this._paramPopover.destroy();
		}
	}

});
