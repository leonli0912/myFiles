
package com.sap.hcm.resume.collection.registry;

import static org.junit.Assert.assertEquals;

import java.util.HashSet;
import java.util.Set;

import org.junit.Test;

import com.sap.hcm.resume.collection.bean.KeyLabelBean;

/**
 * @author I324117
 * SAP
 */
public class CandidateVendorRegistryTest {
  
  @Test
  public void testGetVendorByCountryFailWithCountryIsNull(){
    String countryCode = "";
    Set<KeyLabelBean> candidateNameSet = new HashSet<KeyLabelBean>();
    assertEquals(candidateNameSet,CandidateVendorRegistry.getVendorByCountry(countryCode));
  }
  
  @Test
  public void testGetTemplateByCountryAndNameFailWithCountryIsNull(){
    String countryCode = "";
    String vendorCode = "";
    Set<KeyLabelBean> templateSet = new HashSet<KeyLabelBean>();
    assertEquals(templateSet,CandidateVendorRegistry.getTemplateByCountryAndName(countryCode, vendorCode));
  }

}
