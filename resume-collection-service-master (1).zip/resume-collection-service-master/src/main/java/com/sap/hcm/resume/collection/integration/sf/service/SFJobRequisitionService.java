package com.sap.hcm.resume.collection.integration.sf.service;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sap.hcm.resume.collection.bean.CompanyIdInfo;
import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.entity.view.JobRequisitionMappingVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.bean.JobReqDataModelMapping;
import com.sap.hcm.resume.collection.integration.bean.JobReqDataModelMappingItem;
import com.sap.hcm.resume.collection.integration.service.JobRequisitionIntegrationService;
import com.sap.hcm.resume.collection.integration.sf.SFOdataFormatter;
import com.sap.hcm.resume.collection.integration.sf.bean.JobRequisitionBean;
import com.sap.hcm.resume.collection.integration.sf.bean.QueryInfo;
import com.sap.hcm.resume.collection.integration.sf.bean.QueryOptionEnum;
import com.sap.hcm.resume.collection.integration.sf.odata.SFAuthentication;
import com.sap.hcm.resume.collection.integration.sf.odata.SFODataEntityType;
import com.sap.hcm.resume.collection.integration.sf.odata.SFODataService;
import com.sap.hcm.resume.collection.integration.wechat.bean.JobStatusEnum;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJob;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJobScreeningQuestion;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJobScreeningQuestionChoice;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatJobScreeningQuestionChoiceService;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatJobScreeningQuestionService;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatJobService;
import com.sap.hcm.resume.collection.service.CompanyInfoService;
import com.sap.hcm.resume.collection.service.DataModelMappingService;
import com.sap.hcm.resume.collection.util.ChangeLogUtil;
import com.sap.hcm.resume.collection.util.MappingUtil;

@Service(value = "sfJobRequisitionService")
public class SFJobRequisitionService implements JobRequisitionIntegrationService {
  @Autowired
  private SFODataService sfOdataService;

  @Autowired
  private CompanyInfoService companyInfoService;

  @Autowired
  private DataModelMappingService mappingService;

  @Autowired
  SFAuthentication sfAuth;

  @Autowired
  private WechatJobService wechatJobService;

  @Autowired
  private WechatJobScreeningQuestionService wechatJobScreeningQuestionService;

  @Autowired
  private WechatJobScreeningQuestionChoiceService wechatJobScreeningQuestionChoiceService;

  @Autowired
  private SFOdataFormatter sfOdataFormatter;

  @Autowired
  private ChangeLogUtil changeLogUtil;

  private static final String APPLICATION_JSON = "application/json;charset=utf-8";

  @Autowired
  private Params params;

  @Autowired
  private CompanyIdInfo companyIdInfo;

  private Date postStartDate;

  private Date postEndDate;

  /**
   * logger
   */
  private static final Logger logger = LoggerFactory.getLogger(SFJobRequisitionService.class);

  @SuppressWarnings("unchecked")
  @Override
  public Map<String, String> getJobRequisition(String jobReqMappingId, String lowDate, String highDate,
      String jobReqIdStr) throws ServiceApplicationException {
    int jobLoadedCounter = 0;
    int jobBypassCounter = 0;
    int jobFailCounter = 0;
    String jobReqId = null;
    // this.syncJobRequisition("dev_default_i323239");

    String companyId = params.getCompanyId();
    List<String> SuccessjobReqIdList = new ArrayList<String>();
    List<String> ByPassjobReqIdList = new ArrayList<String>();
    List<String> FailjobReqIdList = new ArrayList<String>();
    if (StringUtils.isEmpty(companyId)) {
      throw new ServiceApplicationException("Session timeout");
    }
    try {

      CompanyInfo info = companyInfoService.getCompanyInfo(companyId);
      if (info == null) {
        throw new ServiceApplicationException("Invalid company instance");
      }

      String jobStatuses = info.getJobStatuses();
      List<String> items = new ArrayList<String>();
      items.add("");
      if (jobStatuses != null) {
        items.clear();
        items = Arrays.asList(jobStatuses.split("\\s*,\\s*"));
      }

      JobRequisitionMappingVO mapping = mappingService.getJobRequisitionMappingById(companyId,
          Long.valueOf(jobReqMappingId));
      if (mapping == null) {
        throw new ServiceApplicationException("mapping not found with ID: " + jobReqMappingId);
      }

      JobReqDataModelMapping jobReqMapping = mapping.getMapping();

      HashMap<String, List<String>> optionList = buildSelectAndExpandList(jobReqMapping);
      QueryInfo queryInfo = buildLoadJobQueryOptions(optionList, jobReqIdStr, lowDate, highDate, false);
      String jobRequisitioonJsonString = sfOdataService.readFeedAsString(APPLICATION_JSON, queryInfo);

      jobRequisitioonJsonString = jobRequisitioonJsonString.replace("\u0001", "");
      HashMap<String, Object> jobReqMap = new ObjectMapper().readValue(jobRequisitioonJsonString, HashMap.class);
      HashMap<String, Object> jobReqMapD = (HashMap<String, Object>) jobReqMap.get("d");
      List<HashMap<String, Object>> jobReqMapResults = (List<HashMap<String, Object>>) jobReqMapD.get("results");

      for (HashMap<String, Object> resultMap : jobReqMapResults) {
        jobReqId = (String) resultMap.get("jobReqId");
        postStartDate = null;
        postEndDate = null;

        if (isActiveJob(resultMap, items) && isPostedJob(resultMap)) {
          this.loadJobReqRequstionAndChoice(resultMap);
          WechatJob wechatJob = new WechatJob();
          wechatJob.setCreateAt(new Date());
          wechatJob.setCompanyId(companyId);
          wechatJob.setExternalJobId((String) resultMap.get("jobReqId"));
          wechatJob.setStatus(JobStatusEnum.POSTED.getCode());
          wechatJob.setSfStatusSetId(String.valueOf(resultMap.get("statusSetId")));
          wechatJob.setReqMappingId(jobReqMappingId);
          wechatJob = sfOdataFormatter.formatJobReqFromSF2Local(wechatJob, resultMap, mapping);

          if (postStartDate != null) {
            wechatJob.setPostStartDate(postStartDate);
          }
          if (postEndDate != null) {
            wechatJob.setPostEndDate(postEndDate);
          }

          wechatJobService.saveSFJob(wechatJob);
          SuccessjobReqIdList.add(wechatJob.getExternalJobId());
          jobLoadedCounter++;
        } else {
          ByPassjobReqIdList.add((String) resultMap.get("jobReqId"));
          jobBypassCounter++;
        }

      }
    } catch (Exception e) {
      logger.error("Load job error with exception: " + e.getMessage());

      jobFailCounter++;
      if (jobReqId != null) {
        FailjobReqIdList.add(jobReqId);
      } else {
        FailjobReqIdList.add(" ");
      }
      // throw new ServiceApplicationException("Load job error");
    }
    Map<String, String> result = new HashMap<String, String>();

    result.put("loadedJobIdList", StringUtils.collectionToDelimitedString(SuccessjobReqIdList, ","));
    result.put("passedJobIdList", StringUtils.collectionToDelimitedString(ByPassjobReqIdList, ","));
    result.put("failedJobIdList", StringUtils.collectionToDelimitedString(FailjobReqIdList, ","));
    result.put("loaded", Integer.toString(jobLoadedCounter));
    result.put("passed", Integer.toString(jobBypassCounter));
    result.put("failed", Integer.toString(jobFailCounter));

    return result;
  }

  @SuppressWarnings("unchecked")
  public void syncJobRequisition(String companyId) throws ServiceApplicationException {

    if (StringUtils.isEmpty(companyId)) {
      logger.debug("Company Id does not exist");
      return;
    }

    int jobLoadedCounter = 0;
    int jobFailCounter = 0;
    int jobDeletedCounter = 0;

    String jobReqId = null;
    Long jobReqMappingId = null;

    List<String> SuccessjobReqIdList = null;
    List<String> FailjobReqIdList = null;
    List<String> DeletedjobReqIdList = null;

    CompanyInfo compInfo = companyInfoService.getCompanyInfo(companyId);
    // String lowDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date(System.currentTimeMillis() - 24 * 60 * 60
    // * 1000));
    String lowDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date(0000));
    String highDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
    Date lastSyncSuccessDate = null;
    lastSyncSuccessDate = compInfo.getLastJobSyncDate();
    if (lastSyncSuccessDate != null) {
      lowDate = new SimpleDateFormat("yyyy-MM-dd").format(lastSyncSuccessDate);
    }
    logger.debug("lowDate: " + lowDate + " highDate: " + highDate);

    /*
     * Set the current process company ID to ensure the following code would load job from the corresponding SF instance
     */
    companyIdInfo.setCompanyId(companyId);

    jobReqMappingId = compInfo.getJobReqMappingId();
    if (jobReqMappingId == null) {
      logger.debug("job Req Mapping Id does not exist");
      return;
    }

    logger.debug("Start syncing job of company " + compInfo.getCompanyName() + " on " + new Date());
    SuccessjobReqIdList = new ArrayList<String>();
    FailjobReqIdList = new ArrayList<String>();
    DeletedjobReqIdList = new ArrayList<String>();

    jobLoadedCounter = 0;
    jobFailCounter = 0;
    jobDeletedCounter = 0;

    try {

      /* Get active job Req mapping */
      JobRequisitionMappingVO mapping = mappingService.getJobRequisitionMappingById(companyId, jobReqMappingId);
      if (mapping == null) {
        logger.debug("mapping not found with ID: " + jobReqMappingId);
        return;
      }
      JobReqDataModelMapping jobReqMapping = mapping.getMapping();

      HashMap<String, List<String>> optionList = buildSelectAndExpandList(jobReqMapping);
      QueryInfo queryInfo = buildLoadJobQueryOptions(optionList, "", lowDate, highDate, true);
      String jobRequisitioonJsonString = sfOdataService.readFeedAsString(APPLICATION_JSON, queryInfo);
      jobRequisitioonJsonString = jobRequisitioonJsonString.replace("\u0001", "");
      HashMap<String, Object> jobReqMap = new ObjectMapper().readValue(jobRequisitioonJsonString, HashMap.class);
      HashMap<String, Object> jobReqMapD = (HashMap<String, Object>) jobReqMap.get("d");
      List<HashMap<String, Object>> jobReqMapResults = (List<HashMap<String, Object>>) jobReqMapD.get("results");

      String jobStatuses = compInfo.getJobStatuses();
      List<String> items = new ArrayList<String>();
      items.add("");
      if (jobStatuses != null) {
        items.clear();
        items = Arrays.asList(jobStatuses.split("\\s*,\\s*"));
      }

      for (HashMap<String, Object> resultMap : jobReqMapResults) {

        jobReqId = (String) resultMap.get("jobReqId");
        logger.error("process job with id: " + jobReqId);
        String deleted = (String) resultMap.get("deleted");
        postStartDate = null;
        postEndDate = null;
        if (isActiveJob(resultMap, items) && isPostedJob(resultMap) && deleted.equals("Not Deleted")) {
          logger.error("valid job with id: " + jobReqId);
          this.loadJobReqRequstionAndChoice(resultMap);
          WechatJob wechatJob = new WechatJob();
          wechatJob.setCreateAt(new Date());
          wechatJob.setCompanyId(companyId);
          wechatJob.setExternalJobId((String) resultMap.get("jobReqId"));
          wechatJob.setStatus(JobStatusEnum.POSTED.getCode());
          wechatJob.setSfStatusSetId(String.valueOf(resultMap.get("statusSetId")));
          wechatJob.setReqMappingId(Long.toString(jobReqMappingId));
          wechatJob = sfOdataFormatter.formatJobReqFromSF2Local(wechatJob, resultMap, mapping);

          if (postStartDate != null) {
            wechatJob.setPostStartDate(postStartDate);
          }
          if (postEndDate != null) {
            wechatJob.setPostEndDate(postEndDate);
          }

          wechatJobService.saveSFJob(wechatJob);
          SuccessjobReqIdList.add(wechatJob.getExternalJobId());
          jobLoadedCounter++;
        } else {
          logger.error("invalid job with id: " + jobReqId);
          WechatJob job = wechatJobService.findJobByReqId(jobReqId, companyId);
          if (job != null) {
            logger.error("available job to be deleted: " + jobReqId);
            wechatJobScreeningQuestionService.deleteJobScreeningQuestionAndChoice(job.getJobId(), companyId);
            wechatJobService.deleteJobById(job.getJobId());
            jobDeletedCounter++;
            DeletedjobReqIdList.add(jobReqId);
          }
        }

      }
    } catch (Exception e) {
      logger.error("Load job error with exception: " + e.getMessage());

      jobFailCounter++;
      if (jobReqId != null) {
        FailjobReqIdList.add(jobReqId);
      } else {
        FailjobReqIdList.add(" ");
      }
    }

    logger.debug(Integer.toString(jobLoadedCounter) + " Job Loaded successfully with req id: "
        + StringUtils.collectionToDelimitedString(SuccessjobReqIdList, ","));
    logger.debug(Integer.toString(jobDeletedCounter) + " Job Deleted successfully with req id: "
        + StringUtils.collectionToDelimitedString(DeletedjobReqIdList, ","));
    logger.debug(Integer.toString(jobFailCounter) + " Job load failed with req id: "
        + StringUtils.collectionToDelimitedString(FailjobReqIdList, ","));
    logger.debug("End syncing job of company " + compInfo.getCompanyName() + " on " + new Date());
    // }
    String content = Integer.toString(jobLoadedCounter) + " Job Loaded successfully with req id: "
        + StringUtils.collectionToDelimitedString(SuccessjobReqIdList, ",") + "\n"
        + Integer.toString(jobDeletedCounter) + " Job Deleted successfully with req id: "
        + StringUtils.collectionToDelimitedString(DeletedjobReqIdList, ",") + "\n" + Integer.toString(jobFailCounter)
        + " Job load failed with req id: " + StringUtils.collectionToDelimitedString(FailjobReqIdList, ",");
    changeLogUtil.savejobSyncHistory(content, companyId);

    DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
    Date syncSuccessDate = null;
    try {
      highDate = new SimpleDateFormat("yyyy-MM-dd").format(new Date(System.currentTimeMillis() - 24 * 60 * 60 * 1000));
      syncSuccessDate = (Date) formatter.parse(highDate);
      logger.debug("sync success date: " + syncSuccessDate);
    } catch (ParseException e) {
      // TODO Auto-generated catch block
      logger.debug("Parse sync success date error with exception: " + e.getMessage());
    }
    compInfo.setLastJobSyncDate(syncSuccessDate);
    companyInfoService.saveCompanyInfo(compInfo);
    /* Clear the bean used by job sync scheduler */
    companyIdInfo.setCompanyId(null);

  }

  @SuppressWarnings("unchecked")
  private boolean isActiveJob(HashMap<String, Object> resultMap, List<String> items) {

    String jobStatus = "0";

    HashMap<String, Object> jobStatusMap = (HashMap<String, Object>) resultMap.get("status");
    if (!jobStatusMap.isEmpty()) {
      List<HashMap<String, Object>> jobStatusMapResults = (List<HashMap<String, Object>>) jobStatusMap.get("results");
      if (!jobStatusMapResults.isEmpty()) {
        HashMap<String, Object> jobStatusResultsData = jobStatusMapResults.get(0);
        jobStatus = (String) jobStatusResultsData.get("id");
      } else {
        jobStatus = "EMPTY";
      }
    } else {
      jobStatus = "EMPTY";
    }

    if (!items.contains(jobStatus)) {
      return false;
    }

    return true;
  }

  @SuppressWarnings("unchecked")
  private boolean isPostedJob(HashMap<String, Object> resultMap) {
    HashMap<String, Object> jobReqPostingsListD = (HashMap<String, Object>) resultMap.get("jobReqPostings");
    if (jobReqPostingsListD != null) {
      List<HashMap<String, Object>> jobReqPostingsList = (List<HashMap<String, Object>>) jobReqPostingsListD
          .get("results");
      for (HashMap<String, Object> result : jobReqPostingsList) {
        String postingStatus = (String) result.get("postingStatus");
        String boardId = (String) result.get("boardId");
        if ((postingStatus.equals("Updated") || postingStatus.equals("Success") || postingStatus
            .equals("Repost_Success")) && (boardId.equals("_private_external") || boardId.equals("_external"))) {
          String postStartDateOffset = (String) result.get("postStartDateOffset");
          if (postStartDateOffset != null) {
            postStartDate = this.parseDate(postStartDateOffset);
          }
          String postEndDateOffset = (String) result.get("postEndDateOffset");
          if (postEndDateOffset != null) {
            postEndDate = this.parseDate(postEndDateOffset);
          }
          return true;
        }
      }
    }
    return false;
  }

  @SuppressWarnings("unchecked")
  private void loadJobReqRequstionAndChoice(HashMap<String, Object> resultMap) throws ServiceApplicationException {
    HashMap<String, Object> jobReqQuestionListD = (HashMap<String, Object>) resultMap.get("jobReqScreeningQuestions");
    List<HashMap<String, Object>> jobReqQuestionList = (List<HashMap<String, Object>>) jobReqQuestionListD
        .get("results");
    for (HashMap<String, Object> result : jobReqQuestionList) {

      WechatJobScreeningQuestion wechatJobScreeningQuestion = new WechatJobScreeningQuestion();
      wechatJobScreeningQuestion.setQuestionLocale((String) result.get("locale"));
      wechatJobScreeningQuestion.setQuestionOrder(Long.parseLong((String) result.get("order")));
      wechatJobScreeningQuestion.setQuestionId((String) result.get("questionId"));
      wechatJobScreeningQuestion.setQuestionName((String) result.get("questionName"));
      wechatJobScreeningQuestion.setRatingScale((String) result.get("ratingScale"));
      wechatJobScreeningQuestion.setQuestionType((String) result.get("questionType"));
      wechatJobScreeningQuestion.setRequired((boolean) result.get("required"));
      wechatJobScreeningQuestion.setJobReqId((String) result.get("jobReqId"));
      wechatJobScreeningQuestion.setMaxLength((String) result.get("maxLength"));
      if (companyIdInfo.getCompanyId() != null) {
        wechatJobScreeningQuestion.setCompanyId(companyIdInfo.getCompanyId());
      } else {
        wechatJobScreeningQuestion.setCompanyId(params.getCompanyId());
      }
      wechatJobScreeningQuestionService.saveJobScreeningQuestion(wechatJobScreeningQuestion);
      HashMap<String, Object> jobReqQuestionChoiceListD = (HashMap<String, Object>) result.get("choices");
      if (jobReqQuestionChoiceListD != null) {
        List<HashMap<String, Object>> jobReqQuestionChoiceList = (List<HashMap<String, Object>>) jobReqQuestionChoiceListD
            .get("results");
        for (HashMap<String, Object> choice : jobReqQuestionChoiceList) {
          WechatJobScreeningQuestionChoice wechatJobScreeningQuestionChoice = new WechatJobScreeningQuestionChoice();
          wechatJobScreeningQuestionChoice.setChoiceLocale((String) choice.get("locale"));
          if (companyIdInfo.getCompanyId() != null) {
            wechatJobScreeningQuestionChoice.setCompanyId(companyIdInfo.getCompanyId());
          } else {
            wechatJobScreeningQuestionChoice.setCompanyId(params.getCompanyId());
          }

          wechatJobScreeningQuestionChoice.setOptionId(Long.parseLong((String) choice.get("optionId")));
          wechatJobScreeningQuestionChoice.setOptionLabel((String) choice.get("optionLabel"));
          wechatJobScreeningQuestionChoice.setOptionValue(Double.parseDouble((String) choice.get("optionValue")));
          wechatJobScreeningQuestionChoice.setJobReqQuestionChoiceKey(wechatJobScreeningQuestionService
              .constructJobReqQuestionChoiceKey(wechatJobScreeningQuestion.getQuestionOrder().toString(),
                  wechatJobScreeningQuestion.getJobReqId(), wechatJobScreeningQuestion.getQuestionLocale()));
          wechatJobScreeningQuestionChoiceService.saveJobScreeningQuestionChoice(wechatJobScreeningQuestionChoice);
        }
      }

    }
  }

  private QueryInfo buildLoadJobQueryOptions(HashMap<String, List<String>> selectAndExpandListMap, String jobReqIdStr,
      String lowDate, String highDate, boolean isJobSync) throws ServiceApplicationException {
    List<String> expandList = selectAndExpandListMap.get("expand");
    List<String> selectList = selectAndExpandListMap.get("select");

    QueryInfo queryInfo = new QueryInfo(SFODataEntityType.JOBREQUISITION.getName());

    String select = StringUtils.collectionToDelimitedString(selectList, ",");
    String expand = StringUtils.collectionToDelimitedString(expandList, ",");

    queryInfo.addQueryOption(QueryOptionEnum.SELECT, select);
    queryInfo.addQueryOption(QueryOptionEnum.EXPAND, expand);

    Long jobReqId = 0L;
    List<String> jobReqIdList = new ArrayList<String>();

    Date lDate = new Date(0000);
    Date hDate = new Date(Long.MAX_VALUE);
    DateTime lowDateTime = new DateTime(0000, 1, 1, 0, 0, 0, DateTimeZone.UTC);
    DateTime highDateTime = new DateTime(9999, 1, 1, 0, 0, 0, DateTimeZone.UTC);

    DateFormat format1 = new SimpleDateFormat("yyyy-MM-dd");
    if (!StringUtils.isEmpty(lowDate) && !lowDate.equals("undefined")) {
      try {
        lDate = format1.parse(lowDate);
      } catch (ParseException e) {
        throw new ServiceApplicationException("Low Date Parse Error" + e.getMessage());
      }
      lowDateTime = new DateTime(lDate);
      // lowDateTime = lowDateTime.plusHours(25);
    }
    if (!StringUtils.isEmpty(highDate) && !highDate.equals("undefined")) {
      try {
        hDate = format1.parse(highDate);
      } catch (ParseException e) {
        throw new ServiceApplicationException("High Date Parse Error: " + e.getMessage());
      }
      highDateTime = new DateTime(hDate);
      highDateTime = highDateTime.plusHours(25);
    }
    DateTime lowDateTimeUTC;
    DateTime highDateTimeUTC;
    if (isJobSync) {
      lowDateTimeUTC = lowDateTime.withZone(DateTimeZone.forID("CST6CDT"));
      highDateTimeUTC = highDateTime.withZone(DateTimeZone.forID("CST6CDT"));
    } else {
      lowDateTimeUTC = lowDateTime.withZone(DateTimeZone.UTC);
      highDateTimeUTC = highDateTime.withZone(DateTimeZone.UTC);
    }
    String filter = null;

    if (!jobReqIdStr.isEmpty()) {
      if (jobReqIdStr.contains(",")) {
        jobReqIdList = Arrays.asList(jobReqIdStr.split(","));
        if (!jobReqIdList.isEmpty()) {
          for (String reqId : jobReqIdList) {
            if (jobReqIdList.get(0).equals(reqId)) {
              filter = "deleted eq '0' and (jobReqId eq " + reqId;
            } else {
              filter = filter + " or jobReqId eq " + reqId;
            }
          }
          filter = filter + ")";
          queryInfo.addQueryOption(QueryOptionEnum.FILTER, filter);
        }
      } else {
        jobReqId = Long.parseLong(jobReqIdStr);
        filter = "(jobReqId eq " + String.valueOf(jobReqId) + ")" + " and deleted eq '0'";
        queryInfo.addQueryOption(QueryOptionEnum.FILTER, filter);
      }

    }

    if (jobReqId == 0 && jobReqIdStr.isEmpty()) {
      queryInfo = new QueryInfo(SFODataEntityType.JOBREQUISITION.getName());

      queryInfo.addQueryOption(QueryOptionEnum.SELECT, select);
      queryInfo.addQueryOption(QueryOptionEnum.EXPAND, expand);
      if (!isJobSync) {
        filter = "deleted eq '0' and ";
      } else {
        filter = "";
      }
      filter = filter + "lastModifiedDateTime ge datetimeoffset'" + lowDateTimeUTC.toString() + "'"
          + " and lastModifiedDateTime le datetimeoffset'" + highDateTimeUTC.toString() + "'";
      logger.error("time filter: " + filter);
      queryInfo.addQueryOption(QueryOptionEnum.FILTER, filter);

    }
    return queryInfo;

  }

  private HashMap<String, List<String>> buildSelectAndExpandList(JobReqDataModelMapping jobReqMapping)
      throws ServiceApplicationException {
    HashMap<String, List<String>> selectAndExpandListMap = new HashMap<String, List<String>>();
    // default expand
    List<String> expandList = new ArrayList<String>();
    expandList.add("jobReqLocale");
    expandList.add("recruiter");
    expandList.add("status");
    expandList.add("jobReqPostings");
    expandList.add("jobReqScreeningQuestions/choices");
    // default select
    List<String> selectList = new ArrayList<String>();
    selectList.add("jobReqLocale");
    selectList.add("recruiter");
    selectList.add("status");
    selectList.add("jobReqId");
    selectList.add("statusSetId");
    selectList.add("deleted");
    selectList.add("lastModifiedDateTime");
    selectList.add("internalStatus");
    selectList.add("jobReqPostings");
    selectList.add("jobReqScreeningQuestions");

    List<JobReqDataModelMappingItem> itemList = jobReqMapping.getItems();

    for (JobReqDataModelMappingItem mappingItem : itemList) {

      String sfDmField = mappingItem.getSfDmField();
      if (!StringUtils.isEmpty(sfDmField) && sfDmField.contains("/")) {
        String arrField[] = sfDmField.split("/");
        if (!expandList.contains(arrField[0])) {
          expandList.add(arrField[0]);
        }
        if (!selectList.contains(arrField[0])) {
          selectList.add(arrField[0]);
        }
      } else if (!StringUtils.isEmpty(sfDmField)) {

        if (!StringUtils.isEmpty(mappingItem.getPicklist())) {
          if (!expandList.contains(sfDmField)) {
            expandList.add(sfDmField);
          }
        }
        if (!selectList.contains(sfDmField)) {
          selectList.add(sfDmField);
        }
      }
    }

    selectAndExpandListMap.put("expand", expandList);
    selectAndExpandListMap.put("select", selectList);

    return selectAndExpandListMap;
  }

  public Date parseDate(String dateString) {
    Date date = null;
    if (dateString != null) {
      Calendar calendar = Calendar.getInstance();
      String regex = "(?<=Date\\()\\d+(?=\\+)";
      calendar.setTimeInMillis(Long.valueOf(MappingUtil.matchSingle(regex, dateString)));
      date = calendar.getTime();
    } else {
      date = null;
    }
    return date;
  }

  @SuppressWarnings("unchecked")
  @Override
  public Map<String, Object> getJobRequisitionForSearch(String condition) throws UnsupportedEncodingException {
    Map<String, Object> map = new HashMap<String, Object>();
    List<JobRequisitionBean> jobInfoList = new ArrayList<JobRequisitionBean>();

    if (condition != null && !condition.equals("undefined")) {
      condition = java.net.URLDecoder.decode(condition, StandardCharsets.UTF_8.name());
    } else if (condition == null) {
      condition = "";
    }
    try {
      String companyId = params.getCompanyId();
      CompanyInfo info = this.companyInfoService.getCompanyInfo(companyId);

      condition = URLEncoder.encode(condition, "utf-8");

      String selectItem = "jobReqId,statusSetId,status,jobReqPostings,deleted,jobReqLocale/jobTitle";
      String expandItem = "jobReqLocale,status,jobReqPostings";
      String filterItem = "substringof(tolower('" + condition + "'),tolower(jobReqLocale/jobTitle))";
      Pattern pattern = Pattern.compile("[0-9]*");
      if (pattern.matcher(condition).matches()) {
        filterItem = filterItem + "%20or%20(jobReqId%20eq%20" + condition;
      }
      QueryInfo queryInfo = new QueryInfo("JobRequisition");
      queryInfo.addQueryOption(QueryOptionEnum.SELECT, selectItem);
      queryInfo.addQueryOption(QueryOptionEnum.EXPAND, expandItem);
      queryInfo.addQueryOption(QueryOptionEnum.FILTER, filterItem);

      // String jobRequisitioonJsonString = sfJobApplicationService.getOdataFeedStringFromSF(queryInfo);
      String jobRequisitioonJsonString = sfOdataService.readFeedAsString(APPLICATION_JSON, queryInfo);

      HashMap<String, Object> jobReqMap = new ObjectMapper().readValue(jobRequisitioonJsonString, HashMap.class);
      HashMap<String, Object> jobReqMapD = (HashMap<String, Object>) jobReqMap.get("d");
      List<HashMap<String, Object>> jobReqMapResults = (List<HashMap<String, Object>>) jobReqMapD.get("results");

      String jobStatuses = info.getJobStatuses();
      List<String> items = Arrays.asList(jobStatuses.split("\\s*,\\s*"));

      for (HashMap<String, Object> resultMap : jobReqMapResults) {

        if (!this.isActiveJob(resultMap, items) || !this.isPostedJob(resultMap) || !this.inPostTimeZone(resultMap)) {
          continue;
        }

        JobRequisitionBean bean = new JobRequisitionBean();
        bean.setJobReqId((String) resultMap.get("jobReqId"));
        bean.setStatusSetId((String) resultMap.get("statusSetId"));

        HashMap<String, Object> jobReqLocaleMap = (HashMap<String, Object>) resultMap.get("jobReqLocale");
        List<HashMap<String, Object>> jobReqLocaleMapResults = (List<HashMap<String, Object>>) jobReqLocaleMap
            .get("results");
        HashMap<String, Object> jobReqLocaleMapResultsData = jobReqLocaleMapResults.get(0);
        bean.setJobTitle((String) jobReqLocaleMapResultsData.get("jobTitle"));
        jobInfoList.add(bean);
      }

    } catch (Exception e) {
      e.printStackTrace();
    }

    map.put("jobInfoList", jobInfoList);
    map.put("count", jobInfoList.size());
    return map;
  }

  @SuppressWarnings("unchecked")
  private boolean inPostTimeZone(HashMap<String, Object> resultMap) {
    HashMap<String, Object> jobReqPostingsListD = (HashMap<String, Object>) resultMap.get("jobReqPostings");
    if (jobReqPostingsListD != null) {
      List<HashMap<String, Object>> jobReqPostingsList = (List<HashMap<String, Object>>) jobReqPostingsListD
          .get("results");
      for (HashMap<String, Object> result : jobReqPostingsList) {
        String boardId = (String) result.get("boardId");
        String postStartDate = (String) result.get("postStartDateOffset");
        String postEndDate = (String) result.get("postEndDateOffset");
        Date startDate = parseDate(postStartDate);
        Date endDate = parseDate(postEndDate);
        Date nowDate = new Date();
        if (boardId.equals("_private_external") || boardId.equals("_external")) {
          if (endDate == null && !startDate.after(nowDate)) {
            return true;
          } else if (!(startDate.before(nowDate) && endDate.before(nowDate)) &&
              (!(startDate.after(nowDate) && endDate.after(nowDate)))) {
            return true;
          }
        }
      }
    }
    return false;
  }

}
