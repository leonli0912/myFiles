package com.sap.hcm.resume.collection.entity.view;

import java.io.Serializable;

import com.sap.hcm.resume.collection.annotation.ProfileAttribute;
import com.sap.hcm.resume.collection.util.I18nMessages;
import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("education")
public class CandidateBgEducationVO implements CandidateBgBase, Serializable{

	/**
	 * serialVersionUID
	 */
    private static final long serialVersionUID = 8714060539592000604L;
    
    @ProfileAttribute(name="major", type=String.class, label=I18nMessages.LABEL_MAJOR)
    private String major;
    
    @ProfileAttribute(name="school", type=String.class, label=I18nMessages.LABEL_SCHOOL)
    private String school;
    
    @ProfileAttribute(name="degree", type=String.class, label=I18nMessages.LABEL_DEGREE)
    private String degree;
    
    @ProfileAttribute(name="startDate", type=String.class, label=I18nMessages.LABEL_START_DATE)
    private String startDate;
    
    @ProfileAttribute(name="endDate", type=String.class, label=I18nMessages.LABEL_END_DATE)
    private String endDate;
    
    @ProfileAttribute(name="schoolState", type=String.class, label=I18nMessages.LABEL_SCHOOL_STATE)
    private String schoolState;
    
    @ProfileAttribute(name="gpa", type=String.class, label=I18nMessages.LABEL_GPA)
    private String gpa;

	/**
	 * @return the schoolState
	 */
	public String getSchoolState() {
		return schoolState;
	}

	/**
	 * @param schoolState the schoolState to set
	 */
	public void setSchoolState(String schoolState) {
		this.schoolState = schoolState;
	}

	/**
	 * @return the gpa
	 */
	public String getGpa() {
		return gpa;
	}

	/**
	 * @param gpa the gpa to set
	 */
	public void setGpa(String gpa) {
		this.gpa = gpa;
	}

	/**
	 * @return the major
	 */
	public String getMajor() {
		return major;
	}

	/**
	 * @param major the major to set
	 */
	public void setMajor(String major) {
		this.major = major;
	}

	/**
	 * @return the school
	 */
	public String getSchool() {
		return school;
	}

	/**
	 * @param school the school to set
	 */
	public void setSchool(String school) {
		this.school = school;
	}

	/**
	 * @return the degree
	 */
	public String getDegree() {
		return degree;
	}

	/**
	 * @param degree the degree to set
	 */
	public void setDegree(String degree) {
		this.degree = degree;
	}

	/**
	 * @return the startDate
	 */
	public String getStartDate() {
		return startDate;
	}

	/**
	 * @param startDate the startDate to set
	 */
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	/**
	 * @return the endDate
	 */
	public String getEndDate() {
		return endDate;
	}

	/**
	 * @param endDate the endDate to set
	 */
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

}
