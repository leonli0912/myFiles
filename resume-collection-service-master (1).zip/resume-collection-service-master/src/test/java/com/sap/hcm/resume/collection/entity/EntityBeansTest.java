package com.sap.hcm.resume.collection.entity;

import org.junit.Assert;
import org.junit.Test;

import com.sap.hcm.resume.collection.integration.wechat.entity.WechatApplyHistory;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJobApplicationVO;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJobVO;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatUser;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatUserResumeMapping;
import com.sap.hcm.resume.collection.util.BeanTestUtil;

public class EntityBeansTest {
  @Test
  public void testGetterSetter() {
    BeanTestUtil.registerBean4Test(CandBackgroundID.class);
    BeanTestUtil.registerBean4Test(CandidateBackground.class);
    BeanTestUtil.registerBean4Test(CandidateProfile.class);
    BeanTestUtil.registerBean4Test(CandidateProfileExt.class);
    BeanTestUtil.registerBean4Test(CandProExtID.class);
    BeanTestUtil.registerBean4Test(DataModelMapping.class);
    BeanTestUtil.registerBean4Test(ExceptionLog.class);
    BeanTestUtil.registerBean4Test(Photo.class);
    BeanTestUtil.registerBean4Test(UserInfo.class);
    BeanTestUtil.registerBean4Test(WechatApplyHistory.class);
    BeanTestUtil.registerBean4Test(WechatJobApplicationVO.class);
    BeanTestUtil.registerBean4Test(WechatJobVO.class);
    BeanTestUtil.registerBean4Test(WechatUser.class);
    BeanTestUtil.registerBean4Test(WechatUserResumeMapping.class);

    BeanTestUtil.processBeanTest();

  }
  
  @Test
  public void testCandidateBackground(){
    CandidateBackground bg = new CandidateBackground();
    bg.setCandidateId(1L);
    Assert.assertEquals(bg.getCandidateId().toString(), "1");
  }
  
  @Test
  public void testCandidateProfileExt(){
    CandidateProfileExt ext = new CandidateProfileExt();
    
    ext.setCandidateId(1L);
    ext.setCompanyId("test");
    ext.setDateValue(null);
    ext.setParamName("test");
    ext.setStringValue("test");
    ext.setBlobValue(null);
    
    Assert.assertEquals(ext.getCandidateId().toString(), "1");
    Assert.assertEquals(ext.getCompanyId(), "test");
    Assert.assertEquals(ext.getDateValue(), null);
    Assert.assertEquals(ext.getParamName(),"test");
    Assert.assertEquals(ext.getStringValue(),"test");
    Assert.assertEquals(ext.getBlobValue(), null);
  }
  
  @Test
  public void testCompanyInfo(){
    CompanyInfo info = new CompanyInfo();
    
    info.setShortDescription("test");
    info.setLongDescription("test");
    info.setPhone("test");
    info.setWechatServerUrl("test");
    info.setContactEmail("test");
    info.setWebsite("test");
    info.setCountry("test");
    info.setEmailPostfix("test");
    
    Assert.assertEquals(info.getLongDescription(), "test");
    Assert.assertEquals(info.getShortDescription(), "test");
    Assert.assertEquals(info.getPhone(), "test");
    Assert.assertEquals(info.getWechatServerUrl(), "test");
    Assert.assertEquals(info.getContactEmail(), "test");
    Assert.assertEquals(info.getWebsite(), "test");
    Assert.assertEquals(info.getCountry(), "test");
    Assert.assertEquals(info.getEmailPostfix(), "test");
  }
  

  @Test
  public void testDataModelMapping(){
    DataModelMapping dm = new DataModelMapping();
    dm.setMappingType("test");
    dm.setLastmodify(null);
    
    Assert.assertEquals(dm.getMappingType(), "test");
    Assert.assertEquals(dm.getLastmodify(), null);
  }
  
  @Test
  public void testExceptionLog(){
    ExceptionLog log = new ExceptionLog();
    log.setLogId(1L);
    log.setCompanyId("test");
    log.setCreateAt("test");
    log.setExceptionType("test");
    log.setFunctionType("test");
    log.setExceptionMessage("message");
    
    Assert.assertEquals(log.getLogId(), 1);
    Assert.assertEquals(log.getCompanyId(), "test");
    Assert.assertEquals(log.getCreateAt(), "test");
    Assert.assertEquals(log.getExceptionType(), "test");
    Assert.assertEquals(log.getFunctionType(), "test");
    Assert.assertEquals(log.getExceptionMessage(), "message");
  }
  
  @Test
  public void testPhoto(){
    Photo p = new Photo();
    p.setCategory("test");
    Assert.assertEquals(p.getCategory(), "test");
  }
  
  @Test
  public void testUserInfo(){
    UserInfo info = new UserInfo();
    info.setUserId(1L);
    info.setFristName("test");
    info.setLastName("test");
    
    Assert.assertEquals(info.getUserId().toString(), "1");
    Assert.assertEquals(info.getFristName(), "test");
    Assert.assertEquals(info.getLastName(), "test");
  }
}
