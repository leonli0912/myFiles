package com.sap.hcm.resume.collection.bean;

/**
 * @author I075908 SAP
 */
public class JobReqScreeningQuestionChoice {
  private String choiceKey;

  private long optionId;

  private double optionValue;
  
  private String optionLabel;

  private String locale;

  public String getChoiceKey() {
    return choiceKey;
  }

  public void setChoiceKey(String choiceKey) {
    this.choiceKey = choiceKey;
  }

  public long getOptionId() {
    return optionId;
  }

  public void setOptionId(long optionId) {
    this.optionId = optionId;
  }

  public double getOptionValue() {
    return optionValue;
  }

  public void setOptionValue(double optionValue) {
    this.optionValue = optionValue;
  }

  /**
   * @return the optionLabel
   */
  public String getOptionLabel() {
    return optionLabel;
  }

  /**
   * @param optionLabel the optionLabel to set
   */
  public void setOptionLabel(String optionLabel) {
    this.optionLabel = optionLabel;
  }

  public String getLocale() {
    return locale;
  }

  public void setLocale(String locale) {
    this.locale = locale;
  }

}
