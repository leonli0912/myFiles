package com.sap.hcm.resume.collection.integration.wechat.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.sap.hcm.resume.collection.annotation.RequisitionAttribute;

@Entity
@Table(name = "WECHAT_JOB")
public class WechatJob {

  @Id
  @GeneratedValue(strategy = GenerationType.TABLE, generator = "wechat_job_seq")
  @TableGenerator(initialValue = 1, table = "SEQUENCE", name = "wechat_job_seq", pkColumnName = "SEQ_NAME", valueColumnName = "SEQ_COUNT", pkColumnValue = "WECHAT_JOB_PK", allocationSize = 1)
  @Column(name = "job_id")
  private Long jobId;

  @Column(name = "company_id")
  private String companyId;

  @Column(name = "ext_job_id", length = 50)
  @RequisitionAttribute(name = "externalJobId", type = Long.class, label = "REQUISITION_ID")
  private String externalJobId;

  @Column(name = "country", length = 20)
  @RequisitionAttribute(name = "country", type = String.class, label = "COUNTRY")
  private String country;

  @Column(name = "city", length = 20)
  @RequisitionAttribute(name = "city", type = String.class, label = "CITY", filterable = false)
  private String city;

  @Column(name = "location", length = 200)
  @RequisitionAttribute(name = "location", type = String.class, label = "LOCATION", filterable = true)
  private String location;

  /**
   * refer to JobIndustryEnum
   */
  @Column(name = "industry", length = 100)
  @RequisitionAttribute(name = "industry", type = String.class, label = "JOB_INDUSTRY")
  private String industry;

  /**
   * refer to JobCareerStatusEnum
   */
  @Column(name = "career_status", length = 15)
  @RequisitionAttribute(name = "careerStatus", type = String.class, label = "CAREER_STATUS")
  private String careerStatus;

  @Column(name = "jobTitle", length = 2000)
  @RequisitionAttribute(name = "jobTitle", type = String.class, label = "JOB_TITLE")
  private String jobTitle;

  /**
   * full time part time refer to JobEmploymentTypeEnum
   */
  @Column(name = "employment_type", length = 20)
  @RequisitionAttribute(name = "employmentType", type = String.class, label = "EMPLOYMENT_TYPE")
  private String employmentType;

  @Column(name = "recruiter", length = 50)
  @RequisitionAttribute(name = "recruiterName", type = String.class, label = "RECRUITER_NAME")
  private String recruiterName;

  @Column(name = "department", length = 300)
  @RequisitionAttribute(name = "department", type = String.class, label = "DEPARTMENT")
  private String department;

  @Column(name = "salary", length = 15)
  @RequisitionAttribute(name = "salary", type = String.class, label = "JOB_SALARY")
  private String salary;

  @Column(name = "work_area", length = 50)
  @RequisitionAttribute(name = "workArea", type = String.class, label = "WORK_AREA")
  private String workArea;

  @Column(name = "career_level", length = 10)
  @RequisitionAttribute(name = "careerLevel", type = String.class, label = "CAREER_LEVEL")
  private String careerLevel;

  @Column(name = "expected_travel", length = 20)
  @RequisitionAttribute(name = "expectedTravel", type = String.class, label = "EXPECTED_TRAVEL")
  private String expectedTravel;

  /**
   * description of the job
   */
  @Column(name = "description")
  @Lob
  @RequisitionAttribute(name = "jobDescription", type = byte.class, label = "JOB_DESCRIPTION")
  private byte[] jobDescription;

  /**
   * expectation from the candidate
   */
  @Column(name = "expectation", length = 4000)
  @RequisitionAttribute(name = "jobExpectation", type = String.class, label = "JOB_EXPECTATION")
  private String jobExpectation;

  /**
   * job responsibility
   */
  @Column(name = "responsiblity", length = 4000)
  @RequisitionAttribute(name = "jobResponsiblity", type = String.class, label = "JOB_DETAIL_JOB_RESPONSIBILITY")
  private String jobResponsiblity;

  /**
   * qualification required from candidate
   */
  @Column(name = "qualification", length = 4000)
  @RequisitionAttribute(name = "jobQualification", type = String.class, label = "JOB_QUALIFICATION")
  private String jobQualification;

  /**
   * benefit could given by this job e.g. social insurance
   */
  @Column(name = "benefit", length = 4000)
  @RequisitionAttribute(name = "jobBenefit", type = String.class, label = "JOB_BENEFIT")
  private String jobBenefit;

  @Column(name = "educationReq", length = 500)
  private String educationReq;

  /**
   * shining point of the job e.g. special service
   */
  @Column(name = "jobFeature", length = 500)
  @RequisitionAttribute(name = "jobFeature", type = String.class, label = "JOB_FEATURE")
  private String jobFeature;

  @Column(name = "sf_status_setid", length = 10)
  private String sfStatusSetId;

  /**
   * status of the job refer to JobStatusEnum
   */
  @Column(name = "status", length = 2)
  private int status;

  @Column(name = "create_at")
  @Temporal(TemporalType.DATE)
  private Date createAt;

  @Column(name = "post_start_date")
  @Temporal(TemporalType.DATE)
  private Date postStartDate;

  @Column(name = "post_end_date")
  @Temporal(TemporalType.DATE)
  private Date postEndDate;

  @Column(name = "changed_by", length = 50)
  private String changedBy;

  @Column(name = "job_desc_video_name", length = 50)
  private String jobDescVideoName;

  @Column(name = "lastmodify")
  @Temporal(TemporalType.DATE)
  private Date lastModify;

  @Column(name = "req_mapping_id", length = 11)
  private String reqMappingId;

  /**
   * @return the jobId
   */
  public Long getJobId() {
    return jobId;
  }

  /**
   * @param jobId
   *          the jobId to set
   */
  public void setJobId(Long jobId) {
    this.jobId = jobId;
  }

  /**
   * @return the companyId
   */
  public String getCompanyId() {
    return companyId;
  }

  /**
   * @param companyId
   *          the companyId to set
   */
  public void setCompanyId(String companyId) {
    this.companyId = companyId;
  }

  /**
   * @return the externalJobId
   */
  public String getExternalJobId() {
    return externalJobId;
  }

  /**
   * @param externalJobId
   *          the externalJobId to set
   */
  public void setExternalJobId(String externalJobId) {
    this.externalJobId = externalJobId;
  }

  /**
   * @return the country
   */
  public String getCountry() {
    return country;
  }

  /**
   * @param country
   *          the country to set
   */
  public void setCountry(String country) {
    this.country = country;
  }

  /**
   * @return the city
   */
  public String getCity() {
    return city;
  }

  /**
   * @param city
   *          the city to set
   */
  public void setCity(String city) {
    this.city = city;
  }

  /**
   * @return the location
   */
  public String getLocation() {
    return location;
  }

  /**
   * @param location
   *          the location to set
   */
  public void setLocation(String location) {
    this.location = location;
  }

  /**
   * @return the industry
   */
  public String getIndustry() {
    return industry;
  }

  /**
   * @param industry
   *          the industry to set
   */
  public void setIndustry(String industry) {
    this.industry = industry;
  }

  /**
   * @return the careerStatus
   */
  public String getCareerStatus() {
    return careerStatus;
  }

  /**
   * @param careerStatus
   *          the careerStatus to set
   */
  public void setCareerStatus(String careerStatus) {
    this.careerStatus = careerStatus;
  }

  /**
   * @return the jobTitle
   */
  public String getJobTitle() {
    return jobTitle;
  }

  /**
   * @param jobTitle
   *          the jobTitle to set
   */
  public void setJobTitle(String jobTitle) {
    this.jobTitle = jobTitle;
  }

  /**
   * @return the employmentType
   */
  public String getEmploymentType() {
    return employmentType;
  }

  /**
   * @param employmentType
   *          the employmentType to set
   */
  public void setEmploymentType(String employmentType) {
    this.employmentType = employmentType;
  }

  /**
   * @return the recruiterName
   */
  public String getRecruiterName() {
    return recruiterName;
  }

  /**
   * @param recruiterName
   *          the recruiterName to set
   */
  public void setRecruiterName(String recruiterName) {
    this.recruiterName = recruiterName;
  }

  public String getDepartment() {
    return department;
  }

  public void setDepartment(String department) {
    this.department = department;
  }

  /**
   * @return the workArea
   */
  public String getWorkArea() {
    return workArea;
  }

  /**
   * @param workArea
   *          the workArea to set
   */
  public void setWorkArea(String workArea) {
    this.workArea = workArea;
  }

  /**
   * @return the careerLevel
   */
  public String getCareerLevel() {
    return careerLevel;
  }

  /**
   * @param careerLevel
   *          the careerLevel to set
   */
  public void setCareerLevel(String careerLevel) {
    this.careerLevel = careerLevel;
  }

  /**
   * @return the expectedTravel
   */
  public String getExpectedTravel() {
    return expectedTravel;
  }

  /**
   * @param expectedTravel
   *          the expectedTravel to set
   */
  public void setExpectedTravel(String expectedTravel) {
    this.expectedTravel = expectedTravel;
  }

  /**
   * @return the jobDescription
   */
  public byte[] getJobDescription() {
    return jobDescription;
  }

  /**
   * @param jobDescription
   *          the jobDescription to set
   */
  public void setJobDescription(byte[] jobDescription) {
    this.jobDescription = jobDescription;
  }

  /**
   * @return the jobExpectation
   */
  public String getJobExpectation() {
    return jobExpectation;
  }

  /**
   * @param jobExpectation
   *          the jobExpectation to set
   */
  public void setJobExpectation(String jobExpectation) {
    this.jobExpectation = jobExpectation;
  }

  /**
   * @return the jobQualification
   */
  public String getJobQualification() {
    return jobQualification;
  }

  /**
   * @param jobQualification
   *          the jobQualification to set
   */
  public void setJobQualification(String jobQualification) {
    this.jobQualification = jobQualification;
  }

  /**
   * @return the jobResponsiblity
   */
  public String getJobResponsiblity() {
    return jobResponsiblity;
  }

  /**
   * @param jobResponsiblity
   *          the jobResponsiblity to set
   */
  public void setJobResponsiblity(String jobResponsiblity) {
    this.jobResponsiblity = jobResponsiblity;
  }

  /**
   * @return the createAt
   */
  public Date getCreateAt() {
    return createAt;
  }

  /**
   * @param createAt
   *          the createAt to set
   */
  public void setCreateAt(Date createAt) {
    this.createAt = createAt;
  }

  /**
   * @return the changedBy
   */
  public String getChangedBy() {
    return changedBy;
  }

  /**
   * @param changedBy
   *          the changedBy to set
   */
  public void setChangedBy(String changedBy) {
    this.changedBy = changedBy;
  }

  /**
   * @return the lastModify
   */
  public Date getLastModify() {
    return lastModify;
  }

  /**
   * @return the sfStatusSetId
   */
  public String getSfStatusSetId() {
    return sfStatusSetId;
  }

  /**
   * @param sfStatusSetId
   *          the sfStatusSetId to set
   */
  public void setSfStatusSetId(String sfStatusSetId) {
    this.sfStatusSetId = sfStatusSetId;
  }

  public int getStatus() {
    return status;
  }

  public void setStatus(int status) {
    this.status = status;
  }

  /**
   * @param lastModify
   *          the lastModify to set
   */
  public void setLastModify(Date lastModify) {
    this.lastModify = lastModify;
  }

  /**
   * @return the jobBenefit
   */
  public String getJobBenefit() {
    return jobBenefit;
  }

  /**
   * @param jobBenefit
   *          the jobBenefit to set
   */
  public void setJobBenefit(String jobBenefit) {
    this.jobBenefit = jobBenefit;
  }

  public String getEducationReq() {
    return educationReq;
  }

  public void setEducationReq(String educationReq) {
    this.educationReq = educationReq;
  }

  public String getJobFeature() {
    return jobFeature;
  }

  public void setJobFeature(String jobFeature) {
    this.jobFeature = jobFeature;
  }

  public String getJobDescVideoName() {
    return jobDescVideoName;
  }

  public void setJobDescVideoName(String jobDescVideoName) {
    this.jobDescVideoName = jobDescVideoName;
  }

  public String getSalary() {
    return salary;
  }

  public void setSalary(String salary) {
    this.salary = salary;
  }

  /**
   * @return the reqMappingId
   */
  public String getReqMappingId() {
    return reqMappingId;
  }

  /**
   * @param reqMappingId
   *          the reqMappingId to set
   */
  public void setReqMappingId(String reqMappingId) {
    this.reqMappingId = reqMappingId;
  }

  public Date getPostStartDate() {
    return postStartDate;
  }

  public void setPostStartDate(Date postStartDate) {
    this.postStartDate = postStartDate;
  }

  public Date getPostEndDate() {
    return postEndDate;
  }

  public void setPostEndDate(Date postEndDate) {
    this.postEndDate = postEndDate;
  }

}
