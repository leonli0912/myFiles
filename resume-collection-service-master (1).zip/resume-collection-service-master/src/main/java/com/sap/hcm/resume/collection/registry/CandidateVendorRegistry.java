package com.sap.hcm.resume.collection.registry;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import com.sap.hcm.resume.collection.bean.CandidateVendor;
import com.sap.hcm.resume.collection.bean.CandidateVendorEnum;
import com.sap.hcm.resume.collection.bean.CountryEnum;
import com.sap.hcm.resume.collection.bean.KeyLabelBean;

/**
 * candidate vendor registry
 * 
 * @author i065831
 *
 */
public class CandidateVendorRegistry {
	// private constructor
	private CandidateVendorRegistry() {

	}

	private static List<CandidateVendor> candidateVendorList = new ArrayList<CandidateVendor>();

	static {
		CandidateVendor vendor = new CandidateVendor(CountryEnum.CN, CandidateVendorEnum.ZHILIAN, "智联招聘2015",
		        "static/pdf/zhilian_template.pdf");
		candidateVendorList.add(vendor);
		vendor = new CandidateVendor(CountryEnum.CN, CandidateVendorEnum.JOB51, "51Job_2015",
		        "static/pdf/51job_template.pdf");
		candidateVendorList.add(vendor);
		vendor = new CandidateVendor(CountryEnum.CN, CandidateVendorEnum.JOB51, "51Job_2016",
		        "static/pdf/51job_2016_template.pdf");
		candidateVendorList.add(vendor);
	}

	public static Set<KeyLabelBean> getAllCountries() {
		Set<KeyLabelBean> countrySet = new HashSet<KeyLabelBean>();
		for (CandidateVendor candidateVendor : candidateVendorList) {
			KeyLabelBean keyLabel = new KeyLabelBean();
			keyLabel.setKey(candidateVendor.getCountry().name());
			keyLabel.setLabel(candidateVendor.getCountry().getCountryName());
			countrySet.add(keyLabel);
		}
		return countrySet;
	}

	public static Set<KeyLabelBean> getVendorByCountry(String countryCode) {
		CountryEnum country = CountryEnum.fromCountryCode(countryCode);
		Set<KeyLabelBean> candidateNameSet = new HashSet<KeyLabelBean>();
		if (country == null) {
			return candidateNameSet;
		}
		for (CandidateVendor candidateVendor : candidateVendorList) {
			if (candidateVendor.getCountry() == country) {
				KeyLabelBean keyLabel = new KeyLabelBean();
				keyLabel.setKey(candidateVendor.getName().name());
				keyLabel.setLabel(candidateVendor.getName().getVendorName());
				candidateNameSet.add(keyLabel);
			}
		}
		return candidateNameSet;
	}

	public static Set<KeyLabelBean> getTemplateByCountryAndName(String countryCode, String vendorCode) {
		CountryEnum country = CountryEnum.fromCountryCode(countryCode);
		CandidateVendorEnum vendor = CandidateVendorEnum.fromVendorCode(vendorCode);
		Set<KeyLabelBean> templateSet = new HashSet<KeyLabelBean>();
		if (country == null) {
			return templateSet;
		}
		for (CandidateVendor candidateVendor : candidateVendorList) {
			if (candidateVendor.getCountry() == country && candidateVendor.getName() == vendor) {
				KeyLabelBean keyLabel = new KeyLabelBean();
				keyLabel.setKey(candidateVendor.getTemplateName());
				keyLabel.setLabel(candidateVendor.getTemplateName());
				keyLabel.setAdditionalText(candidateVendor.getTemplatePath());
				templateSet.add(keyLabel);
			}
		}
		return templateSet;
	}

}
