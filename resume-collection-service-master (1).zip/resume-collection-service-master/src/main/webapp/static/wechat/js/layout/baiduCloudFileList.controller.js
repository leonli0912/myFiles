sap.ui.controller("static.wechat.js.layout.baiduCloudFileList", {

	/**
	 * Called when a controller is instantiated and its View controls (if
	 * available) are already created. Can be used to modify the View before it
	 * is displayed, to bind event handlers and do other one-time
	 * initialization.
	 * 
	 * @memberOf resume-collection-service.baiduCloudFileList
	 */
	selectedFileName : "",

	GetQueryString : function(name) {
		var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)");
		var r = window.location.search.substr(1).match(reg);
		if (r != null)
			return unescape(r[2]);
		return null;
	},

	onInit : function() {
		var code = this.GetQueryString('code');
		var url = "loadBaiDuYunFileList" + "?auth_code=" + code;
		var listModel = new sap.ui.model.json.JSONModel(url);
		// var listModel = new sap.ui.model.json.JSONModel(
		// "static/wechat/js/json/file_list.json");

		this.getView().setModel(listModel);

		

	},

	saveAsResume : function() {
		 alert(this.selectedFileName);
		
		 var cfg = {
		 type : 'GET',
		 dataType : 'json'
		 };
				
		 cfg.url = "downloadFile" + "?file_name=" + this.selectedFileName;
		
		 $.ajax(cfg).success(function(data) {
			
		
		 });
	},

	onSelectionChange : function(oEvent) {
		var itemSel = oEvent.getParameters().listItem;
		var path = itemSel._getBindingContext().getPath();
		var fileNbr = path.match(/\d+/g);
		var oModel = this.getView().getModel();
		this.selectedFileName = oModel.getData()["list"][fileNbr]["path"];

	},

/**
 * Similar to onAfterRendering, but this hook is invoked before the controller's
 * View is re-rendered (NOT before the first rendering! onInit() is used for
 * that one!).
 * 
 * @memberOf resume-collection-service.baiduCloudFileList
 */
// onBeforeRendering: function() {
//
// },
/**
 * Called when the View has been rendered (so its HTML is part of the document).
 * Post-rendering manipulations of the HTML could be done here. This hook is the
 * same one that SAPUI5 controls get after being rendered.
 * 
 * @memberOf resume-collection-service.baiduCloudFileList
 */
// onAfterRendering: function() {
//
// },
/**
 * Called when the Controller is destroyed. Use this one to free resources and
 * finalize activities.
 * 
 * @memberOf resume-collection-service.baiduCloudFileList
 */
// onExit: function() {
//
// }
});