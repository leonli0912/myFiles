package com.sap.hcm.resume.collection.integration.sf.bean;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

/**
 * @author I075908 SAP
 */
@XStreamAlias("auth")
public class SFAuthenticationBean implements Serializable {

  private static final long serialVersionUID = 4541112902638951214L;

  /**
   * URL for OData API calls, e.g. http://host/odata/v2
   */
  private String serviceURL;

  private String authType;

  private String companyId;

  // Basic Auth Only
  private String basicAuth;

  // below fields are OAuth Only
  private String clientKey;

  private String tokenServiceURL;

  private String privateKey;

  private String assertion;

  private String accessToken;

  /**
   * the user who registered oauth client in SF
   */
  private String tokenServiceUser;

  public String getServiceURL() {
    return serviceURL;
  }

  public void setServiceURL(String serviceURL) {
    this.serviceURL = serviceURL;
  }

  public String getCompanyId() {
    return companyId;
  }

  public void setCompanyId(String companyId) {
    this.companyId = companyId;
  }

  public String getBasicAuth() {
    return basicAuth;
  }

  public void setBasicAuth(String basicAuth) {
    this.basicAuth = basicAuth;
  }

  public String getClientKey() {
    return clientKey;
  }

  public void setClientKey(String clientKey) {
    this.clientKey = clientKey;
  }

  public String getTokenServiceURL() {
    return tokenServiceURL;
  }

  public void setTokenServiceURL(String tokenServiceURL) {
    this.tokenServiceURL = tokenServiceURL;
  }

  public String getTokenServiceUser() {
    return tokenServiceUser;
  }

  public void setTokenServiceUser(String tokenServiceUser) {
    this.tokenServiceUser = tokenServiceUser;
  }

  public String getPrivateKey() {
    return privateKey;
  }

  public void setPrivateKey(String privateKey) {
    this.privateKey = privateKey;
  }

  public String getAuthType() {
    return authType;
  }

  public void setAuthType(String authType) {
    this.authType = authType;
  }

  public String getAssertion() {
    return assertion;
  }

  public void setAssertion(String assertion) {
    this.assertion = assertion;
  }

  public String getAccessToken() {
    return accessToken;
  }

  public void setAccessToken(String accessToken) {
    this.accessToken = accessToken;
  }
}
