package com.sap.hcm.resume.collection.util;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang.reflect.MethodUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.sap.hcm.resume.collection.bean.CandidateAttribute;
import com.sap.hcm.resume.collection.bean.CandidateProfileModel;
import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.entity.CandidateBackground;
import com.sap.hcm.resume.collection.entity.CandidateProfile;
import com.sap.hcm.resume.collection.entity.CandidateProfileExt;
import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.entity.view.CandidateBgCertificateVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgEducationVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgFamilyVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgLanguageVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgTypeEnum;
import com.sap.hcm.resume.collection.entity.view.CandidateBgWorkExprVO;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileConstants;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileExtVO;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.bean.ApplyDMMappingItemLabelTranslation;
import com.sap.hcm.resume.collection.integration.bean.ApplyDataModelMappingItem;
import com.sap.hcm.resume.collection.integration.bean.CandProfileDataModelMapping;
import com.sap.hcm.resume.collection.integration.bean.DataMappingPicklist;
import com.sap.hcm.resume.collection.integration.bean.DataMappingPicklistOption;
import com.sap.hcm.resume.collection.integration.bean.DataMappingPkOptionMapping;
import com.sap.hcm.resume.collection.integration.sf.bean.SFPicklist;
import com.sap.hcm.resume.collection.integration.sf.bean.SFPicklistCacheEntityType;
import com.sap.hcm.resume.collection.integration.sf.bean.SFPicklistItem;
import com.sap.hcm.resume.collection.integration.sf.service.SFPicklistCacheService;
import com.sap.hcm.resume.collection.integration.sf.service.SFPicklistService;
import com.sap.hcm.resume.collection.service.CompanyInfoService;
import com.sap.hcm.resume.collection.service.DataModelMappingService;
import com.sap.hcm.resume.collection.xml.CandidateBgXMLConverter;

/**
 * candidate profile helper
 * 
 * @author i065831
 */
@Service
public class CandidateProfileHelper {

  private static Logger logger = LoggerFactory.getLogger(CandidateProfileHelper.class);

  @Autowired
  private Params params;

  @Autowired
  private CompanyInfoService compInfoService;

  @Autowired
  private SFPicklistCacheService sfPicklistCacheService;

  @Autowired
  private SFPicklistCacheService pklCacheService;

  @Autowired
  private DataModelMappingService dmMappingService;
  
  @Autowired
  private SFPicklistService sFPicklistService;

  public void convertFromProfileUI2DB(CandidateProfileVO profileVO, CandidateProfile profile,
      List<CandidateProfileExt> extProfileList, List<CandidateBackground> backgroundList) {

    CandidateProfileModel dataModel = CandidateDataModelBuilder.getInstance().build();

    // deal with basic profile information
    BeanUtils.copyProperties(profileVO, profile);

    // deal with extended profile information
    CandidateProfileExtVO extVO = profileVO.getExtProfile();
    List<CandidateAttribute> attrs = dataModel.getAttributes();
    for (CandidateAttribute att : attrs) {
      if (att.getIsExt()) {
        CandidateProfileExt ext = new CandidateProfileExt();
        ext.setCandidateId(profileVO.getCandidateId());
        ext.setParamName(att.getName());
        ext.setCompanyId(profileVO.getCompanyId());
        String attType = att.getType();
        if ("string".equals(attType) || "boolean".equals(attType)) {
          ext.setStringValue((String) getGetterValue(extVO, CandidateProfileExtVO.class, att.getName()));
        }
        if ("date".equals(attType)) {
          ext.setDateValue((Date) getGetterValue(extVO, CandidateProfileExtVO.class, att.getName()));
        }
        if ("byte[]".equals(attType)) {
          ext.setBlobValue((byte[]) getGetterValue(extVO, CandidateProfileExtVO.class, att.getName()));
        }
        extProfileList.add(ext);
      }

    }

    // deal with background elements
    List<CandidateBgWorkExprVO> exprList = profileVO.getWorkExprs();
    if (exprList != null) {
      CandidateBackground bg = new CandidateBackground();
      bg.setCandidateId(profileVO.getCandidateId());
      bg.setBackgroundType(CandidateBgTypeEnum.WORK_EXPR.name());
      bg.setCompanyId(profileVO.getCompanyId());
      bg.setContent(CandidateBgXMLConverter.convertFromBgElementToXML(exprList).getBytes(StandardCharsets.UTF_8));
      backgroundList.add(bg);
    }

    List<CandidateBgLanguageVO> langList = profileVO.getLanguages();
    if (langList != null) {
      CandidateBackground bg = new CandidateBackground();
      bg.setCandidateId(profileVO.getCandidateId());
      bg.setBackgroundType(CandidateBgTypeEnum.LANGUAGE.name());
      bg.setCompanyId(profileVO.getCompanyId());
      bg.setContent(CandidateBgXMLConverter.convertFromBgElementToXML(langList).getBytes(StandardCharsets.UTF_8));
      backgroundList.add(bg);
    }

    List<CandidateBgCertificateVO> certList = profileVO.getCertificates();
    if (certList != null) {
      CandidateBackground bg = new CandidateBackground();
      bg.setCandidateId(profileVO.getCandidateId());
      bg.setBackgroundType(CandidateBgTypeEnum.CERTIFICATE.name());
      bg.setCompanyId(profileVO.getCompanyId());
      bg.setContent(CandidateBgXMLConverter.convertFromBgElementToXML(certList).getBytes(StandardCharsets.UTF_8));
      backgroundList.add(bg);
    }

    List<CandidateBgEducationVO> eduList = profileVO.getEducation();
    if (eduList != null) {
      CandidateBackground bg = new CandidateBackground();
      bg.setCandidateId(profileVO.getCandidateId());
      bg.setBackgroundType(CandidateBgTypeEnum.EDUCATION.name());
      bg.setCompanyId(profileVO.getCompanyId());
      bg.setContent(CandidateBgXMLConverter.convertFromBgElementToXML(eduList).getBytes(StandardCharsets.UTF_8));
      backgroundList.add(bg);
    }

    List<CandidateBgFamilyVO> familyList = profileVO.getFamilies();
    if (familyList != null) {
      CandidateBackground bg = new CandidateBackground();
      bg.setCandidateId(profileVO.getCandidateId());
      bg.setBackgroundType(CandidateBgTypeEnum.FAMILY.name());
      bg.setCompanyId(profileVO.getCompanyId());
      bg.setContent(CandidateBgXMLConverter.convertFromBgElementToXML(familyList).getBytes(StandardCharsets.UTF_8));
      backgroundList.add(bg);
    }
  }

  private Object getGetterValue(Object instance, Class<?> claz, String fieldName) {
    Method[] methods = claz.getDeclaredMethods();
    for (Method method : methods) {
      String methodName = "get" + fieldName;
      if (method.getName().equalsIgnoreCase(methodName)) {
        try {
          return method.invoke(instance);
        } catch (Exception e) {
          System.out.println("failed to get value from : " + methodName);
        }
      }
    }
    return null;
  }

  public CandidateProfileVO convertFromProfileDB2UI(CandidateProfile profile, List<CandidateProfileExt> extProfileList,
      List<CandidateBackground> backgroundList) {

    CandidateProfileVO profileVO = new CandidateProfileVO();
    CandidateProfileModel dataModel = CandidateDataModelBuilder.getInstance().build();
    // copy the candidate profile
    BeanUtils.copyProperties(profile, profileVO);

    // copy the extended profile
    CandidateProfileExtVO extVO = new CandidateProfileExtVO();
    try {
      copyExtProfileFromDB2UI(extProfileList, extVO, dataModel);
      profileVO.setExtProfile(extVO);
    } catch (Exception e) {
      System.out.println("error: " + e.getLocalizedMessage());
    }

    // copy the background profile
    copyProfileBackgroundsFromDB2UI(profileVO, backgroundList);
    return profileVO;
  }

  @SuppressWarnings("unchecked")
  private void copyProfileBackgroundsFromDB2UI(CandidateProfileVO profileVO, List<CandidateBackground> backgroundList) {

    List<CandidateBgWorkExprVO> exprList = new ArrayList<CandidateBgWorkExprVO>();
    List<CandidateBgEducationVO> educationList = new ArrayList<CandidateBgEducationVO>();
    List<CandidateBgLanguageVO> langList = new ArrayList<CandidateBgLanguageVO>();
    List<CandidateBgCertificateVO> certiList = new ArrayList<CandidateBgCertificateVO>();
    List<CandidateBgFamilyVO> famList = new ArrayList<CandidateBgFamilyVO>();

    if (backgroundList != null && backgroundList.size() > 0) {
      for (CandidateBackground bg : backgroundList) {
        if (bg.getBackgroundType().equals(CandidateBgTypeEnum.WORK_EXPR.toString())) {
          if (bg.getContent() != null) {
            exprList = (List<CandidateBgWorkExprVO>) CandidateBgXMLConverter.convertFromXMLToBgElement(new String(bg
                .getContent(), StandardCharsets.UTF_8));
          }
        }
        if (bg.getBackgroundType().equals(CandidateBgTypeEnum.EDUCATION.toString())) {
          if (bg.getContent() != null) {
            educationList = (List<CandidateBgEducationVO>) CandidateBgXMLConverter
                .convertFromXMLToBgElement(new String(bg.getContent(), StandardCharsets.UTF_8));
          }
        }
        if (bg.getBackgroundType().equals(CandidateBgTypeEnum.LANGUAGE.toString())) {
          if (bg.getContent() != null) {
            langList = (List<CandidateBgLanguageVO>) CandidateBgXMLConverter.convertFromXMLToBgElement(new String(bg
                .getContent(), StandardCharsets.UTF_8));
          }
        }
        if (bg.getBackgroundType().equals(CandidateBgTypeEnum.CERTIFICATE.toString())) {
          if (bg.getContent() != null) {
            certiList = (List<CandidateBgCertificateVO>) CandidateBgXMLConverter.convertFromXMLToBgElement(new String(
                bg.getContent(), StandardCharsets.UTF_8));
          }
        }
        if (bg.getBackgroundType().equals(CandidateBgTypeEnum.FAMILY.name())) {
          if (bg.getContent() != null) {
            famList = (List<CandidateBgFamilyVO>) CandidateBgXMLConverter.convertFromXMLToBgElement(new String(bg
                .getContent(), StandardCharsets.UTF_8));
          }
        }
      }
    }
    profileVO.setWorkExprs(exprList);
    profileVO.setEducation(educationList);
    profileVO.setLanguages(langList);
    profileVO.setCertificates(certiList);
    profileVO.setFamilies(famList);
  }

  private void copyExtProfileFromDB2UI(List<CandidateProfileExt> extProfileList, CandidateProfileExtVO extVO,
      CandidateProfileModel dataModel) throws IllegalAccessException, IllegalArgumentException,
      InvocationTargetException {
    // TODO Auto-generated method stub
    if (extProfileList == null || extProfileList.size() == 0) {
      return;
    }
    for (CandidateProfileExt ext : extProfileList) {
      String paramName = ext.getParamName();
      Object value = null;
      String type = getAttributeType(paramName, dataModel);
      if ("string".equals(type) || "boolean".equals(type)) {
        value = ext.getStringValue();
      }
      if ("byte[]".equals(type)) {
        value = ext.getBlobValue();
      }
      if ("date".equals(type)) {
        value = ext.getDateValue();
      }

      // set method
      String setMethod = "set" + paramName;
      Method[] methods = CandidateProfileExtVO.class.getDeclaredMethods();
      for (Method method : methods) {
        if (method.getName().equalsIgnoreCase(setMethod)) {
          method.invoke(extVO, value);
        }
      }

    }
  }

  /**
   * get attribute type
   * 
   * @param attributeName
   * @param model
   * @return
   */
  private static String getAttributeType(String attributeName, CandidateProfileModel model) {
    List<CandidateAttribute> attrs = model.getAttributes();
    if (attrs == null) {
      return null;
    }
    for (CandidateAttribute attr : attrs) {
      if (attr.getName().equals(attributeName)) {
        return attr.getType();
      }
    }
    return null;
  }

  public void fillPicklistOptions(CandidateProfileVO profile, Locale resumeLocale) throws ServiceApplicationException {

    String companyId = params.getCompanyId();

    CompanyInfo compInfo = compInfoService.getCompanyInfo(companyId);
    if (compInfo == null) {
      return;
    }
    Long mappingId = compInfo.getDmMappingId();
    if (mappingId == null) {
      return;
    }

    CandProfileDataModelMapping candProfileMapping = dmMappingService
        .getCandidateProfileDataModelMappingById(mappingId);
    if (candProfileMapping != null) {

      DataMappingPkOptionMapping picklistMapping = candProfileMapping.getPicklistOptionMapping();
      if (picklistMapping == null) {
        return;
      }

      List<SFPicklist> picklists = candProfileMapping.picklists();
      Map<String, SFPicklist> pickListMap = new HashMap<String, SFPicklist>();
      String locale = resumeLocale.toString();
      locale = sFPicklistService.validateLocale(locale);
      pickListMap = this.readPicklistFromDB(picklists, SFPicklistCacheEntityType.CANDIDATE.name(),
          locale);

      if (picklists != null && !picklists.isEmpty()) {
        for (SFPicklist sfPicklist : picklists) {
          String sourcePropertyName = sfPicklist.getSrcPropertyName();
          String picklistName = sfPicklist.getPicklistName();
          String category = sfPicklist.getCategory();

          if (!StringUtils.isEmpty(sourcePropertyName) && !StringUtils.isEmpty(picklistName)) {
            if (category == null)
              category = "profile";
            switch (category) {
            case CandidateProfileConstants.BG_WORKEXPR_NAME:
              List<CandidateBgWorkExprVO> exprList = profile.getWorkExprs();
              if (exprList == null) {
                break;
              }
              for (CandidateBgWorkExprVO expr : exprList) {
                String reflectValue = String.valueOf(getPropertyValueFromObject(expr, sourcePropertyName));
                String optionLabel = this.matchPickListOption(reflectValue, picklistName, picklistMapping, pickListMap);
                this.setValueToCandidateProfile(expr, sourcePropertyName, optionLabel);
              }
              break;
            case CandidateProfileConstants.BG_EDUC_NAME:
              List<CandidateBgEducationVO> educList = profile.getEducation();
              if (educList == null) {
                break;
              }
              for (CandidateBgEducationVO educ : educList) {
                String reflectValue = String.valueOf(getPropertyValueFromObject(educ, sourcePropertyName));
                String optionLabel = this.matchPickListOption(reflectValue, picklistName, picklistMapping, pickListMap);
                this.setValueToCandidateProfile(educ, sourcePropertyName, optionLabel);
              }
              break;
            case CandidateProfileConstants.BG_LANGU_NAME:
              List<CandidateBgLanguageVO> languList = profile.getLanguages();
              List<CandidateBgLanguageVO> languListFillFailed = new ArrayList<CandidateBgLanguageVO>();
              if (languList == null) {
                break;
              }
              for (CandidateBgLanguageVO langu : languList) {
                String reflectValue = String.valueOf(getPropertyValueFromObject(langu, sourcePropertyName));
                String optionLabel = this.matchPickListOption(reflectValue, picklistName, picklistMapping, pickListMap);
                if (StringUtils.isEmpty(optionLabel) && "name".equals(sourcePropertyName)) {
                  languListFillFailed.add(langu);
                } else {
                  this.setValueToCandidateProfile(langu, sourcePropertyName, optionLabel);
                }
              }
              languList.removeAll(languListFillFailed);
              break;
            case CandidateProfileConstants.BG_CERT_NAME:
              List<CandidateBgCertificateVO> certList = profile.getCertificates();
              if (certList == null) {
                break;
              }
              for (CandidateBgCertificateVO cert : certList) {
                String reflectValue = String.valueOf(getPropertyValueFromObject(cert, sourcePropertyName));
                String optionLabel = this.matchPickListOption(reflectValue, picklistName, picklistMapping, pickListMap);
                this.setValueToCandidateProfile(cert, sourcePropertyName, optionLabel);
              }
              break;
            case CandidateProfileConstants.BG_FAMI_NAME:
              List<CandidateBgFamilyVO> famList = profile.getFamilies();
              if (famList == null) {
                break;
              }
              for (CandidateBgFamilyVO fam : famList) {
                String reflectValue = String.valueOf(getPropertyValueFromObject(fam, sourcePropertyName));
                String optionLabel = this.matchPickListOption(reflectValue, picklistName, picklistMapping, pickListMap);
                this.setValueToCandidateProfile(fam, sourcePropertyName, optionLabel);
              }
              break;
            default:
              // handle profile and extProfile
              String reflectValue = String.valueOf(this.getValueFromCandidateProfile(profile, sourcePropertyName));
              String optionLabel = this.matchPickListOption(reflectValue, picklistName, picklistMapping, pickListMap);

              CandidateProfileModel profileModel = CandidateDataModelBuilder.getInstance().build();
              if (profileModel.isExtProfile(sourcePropertyName)) {
                this.setValueToCandidateProfile(profile.getExtProfile(), sourcePropertyName, optionLabel);
              } else {
                this.setValueToCandidateProfile(profile, sourcePropertyName, optionLabel);
              }
              break;
            }
          }
        }
      }
    }

  }

  // private String getPicklistOptionLabel(DataMappingPkOptionMapping picklistMapping, String picklistName,
  // String reflectValue) {
  // Map<String, SFPicklist> pickListMap = new HashMap<String, SFPicklist>();
  // pickListMap = this.readPicklistFromDB(picklists, SFPicklistCacheEntityType.CANDIDATE.name());
  // this.matchPickListOption(fieldValue, pickListName, dataMappingPkOptionMapping, pickListMap)
  // List<DataMappingPicklist> picklistMappingList = picklistMapping.getPicklists();
  // String targetPicklistLabel = null;
  // if (picklistMappingList != null) {
  // for (DataMappingPicklist pkMapping : picklistMappingList) {
  // if (StringUtils.isEmpty(picklistName) || !picklistName.equals(pkMapping.getId())) {
  // continue;
  // }
  // List<DataMappingPicklistOption> options = pkMapping.getOptions();
  // if (options == null || options.isEmpty()) {
  // continue;
  // }
  // for (DataMappingPicklistOption option : options) {
  // if (reflectValue != null && reflectValue.equalsIgnoreCase(option.getSource())) {
  // targetPicklistLabel = option.getTarget();
  // break;
  // }
  // }
  // }
  // }
  // return targetPicklistLabel;
  // }

  /**
   * @param candidateProfileVO
   * @param fieldName
   * @return
   */
  public Object getValueFromCandidateProfile(CandidateProfileVO candidateProfileVO, String fieldName) {

    // format profile info
    CandidateProfileModel profileModel = CandidateDataModelBuilder.getInstance().build();
    Object reflectValue = null;
    // check current item, whether it is from profile table
    // or coming from extended profile
    // special case for candidateType and candidateSource
    if (profileModel.isExtProfile(fieldName) || "candidateType".equals(fieldName)
        || "candidateSource".equals(fieldName)) {
      reflectValue = getValueFromCandidateExtProfile(candidateProfileVO, fieldName);
    } else {
      reflectValue = getPropertyValueFromObject(candidateProfileVO, fieldName);
    }
    return reflectValue;
  }

  /**
   * @param candidateProfileVO
   * @param fieldName
   * @return
   */
  private Object getValueFromCandidateExtProfile(CandidateProfileVO candidateProfileVO, String fieldName) {

    Object reflectValue = null;
    CandidateProfileExtVO extProfile = candidateProfileVO.getExtProfile();
    if (extProfile != null) {
      reflectValue = getPropertyValueFromObject(extProfile, fieldName);
    }
    return reflectValue;
  }

  public Object getPropertyValueFromObject(Object instance, String fieldName) {
    String methodName = "get" + MappingUtil.methodNameCapitalized(fieldName);
    Object reflectValue;
    try {
      reflectValue = MethodUtils.invokeExactMethod(instance, methodName, null);
    } catch (Exception e) {
      reflectValue = null;
    }
    return reflectValue;
  }

  @SuppressWarnings({ "unchecked", "rawtypes" })
  public void setValueToCandidateProfile(Object instance, String fieldName, Object value) {
    try {
      String methodName = "set" + MappingUtil.methodNameCapitalized(fieldName);
      Class clazz;
      if (instance instanceof CandidateProfileVO) {
        clazz = CandidateProfile.class;
      } else {
        clazz = instance.getClass();
      }
      Method method = clazz.getDeclaredMethod(methodName, String.class);
      method.invoke(instance, value);

      // java.lang.reflect.Field prop = null;
      // if(instance instanceof CandidateProfileVO){
      // prop = CandidateProfile.class.getDeclaredField(fieldName);
      // }else{
      // prop = instance.getClass().getDeclaredField(fieldName);
      // }
      // if("String".equals(prop.getType().getSimpleName())){
      // prop.setAccessible(true);
      // prop.set(instance, value);
      // }
    } catch (IllegalArgumentException | InvocationTargetException | NoSuchMethodException | IllegalAccessException e) {
      logger.debug("failed to invoke set method of set" + fieldName + " with value: " + value);
    }
  }

  /**
   * @param applyItem
   * @param locale
   * @return
   */
  public String getTranslatedLabel(ApplyDataModelMappingItem applyItem, Locale locale) {
    String translation = null;
    List<ApplyDMMappingItemLabelTranslation> translations = applyItem.getLabelTranslations();
    if (translations != null && !translations.isEmpty()) {
      for (ApplyDMMappingItemLabelTranslation transl : translations) {
        if (locale.toString().equalsIgnoreCase(transl.getLanguageKey())) {
          translation = transl.getTranslation();
          break;
        }
      }
      if (translation == null) {
        translation = translations.get(0).getTranslation();
      }
    }
    return translation;
  }

  /**
   * match value from pickListOption
   * 
   * @throws ServiceApplicationException
   */
  public String matchPickListOption(Object fieldValue, String pickListName,
      DataMappingPkOptionMapping dataMappingPkOptionMapping, Map<String, SFPicklist> pickListMap)
      throws ServiceApplicationException {

    String optionTargetValue = null;

    // check whether fieldValue already existed in the picklist
    SFPicklist sfPicklist = pickListMap.get(pickListName);
    if (sfPicklist != null && sfPicklist.getValueList() != null) {
      List<SFPicklistItem> sfPickList = sfPicklist.getValueList();
      for (SFPicklistItem sfPicklistItem : sfPickList) {
        if (sfPicklistItem.getLabel().equalsIgnoreCase(String.valueOf(fieldValue))) {
          optionTargetValue = sfPicklistItem.getLabel();
          return optionTargetValue;
        }
      }
    }

    // if not existing the picklist from SF
    if (dataMappingPkOptionMapping != null) {
      for (DataMappingPicklist dataMappingPicklist : dataMappingPkOptionMapping.getPicklists()) {
        if (pickListName.equals(dataMappingPicklist.getId())) {
          for (DataMappingPicklistOption dataMappingPicklistOption : dataMappingPicklist.getOptions()) {
            if (dataMappingPicklistOption.getSource().equalsIgnoreCase(String.valueOf(fieldValue))) {
              optionTargetValue = dataMappingPicklistOption.getTarget();
            }
          }
          optionTargetValue = optionTargetValue != null ? optionTargetValue : dataMappingPicklist.getOther();
        }
      }
    }

    return optionTargetValue;
  }

  /**
   * @param picklist
   * @return
   */
  public Map<String, SFPicklist> readPicklistFromDB(List<SFPicklist> picklist, String type, String locale) {
    Map<String, SFPicklist> pickListMap = new HashMap<String, SFPicklist>();

    if (picklist != null && picklist.size() > 0) {
      for (SFPicklist sfPicklist : picklist) {
        List<SFPicklistItem> valueItems = sfPicklistCacheService.getPicklistOptionsByName(params.getCompanyId(),
            sfPicklist.getPicklistName(), locale, type);
        sfPicklist.setValueList(valueItems);
        pickListMap.put(sfPicklist.getPicklistName(), sfPicklist);
      }
    }
    return pickListMap;
  }
}
