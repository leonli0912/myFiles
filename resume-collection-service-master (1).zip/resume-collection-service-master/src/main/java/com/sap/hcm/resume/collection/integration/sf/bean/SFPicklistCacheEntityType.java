package com.sap.hcm.resume.collection.integration.sf.bean;

public enum SFPicklistCacheEntityType {
  JOB_REQUISITION,
  JOB_APPLICATION,
  CANDIDATE;
}
