package com.sap.hcm.resume.collection.integration.job51;

import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;

import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.context.MessageSource;
import org.springframework.core.io.ClassPathResource;

import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.util.CandidateFileUtil;

public class ResumeParser51Test {

  @Test
  public void testParseResumeContent() throws ServiceApplicationException, IOException {
    MessageSource ms = Mockito.mock(MessageSource.class);
    Mockito.when(ms.getMessage(Mockito.anyString(), Mockito.any(Object[].class), Mockito.any(Locale.class)))
        .thenReturn("test");

    CandidateProfileVO profileVO = new CandidateProfileVO();

    ClassPathResource resume = new ClassPathResource("resumes/parser/51_TEST_RC_CN.doc");
    InputStream is = null;

    try {
      is = resume.getInputStream();
      String resumeContent = CandidateFileUtil.getFileContent(IOUtils.toByteArray(is)).getTextContent();

      ResumeParser51 parser = new ResumeParser51(ms);
      profileVO = parser.parseProfile(profileVO, resumeContent);
      profileVO = parser.parseBackgroundWorkExp(profileVO, resumeContent);
      profileVO = parser.parseBackgroundCertificate(profileVO, resumeContent);
      profileVO = parser.parseBackgroundEducation(profileVO, resumeContent);
      profileVO = parser.parseBackgroundLanguage(profileVO, resumeContent);
    } catch (Exception e) {
    } finally {
      IOUtils.closeQuietly(is);
    }

    Assert.assertEquals(profileVO.getCellPhone(), "1234567890");
    Assert.assertEquals(profileVO.getWorkExprs().size(), 5);
    Assert.assertEquals(profileVO.getEducation().size(), 1);
    Assert.assertEquals(profileVO.getLanguages().size(), 1);
    Assert.assertEquals(profileVO.getCertificates().size(), 3);
  }

  @Test
  public void testParseResumeContentInHTML() throws ServiceApplicationException, IOException {
    MessageSource ms = Mockito.mock(MessageSource.class);
    Mockito.when(ms.getMessage(Mockito.anyString(), Mockito.any(Object[].class), Mockito.any(Locale.class)))
        .thenReturn("test");

    ClassPathResource resume = new ClassPathResource("resumes/parser/51_TEST_CN.html");
    InputStream is = null;
    CandidateProfileVO profileVO = new CandidateProfileVO();
    try {
      is = resume.getInputStream();
      ResumeParser51 parser = new ResumeParser51(ms);
      String resumeContent = CandidateFileUtil.getFileContent(IOUtils.toByteArray(is)).getTextContent();
      profileVO = parser.parseProfile(profileVO, resumeContent);
      profileVO = parser.parseBackgroundWorkExp(profileVO, resumeContent);
      profileVO = parser.parseBackgroundCertificate(profileVO, resumeContent);
      profileVO = parser.parseBackgroundEducation(profileVO, resumeContent);
      profileVO = parser.parseBackgroundLanguage(profileVO, resumeContent);
    } catch (Exception e) {
    } finally {
      IOUtils.closeQuietly(is);
    }

    Assert.assertEquals(profileVO.getCellPhone(), "18302000000");
    Assert.assertEquals(profileVO.getWorkExprs().size(), 3);
    Assert.assertEquals(profileVO.getEducation().size(), 1);
    Assert.assertEquals(profileVO.getLanguages().size(), 1);
    Assert.assertEquals(profileVO.getCertificates().size(), 4);
  }
}
