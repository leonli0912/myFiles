package com.sap.hcm.resume.collection.integration.sf.bean.cdm;

import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

@XStreamAlias("enum-value")
public class SFCDMFieldEnum {
    
    @XStreamAsAttribute
    public String value;
    
    @XStreamImplicit(itemFieldName="enum-label")
    List<SFCDMFieldEnumLabel> enumLabel;

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    public List<SFCDMFieldEnumLabel> getEnumLabel() {
        return enumLabel;
    }

    public void setEnumLabel(List<SFCDMFieldEnumLabel> enumLabel) {
        this.enumLabel = enumLabel;
    }
}
