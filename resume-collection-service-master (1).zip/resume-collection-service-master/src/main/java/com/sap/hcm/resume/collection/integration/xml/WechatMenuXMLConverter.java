package com.sap.hcm.resume.collection.integration.xml;

import java.nio.charset.StandardCharsets;
import java.util.Collection;

import com.sap.hcm.resume.collection.integration.wechat.bean.WechatMenuContent;
import com.sap.hcm.resume.collection.integration.wechat.bean.WechatMenuItem;
import com.sap.hcm.resume.collection.integration.wechat.bean.WechatSubMenuItem;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.security.NullPermission;
import com.thoughtworks.xstream.security.PrimitiveTypePermission;

public class WechatMenuXMLConverter {

  private static XStream stream = new XStream();

  private WechatMenuXMLConverter() {
  }

  static {
    stream.autodetectAnnotations(true);
    stream.processAnnotations(WechatMenuContent.class);
    stream.processAnnotations(WechatMenuItem.class);
    stream.processAnnotations(WechatSubMenuItem.class);
    
    // add permissions, allow some basics
    stream.addPermission(NullPermission.NULL);
    stream.addPermission(PrimitiveTypePermission.PRIMITIVES);
    stream.allowTypeHierarchy(Collection.class);
    // allow any type from the same package
    stream.allowTypesByWildcard(new String[] {
        WechatMenuContent.class.getPackage().getName()+".*"
    });
  }

  public static String toXML(WechatMenuContent content) {
    return stream.toXML(content);
  }

  public static WechatMenuContent fromXML(String xml) {
    return (WechatMenuContent) stream.fromXML(xml);
  }

  public static WechatMenuContent fromByte(byte[] content) {
    return fromXML(new String(content, StandardCharsets.UTF_8));
  }
}
