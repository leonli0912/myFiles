package com.sap.hcm.resume.collection.parser;

import org.jsoup.nodes.Document;
import org.springframework.context.MessageSource;

import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;

public abstract class HTMLDocumentParser {
  
  protected MessageSource messageSource;
  
  public HTMLDocumentParser(MessageSource messageSource){
    this.messageSource = messageSource;
  }
  
  protected String resumeLanguageType;
  
  public CandidateProfileVO parseCandidateProfile(CandidateProfileVO candidateProfileVO, Document content) 
      throws ServiceApplicationException{
    this.parseProfile(candidateProfileVO, content);
    this.parseBackgroundWorkExp(candidateProfileVO, content);
    this.parseBackgroundCertificate(candidateProfileVO, content);
    this.parseBackgroundEducation(candidateProfileVO, content);
    this.parseBackgroundLanguage(candidateProfileVO, content);
    return candidateProfileVO;
  };
  
  public abstract CandidateProfileVO parseProfile(CandidateProfileVO candidateProfileVO, Document content)
      throws ServiceApplicationException;
  
  public abstract CandidateProfileVO parseBackgroundWorkExp(CandidateProfileVO candidateProfileVO, Document content)
      throws ServiceApplicationException;

  public abstract CandidateProfileVO parseBackgroundEducation(CandidateProfileVO candidateProfileVO, Document content)
      throws ServiceApplicationException;

  public abstract CandidateProfileVO parseBackgroundLanguage(CandidateProfileVO candidateProfileVO, Document content)
      throws ServiceApplicationException;

  public abstract CandidateProfileVO parseBackgroundCertificate(CandidateProfileVO candidateProfileVO, Document content)
      throws ServiceApplicationException;
}
