jQuery.sap.require("jquery.sap.resources");
sap.ui.define([ 'sap/m/MessageBox',
 								'static/job/js/layout/JobBaseEditController',
								'sap/ui/model/json/JSONModel',
							  'static/job/js/JobRequisitionUtil'],
		function(MessageBox, JobBaseEditController, JSONModel,JobRequisitionUtil) {
			"use strict";

			var jobDisplayController = JobBaseEditController.extend("static.job.js.layout.jobDisplay", {

				_jobId : null,
				/**
				 * Called when a controller is instantiated and its View
				 * controls (if available) are already created. Can be used to
				 * modify the View before it is displayed, to bind event
				 * handlers and do other one-time initialization.
				 *
				 * @memberOf resume-collection-service.jp
				 */
				onInit : function() {
					this._router = sap.ui.core.UIComponent.getRouterFor(this);
					var that = this;

					this._router.attachRoutePatternMatched(this.prepareData, this);
					var pickListModel = new sap.ui.model.json.JSONModel();
					pickListModel.loadData("job/picklists", null, false);
					this.getView().setModel(pickListModel, "picklistModel");
				},

				prepareData : function(oEvent) {

					this._jobId = oEvent.getParameter("arguments").jobId;
					var that = this;
					if (this._jobId) {
						$.get("job/" + this._jobId + "?mode=display", function(data) {
							if (data && data.jobInfo) {
								var oModel = new sap.ui.model.json.JSONModel();
								oModel.setData(data.jobInfo);
								that.getView().setModel(oModel);

								var reqUtil = new JobRequisitionUtil();
								var mappingItems = reqUtil.getMappingItems(data.jobInfo.reqMappingId);
								var oForm = that.getView().byId("jobDisplayForm");
								reqUtil.buildPageContent(that, mappingItems, oForm);
							}
						});
					}

					// call setup data in parent controller
					this.setupData(oEvent);
				},

				onCancel : function() {

					var oHistory = sap.ui.core.routing.History.getInstance();
					var sPreviousHash = oHistory.getPreviousHash();

					if (sPreviousHash !== undefined) {
						window.history.go(-1);
					} else {
						var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
						oRouter.navTo("maintainJob", true);
					}
				},
				
				picklistFormatter : function(val) {
					  if(!val) return "";
					  var picklistData  = this.getView().getModel("picklistModel").getData();
					  for(var picklist in picklistData){
						  for(var i = 0; i < picklistData[picklist].length; i++){
							  if(picklistData[picklist][i].optionId == val){
								  return picklistData[picklist][i].label;
							  }
						  }
					  }
					  return val;
				},

			});
			return jobDisplayController;
});
