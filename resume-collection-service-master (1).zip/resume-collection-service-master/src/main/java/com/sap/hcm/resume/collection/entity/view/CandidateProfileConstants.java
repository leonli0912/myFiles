package com.sap.hcm.resume.collection.entity.view;

/**
 * Candidate profile constants
 * @author i065831
 *
 */
public class CandidateProfileConstants {
  
  public static final String EXT_NAME = "extProfile";
  
  public static final String BG_WORKEXPR_NAME = "workExprs";
  
  public static final String BG_LANGU_NAME = "languages";
  
  public static final String BG_CERT_NAME = "certificates";
  
  public static final String BG_EDUC_NAME = "education";
  
  public static final String BG_FAMI_NAME = "families";
}
