package com.sap.hcm.resume.collection.integration.bean;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("mapping-item")
public class DataModelMappingItem implements Serializable, Comparable<DataModelMappingItem> {

  /*
   * serialVersionUID
   */
  private static final long serialVersionUID = 5129822882295529111L;

  private String from;

  private String to;

  private String label;

  private boolean required;

  private String defaultValue;

  private String fieldType = "PLAIN_TEXT";

  private boolean displayPicklistId = false;

  private int seq;

  /**
   * @return the defaultValue
   */
  public String getDefaultValue() {
    return defaultValue;
  }

  /**
   * @param defaultValue
   *          the defaultValue to set
   */
  public void setDefaultValue(String defaultValue) {
    this.defaultValue = defaultValue;
  }

  /**
   * picklist name for successfactors
   */
  private String picklist;

  /**
   * @return the from
   */
  public String getFrom() {
    return from;
  }

  /**
   * @param from
   *          the from to set
   */
  public void setFrom(String from) {
    this.from = from;
  }

  /**
   * @return the to
   */
  public String getTo() {
    return to;
  }

  /**
   * @param to
   *          the to to set
   */
  public void setTo(String to) {
    this.to = to;
  }

  /**
   * @return the label
   */
  public String getLabel() {
    return label;
  }

  /**
   * @param label
   *          the label to set
   */
  public void setLabel(String label) {
    this.label = label;
  }

  /**
   * @return the required
   */
  public boolean isRequired() {
    return required;
  }

  /**
   * @param required
   *          the required to set
   */
  public void setRequired(boolean required) {
    this.required = required;
  }

  /**
   * @return the picklist
   */
  public String getPicklist() {
    return picklist;
  }

  /**
   * @param picklist
   *          the picklist to set
   */
  public void setPicklist(String picklist) {
    this.picklist = picklist;
  }

  /**
   * @return the order
   */
  public int getSeq() {
    return seq;
  }

  /**
   * @param order
   *          the order to set
   */
  public void setSeq(int seq) {
    this.seq = seq;
  }

  public String getFieldType() {
    return fieldType;
  }

  public void setFieldType(String fieldType) {
    this.fieldType = fieldType;
  }

  public boolean isDisplayPicklistId() {
    return displayPicklistId;
  }

  public void setDisplayPicklistId(boolean displayPicklistId) {
    this.displayPicklistId = displayPicklistId;
  }

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((from == null) ? 0 : from.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj)
      return true;
    if (obj == null)
      return false;
    if (getClass() != obj.getClass())
      return false;
    DataModelMappingItem other = (DataModelMappingItem) obj;
    if (from == null) {
      if (other.from != null)
        return false;
    } else if (!from.equals(other.from))
      return false;
    return true;
  }

  @Override
  public int compareTo(DataModelMappingItem o) {
    if (this.getSeq() < o.getSeq()) {
      return -1;
    } else if (this.getSeq() == o.getSeq()) {
      return 0;
    } else {
      return 1;
    }
  }
}
