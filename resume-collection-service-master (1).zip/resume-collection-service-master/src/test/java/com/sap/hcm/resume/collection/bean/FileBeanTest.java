package com.sap.hcm.resume.collection.bean;

import org.junit.Assert;
import org.junit.Test;


public class FileBeanTest {
     
    @Test
    public void testGetter(){
        FileBean fileBean = new FileBean();
        fileBean.setFileContent("haha");
        Assert.assertEquals("haha", fileBean.getFileContent());
        
        fileBean.setFileType("doc");
        Assert.assertEquals("doc", fileBean.getFileType());
    }
}
