package com.sap.hcm.resume.collection.integration.sf.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.apache.olingo.odata2.api.edm.Edm;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sap.hcm.resume.collection.bean.SimpleJsonResponse;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.sf.bean.SFPicklistItem;
import com.sap.hcm.resume.collection.integration.sf.odata.SFODataService;
import com.sap.hcm.resume.collection.integration.sf.service.SFPicklistService;

@RestController
@RequestMapping(value = "/sf")
public class SFODataController {

  private Logger logger = LoggerFactory.getLogger(this.getClass());

  @Autowired
  private SFODataService sfODataService;

  @Autowired
  private SFPicklistService sfPicklistService;

  @RequestMapping(value = "/refreshMetadata", method = RequestMethod.GET)
  public SimpleJsonResponse refreshMetadata(HttpServletRequest request) {
    SimpleJsonResponse response = new SimpleJsonResponse();
    response.setCode(0);
    response.setMessage("success");

    Edm edm = null;
    try {
      edm = sfODataService.getEdm(true);
      if (edm == null) {
        response.setCode(-1);
        response.setMessage("refresh metadata failed");
        logger.error("refresh metadata failed: edm is null");
      }
    } catch (ServiceApplicationException e) {
      response.setCode(-1);
      response
          .setMessage("refresh metadata failed, please check destination 'SF_ODATA' or contact application admin for help");
      logger.error("refresh metadata failed due to: " + e.getMessage());
    }
    return response;
  }

  @RequestMapping(value = "picklistOptions", method = RequestMethod.GET)
  public List<SFPicklistItem> loadPicklistOptions(HttpServletRequest request,
      @RequestParam(value = "picklist") String picklistId,
      @RequestParam(value = "locale", defaultValue = "zh_CN", required = false) String locale) {

    List<SFPicklistItem> result = new ArrayList<SFPicklistItem>();
    if ("en".equals(locale)) {
      locale = Locale.US.toString();
    }
    try {
      result = sfPicklistService.loadPickListOption(picklistId);
    } catch (ServiceApplicationException e) {
      logger.error("load picklist failed, picklistId = " + picklistId + "; Root Casue: " + e.getMessage());
    }

    if (result != null) {
      Iterator<SFPicklistItem> iter = result.iterator();
      while (iter.hasNext()) {
        if (!locale.equals(iter.next().getLocale())) {
          iter.remove();
        }
      }
    }
    return result;
  }

  @RequestMapping(value = "picklistName", method = RequestMethod.GET)
  public SimpleJsonResponse getPicklistName(HttpServletRequest request,
      @RequestParam(value = "propName", required = true) String propName,
      @RequestParam(value = "entityTypeName", required = true) String entityTypeName) {

    SimpleJsonResponse response = new SimpleJsonResponse();
    String picklistName = "";
    try {
      picklistName = sfPicklistService.getPicklistName(propName, entityTypeName);
      response.setCode(0);
    } catch (ServiceApplicationException e) {
      logger.error("get picklist name failed due to: " + e.getMessage());
      response.setCode(-1);
    }
    response.setMessage(picklistName);

    return response;
  }
}
