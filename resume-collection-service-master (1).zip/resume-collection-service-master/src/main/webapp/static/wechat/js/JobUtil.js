sap.ui.define([], function(){
	"use strict";

  var JobUtil = function(){
  };

  JobUtil.prototype.getMappingItems = function(dmMappingId){
    var reqMappingURL = "job/jobreq/"+dmMappingId;
    var reqMappingModel = new sap.ui.model.json.JSONModel();
		reqMappingModel.loadData(reqMappingURL,null,false);
    var mappingEntry = reqMappingModel.getData();
    var mappingItems = [];
    if(mappingEntry){
      var mapping = mappingEntry.mapping;
      for(var i in mapping.items){
        var item = mapping.items[i];
        if(item.sfDmField){
          mappingItems.push(item);
        }
      }
    }
    return mappingItems;
  }
  
  JobUtil.prototype.fieldContain = function(field) {
	  var panelItems = ['jobDescription','jobResponsiblity','jobQualification',
	                    'jobBenefit','jobExpectation'];
	  for (var i=0; i < panelItems.length; i++) {
		  if (field == panelItems[i]) {
			  return true;
		  }
	  }
	  return false;
  }

  JobUtil.prototype.buildPageContent = function(mappingItems, oContent, wModel, oController){
    oContent.removeAllContent();
    var oPanel = new sap.m.Panel();
    for(var i in mappingItems){
      var item = mappingItems[i];
      
      if (item && item.displayInWeChat) {
    	  if (!this.fieldContain(item.sourceField)) {
    		  var label = wModel.getResourceBundle().getText(item.label);
    		  if(item.picklist){
        		  var oListItem = new sap.m.StandardListItem({
        			  title : label,
        			  info : {path:"/"+item.sourceField, formatter:jQuery.proxy(oController.picklistFormatter,oController)}
        		  });
    		  } else {
        		  var oListItem = new sap.m.StandardListItem({
        			  title : label,
        			  info : "{/" + item.sourceField + "}"
        		  });
    		  }
    		  oListItem.addStyleClass("jobInfoItem");
    		  oPanel.addContent(oListItem);
    	  }
      }
    }
    oContent.addContent(oPanel);
    
    for(var i in mappingItems){
        var item = mappingItems[i];
        
        if (item && item.displayInWeChat) {
      	  if (this.fieldContain(item.sourceField)) {
	  		  var label = wModel.getResourceBundle().getText(item.label);
	  		  var oHeaderToolBar = new sap.m.Toolbar({
	  			height : "3rem"
	  		  });
	  		  var oTitle = new sap.m.Title({
	  			  text : label
	  		  });
	  		  oHeaderToolBar.addContent(oTitle);
	  		  var oItemPanel = new sap.m.Panel();
	  		  var oText = new sap.m.Text({
	  			  text : {path:"/"+item.sourceField}
	  		  });
	  		  oText.addStyleClass("sapUiSmallMarginTop");
	  		  oItemPanel.addContent(oHeaderToolBar);
	  		  oItemPanel.addContent(oText);
	  		  oItemPanel.addStyleClass("jobInfoPanel");
	  		  oContent.addContent(oItemPanel);
      	  }
        }
      }
  }

  return JobUtil;
});
