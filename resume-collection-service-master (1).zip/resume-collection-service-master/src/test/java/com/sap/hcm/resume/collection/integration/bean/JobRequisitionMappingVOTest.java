package com.sap.hcm.resume.collection.integration.bean;

import org.junit.Assert;
import org.junit.Test;

import com.sap.hcm.resume.collection.entity.view.JobRequisitionMappingVO;


public class JobRequisitionMappingVOTest {
  
  @Test
  public void testSetGetter(){
    JobRequisitionMappingVO vo = new JobRequisitionMappingVO();
    
    vo.setCreateBy("test");
    vo.setId(1L);
    vo.setMapping(null);
    vo.setMappingName("test");
    vo.setTargetSystem("SF");
    
    Assert.assertEquals(vo.getCreateBy(), "test");
    Assert.assertEquals(vo.getId().toString(), "1");
    Assert.assertEquals(vo.getMapping(), null);
    Assert.assertEquals(vo.getMappingName(), "test");
    Assert.assertEquals(vo.getTargetSystem(), "SF");
  }
}
