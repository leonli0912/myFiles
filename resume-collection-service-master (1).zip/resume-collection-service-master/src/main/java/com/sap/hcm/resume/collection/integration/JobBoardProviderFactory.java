package com.sap.hcm.resume.collection.integration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.sap.hcm.resume.collection.bean.CandidateVendorEnum;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;

/**
 * factory to build the job provider
 * @author i065831
 *
 */
@Component
public class JobBoardProviderFactory {
  
  @Autowired
  @Qualifier(value="dajieProvider")
  private JobBoardBaseProvider dajieProvider;
  
  @Autowired
  @Qualifier(value="job51Provider")
  private JobBoardBaseProvider job51Provider;
  
  @Autowired
  @Qualifier(value="zhilianProvider")
  private JobBoardBaseProvider zhilianProvider;
  
  @Autowired
  @Qualifier(value="liepinProvider")
  private JobBoardBaseProvider liepinProvider;
  
  public JobBoardBaseProvider getProvider(String vendor) throws ServiceApplicationException{
    if(CandidateVendorEnum.DAJIE.toString().equalsIgnoreCase(vendor)){
      return dajieProvider;
    }else if(CandidateVendorEnum.JOB51.toString().equalsIgnoreCase(vendor)){
      return job51Provider;
    }else if(CandidateVendorEnum.ZHILIAN.toString().equalsIgnoreCase(vendor)){
      return zhilianProvider;
    }else if(CandidateVendorEnum.LIEPIN.toString().equalsIgnoreCase(vendor)){
      return liepinProvider;
    }else{
      throw new ServiceApplicationException("vendor " + vendor + " is not supported yet");
    }
    
  }
}
