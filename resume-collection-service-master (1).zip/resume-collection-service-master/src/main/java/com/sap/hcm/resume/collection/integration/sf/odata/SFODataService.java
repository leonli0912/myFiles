package com.sap.hcm.resume.collection.integration.sf.odata;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;
import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.HttpHeaders;

import org.apache.commons.io.IOUtils;
import org.apache.olingo.odata2.api.commons.HttpStatusCodes;
import org.apache.olingo.odata2.api.edm.Edm;
import org.apache.olingo.odata2.api.edm.EdmEntityContainer;
import org.apache.olingo.odata2.api.edm.EdmEntitySet;
import org.apache.olingo.odata2.api.edm.EdmEntityType;
import org.apache.olingo.odata2.api.edm.EdmException;
import org.apache.olingo.odata2.api.edm.EdmSimpleTypeKind;
import org.apache.olingo.odata2.api.edm.FullQualifiedName;
import org.apache.olingo.odata2.api.edm.provider.EntityType;
import org.apache.olingo.odata2.api.edm.provider.NavigationProperty;
import org.apache.olingo.odata2.api.edm.provider.Property;
import org.apache.olingo.odata2.api.edm.provider.SimpleProperty;
import org.apache.olingo.odata2.api.ep.EntityProvider;
import org.apache.olingo.odata2.api.ep.EntityProviderException;
import org.apache.olingo.odata2.api.ep.EntityProviderReadProperties;
import org.apache.olingo.odata2.api.ep.EntityProviderWriteProperties;
import org.apache.olingo.odata2.api.ep.entry.ODataEntry;
import org.apache.olingo.odata2.api.ep.feed.ODataFeed;
import org.apache.olingo.odata2.api.exception.ODataException;
import org.apache.olingo.odata2.api.processor.ODataResponse;
import org.apache.olingo.odata2.core.edm.provider.EdmImplProv;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.sf.bean.QueryInfo;

/**
 * @author I075908 SAP
 */
@Service
public class SFODataService {

  @Autowired
  private SFAuthentication auth;

  @Autowired
  Params params;

  private Map<String, Edm> cachedEdm = new HashMap<String, Edm>();

  private static final Logger logger = LoggerFactory.getLogger(SFODataService.class);

  public static final String HTTP_METHOD_PUT = "PUT";

  public static final String HTTP_METHOD_POST = "POST";

  public static final String HTTP_METHOD_GET = "GET";

  // delete function currently is not supported
  // private static final String HTTP_METHOD_DELETE = "DELETE";

  public static final String HTTP_HEADER_CONTENT_TYPE = "Content-Type";

  public static final String HTTP_HEADER_ACCEPT = "Accept";

  public static final String HTTP_HEADER_AUTHORIZATION = "Authorization";

  public static final String APPLICATION_JSON = "application/json";

  public static final String APPLICATION_XML = "application/xml";

  public static final String APPLICATION_ATOM_XML = "application/atom+xml";

  public static final String APPLICATION_FORM = "application/x-www-form-urlencoded";

  public static final String METADATA = "$metadata";

  public static final String SEPARATOR = "/";

  public static final boolean PRINT_RAW_CONTENT = false;

  private static final String SFODATA_NAMESPACE = "SFOData";

  public Edm getEdm() throws ServiceApplicationException {
    return getEdm(false);
  }

  /**
   * @param forceRefresh
   *          force fetch metadata from server when true
   * @return
   * @throws ServiceApplicationException
   */
  public Edm getEdm(boolean forceRefresh) throws ServiceApplicationException {
    Edm edm = cachedEdm.get(params.getCompanyId());
    if (forceRefresh || edm == null) {
      edm = readMetadata();
      cachedEdm.put(params.getCompanyId(), edm);
    }
    return edm;
  }

  private Edm readMetadata() throws ServiceApplicationException {
    InputStream content = null;
    try {
      String absolutUri = auth.getServiceURL() + METADATA;
      HttpURLConnection connection = connect(absolutUri, APPLICATION_XML, HttpMethod.GET);
      content = connection.getInputStream();
      return EntityProvider.readMetadata(content, false);
    } catch (EntityProviderException | IOException e) {
      String msg = e.getMessage();
      logger.error("Read Metadata failed due to exception: " + msg);
      throw new ServiceApplicationException(msg, e);
    } finally {
      IOUtils.closeQuietly(content);
    }
  }

  public List<String> getNaviPropertyNames(String name) throws ServiceApplicationException {
    List<String> result = new ArrayList<String>();

    EdmEntityType entityType;
    try {
      entityType = getEdm().getEntityType("SFOData", name);
      if (entityType != null) {
        result = entityType.getNavigationPropertyNames();
      }
    } catch (EdmException e) {
      String msg = "Failed to get navigation properties from entity: " + name;
      logger.error(msg);
      throw new ServiceApplicationException(msg, e);
    }

    return result;
  }

  public List<NavigationProperty> getNaviProperties(String name) throws ServiceApplicationException {
    List<NavigationProperty> result = new ArrayList<NavigationProperty>();
    try {
      EntityType entityType = ((EdmImplProv) getEdm()).getEdmProvider().getEntityType(
          new FullQualifiedName(SFODATA_NAMESPACE, "Candidate"));
      if (entityType != null) {
        result = entityType.getNavigationProperties();
      }
    } catch (Exception e) {
      String msg = "Failed to get navigation properties from entity: " + name;
      logger.error(msg);
      throw new ServiceApplicationException(msg, e);
    }

    return result;
  }

  public EdmSimpleTypeKind getPropertyType(String propName, String entityName) throws ServiceApplicationException {
    EdmSimpleTypeKind propType = null;
    EntityType entityType = null;
    try {
      entityType = ((EdmImplProv) getEdm()).getEdmProvider().getEntityType(
          new FullQualifiedName(SFODATA_NAMESPACE, entityName));
    } catch (ODataException e) {
      logger.error("get entity type failed: " + e.getMessage());
      throw new ServiceApplicationException("get entity type failed: " + e.getMessage());
    }

    if (entityType == null) {
      logger.error("get entity type failed, entity name: " + entityName);
      throw new ServiceApplicationException("get entity type failed, entity name: " + entityName);
    }

    List<Property> propList = entityType.getProperties();
    if (propList != null && propList.size() > 0) {
      for (Property prop : propList) {
        if (prop instanceof SimpleProperty) {
          if (propName.equals(prop.getName())) {
            propType = ((SimpleProperty) prop).getType();
            break;
          }
        }
      }
    }

    return propType;
  }

  /**
   * @param contentType
   *          format of content in the given input stream known as "Accept", e.g. "application/json"
   * @param queryInfo
   *          contains query options and key values
   * @return
   * @throws ServiceApplicationException
   */
  public ODataEntry readEntry(String contentType, QueryInfo queryInfo) throws ServiceApplicationException {
    ODataEntry result = null;
    InputStream content = null;
    try {
      // get entity set
      EdmEntityContainer entityContainer = getEdm().getDefaultEntityContainer();
      EdmEntitySet entitySet = entityContainer.getEntitySet(queryInfo.getEntitySetName());
      // get content
      String absolutUri = createUri(auth.getServiceURL(), queryInfo);
      HttpURLConnection connection = connect(absolutUri, contentType, HttpMethod.GET);
      content = connection.getInputStream();
      // get entry
      result = EntityProvider.readEntry(contentType, entitySet, content, EntityProviderReadProperties.init().build());
    } catch (EntityProviderException | EdmException | IOException e) {
      String errMsg = "Failed to read OData entry: " + e.getMessage();
      logger.error(errMsg);
      throw new ServiceApplicationException(errMsg, e);
    } finally {
      IOUtils.closeQuietly(content);
    }
    return result;
  }

  /**
   * @param contentType
   *          format of content in the given input stream known as "Accept", e.g. "application/json"
   * @param entitySetName
   * @param data
   * @param viaOlingo
   *          some entity has null check for particular properties, using Olingo may not able to get the response
   * @return
   * @throws ServiceApplicationException
   */
  public ODataEntry createEntry(String contentType, String entitySetName, Map<String, Object> data, boolean viaOlingo)
      throws ServiceApplicationException {
    String absolutUri = createUri(auth.getServiceURL(), entitySetName, null);
    return writeEntity(absolutUri, entitySetName, data, contentType, HttpMethod.POST, viaOlingo);
  }

  /**
   * @param contentType
   *          format of content in the given input stream known as "Accept", e.g. "application/json"
   * @param entitySetName
   * @param id
   * @param data
   * @param viaOlingo
   * @return
   * @throws ServiceApplicationException
   */
  public void replaceEntry(String contentType, String entitySetName, String id, Map<String, Object> data,
      boolean viaOlingo) throws ServiceApplicationException {
    String absolutUri = createUri(auth.getServiceURL(), entitySetName, id);
    writeEntity(absolutUri, entitySetName, data, contentType, HttpMethod.PUT, viaOlingo);
  }

  public HttpStatusCodes deleteEntry(String entityName, String id) throws IOException, ServiceApplicationException {
    String absolutUri = createUri(auth.getServiceURL(), entityName, id);
    HttpURLConnection connection = connect(absolutUri, APPLICATION_XML, HttpMethod.DELETE);
    return HttpStatusCodes.fromStatusCode(connection.getResponseCode());
  }

  private byte[] streamToArray(InputStream stream) throws IOException {
    byte[] result = new byte[0];
    byte[] tmp = new byte[8192];
    int readCount = stream.read(tmp);
    while (readCount >= 0) {
      byte[] innerTmp = new byte[result.length + readCount];
      System.arraycopy(result, 0, innerTmp, 0, result.length);
      System.arraycopy(tmp, 0, innerTmp, result.length, readCount);
      result = innerTmp;
      readCount = stream.read(tmp);
    }
    return result;
  }

  private ODataEntry writeEntity(String absolutUri, String entitySetName, Map<String, Object> data, String contentType,
      String httpMethod, boolean viaOlingo) throws ServiceApplicationException {

    ODataEntry entry = null;
    byte[] buffer = null;
    HttpURLConnection connection = null;
    OutputStream os = null;
    InputStream is = null;

    try {
      // step 1: initialize the connection
      connection = initializeConnection(absolutUri, contentType, httpMethod);

      // step 2: write OData entry into the output stream of connection
      EdmEntitySet entitySet = getEdm().getDefaultEntityContainer().getEntitySet(entitySetName);
      ObjectMapper objectMapper = new ObjectMapper();
      if (viaOlingo) {
        // serialize data into ODataResponse object
        URI rootUri = new URI(entitySetName);
        EntityProviderWriteProperties writeProperties = EntityProviderWriteProperties.serviceRoot(rootUri).build();
        ODataResponse response = EntityProvider.writeEntry(contentType, entitySet, data, writeProperties);
        // get entity from default Olingo implementation (as InputStream)
        Object entity = response.getEntity();
        if (entity instanceof InputStream) {
          buffer = streamToArray((InputStream) entity);
        }
      } else {
        // some entity has nullable check for particular properties, using Olingo may not able to get the response
        String jsonData = objectMapper.writeValueAsString(data);
        buffer = jsonData.getBytes(StandardCharsets.UTF_8);
      }
      os = connection.getOutputStream();
      os.write(buffer);

      // Step 3: put the newly created entity into response body as an ODataEntry object
      if (checkStatus(connection) == HttpStatusCodes.CREATED) {
        // de-serialize the content into an ODataEntry object
        is = connection.getInputStream();
        // remove navigation properties which may lead problems when build the ODataEntry
        JsonNode entryNode = objectMapper.readTree(is).get("d");
        Iterator<Entry<String, JsonNode>> itr = entryNode.fields();
        while (itr.hasNext()) {
          Entry<String, JsonNode> field = itr.next();
          JsonNode propertyNode = field.getValue();
          if (!propertyNode.isValueNode()) {
            itr.remove();
          }
        }
        // use the updated content as the newly created entry
        InputStream content = new ByteArrayInputStream(entryNode.toString().getBytes(StandardCharsets.UTF_8));
        EntityProviderReadProperties readProps = EntityProviderReadProperties.init().build();
        entry = EntityProvider.readEntry(contentType, entitySet, content, readProps);
      }
    } catch (IOException | EntityProviderException | URISyntaxException | EdmException e) {
      logger.error("write entry failed due to: " + e.getMessage());
      throw new ServiceApplicationException("write entry failed due to: " + e.getMessage(), e);
    } finally {
      if (connection != null) {
        connection.disconnect();
      }
      IOUtils.closeQuietly(os);
      IOUtils.closeQuietly(is);
    }
    return entry;
  }

  /**
   * @param contentType
   *          format of content in the given input stream known as "Accept", e.g. "application/json"
   * @param queryInfo
   *          contains query options and key values
   * @return
   * @throws ServiceApplicationException
   */
  public ODataFeed readFeed(String contentType, QueryInfo queryInfo) throws ServiceApplicationException {
    ODataFeed result = null;
    InputStream content = null;
    try {
      // get entity set
      EdmEntityContainer entityContainer = getEdm().getDefaultEntityContainer();
      EdmEntitySet entitySet = entityContainer.getEntitySet(queryInfo.getTargetEntitySetName());
      // get content
      String absolutUri = createUri(auth.getServiceURL(), queryInfo);
      HttpURLConnection connection = connect(absolutUri, contentType, HttpMethod.GET);
      content = connection.getInputStream();
      // get feed
      result = EntityProvider.readFeed(contentType, entitySet, content, EntityProviderReadProperties.init().build());
    } catch (EntityProviderException | EdmException | IOException e) {
      String errMsg = "Read OData Feed Failed: " + e.getMessage();
      logger.error(errMsg);
      throw new ServiceApplicationException(errMsg, e);
    } finally {
      IOUtils.closeQuietly(content);
    }
    return result;
  }

  public String readFeedAsString(String contentType, QueryInfo queryInfo) throws ServiceApplicationException {
    String result = null;
    InputStream content = null;
    try {
      String absolutUri = createUri(auth.getServiceURL(), queryInfo);
      HttpURLConnection connection = connect(absolutUri, contentType, HttpMethod.GET);
      content = connection.getInputStream();
      result = IOUtils.toString(content, StandardCharsets.UTF_8.name());
    } catch (IOException e) {
      String errMsg = "Read OData Feed Failed: " + e.getMessage();
      logger.error(errMsg);
      throw new ServiceApplicationException(errMsg, e);
    } finally {
      IOUtils.closeQuietly(content);
    }
    return result;
  }

  private HttpURLConnection connect(String absolutUri, String contentType, String httpMethod) throws IOException,
      ServiceApplicationException {
    HttpURLConnection connection = initializeConnection(absolutUri, contentType, httpMethod);
    connection.connect();
    checkStatus(connection);
    return connection;
  }

  private HttpStatusCodes checkStatus(HttpURLConnection connection) throws IOException {
    HttpStatusCodes httpStatusCode = HttpStatusCodes.fromStatusCode(connection.getResponseCode());
    if (400 <= httpStatusCode.getStatusCode() && httpStatusCode.getStatusCode() <= 599) {
      String errMsg = "Http Connection failed with status " + httpStatusCode.getStatusCode() + " "
          + httpStatusCode.toString();

      logger.error(errMsg);
      InputStream errStream = null;
      try {
        errStream = connection.getErrorStream();
        String responseText = IOUtils.toString(errStream);
        logger.error("Error response is: " + responseText);
      } catch (IOException e) {

      } finally {
        IOUtils.closeQuietly(errStream);
      }

      throw new RuntimeException(errMsg);
    }
    return httpStatusCode;
  }

  private HttpURLConnection initializeConnection(String absolutUri, String contentType, String httpMethod)
      throws IOException {
    HttpURLConnection connection = null;
    URL url = new URL(absolutUri);

    connection = (HttpURLConnection) url.openConnection();
    if (connection instanceof HttpsURLConnection) {
      disableSSLVerification((HttpsURLConnection) connection);
    }

    connection.setRequestMethod(httpMethod);
    connection.setRequestProperty(HttpHeaders.ACCEPT, contentType);
    connection.setRequestProperty(HttpHeaders.AUTHORIZATION, auth.getAuthentication());
    if (HttpMethod.POST.equals(httpMethod) || HttpMethod.PUT.equals(httpMethod)) {
      connection.setDoOutput(true);
      connection.setRequestProperty(HttpHeaders.CONTENT_TYPE, contentType);
    }
    return connection;
  }

  private void disableSSLVerification(HttpsURLConnection connection) {
    connection.setHostnameVerifier(new HostnameVerifier() {
      public boolean verify(String hostname, SSLSession session) {
        return true;
      }
    });
  }

  /**
   * @param serviceUri
   * @param queryInfo
   * @return
   */
  private String createUri(String serviceUri, QueryInfo queryInfo) {
    StringBuilder sb = new StringBuilder(serviceUri);
    sb.append(queryInfo.getEntitySetName());
    // key value
    if (queryInfo.getKeyValue() != null) {
      sb.append("('").append(queryInfo.getKeyValue()).append("')");
      // check if navigation is required
      if (queryInfo.getNavPropName() != null) {
        sb.append("/").append(queryInfo.getNavPropName());
      }
    }
    // options
    Map<String, String> queryOptions = queryInfo.getQueryOptions();
    if (!queryOptions.isEmpty()) {
      boolean isFirstOption = true;
      for (Map.Entry<String, String> entry : queryOptions.entrySet()) {
        sb.append(isFirstOption ? "?" : "&");
        sb.append(entry.getKey()).append("=");
        // no white space in URI
        String encodedUri = entry.getValue().replaceAll(" ", "%20");
        sb.append(encodedUri);
        isFirstOption = false;
      }
    }
    return sb.toString();
  }

  private String createUri(String serviceUri, String entitySetName, String id) {
    QueryInfo queryInfo = new QueryInfo(entitySetName, id);
    return createUri(serviceUri, queryInfo);
  }

}
