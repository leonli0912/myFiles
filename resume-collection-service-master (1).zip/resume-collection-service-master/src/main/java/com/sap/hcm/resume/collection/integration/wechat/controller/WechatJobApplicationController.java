package com.sap.hcm.resume.collection.integration.wechat.controller;

import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MarkerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sap.hcm.resume.collection.bean.ExceptionTypeEnum;
import com.sap.hcm.resume.collection.bean.FunctionTypeEnum;
import com.sap.hcm.resume.collection.bean.JobAppQuestionResponse;
import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.bean.SimpleJsonResponse;
import com.sap.hcm.resume.collection.controller.ControllerBase;
import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.entity.DataModelMapping;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileExtVO;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatApplyHistory;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJob;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJobApplicationVO;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatUser;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatJobService;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatUserService;
import com.sap.hcm.resume.collection.service.CandidateProfileService;
import com.sap.hcm.resume.collection.service.CandidateService;
import com.sap.hcm.resume.collection.service.DataModelMappingService;
import com.sap.hcm.resume.collection.service.ExceptionLogService;
import com.sap.hcm.resume.collection.service.JobApplicationService;
import com.sap.hcm.resume.collection.util.CandidateDateUtil;

@RestController
@RequestMapping(value = "/wechatJobApp")
public class WechatJobApplicationController extends ControllerBase {

  private Logger logger = LoggerFactory.getLogger(this.getClass());

  @Autowired
  private DataModelMappingService mappingService;

  @Autowired
  private WechatJobService wechatJobService;

  @Autowired
  private CandidateProfileService candidateProfileService;

  @Autowired
  private CandidateService candidateService;

  @Autowired
  private JobApplicationService jobApplicationService;

  @Autowired
  private WechatUserService wechatUserService;

  @Autowired
  private ExceptionLogService exceptionLogService;

  @Autowired
  private Params params;

  @RequestMapping("/refreshStatus")
  public SimpleJsonResponse refreshStatus(HttpServletRequest request,
      @RequestParam(value = "applyHistoryId") Long applyHistoryId) {

    SimpleJsonResponse response = new SimpleJsonResponse();
    String companyId = params.getCompanyId();
    String userEmail = params.getUserEmail();
    Locale locale = request.getLocale();

    String applicationId = null;
    String status = null;
    try {
      applicationId = wechatJobService.getAppId(userEmail, companyId, applyHistoryId);
      status = jobApplicationService.queryAppliationStatus(applicationId, locale);
      wechatJobService.saveStatus(userEmail, companyId, applyHistoryId, status);
      response.setCode(0);
      response.setMessage(status);
    } catch (ServiceApplicationException e) {
      response.setCode(-1);
      response.setMessage("refresh job application status failed"); // TODO i18n required
      logger.error("refresh job application status failed due to: " + e.getMessage());
    }

    return response;
  }

  @RequestMapping(value = "/jobApp", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
  public SimpleJsonResponse applyJob(HttpServletRequest request,
      @RequestParam(value = "candidateId") Long candidateId, @RequestParam(value = "jobId") Long jobId,
      @RequestBody(required = false) List<JobAppQuestionResponse> questionResponses) throws ServiceApplicationException {

    SimpleJsonResponse response = new SimpleJsonResponse();

    // get wechatId and companyId from session
    String companyId = params.getCompanyId();
    String userEmail = params.getUserEmail();

    try {
      // get companyInfo
      CompanyInfo companyInfo = compInfoService.getCompanyInfo(companyId);
      if (companyInfo == null) {
        response.setCode(-1);
        // TODO - i18n required
        response.setMessage("company info not found");
        logger.error(MarkerFactory.getMarker("Critial"), "company info not found, compnayId:" + companyId);
        return response;
      }
      // get WeChat user and verify user's status of privacy agreement
      WechatUser wechatUser = wechatUserService.getUserInfoByEmail(userEmail, companyId);
      if (!wechatUser.isDpcsAgreed()) {
        wechatUser.setDpcsAgreed(true);
        wechatUserService.saveWechatUser(wechatUser);
      }
      // get data model mapping
      DataModelMapping mapping = mappingService.getMappingById(companyInfo.getDmMappingId());
      if (mapping == null) {
        response.setCode(-1);
        // TODO - i18n required
        response.setMessage("candidate profile mapping not found.");
        logger.error("candidate profile mapping not found.");
        return response;
      }

      // get local candidate
      CandidateProfileVO candidateProfileVO = candidateProfileService.getCandidateProfileById(candidateId);
      CandidateProfileExtVO extProfile = candidateProfileVO.getExtProfile();
      if (extProfile == null) {
        extProfile = new CandidateProfileExtVO();
      }
      extProfile.setResumeExtension("pdf");
      extProfile.setCandidateSource("WeChat");
      extProfile.setCandidateType("WeChat");
      candidateProfileVO.setExtProfile(extProfile);

      // get SF jobReqId from WechatJob by jobId
      WechatJob wechatJob = wechatJobService.findJobById(jobId);
      // check whether the job has been applied before
      List<WechatApplyHistory> applyHistoryList = wechatJobService.findApplyHistoryForCheck(
          candidateProfileVO.getPrimaryEmail(), wechatJob.getExternalJobId());
      if (!applyHistoryList.isEmpty()) {
        response.setCode(0);
        response.setMessage("JOB_ALREADY_APPLIED");
        logger.error("The candidate has already applied the job");
        return response;
      }

      // TODO transaction implementation required via batch odata api
      // calls
      Long sfCandidateId = candidateService.getCandidateId(candidateProfileVO.getPrimaryEmail());
      // this candidate has not been inserted before
      if (sfCandidateId == null) {
        // insert candidate into SF
        candidateProfileVO = candidateService.insertCandidate(candidateProfileVO, mapping);
      } else {
        candidateProfileVO.getExtProfile().setExternalCandidateId(sfCandidateId);
      }

      // apply job to successfactors
      WechatJobApplicationVO jobAppVO = jobApplicationService.insertJobApplication(candidateProfileVO, mapping,
          wechatJob, questionResponses);
      Locale locale = request.getLocale();
      if (locale == null) {
        locale = Locale.CHINESE;
      }
      String status = jobApplicationService.queryAppliationStatus(jobAppVO.getApplicationId(), locale);
      // insert history into local
      WechatApplyHistory wechatApplyHistory = new WechatApplyHistory();
      wechatApplyHistory.setWechatId(params.getUserEmail());
      wechatApplyHistory.setCompanyId(companyId);
      wechatApplyHistory.setSfjobApplicationId(jobAppVO.getApplicationId());
      wechatApplyHistory.setJobId(wechatJob.getJobId());
      wechatApplyHistory.setExternalJobId(wechatJob.getExternalJobId());
      wechatApplyHistory.setJobTitle(wechatJob.getJobTitle());
      wechatApplyHistory.setApplyEmail(candidateProfileVO.getPrimaryEmail());
      wechatApplyHistory.setApplyStatus(status);
      wechatApplyHistory.setApplyDate(CandidateDateUtil.formatDate2String(new Date(), "yyyy/MM/dd"));
      wechatJobService.saveHistory(wechatApplyHistory);

      response.setCode(1);
      response.setMessage("success");

      return response;

    } catch (ServiceApplicationException e) {
      String errorMsg = "apply job failed, user: " + userEmail;
      exceptionLogService.saveExceptionLog(companyId, ExceptionTypeEnum.ERROR.getLabelKey(),
          FunctionTypeEnum.JOB_APPLY.getLabelKey(), errorMsg + "; root cause: " + e.getMessage());
      response.setCode(0);
      // TODO - i18n required
      response.setMessage(errorMsg);
      logger.error(MarkerFactory.getMarker("Critical"), errorMsg + "; root cause: " + e.getMessage());
      return response;
    }

  }

}
