package com.sap.hcm.resume.collection.integration.sf.bean.cdm;

import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

/**
 * Successfactor candidate data model field definition
 * @author i065831
 *
 */
@XStreamAlias("field-definition")
public class SFCDMFieldDefinition {
   
    @XStreamAsAttribute()
    public String id;
    
    @XStreamAsAttribute()
    public String type;
    
    @XStreamAsAttribute()
    public boolean required;
    
    @XStreamAsAttribute()
    public boolean custom;
    
    @XStreamAsAttribute()
    public boolean readOnly;
    
    @XStreamAsAttribute()
    public boolean anonymize;
    
    @XStreamAsAttribute()
    @XStreamAlias("forward-intact")
    public boolean forwardIntact;
    
    @XStreamImplicit(itemFieldName="field-label")
    public List<SFCDMFieldLabel> FieldLabel;
    
    @XStreamImplicit(itemFieldName="field-description")
    public List<String> fieldDescription;
    
    @XStreamAlias("picklist-id")
    public String picklistId;
    
    @XStreamImplicit(itemFieldName="enum-value")  
    public List<SFCDMFieldEnum> enumValue;
    
    @XStreamAlias("default-value")
    public String defaultValue;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public boolean isRequired() {
        return required;
    }

    public void setRequired(boolean required) {
        this.required = required;
    }

    public boolean isCustom() {
        return custom;
    }

    public void setCustom(boolean custom) {
        this.custom = custom;
    }

    public boolean isReadOnly() {
        return readOnly;
    }

    public void setReadOnly(boolean readOnly) {
        this.readOnly = readOnly;
    }

    public boolean isAnonymize() {
        return anonymize;
    }

    public void setAnonymize(boolean anonymize) {
        this.anonymize = anonymize;
    }

    public boolean isForwardIntact() {
        return forwardIntact;
    }

    public void setForwardIntact(boolean forwardIntact) {
        this.forwardIntact = forwardIntact;
    }

    public String getPicklistId() {
        return picklistId;
    }

    public void setPicklistId(String picklistId) {
        this.picklistId = picklistId;
    }

    public List<SFCDMFieldEnum> getEnumValue() {
        return enumValue;
    }

    public void setEnumValue(List<SFCDMFieldEnum> enumValue) {
        this.enumValue = enumValue;
    }

    public String getDefaultValue() {
        return defaultValue;
    }

    public void setDefaultValue(String defaultValue) {
        this.defaultValue = defaultValue;
    }
}
