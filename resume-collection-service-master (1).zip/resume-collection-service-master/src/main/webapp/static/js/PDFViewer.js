sap.ui.core.Control.extend("static.js.PDFViewer",{
	metadata:{
		properties:{
			path:"string",
			width:{
				type:"string",
				defaultValue:"800px"
			},
			height:{
				type:"string",
				defaultValue:"700px"
			}
		}
	},
	
	renderer:function(rm, oControl){
	
		rm.write("<object toolbar= 'false' type='application/pdf'");
		rm.writeControlData(oControl);
		rm.addStyle("width", oControl.getWidth());
		rm.addStyle("height", oControl.getHeight());
		rm.writeStyles();
		rm.write("data = " + oControl.getPath());
		rm.write(">")
		
		rm.write("</object>");
	}
});