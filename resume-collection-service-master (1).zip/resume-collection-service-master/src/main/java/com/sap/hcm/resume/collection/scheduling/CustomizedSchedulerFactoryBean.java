package com.sap.hcm.resume.collection.scheduling;

import java.util.List;

import org.quartz.CronTrigger;
import org.quartz.Job;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.MethodInvokingJobDetailFactoryBean;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;
import org.springframework.util.StringUtils;

import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.service.CompanyInfoService;

@Configuration
public class CustomizedSchedulerFactoryBean {

  private static final Logger logger = LoggerFactory.getLogger(CustomizedSchedulerFactoryBean.class);
  
  private CompanyInfo info;

  @Autowired
  @Qualifier(value="jobRequisitionSynchronizeScheduler")
  private Job jobRequisitionSynchronizeScheduler;

  @Autowired
  private ChangeLogCleanScheduler changeLogCleanScheduler;

  @Autowired
  private CompanyInfoService companyInfoService;
  
  @Autowired
  private JobTriggerBean jobTriggerBean;

  /**
   * @return the info
   */
  public CompanyInfo getInfo() {
    return info;
  }

  /**
   * @param info the info to set
   */
  public void setInfo(CompanyInfo info) {
    this.info = info;
  }

  @Bean
  public SchedulerFactoryBean trigger() throws ServiceApplicationException {
    logger.debug("Start Scheduler ...");
    SchedulerFactoryBean schedulerFactoryBean = new SchedulerFactoryBean();
    List<CompanyInfo> companyInfoList = companyInfoService.findAllCompany();
    int arrSize = companyInfoList.size() + 1;
    CronTrigger[] triggerArray = new CronTrigger[arrSize];
    for (int i = 0; i < companyInfoList.size(); i++) {
      this.setInfo(companyInfoList.get(i));
      triggerArray[i] = jobReqSyncTrigger().getObject();
    }
    triggerArray[arrSize-1] = cleanChangeLogTrigger().getObject();
    schedulerFactoryBean.setTriggers(triggerArray);
    jobTriggerBean.setSchedulerFactoryBean(schedulerFactoryBean);
    logger.debug("End Scheduler ...");
    return schedulerFactoryBean;
  }

  @Bean
  @Scope(value = "prototype")
  public CronTriggerFactoryBean jobReqSyncTrigger() {
    logger.debug("Start Trigger ...");
    CronTriggerFactoryBean cronTriggerFactoryBean = new CronTriggerFactoryBean();
    cronTriggerFactoryBean.setJobDetail(jobReqSyncJob().getObject());
    String cronExpression = this.getInfo().getTriggerExpression();
    if (StringUtils.isEmpty(cronExpression)) {
      cronExpression = "0 0 0 * * ?";
    }
    cronTriggerFactoryBean.setCronExpression(cronExpression);
    cronTriggerFactoryBean.setName(this.getInfo().getCompanyId() + "_Trigger");
    logger.debug("End Trigger ...");
    return cronTriggerFactoryBean;
  }

  @Bean
  public CronTriggerFactoryBean cleanChangeLogTrigger() {
    CronTriggerFactoryBean cronTriggerFactoryBean = new CronTriggerFactoryBean();
    cronTriggerFactoryBean.setJobDetail(cleanChangeLogJob().getObject());
    cronTriggerFactoryBean.setCronExpression("0 0 23 * * ?");
    return cronTriggerFactoryBean;
  }
  
  @Bean
  @Scope(value = "prototype")
  public MethodInvokingJobDetailFactoryBean jobReqSyncJob() {
    logger.debug("Start Job ...");
    MethodInvokingJobDetailFactoryBean methodInvokingJobDetailFactoryBean = new MethodInvokingJobDetailFactoryBean();
    methodInvokingJobDetailFactoryBean.setTargetObject(jobRequisitionSynchronizeScheduler);
    methodInvokingJobDetailFactoryBean.setTargetMethod("work");
    methodInvokingJobDetailFactoryBean.setConcurrent(false);
    methodInvokingJobDetailFactoryBean.setName(this.getInfo().getCompanyId() + "_Job");
    String[] arguments = new String[]{this.getInfo().getCompanyId()};
    methodInvokingJobDetailFactoryBean.setArguments(arguments);
    logger.debug("End Job ...");
    return methodInvokingJobDetailFactoryBean;
  }

  @Bean
  public MethodInvokingJobDetailFactoryBean cleanChangeLogJob() {
    MethodInvokingJobDetailFactoryBean methodInvokingJobDetailFactoryBean = new MethodInvokingJobDetailFactoryBean();
    methodInvokingJobDetailFactoryBean.setTargetObject(changeLogCleanScheduler);
    methodInvokingJobDetailFactoryBean.setTargetMethod("work");
    return methodInvokingJobDetailFactoryBean;
  }
}
