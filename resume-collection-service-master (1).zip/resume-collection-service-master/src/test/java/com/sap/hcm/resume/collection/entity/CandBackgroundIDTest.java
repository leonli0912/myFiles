package com.sap.hcm.resume.collection.entity;


import org.junit.Assert;
import org.junit.Test;

public class CandBackgroundIDTest {
  
  @Test
  public void testIdenticalCandBackgroundID(){
    CandBackgroundID bgId = new CandBackgroundID();
    bgId.setBackgroundType("test");
    bgId.setCandidateId(1L);
    
    CandBackgroundID bgId2 = new CandBackgroundID();
    bgId2.setBackgroundType("test");
    bgId2.setCandidateId(1L);
    Assert.assertEquals(bgId.equals(bgId2), true);
    
    Assert.assertEquals(bgId.getCandidateId().toString(), "1");
    Assert.assertEquals(bgId.getBackgroundType(), "test");
  }
  
  @Test
  public void testNotIdenticalCandBackgroundID(){
    CandBackgroundID bgId = new CandBackgroundID();
    bgId.setBackgroundType("test");
    bgId.setCandidateId(1L);
    
    CandBackgroundID bgId2 = new CandBackgroundID();
    bgId2.setBackgroundType("test2");
    bgId2.setCandidateId(1L);
    Assert.assertEquals(bgId.equals(bgId2), false);
  }
  
  @Test
  public void testEquals(){
    CandBackgroundID bean1 = new CandBackgroundID();
    bean1.setBackgroundType("type");
    
    CandBackgroundID bean2 = new CandBackgroundID();
    bean2.setBackgroundType("type");
    
    Assert.assertEquals(bean1, bean2);
    
    bean1.setCandidateId(1L);
    bean2.setCandidateId(1L);
    Assert.assertEquals(bean1, bean2);
    
    Assert.assertEquals(bean1.equals(bean1), true);
    
    Assert.assertEquals(bean1.hashCode(), bean2.hashCode());
  }
  
  @Test
  public void testNotEquals(){
    CandBackgroundID bean1 = null;
    CandBackgroundID bean2 = new CandBackgroundID();
    Assert.assertNotEquals(bean1, bean2);
    
    Assert.assertNotEquals(bean2.equals(null), true);
    
    Assert.assertNotEquals(bean2, new String(""));
    
    bean1 = new CandBackgroundID();
    bean1.setBackgroundType("type");;
    Assert.assertNotEquals(bean1, bean2);
        
    bean1.setCandidateId(1L);
    Assert.assertNotEquals(bean1, bean2);


    bean1.setBackgroundType(null);
    bean2.setBackgroundType("test");
    Assert.assertNotEquals(bean1.equals(bean2), true);
    
    bean1.setBackgroundType("test");
    bean2.setBackgroundType("test");
    bean1.setCandidateId(null);
    bean2.setCandidateId(1L);
    Assert.assertNotEquals(bean1.equals(bean2), true);
        
    bean1.setBackgroundType("test");
    bean2.setBackgroundType("test");
    bean1.setCandidateId(2L);
    bean2.setCandidateId(1L);
    Assert.assertNotEquals(bean1.equals(bean2), true);
  }
}
