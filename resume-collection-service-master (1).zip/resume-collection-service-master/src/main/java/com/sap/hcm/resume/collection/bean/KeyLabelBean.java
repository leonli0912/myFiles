package com.sap.hcm.resume.collection.bean;

import java.io.Serializable;

/**
 * bean for dropdown
 * @author i065831
 *
 */
public class KeyLabelBean implements Serializable{
	
	/**
	 * serialVersionUID
	 */
    private static final long serialVersionUID = -3000020092109285110L;

	private String key;
	
	private String label;
	
	private String additionalText;

	/**
	 * @return the key
	 */
	public String getKey() {
		return key;
	}

	/**
	 * @param key the key to set
	 */
	public void setKey(String key) {
		this.key = key;
	}

	/**
	 * @return the label
	 */
	public String getLabel() {
		return label;
	}

	/**
	 * @param label the label to set
	 */
	public void setLabel(String label) {
		this.label = label;
	}

	/**
     * @return the additionalText
     */
    public String getAdditionalText() {
        return additionalText;
    }

    /**
     * @param additionalText the additionalText to set
     */
    public void setAdditionalText(String additionalText) {
        this.additionalText = additionalText;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#hashCode()
     */
    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + ((additionalText == null) ? 0 : additionalText.hashCode());
        result = prime * result + ((key == null) ? 0 : key.hashCode());
        result = prime * result + ((label == null) ? 0 : label.hashCode());
        return result;
    }

    /* (non-Javadoc)
     * @see java.lang.Object#equals(java.lang.Object)
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        KeyLabelBean other = (KeyLabelBean) obj;
        if (additionalText == null) {
            if (other.additionalText != null)
                return false;
        } else if (!additionalText.equals(other.additionalText))
            return false;
        if (key == null) {
            if (other.key != null)
                return false;
        } else if (!key.equals(other.key))
            return false;
        if (label == null) {
            if (other.label != null)
                return false;
        } else if (!label.equals(other.label))
            return false;
        return true;
    }

    
}
