package com.sap.hcm.resume.collection.parser;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import com.sap.hcm.resume.collection.bean.ResumeInfo;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;

public class DocumentParserAdapterTest {
  
  HTMLDocumentParser htmlParser = null;

  TextDocumentParser textParser = null;
  
  private CandidateProfileVO candidateProfileVO;
  
  private ResumeInfo resumeInfo;

  
  private void initHTMLParser(){
    htmlParser = Mockito.mock(HTMLDocumentParser.class);
    textParser = null;
  }
  
  private void initTextParser(){
    htmlParser = null;
    textParser = Mockito.mock(TextDocumentParser.class);
  }
  
  @Before
  public void setUp(){
    candidateProfileVO = new CandidateProfileVO();
    candidateProfileVO.setFirstName("test");
    
    resumeInfo = new ResumeInfo();
    resumeInfo.setResumeExtension("html");
    resumeInfo.setHtmlDocument(null);
    resumeInfo.setTextContent("content");
  }
  
  @Test
  public void testConstructor(){
    initHTMLParser();
    DocumentParserAdapter adapter = new DocumentParserAdapter(htmlParser, textParser);
    Assert.assertNotNull(adapter.htmlParser);
    Assert.assertNull(adapter.textParser);
  }
  
  @Test
  public void testConstructor2(){
    initTextParser();
    DocumentParserAdapter adapter = new DocumentParserAdapter(htmlParser, textParser);
    Assert.assertNotNull(adapter.textParser);
    Assert.assertNull(adapter.htmlParser);
  }
  
  @Test
  public void testParseProfile() throws ServiceApplicationException{
    CandidateProfileVO vo = new CandidateProfileVO();
    this.initHTMLParser();
    DocumentParserAdapter adapter = new DocumentParserAdapter(htmlParser, textParser);
    
    Mockito.when(htmlParser.parseProfile(candidateProfileVO, resumeInfo.getHtmlDocument())).thenReturn(vo);
    vo = adapter.parseProfile(candidateProfileVO, resumeInfo);
    Assert.assertNotNull(vo);
    
    this.initTextParser();
    adapter = new DocumentParserAdapter(htmlParser, textParser);
    
    Mockito.when(textParser.parseProfile(candidateProfileVO, resumeInfo.getTextContent())).thenReturn(vo);
    vo = adapter.parseProfile(candidateProfileVO, resumeInfo);
    Assert.assertNotNull(vo);
  }
  
  @Test
  public void testParseWorkExpr() throws ServiceApplicationException{
    CandidateProfileVO vo = new CandidateProfileVO();
    this.initHTMLParser();
    DocumentParserAdapter adapter = new DocumentParserAdapter(htmlParser, textParser);
    
    Mockito.when(htmlParser.parseBackgroundWorkExp(candidateProfileVO, resumeInfo.getHtmlDocument())).thenReturn(vo);
    vo = adapter.parseBackgroundWorkExp(candidateProfileVO, resumeInfo);
    Assert.assertNotNull(vo);
    
    this.initTextParser();
    adapter = new DocumentParserAdapter(htmlParser, textParser);
    
    Mockito.when(textParser.parseBackgroundWorkExp(candidateProfileVO, resumeInfo.getTextContent())).thenReturn(vo);
    vo = adapter.parseBackgroundWorkExp(candidateProfileVO, resumeInfo);
    Assert.assertNotNull(vo);
  }
  
  @Test
  public void testParseEducation() throws ServiceApplicationException{
    CandidateProfileVO vo = new CandidateProfileVO();
    this.initHTMLParser();
    DocumentParserAdapter adapter = new DocumentParserAdapter(htmlParser, textParser);
    
    Mockito.when(htmlParser.parseBackgroundEducation(candidateProfileVO, resumeInfo.getHtmlDocument())).thenReturn(vo);
    vo = adapter.parseBackgroundEducation(candidateProfileVO, resumeInfo);
    Assert.assertNotNull(vo);
    
    this.initTextParser();
    adapter = new DocumentParserAdapter(htmlParser, textParser);
    
    Mockito.when(textParser.parseBackgroundEducation(candidateProfileVO, resumeInfo.getTextContent())).thenReturn(vo);
    vo = adapter.parseBackgroundEducation(candidateProfileVO, resumeInfo);
    Assert.assertNotNull(vo);
  }
  
  @Test
  public void testParseLanguage() throws ServiceApplicationException{
    CandidateProfileVO vo = new CandidateProfileVO();
    this.initHTMLParser();
    DocumentParserAdapter adapter = new DocumentParserAdapter(htmlParser, textParser);
    
    Mockito.when(htmlParser.parseBackgroundLanguage(candidateProfileVO, resumeInfo.getHtmlDocument())).thenReturn(vo);
    vo = adapter.parseBackgroundLanguage(candidateProfileVO, resumeInfo);
    Assert.assertNotNull(vo);
    
    this.initTextParser();
    adapter = new DocumentParserAdapter(htmlParser, textParser);
    
    Mockito.when(textParser.parseBackgroundLanguage(candidateProfileVO, resumeInfo.getTextContent())).thenReturn(vo);
    vo = adapter.parseBackgroundLanguage(candidateProfileVO, resumeInfo);
    Assert.assertNotNull(vo);
  }
  
  @Test
  public void testParseCertificate() throws ServiceApplicationException{
    CandidateProfileVO vo = new CandidateProfileVO();
    this.initHTMLParser();
    DocumentParserAdapter adapter = new DocumentParserAdapter(htmlParser, textParser);
    
    Mockito.when(htmlParser.parseBackgroundCertificate(candidateProfileVO, resumeInfo.getHtmlDocument())).thenReturn(vo);
    vo = adapter.parseBackgroundCertificate(candidateProfileVO, resumeInfo);
    Assert.assertNotNull(vo);
    
    this.initTextParser();
    adapter = new DocumentParserAdapter(htmlParser, textParser);
    
    Mockito.when(textParser.parseBackgroundCertificate(candidateProfileVO, resumeInfo.getTextContent())).thenReturn(vo);
    vo = adapter.parseBackgroundCertificate(candidateProfileVO, resumeInfo);
    Assert.assertNotNull(vo);
  }
  
  @Test(expected=ServiceApplicationException.class)
  public void testNoParserFound() throws ServiceApplicationException{
    DocumentParserAdapter adapter = new DocumentParserAdapter(null, null);
    adapter.parseProfile(candidateProfileVO, resumeInfo);
  }
  
  @Test(expected=ServiceApplicationException.class)
  public void testNoParserFound2() throws ServiceApplicationException{
    DocumentParserAdapter adapter = new DocumentParserAdapter(null, null);
    adapter.parseBackgroundWorkExp(candidateProfileVO, resumeInfo);
  }
  
  @Test(expected=ServiceApplicationException.class)
  public void testNoParserFound3() throws ServiceApplicationException{
    DocumentParserAdapter adapter = new DocumentParserAdapter(null, null);
    adapter.parseBackgroundEducation(candidateProfileVO, resumeInfo);
  }
  
  @Test(expected=ServiceApplicationException.class)
  public void testNoParserFound4() throws ServiceApplicationException{
    DocumentParserAdapter adapter = new DocumentParserAdapter(null, null);
    adapter.parseBackgroundCertificate(candidateProfileVO, resumeInfo);
  }
  
  @Test(expected=ServiceApplicationException.class)
  public void testNoParserFound5() throws ServiceApplicationException{
    DocumentParserAdapter adapter = new DocumentParserAdapter(null, null);
    adapter.parseBackgroundLanguage(candidateProfileVO, resumeInfo);
  }
}
