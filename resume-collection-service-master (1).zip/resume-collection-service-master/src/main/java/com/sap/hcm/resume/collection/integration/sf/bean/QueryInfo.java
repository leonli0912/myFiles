package com.sap.hcm.resume.collection.integration.sf.bean;

import java.util.HashMap;
import java.util.Map;

/**
 * @author I075908 SAP
 */
public class QueryInfo {

  private final String entitySetName;

  private final String keyValue;

  private final String navPropName;
  
  private final String targetEntitySetName;

  private Map<String, String> queryOptions = new HashMap<String, String>();

  public QueryInfo(String entitySetName) {
    this(entitySetName, null);
  }

  public QueryInfo(String entitySetName, String keyValue) {
    this(entitySetName, keyValue, null);
  }

  public QueryInfo(String entitySetName, String keyValue, String navPropName) {
    this(entitySetName, keyValue, navPropName, entitySetName);
  }
  
  public QueryInfo(String entitySetName, String keyValue, String navPropName, String targetEntitySetName){
    this.entitySetName = entitySetName;
    this.keyValue = keyValue;
    this.navPropName = navPropName;
    this.targetEntitySetName = targetEntitySetName;
  }

  public String getEntitySetName() {
    return entitySetName;
  }

  public String getKeyValue() {
    return keyValue;
  }

  public String getNavPropName() {
    return navPropName;
  }

  public String getTargetEntitySetName() {
    return targetEntitySetName;
  }

  public Map<String, String> getQueryOptions() {
    return queryOptions;
  }

  public void addQueryOption(QueryOptionEnum queryOption, String value) {
    this.queryOptions.put(queryOption.getName(), value);
  }
}
