package com.sap.hcm.resume.collection.integration.wechat.service;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Service;

import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJobScreeningQuestionChoice;

@Service
public class WechatJobScreeningQuestionChoiceService {
  @PersistenceContext
  private EntityManager entityManager;

  public WechatJobScreeningQuestionChoice saveJobScreeningQuestionChoice(
      WechatJobScreeningQuestionChoice wechatJobScreeningQuestionChoice) throws ServiceApplicationException {

    wechatJobScreeningQuestionChoice = entityManager.merge(wechatJobScreeningQuestionChoice);
    return wechatJobScreeningQuestionChoice;
  }

  public List<WechatJobScreeningQuestionChoice> findJobScreeningQuestionChoice(String jobReqQuestionChoiceKey) {
    List<WechatJobScreeningQuestionChoice> wechatJobScreeningQuestionChoice = new ArrayList<WechatJobScreeningQuestionChoice>();
    String sel = "select h from WechatJobScreeningQuestionChoice h where h.jobReqQuestionChoiceKey = :jobReqQuestionChoiceKey";
    TypedQuery<WechatJobScreeningQuestionChoice> queryJobInfo = entityManager.createQuery(sel,
        WechatJobScreeningQuestionChoice.class);
    queryJobInfo.setParameter("jobReqQuestionChoiceKey", jobReqQuestionChoiceKey);
    wechatJobScreeningQuestionChoice = queryJobInfo.getResultList();
    return wechatJobScreeningQuestionChoice;
  }
}
