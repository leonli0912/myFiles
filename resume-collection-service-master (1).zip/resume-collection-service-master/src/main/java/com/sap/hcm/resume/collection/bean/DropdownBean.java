package com.sap.hcm.resume.collection.bean;

import java.io.Serializable;
import java.util.Set;

public class DropdownBean implements Serializable{
	
	/**
	 * serialVersionUID
	 */
    private static final long serialVersionUID = -5764758667007174936L;
    
	private Set<KeyLabelBean> options;

	/**
	 * @return the options
	 */
	public Set<KeyLabelBean> getOptions() {
		return options;
	}

	/**
	 * @param options the options to set
	 */
	public void setOptions(Set<KeyLabelBean> options) {
		this.options = options;
	}
	
}
