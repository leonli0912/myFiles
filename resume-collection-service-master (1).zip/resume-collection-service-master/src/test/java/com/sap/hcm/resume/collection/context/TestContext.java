package com.sap.hcm.resume.collection.context;

import static org.mockito.Mockito.mock;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;

import org.quartz.Job;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;

import com.sap.cloud.account.TenantContext;
import com.sap.core.connectivity.api.configuration.ConnectivityConfiguration;
import com.sap.hcm.resume.collection.bean.CompanyIdInfo;
import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.hcp.HCPUserProvider;
import com.sap.hcm.resume.collection.integration.JobBoardBaseProvider;
import com.sap.hcm.resume.collection.integration.JobBoardProviderFactory;
import com.sap.hcm.resume.collection.integration.service.CandidateIntegrationService;
import com.sap.hcm.resume.collection.integration.service.CandidateIntegrationServiceProxy;
import com.sap.hcm.resume.collection.integration.service.IntegrationServiceFactory;
import com.sap.hcm.resume.collection.integration.service.IntegrationServiceFactoryManager;
import com.sap.hcm.resume.collection.integration.service.JobApplicationIntegrationService;
import com.sap.hcm.resume.collection.integration.service.JobApplicationIntegrationServiceProxy;
import com.sap.hcm.resume.collection.integration.service.JobRequisitionIntegrationService;
import com.sap.hcm.resume.collection.integration.service.JobRequisitionIntergrationServiceProxy;
import com.sap.hcm.resume.collection.integration.service.ResumeService;
import com.sap.hcm.resume.collection.integration.sf.SFOdataFormatter;
import com.sap.hcm.resume.collection.integration.sf.odata.SFAuthentication;
import com.sap.hcm.resume.collection.integration.sf.odata.SFODataService;
import com.sap.hcm.resume.collection.integration.sf.service.SFCandidateService;
import com.sap.hcm.resume.collection.integration.sf.service.SFIntegrationServiceFactory;
import com.sap.hcm.resume.collection.integration.sf.service.SFJobApplicationService;
import com.sap.hcm.resume.collection.integration.sf.service.SFJobRequisitionService;
import com.sap.hcm.resume.collection.integration.sf.service.SFPicklistCacheService;
import com.sap.hcm.resume.collection.integration.sf.service.SFPicklistService;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJobScreeningQuestionAndChoice;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatAuthService;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatJobScreeningQuestionChoiceService;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatJobScreeningQuestionService;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatJobService;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatLoginService;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatUserService;
import com.sap.hcm.resume.collection.integration.wechat.util.WechatHelper;
import com.sap.hcm.resume.collection.integration.wechat.util.WechatResumeHelper;
import com.sap.hcm.resume.collection.scheduling.ChangeLogCleanScheduler;
import com.sap.hcm.resume.collection.scheduling.JobRequisitionSynchronizeScheduler;
import com.sap.hcm.resume.collection.scheduling.JobTriggerBean;
import com.sap.hcm.resume.collection.service.CandidateProfileService;
import com.sap.hcm.resume.collection.service.CandidateService;
import com.sap.hcm.resume.collection.service.ChangeLogService;
import com.sap.hcm.resume.collection.service.CompanyInfoService;
import com.sap.hcm.resume.collection.service.DataModelMappingService;
import com.sap.hcm.resume.collection.service.ExceptionLogService;
import com.sap.hcm.resume.collection.service.JobApplicationService;
import com.sap.hcm.resume.collection.service.JobRequisitionService;
import com.sap.hcm.resume.collection.service.JobSchedulerService;
import com.sap.hcm.resume.collection.service.PhotoService;
import com.sap.hcm.resume.collection.util.CandidateProfileHelper;
import com.sap.hcm.resume.collection.util.ChangeLogUtil;
import com.sap.hcm.resume.collection.util.HTTPConnection;
import com.sap.security.um.user.UserProvider;

@Configuration
public class TestContext {
  
  @Bean(name = "companyInfoService")
  public CompanyInfoService companyInfoService() {
    return mock(CompanyInfoService.class);
  }

  @Bean(name = "exceptionLogService")
  public ExceptionLogService exceptionLogService() {
    return mock(ExceptionLogService.class);
  }

  @Bean(name = "candidateProfileService")
  public CandidateProfileService candidateProfileService() {
    return mock(CandidateProfileService.class);
  }

  @Bean(name = "dataModelMappingService")
  public DataModelMappingService dataModelMappingService() {
    return mock(DataModelMappingService.class);
  }

  @Bean(name = "entityManagerFactory")
  public EntityManagerFactory entityManagerFactory() {
    return mock(EntityManagerFactory.class);
  }

  @Bean(name = "entityManager")
  public EntityManager entityManager() {
    return mock(EntityManager.class);
  }

  @Bean(name = "photoService")
  public PhotoService photoService() {
    return mock(PhotoService.class);
  }

  @Bean(name = "wechatJobService")
  public WechatJobService wechatJobService() {
    return mock(WechatJobService.class);
  }

  @Bean(name = "query")
  public Query query() {
    return mock(Query.class);
  }

  @Bean(name = "wechatUserService")
  public WechatUserService wechatUserService() {
    return mock(WechatUserService.class);
  }

  @Bean(name = "candidateProfileService")
  public CandidateProfileService CandidateProfileService() {
    return mock(CandidateProfileService.class);
  }

  @Bean(name = "wechatResumeHelper")
  public WechatResumeHelper WechatResumeHelper() {
    return mock(WechatResumeHelper.class);
  }

  @Bean(name = "messageSource")
  public MessageSource messageSource() {
    return mock(MessageSource.class);
  }

  @Bean(name = "connectivityConfiguration")
  public ConnectivityConfiguration connectivityConfiguration() {
    return mock(ConnectivityConfiguration.class);
  }

  @Bean(name = "tenantContext")
  public TenantContext tenantContext() {
    return mock(TenantContext.class);
  }

  @Bean(name = "userProvider")
  public UserProvider userProvider() {
    return mock(UserProvider.class);
  }

  @Bean(name = "pklCacheService")
  public SFPicklistCacheService pklCacheService() {
    return mock(SFPicklistCacheService.class);
  }

  @Bean(name = "hcpUserProvider")
  public HCPUserProvider hcpUserProvider() {
    return mock(HCPUserProvider.class);
  }

  @Bean(name = "sfOdataFormatter")
  public SFOdataFormatter sfOdataFormatter() {
    return mock(SFOdataFormatter.class);
  }

  @Bean(name = "jobBoardProviderFactory")
  public JobBoardProviderFactory jobBoardProviderFactory() {
    return mock(JobBoardProviderFactory.class);
  }

  @Bean(name = "jobBoardBaseProvider")
  public JobBoardBaseProvider jobBoardBaseProvider() {
    return mock(JobBoardBaseProvider.class);
  }

  @Bean(name = "dajieProvider")
  public JobBoardBaseProvider dajieProvider() {
    return mock(JobBoardBaseProvider.class);
  }

  @Bean(name = "job51Provider")
  public JobBoardBaseProvider job51Provider() {
    return mock(JobBoardBaseProvider.class);
  }

  @Bean(name = "zhilianProvider")
  public JobBoardBaseProvider zhilianProvider() {
    return mock(JobBoardBaseProvider.class);
  }

  @Bean(name = "liepinProvider")
  public JobBoardBaseProvider liepinProvider() {
    return mock(JobBoardBaseProvider.class);
  }

  @Bean(name = "httpConnection")
  public HTTPConnection httpConnection() {
    return mock(HTTPConnection.class);
  }

  @Bean(name = "wechatMenuService")
  public WechatLoginService wechatMenuService() {
    return mock(WechatLoginService.class);
  }

  @Bean(name = "wechatHelper")
  public WechatHelper wechatHelper() {
    return mock(WechatHelper.class);
  }

  @Bean(name = "sfAuthentication")
  public SFAuthentication sfconnectionInfoBuilder() {
    return mock(SFAuthentication.class);
  }

  @Bean(name = "changeLogService")
  public ChangeLogService changeLogService() {
    return mock(ChangeLogService.class);
  }

  @Bean(name = "changeLogUtil")
  public ChangeLogUtil changeLogUtil() {
    return mock(ChangeLogUtil.class);
  }

  @Bean(name = "resumeService")
  public ResumeService resumeService() {
    return mock(ResumeService.class);
  }

  /**
   * candidate service mock starts
   */
  @Bean(name = "candidateService")
  public CandidateService candidateService() {
    return mock(CandidateService.class);
  }

  @Bean(name = "candidateIntegrationServiceProxy")
  public CandidateIntegrationService candidateIntegrationServiceProxy() {
    return mock(CandidateIntegrationServiceProxy.class);
  }

  @Bean(name = "sfCandidateService")
  public SFCandidateService sfCandidateService() {
    return mock(SFCandidateService.class);
  }

  /**
   * candidate service mock ends
   */

  /**
   * job application service mock starts
   */
  @Bean(name = "jobApplicationService")
  public JobApplicationService jobApplicationService() {
    return mock(JobApplicationService.class);
  }

  @Bean(name = "jobApplicationIntegrationServiceProxy")
  public JobApplicationIntegrationService integrationService() {
    return mock(JobApplicationIntegrationServiceProxy.class);
  }

  @Bean(name = "sfJobApplicationService")
  public SFJobApplicationService sfJobApplicationService() {
    return mock(SFJobApplicationService.class);
  }

  /**
   * job application service mock ends
   */

  @Bean(name = "factoryManager")
  public IntegrationServiceFactoryManager factoryManager() {
    return new IntegrationServiceFactoryManager();
  }

  @Bean(name = "sfIntegrationServiceFactory")
  public IntegrationServiceFactory sfFactory() {
    return mock(SFIntegrationServiceFactory.class);
  }

  @Bean(name = "sfODataService")
  public SFODataService sfODataService() {
    return mock(SFODataService.class);
  }

  @Bean(name = "candidateProfileHelper")
  public CandidateProfileHelper candidateProfileHelper() {
    return mock(CandidateProfileHelper.class);
  }

  @Bean(name = "params")
  public Params params() {
    Params params = new Params();
    params.setCompanyId("sap");
    params.setWechatOpenId("openid");
    return params;
  }

  @Bean(name = "sfPicklistService")
  public SFPicklistService sfPicklistService() {
    return mock(SFPicklistService.class);
  }

  @Bean(name = "wechatAuthService")
  public WechatAuthService wechatAuthService() {
    return mock(WechatAuthService.class);
  }

  @Bean(name = "wechatJobScreeningQuestionAndChoice")
  public WechatJobScreeningQuestionAndChoice wechatJobScreeningQuestionAndChoice() {
    return mock(WechatJobScreeningQuestionAndChoice.class);
  }

  @Bean(name = "wechatJobScreeningQuestionService")
  public WechatJobScreeningQuestionService wechatJobScreeningQuestionService() {
    return mock(WechatJobScreeningQuestionService.class);
  }

  @Bean(name = "wechatJobScreeningQuestionChoiceService")
  public WechatJobScreeningQuestionChoiceService wechatJobScreeningQuestionChoiceService() {
    return mock(WechatJobScreeningQuestionChoiceService.class);
  }
  
  @Bean(name="companyIdInfo")
  public CompanyIdInfo companyIdInfo(){
    return mock(CompanyIdInfo.class);
  }
  
  @Bean(name="jobRequisitionSynchronizeScheduler")
  public Job jobRequisitionSynchronizeScheduler(){
    return mock(JobRequisitionSynchronizeScheduler.class);
  }
  
  @Bean(name="changeLogCleanScheduler")
  public ChangeLogCleanScheduler changeLogCleanScheduler(){
    return mock(ChangeLogCleanScheduler.class);
  }
  
  @Bean(name="jobTriggerBean")
  public JobTriggerBean jobTriggerBean(){
    return mock(JobTriggerBean.class);
  }
  
  @Bean(name="jobSchedulerService")
  public JobSchedulerService jobSchedulerService(){
    return mock(JobSchedulerService.class);
  }
  
  @Bean(name="jobRequisitionService")
  public JobRequisitionService jobRequisitionService(){
    return mock(JobRequisitionService.class);
  }
  
  @Bean(name="jobRequisitionIntergrationServiceProxy")
  public JobRequisitionIntegrationService jobRequisitionIntergrationServiceProxy(){
    return mock(JobRequisitionIntergrationServiceProxy.class);
  }
  
  @Bean(name="sfJobRequisitionService")
  public JobRequisitionIntegrationService sfJobRequisitionService(){
    return mock(SFJobRequisitionService.class);
  }
  
  @Bean(name="schedulerFactoryBean")
  public SchedulerFactoryBean schedulerFactoryBean(){
    SchedulerFactoryBean schedulerFactoryBean = new SchedulerFactoryBean();
    return schedulerFactoryBean;
  }
}
