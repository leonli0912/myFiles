package com.sap.hcm.resume.collection.integration.wechat.util;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import static org.mockito.Mockito.spy;

import java.awt.Color;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.aspectj.lang.annotation.After;
import org.junit.runner.RunWith;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.sap.hcm.resume.collection.context.TestContext;
import com.sap.hcm.resume.collection.context.WebAppContext;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { TestContext.class, WebAppContext.class })
public class PDFPageWriterTest {
  
  private PDFPageWriter writer;
  
  private PDDocument doc = new PDDocument();
  
//  @Test
//  public void generateNewStyle() throws IOException{
//    writer = new PDFPageWriter(doc);
//    String text = "Hello World Hello World Hello World Hello World Hello World Hello World Hello World Hello World Hello World Hello World Hello World Hello World";
//    writer.write(50, 20, 16, Color.BLUE, text);
//    writer.writeSplitterLine(50, 10, Color.RED);
//    writer.write(50, 20, 16, Color.BLACK, text);
//    writer.close();
//    
//    doc.save("test.pdf");
//    doc.close();
//  }
  
  @Test
  public void testConstructor() throws IOException{
    try{
      writer = new PDFPageWriter(doc);
      Assert.assertNotNull(writer);
    }finally{
      writer.close();
    }
  }
  
  @Test
  public void testSetFont() throws IOException{
    try{
      writer = new PDFPageWriter(doc);
      writer.setFont(null);
    }finally{
      writer.close();
    }
  }
  
  @Test
  public void testDeductOffsetBy() throws IOException{
    try{
      writer = new PDFPageWriter(doc);
      int offsetY = writer.deductOffsetBy(20);
      Assert.assertEquals(730, offsetY);
    }finally{
      writer.close();
    }
  }
  
  @Test
  public void testDeductOffsetBy_ExceedThreshold() throws IOException{
    try{
      writer = new PDFPageWriter(doc);
      writer.deductOffsetBy(720);
      int offsetY =  writer.deductOffsetBy(20);
      Assert.assertEquals(750, offsetY);
    }finally{
      writer.close();
    }
  }
  
  @Test
  public void testWriteSingleLine() throws IOException{
    try{
      writer = new PDFPageWriter(doc);
      writer.write(50, 20, 16, null, "Hello World");
    }finally{
      writer.close();
      ByteArrayOutputStream byteOutputStream = new ByteArrayOutputStream();
      doc.save(byteOutputStream);
      doc.close();
      String content = byteOutputStream.toString("utf-8");
      Assert.assertNotNull(content);
    }
  }
  
  @Test
  public void testWriteMultipleLines() throws IOException{
    try{
      writer = new PDFPageWriter(doc);
      String text = "Hello World Hello World Hello World Hello World Hello World Hello World Hello World Hello World Hello World Hello World Hello World Hello World";
      writer.write(50, 20, 16, null, text);
    }finally{
      writer.close();
      ByteArrayOutputStream byteOutputStream = new ByteArrayOutputStream();
      doc.save(byteOutputStream);
      doc.close();
      String content = byteOutputStream.toString("utf-8");
      Assert.assertNotNull(content);
    }
  }
}
