package com.sap.hcm.resume.collection.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.sap.hcm.resume.collection.bean.KeyLabelBean;
import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.entity.ExceptionLog;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatJobService;
import com.sap.hcm.resume.collection.service.ExceptionLogService;

/**
 * controller for analytic data
 * 
 * @author i065831
 *
 */
@Controller
@RequestMapping(value = "report")
public class WechatReportController extends ControllerBase {
  
  @Autowired
  WechatJobService jobService;
  
  @Autowired
  ExceptionLogService exceptionLogService;
  
  @Autowired
  private Params params;
  
  @RequestMapping(value = "maintain")
  public ModelAndView goToReportPage() {
    ModelAndView mav = new ModelAndView();
    String companyId = params.getCompanyId();
    
    // verify company Id
    String resultView = this.validateCompanyAndUser(companyId);
    if (!StringUtils.isEmpty(resultView)) {
      mav.setViewName(resultView);
      return mav;
    }
    
    mav.addObject(companyId);
    mav.setViewName("report");
    return mav;
  }
  
  @RequestMapping(value = "/year")
  public @ResponseBody List<KeyLabelBean> viewDataByYear(){
    String companyId = params.getCompanyId();
    return jobService.getApplyHistoryStaticsByYear(companyId);
  }
  
  @RequestMapping(value = "/wechatusernbr")
  public @ResponseBody long getWechatUserNumber(){
    String companyId = params.getCompanyId();
    return jobService.getTotalWechatUserNumber(companyId);
  }
  
  @RequestMapping(value = "/loadexception")
  public @ResponseBody List<ExceptionLog> getExceptionLog() throws ServiceApplicationException{
    String companyId = params.getCompanyId();
    return exceptionLogService.findExceptionLog(companyId);
  }
  
  @RequestMapping(value = "/month/{year}")
  public @ResponseBody List<KeyLabelBean> viewDataByMonth(@PathVariable(value = "year") String year){
    String companyId = params.getCompanyId();
    return jobService.getApplyHistoryStaticsByMonth(companyId, year);
  }
}
