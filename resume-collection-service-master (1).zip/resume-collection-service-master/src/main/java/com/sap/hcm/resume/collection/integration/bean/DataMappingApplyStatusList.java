package com.sap.hcm.resume.collection.integration.bean;

import java.io.Serializable;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

@XStreamAlias("status-set")
public class DataMappingApplyStatusList implements Serializable {

  /**
   * serialVersionUID
   */
  private static final long serialVersionUID = -2279112850200968257L;
  
  @XStreamImplicit(itemFieldName="status-set-item")
  private List<DataMappingApplyStatus> statusSetItem;

  /**
   * @return the statusSetItem
   */
  public List<DataMappingApplyStatus> getStatusSetItem() {
    return statusSetItem;
  }

  /**
   * @param statusSetItem the statusSetItem to set
   */
  public void setStatusSetItem(List<DataMappingApplyStatus> statusSetItem) {
    this.statusSetItem = statusSetItem;
  }
}
