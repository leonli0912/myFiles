package com.sap.hcm.resume.collection.bean;

import org.junit.Assert;
import org.junit.Test;


public class FilterListItemTest {
  
  @Test
  public void testSetterGetter(){
    FilterListItem item = new FilterListItem();
    item.setTitle("test");
    item.setType("test");
    item.setValues(null);
    
    Assert.assertEquals(item.getTitle(), "test");
    Assert.assertEquals(item.getType(), "test");
    Assert.assertNull(item.getValues());
  }
}
