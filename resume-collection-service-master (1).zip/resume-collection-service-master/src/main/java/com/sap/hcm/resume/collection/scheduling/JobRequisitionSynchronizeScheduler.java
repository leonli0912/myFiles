package com.sap.hcm.resume.collection.scheduling;

import java.util.Date;

import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.QuartzJobBean;
import org.springframework.stereotype.Component;

import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.service.CompanyInfoService;
import com.sap.hcm.resume.collection.service.JobRequisitionService;

@Component(value = "jobRequisitionSynchronizeScheduler")
public class JobRequisitionSynchronizeScheduler extends QuartzJobBean {

  private static final Logger logger = LoggerFactory.getLogger(JobRequisitionSynchronizeScheduler.class);

  @Autowired
  private JobRequisitionService jobRequisitionService;

  @Autowired
  private CompanyInfoService companyInfoService;

  /* 业务实现 */
  public void work(String companyId) {
    CompanyInfo companyInfo = null;
    try {
      companyInfo = companyInfoService.getCompanyInfo(companyId);
    } catch (ServiceApplicationException e1) {
      // TODO Auto-generated catch block
      logger.debug("Error get company info before job sync");
    }
    if (companyInfo != null) {
      if (companyInfo.getEnableJobSync()) {
        logger.debug("Start syncing job on " + new Date());
        try {
          jobRequisitionService.syncJobRequisition(companyId);
        } catch (ServiceApplicationException e) {
          logger.debug("Sync job error with exception " + e.getMessage());
        }
        logger.debug("End syncing job on " + new Date());
      } else {
        logger.debug("Job sync skipped for company: " + companyId);
      }
    } else {
      logger.debug("Company info is null with company ID: " + companyId);
    }

  }

  @Override
  protected void executeInternal(JobExecutionContext arg0) throws JobExecutionException {
    this.work((String) arg0.getMergedJobDataMap().get("companyId"));
  }
}
