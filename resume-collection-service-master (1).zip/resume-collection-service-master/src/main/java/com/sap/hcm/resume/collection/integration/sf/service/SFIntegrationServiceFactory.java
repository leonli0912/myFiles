package com.sap.hcm.resume.collection.integration.sf.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

import com.sap.hcm.resume.collection.bean.BusinessEntityType;
import com.sap.hcm.resume.collection.integration.service.CandidateIntegrationService;
import com.sap.hcm.resume.collection.integration.service.IntegrationService;
import com.sap.hcm.resume.collection.integration.service.IntegrationServiceFactory;
import com.sap.hcm.resume.collection.integration.service.JobApplicationIntegrationService;
import com.sap.hcm.resume.collection.integration.service.JobRequisitionIntegrationService;

@Component(value = "sfIntegrationServiceFactory")
@Lazy
public class SFIntegrationServiceFactory implements IntegrationServiceFactory {

  @Autowired
  @Qualifier(value = "sfCandidateService")
  @Lazy
  CandidateIntegrationService sfCandidateService;

  @Autowired
  @Qualifier(value = "sfJobApplicationService")
  @Lazy
  JobApplicationIntegrationService sfJobApplicationService;

  @Autowired
  @Qualifier(value = "sfJobRequisitionService")
  @Lazy
  JobRequisitionIntegrationService sfJobRequisitionService;

  @Override
  public IntegrationService create(BusinessEntityType type) {
    if (type == BusinessEntityType.CANDIDATE) {
      return sfCandidateService;
    } else if (type == BusinessEntityType.JOBAPPLICATION) {
      return sfJobApplicationService;
    } else if (type == BusinessEntityType.JOBREQUISITION) {
      return sfJobRequisitionService;
    } else {
      return null;
    }

  }

}
