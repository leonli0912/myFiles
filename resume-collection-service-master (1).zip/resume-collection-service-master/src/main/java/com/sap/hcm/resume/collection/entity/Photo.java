package com.sap.hcm.resume.collection.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

@Entity
@Table(name = "POHTO")
public class Photo {
	@Id
    @GeneratedValue(strategy = GenerationType.TABLE, generator = "photo_seq")
    @TableGenerator(initialValue = 1, table = "SEQUENCE", name = "photo_seq", pkColumnName = "SEQ_NAME", valueColumnName = "SEQ_COUNT", pkColumnValue = "PHOTO_PK", allocationSize = 1)
    @Column(name = "PHOTO_ID")
    private Long photoId;
	
    @Column(name = "CATEGORY")
    private String category;
    
    @Column(name = "CONTENT")
    @Lob
    private byte[] content;

	public Long getPhotoId() {
		return photoId;
	}

	public void setPhotoId(Long photoId) {
		this.photoId = photoId;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public byte[] getContent() {
		return content;
	}

	public void setContent(byte[] content) {
		this.content = content;
	}
}
