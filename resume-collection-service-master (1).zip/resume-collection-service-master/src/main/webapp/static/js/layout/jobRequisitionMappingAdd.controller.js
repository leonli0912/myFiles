jQuery.sap.require("sap.m.MessageBox");
sap.ui.controller("static.js.layout.jobRequisitionMappingAdd", {


	_router: null,
	_currentMapping:null,
	_jobReqMapId:null,
/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf resume-collection-service.mappingAdd
*/
	onInit: function() {

		var oData = {
	    	"options":[{
	    		"key":"SF",
	    		"label":"SuccessFactor"
	    	}]
	    };

		/* Set Target System */
	    var oTargetSystem = this.getView().byId("targetSystem");
	    var oTargetSystemModel = new sap.ui.model.json.JSONModel();
	    oTargetSystemModel.setData(oData);
	    oTargetSystem.setModel(oTargetSystemModel);

	    this._router = sap.ui.core.UIComponent.getRouterFor(this);

	    var that = this;
		this._router.attachRouteMatched(function(oEvent){
			that.loadMappingData(oEvent.getParameter("arguments").id);
		});
	},


	alertMsg : function(requiredMsg) {
		var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
	    sap.m.MessageBox.alert(
	    	requiredMsg,
	    	{
	    		styleClass: bCompact? "sapUiSizeCompact" : ""
	    	}
	    );
	},
	loadMappingData: function(mapId){
		var that = this;
		if(mapId){
			this._jobReqMapId = mapId;
			$.ajax({
				type:"GET",
				dataType:"json",
				url:"jobreq/listMapping/"+mapId
			}).success(function(data) {
				that._currentMapping = data;
				var oMappingModel = new sap.ui.model.json.JSONModel();
				oMappingModel.setData(that._currentMapping.mapping);
				that.getView().setModel(oMappingModel);
				that.getView().byId("mappingName").setValue(data.mappingName);
		    });
		}else{
			var oMappingModel = new sap.ui.model.json.JSONModel("jobreq/new");
			that.getView().setModel(oMappingModel);
			that.getView().byId("mappingName").setValue("");
			that._currentMapping = null;
		}

	},

	translateWechatText: function(val){
		if(!val) return "";
		return this.getView().getModel("wi18n").getResourceBundle().getText(val);
	},

	onSave : function(oEvent) {

		var mappingModel = this.getView().getModel();
		var targetSystemData = this.getView().byId("targetSystem").getSelectedKey();
		var mappingNameData = this.getView().byId("mappingName").getValue();
		var mappingData = mappingModel.getData();
		var jsonData = {
				id : this._currentMapping ? this._currentMapping.id : null,
				targetSystem : targetSystemData,
				mappingName : mappingNameData,
				mapping : mappingData
		};
		var that = this;
		var cfg = {
			type : 'POST',
			data: JSON.stringify(jsonData),
			dataType : 'json',
			contentType : 'application/json;charset=UTF-8'
		};
		this.getView().setBusy(true);
		cfg.url = "jobreq/saveReqMapping";
	    $.ajax(cfg).success(function(data) {
	    	that.getView().setBusy(false);
	    	jQuery.sap.require("sap.m.MessageToast");
	    	if(data && data.code == "-1"){
	    		that.alertMsg(data.message);
	    	}else{
	    		sap.m.MessageToast.show("job requisition mapping successfully updated");
	    		that._router.navTo("mappingList");
	    	}

	    });

	},

	onCancel : function() {
		this._router.navTo("mappingList");
	},


	showValueHelp: function(oEvent){
		var bindContext = oEvent.getSource().getBindingContext();
		var rowData = bindContext.getModel().getObject(bindContext.sPath);
		this._picklist = rowData.picklist;

		if(this._picklist){
			this.openPicklistOptionsDialog(oEvent, this._picklist);
		}

	},

	openPicklistOptionsDialog: function(oEvent, picklist){

		var picklistOptionDialog = this.getView().byId("picklistOptionsPopover");
		this.getView().byId("pklLocale").setSelectedKey("zh_CN");
		
		//load picklist from SF
		var cfg = {
			type : 'GET',
			dataType : 'json',
			contentType : 'application/json;charset=UTF-8'
		};
		cfg.url = "sf/picklistOptions?picklist=" + picklist;
		var that = this;
		picklistOptionDialog.setBusy(true);
	    $.ajax(cfg).success(function(data) {
	    	var ojsonModel = new sap.ui.model.json.JSONModel();
	    	if(data && data.code == "-1"){
	    		ojsonModel.setData({errorMsg: data.message, options:[]});
	    	}else{
	    		ojsonModel.setData({errorMsg:"",options:data});
	    	}
			picklistOptionDialog.setModel(ojsonModel);
			picklistOptionDialog.setBusy(false);
	    });

	    picklistOptionDialog.openBy(oEvent.getSource());
	},

	pickOptionsLocaleChange: function(oEvent){
		var picklistOptionDialog = this.getView().byId("picklistOptionsPopover");
		//load picklist from SF
		var cfg = {
			type : 'GET',
			dataType : 'json',
			contentType : 'application/json;charset=UTF-8'
		};
		var locale = this.getView().byId("pklLocale").getSelectedKey();
		cfg.url = "sf/picklistOptions?picklist=" + this._picklist + "&locale="+locale;
		var that = this;
		picklistOptionDialog.setBusy(true);
    $.ajax(cfg).success(function(data) {
    	var ojsonModel = new sap.ui.model.json.JSONModel();
    	if(data && data.code == "-1"){
    		ojsonModel.setData({errorMsg: data.message, options:[]});
    	}else{
    		ojsonModel.setData({errorMsg:"",options:data});
    	}
			picklistOptionDialog.setModel(ojsonModel);
			picklistOptionDialog.setBusy(false);
	    });
	},
	pickOptionsDialogCloseOK: function(){
		this.getView().byId("picklistOptionsPopover").close();
		this._picklist = null;
	},
	pickOptionsDialogClose: function(){
		this.getView().byId("picklistOptionsPopover").close();
		this._picklist = null;
	},

	exportConfigure: function(oEvent){
		if (this._jobReqMapId){
			window.open("jobreq/"+this._jobReqMapId+"/export");
		}
		else{
			this.alertMsg("没有可导出的职位模型映射配置信息");
		}
	},

	importConfigure: function(oEvent){
		// var raw = oEvent.getParameter("response");
		var sResponse = JSON.parse(oEvent.getParameter("responseRaw"));
		// var result = JSON.parse(raw.replace(/<[^>]+>/gi,""));
		// var result = sResponse["results"];
		var ojobReqMappingModel = new sap.ui.model.json.JSONModel();
		ojobReqMappingModel.setData(sResponse);
		this.getView().setModel(ojobReqMappingModel);
	},

	setPickListHelpVisible: function(val){
		if(val){
			val = val.replace(/^\s+/g,"").replace(/\s+$/g,"");
		}
		if(!val){
			return false;
		}
		return true;
	},
		moveup: function(oEvent){
		var source = oEvent.getSource();
		var bindPath = source.getBindingContext().sPath.replace(/^\//,"");
		if(bindPath.split("/") < 2){
			return;
		}
		var propName = bindPath.split("/")[0];
		var index = parseInt(bindPath.split("/")[1]);

		var fData = this.getView().getModel().getData();
		var arr = fData[propName];
		if(index == 0){
			return;
		}else{
				arr[index] = arr.splice(index-1, 1, arr[index])[0];
		}
		this.getView().getModel().setData(fData);
	},

	movedown: function(oEvent){
		var source = oEvent.getSource();
		var bindPath = source.getBindingContext().sPath.replace(/^\//,"");
		if(bindPath.split("/") < 2){
			return;
		}
		var propName = bindPath.split("/")[0];
		var index = parseInt(bindPath.split("/")[1]);

		var fData = this.getView().getModel().getData();
		var arr = fData[propName];
		if(index == arr.length-1){
			return;
		}else{
			arr[index+1] = arr.splice(index, 1, arr[index+1])[0];
		}
		this.getView().getModel().setData(fData);
	},
/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf resume-collection-service.mappingAdd
*/
//	onBeforeRendering: function() {
//
//	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf resume-collection-service.mappingAdd
*/
	onAfterRendering: function() {

	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf resume-collection-service.mappingAdd
*/
//	onExit: function() {
//
//	}

});
