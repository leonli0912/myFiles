package com.sap.hcm.resume.collection.integration.sf.service;

import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.ws.rs.ext.ParamConverter.Lazy;

import org.apache.olingo.odata2.api.ep.entry.ODataEntry;
import org.apache.olingo.odata2.api.ep.feed.ODataFeed;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sap.hcm.resume.collection.bean.JobAppQuestionResponse;
import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.entity.DataModelMapping;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;
import com.sap.hcm.resume.collection.entity.view.JobApplyMappingVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.bean.CandProfileDataModelMapping;
import com.sap.hcm.resume.collection.integration.service.JobApplicationIntegrationService;
import com.sap.hcm.resume.collection.integration.sf.SFOdataFormatter;
import com.sap.hcm.resume.collection.integration.sf.bean.QueryInfo;
import com.sap.hcm.resume.collection.integration.sf.odata.SFODataConstants;
import com.sap.hcm.resume.collection.integration.sf.odata.SFODataEntityType;
import com.sap.hcm.resume.collection.integration.sf.odata.SFODataService;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJob;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJobApplicationVO;
import com.sap.hcm.resume.collection.service.CompanyInfoService;

@Service(value = "sfJobApplicationService")
@Lazy
public class SFJobApplicationService implements JobApplicationIntegrationService {

  /**
   * logger instance
   */
  private Logger logger = LoggerFactory.getLogger(SFJobApplicationService.class);

  @Autowired
  private SFODataService sfOdataService;

  @Autowired
  private SFOdataFormatter odataFormatter;

  @Autowired
  private CompanyInfoService companyInfoService;

  @Autowired
  private Params params;

  private static final String APPLICATION_JSON = "application/json;charset=utf-8";

  @Override
  public WechatJobApplicationVO insertJobApplication(CandidateProfileVO candidateProfileVO, DataModelMapping mapping,
      WechatJob wechatJob, JobApplyMappingVO jobApplyMappingVO, CandProfileDataModelMapping profileMapping, List<JobAppQuestionResponse> questionResponses)
      throws ServiceApplicationException {

    CompanyInfo info = companyInfoService.getCompanyInfo(params.getCompanyId());

    ODataEntry newApplication = null;
    try {
      
      Map<String, Object> data = odataFormatter.getSFJobApplicationOdataFormat(profileMapping, candidateProfileVO,
          jobApplyMappingVO, info, wechatJob, questionResponses);

      newApplication = sfOdataService.createEntry(APPLICATION_JSON, "JobApplication", data, false);
    } catch (ServiceApplicationException e) {
      String errMsg = "Failed to insert JobApplication into SF: " + e.getMessage();
      if (errMsg.contains("jobApplicationQuestionResponse required")) {
        errMsg = "Apply a job with mandatory questions to be answered by the candidate is not supported. Job Id: "
            + wechatJob.getExternalJobId();
      }
      logger.error(errMsg);
      throw new ServiceApplicationException(errMsg);
    } catch (Exception e) {
      throw new ServiceApplicationException("Failed to insert JobApplication into SF: " + e.getMessage());
    }

    WechatJobApplicationVO wechatJobApplicationVO = new WechatJobApplicationVO();
    if (newApplication != null) {
      Long applicationId = (Long) newApplication.getProperties().get("applicationId");
      if (applicationId != null) {
        wechatJobApplicationVO.setApplicationId(String.valueOf(applicationId));
      }
    }

    return wechatJobApplicationVO;
  }

  /**
   * get odata feed of string type by setting selectItem
   * 
   * @param entitySetName
   * @param keyValue
   * @param expandRelationName
   * @param selectItem
   * @return
   * @throws ServiceApplicationException
   */
  @Override
  public String getOdataFeedStringFromSF(QueryInfo queryInfo) throws ServiceApplicationException {

    String str = null;
    try {
      str = sfOdataService.readFeedAsString(APPLICATION_JSON, queryInfo);
    } catch (Exception e) {
      throw new ServiceApplicationException("read " + queryInfo.getEntitySetName() + " error");
    }

    return str;
  }

  @Override
  public String queryApplicationStatus(String applicationId, Locale locale) throws ServiceApplicationException {
    String status = null;
    QueryInfo queryInfo = new QueryInfo(SFODataEntityType.JOBAPPLICATION.getName(),applicationId,"jobAppStatus/jobAppStatusLabel", "JobApplicationStatusLabel");
      ODataFeed feed;
        feed = sfOdataService.readFeed(SFODataConstants.APPLICATION_JSON, queryInfo);

      if (feed != null && feed.getEntries() != null) {
        for (ODataEntry entry : feed.getEntries()) {
          String dLocale = (String) entry.getProperties().get("locale");
          if (dLocale != null && dLocale.equalsIgnoreCase(locale.toString())) {
            status = (String) entry.getProperties().get("statusLabel");
          }
        }
        // no suitable locale found , read out the first one
        if (status == null) {
          ODataEntry entry = feed.getEntries().get(0);
          status = (String) entry.getProperties().get("statusLabel");
        }
      }
    return status;
  }
}
