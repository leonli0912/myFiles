package com.sap.hcm.resume.collection.integration.sf.bean.cdm;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import com.thoughtworks.xstream.annotations.XStreamConverter;
import com.thoughtworks.xstream.converters.extended.ToAttributedValueConverter;

@XStreamAlias("field-label")
@XStreamConverter(value=ToAttributedValueConverter.class, strings={"value"})
public class SFCDMFieldLabel {
    
    @XStreamAsAttribute
    @XStreamAlias("mime-type")
    public String mimeType;
    
    public String value;
    
    public String getMimeType() {
        return mimeType;
    }

    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

}
