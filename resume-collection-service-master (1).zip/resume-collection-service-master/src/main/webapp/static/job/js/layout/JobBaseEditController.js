sap.ui.define([ 'sap/m/MessageBox', 'sap/ui/core/mvc/Controller'
								, 'sap/ui/model/json/JSONModel'], function(MessageBox,
		Controller, JSONModel, JobRequisitionUtil) {
	"use strict";

	var jobBaseEditController = Controller.extend("static.job.js.layout.JobBaseEditController", {
		_oPopover : null,

		setupData : function(oEvent) {

			var listModel = new JSONModel("static/wechat/js/json/salary_range_list.json");
			this.getView().setModel(listModel, "dpList");

			var pickListModel = new JSONModel("job/picklists");
			this.getView().setModel(pickListModel, "pk");

			this.getView().setBusy(true);
			var that = this;
			pickListModel.attachRequestCompleted(function() {
				that.getView().setBusy(false);
				var pickListData = pickListModel.getData();

				// rerender the page UI
				if (pickListData) {
					for ( var fieldName in pickListData) {
						var fieldCell = that.getView().byId(fieldName + "_cell");
						if (fieldCell) {

							// check against the size the of picklist
							if (pickListData[fieldName].length && pickListData[fieldName].length > 50) {
								// build as selection popup instead

								fieldCell.destroyItems();
								var oInput = new sap.m.Input({
									width : "100%",
									id : that.getView().getId() + "_" + fieldName
								});
								oInput.bindProperty("value", "/" + fieldName);

								var oSearch = new sap.m.Button({
									icon : "sap-icon://search",
									type : "Transparent",
									width : "100%",
									press : [ {
										fieldName : fieldName
									}, that.openSelectionPopover, that ]
								});
								oSearch.addStyleClass("sapUiSmallMarginBegin");
								var oHBox = new sap.m.HBox({
									width : "100%",
									items : [ oInput, oSearch ]
								});

								fieldCell.addItem(oHBox);
							} else {

								// build as a dropdown box

								fieldCell.destroyItems();
								var path = "pk>/" + fieldName;

								var oSelect = new sap.m.Select({
									width : "100%"
								});
								oSelect.bindProperty("selectedKey", "/" + fieldName);
								oSelect.bindAggregation("items", {
									path : path,
									template : new sap.ui.core.Item({
										key : "{pk>optionId}",
										text : "{pk>label}"
									})
								});

								fieldCell.addItem(oSelect);
							}
						}
					}
				}
			});
		},

		openSelectionPopover : function(oEvent, data) {
			var fieldName = data.fieldName;
			var selectPopover = this.getView().byId("searchableSelectionPop");

			var cusData = new sap.ui.core.CustomData({
				key : "callbackId",
				value : this.getView().getId() + "_" + fieldName
			});
			selectPopover.addCustomData(cusData);
			selectPopover.setTitle(fieldName);
			selectPopover.bindElement("pk>/" + fieldName);
			selectPopover.openBy(oEvent.getSource());
		},

		closeSearchPop : function() {
			var selectPopover = this.getView().byId("searchableSelectionPop");
			selectPopover.removeCustomData();
			selectPopover.close();
		},

		startPopSearch : function() {
			var searchText = this.getView().byId("popover_conditionInput").getValue();
			var selTable = this.getView().byId("schSelectionList");
			var oBinding = selTable.getBinding("items");
			var oFilters = [];
			if (searchText) {
				var oFilter = new sap.ui.model.Filter({
					path : "label",
					operator : 'Contains',
					value1 : searchText
				});
				var oFilter1 = new sap.ui.model.Filter({
					path : "optionId",
					operator : 'EQ',
					value1 : searchText
				});
				oFilters.push(oFilter);
				oFilters.push(oFilter1);
				var oFilter2 = new sap.ui.model.Filter({
					filters : oFilters,
					and : false
				});

			}
			oBinding.filter(oFilter2);

		},

		selectPopSearchResult : function(oEvent) {
			var bindPath = oEvent.getSource().getBindingContext("pk").sPath;
			var selObj = oEvent.getSource().getModel("pk").getObject(bindPath);
			var selectPopover = this.getView().byId("searchableSelectionPop");
			var callbackId = selectPopover.getCustomData()[0].getValue();
			sap.ui.getCore().byId(callbackId).setValue(selObj.optionId);

			this.closeSearchPop();
		},
		validate : function() {
			// collect input controls
			var view = this.getView();
			var inputs = [ view.byId("jobTitle"), view.byId("externalJobId") ];

			// check that inputs are not empty
			// this does not happen during data binding as this is only
			// triggered by
			// changes
			jQuery.each(inputs, function(i, input) {
				if (!input.getValue()) {
					input.setValueState("Error");
				}
			});

			// check states of inputs
			var canContinue = true;
			jQuery.each(inputs, function(i, input) {
				if ("Error" === input.getValueState()) {
					canContinue = false;
					return false;
				}
			});

			return canContinue;
		},
		setContentVisible : function(val) {
			if (val) {
				return true;
			}
			return false;
		},

		handleClosePress : function(oEvent) {
			this._oPopover.close();
		}

	});

	return jobBaseEditController;
});
