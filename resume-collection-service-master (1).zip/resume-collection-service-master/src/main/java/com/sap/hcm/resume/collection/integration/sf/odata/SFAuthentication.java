package com.sap.hcm.resume.collection.integration.sf.odata;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLSession;
import javax.ws.rs.HttpMethod;
import javax.ws.rs.core.HttpHeaders;

import net.sf.json.JSONObject;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.Base64Utils;

import com.sap.cloud.account.TenantContext;
import com.sap.core.connectivity.api.configuration.ConnectivityConfiguration;
import com.sap.core.connectivity.api.configuration.DestinationConfiguration;
import com.sap.hcm.resume.collection.bean.CompanyIdInfo;
import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.integration.sf.bean.SFAuthenticationBean;

@Component
public class SFAuthentication extends SFODataConstants {

  @Autowired
  private TenantContext tenantContext;

  @Autowired
  private ConnectivityConfiguration connectivityConfig;

  @Autowired
  private Params params;

  @Autowired
  private CompanyIdInfo companyIdInfo;

  private final Logger logger = LoggerFactory.getLogger(this.getClass());

  private SFAuthenticationBean build() {

    SFAuthenticationBean authBean = null;

    logger.debug("start build auth bean");
    if (connectivityConfig == null) {
      logger.error("Connectivity Configuration Not Found");
      return authBean;
    }

    // Step 1. get tenant account id
    // get companyId which will be used to replace the hcp tenantId in our app
    String tenantId = null;
    if (companyIdInfo.getCompanyId() != null) {
      tenantId = companyIdInfo.getCompanyId();
      logger.debug("use companyId as tenant Id from companyIdInfo bean: " + tenantId);
    } else {
      tenantId = params.getCompanyId();
      logger.debug("use companyId as tenant Id from params : " + tenantId);
    }
    // get hcp tenant account id
    String currentTenantId = tenantContext.getTenant().getAccount().getId();
    logger.debug("current hcp tenant account id : " + currentTenantId);
    // use companyId to replace the hcp tenant id
    if (currentTenantId != null && tenantId != null && !currentTenantId.equals(tenantId)
        && !currentTenantId.equals("dev_default")) {
      currentTenantId = tenantId;
    }
    logger.debug("the final current tenantId: " + currentTenantId);

    // Step 2. get hcp destination configuration
    DestinationConfiguration destConfig = null;
    if (currentTenantId.equals("dev_default")) {
      // local dev env - no tenant id
      destConfig = connectivityConfig.getConfiguration(SF_DESTINATION_NAME);
    } else {
      destConfig = connectivityConfig.getConfiguration(currentTenantId, SF_DESTINATION_NAME);
    }
    if (destConfig == null) {
      logger.error("destination configuration not found. tenant account: " + currentTenantId);
      return authBean;
    }

    // Step 3. get authentication based on the connectivity configuration
    authBean = new SFAuthenticationBean();
    String authType = destConfig.getProperty("Authentication");
    logger.debug("authType: " + authType);
    // for basic destination
    if (authType.equals(AUTH_TYPE_BASIC)) {
      authBean.setServiceURL(destConfig.getProperty("URL"));
      String user = destConfig.getProperty("User");
      String raw = user + ":" + destConfig.getProperty("Password");
      String basicAuth = "Basic " + Base64Utils.encodeToString(raw.getBytes());
      authBean.setBasicAuth(basicAuth);
      authBean.setCompanyId(user.split("@")[1]);
      authBean.setAuthType(AUTH_TYPE_BASIC);
    }
    // for OAuth destination
    if (authType.equals(AUTH_TYPE_OAUTH)) {
      authBean.setServiceURL(destConfig.getProperty("URL"));
      authBean.setClientKey(destConfig.getProperty("clientKey"));
      authBean.setCompanyId(destConfig.getProperty("companyId"));
      authBean.setPrivateKey(destConfig.getProperty("privateKey"));
      authBean.setTokenServiceURL(destConfig.getProperty("tokenServiceURL"));
      authBean.setTokenServiceUser(destConfig.getProperty("tokenServiceUser"));
      authBean.setAuthType(AUTH_TYPE_OAUTH);
    }

    return authBean;
  }

  // 1. generate SMAL assertion
  /**
   * SMAL assertion string is used to generate the OAuth access token. The private key generated during OAuth client
   * registration is required for generating the assertion. The default validity of registration is 365 days.
   * 
   * @param authBean
   * @return SAML assertion for OAuth client
   */
  private String generateSMALAssertion(SFAuthenticationBean authBean) {
    String idpURL = authBean.getTokenServiceURL().split("/token")[0] + "/idp";
    StringBuilder sb = new StringBuilder();
    sb.append("client_id=").append(authBean.getClientKey());
    sb.append("&user_id=").append(authBean.getTokenServiceUser());
    sb.append("&token_url=").append(authBean.getTokenServiceURL());
    sb.append("&private_key=").append(authBean.getPrivateKey());
    String payload = sb.toString();
    String smalAssertion = getPostResponse(idpURL, payload);
    if (smalAssertion == null) {
      logger.error("get SAML assertion failed.");
    }
    return smalAssertion;
  }

  // TODO the code should be reused by ODataService
  private String getPostResponse(String urlString, String payload) {
    String result = null;
    OutputStream output = null;
    BufferedReader br = null;
    InputStreamReader isr = null;
    InputStream is = null;
    try {
      URL url = new URL(urlString);
      HttpURLConnection conn = (HttpURLConnection) url.openConnection();
      if (conn instanceof HttpsURLConnection) {
        disableSSLVerification((HttpsURLConnection) conn);
      }

      conn.setRequestMethod(HttpMethod.POST);
      conn.setRequestProperty(HttpHeaders.CONTENT_TYPE, "application/x-www-form-urlencoded");

      conn.setDoOutput(true);
      output = conn.getOutputStream();
      output.write(payload.getBytes(StandardCharsets.UTF_8));
      output.flush();

      int statusCode = conn.getResponseCode();
      if (400 <= statusCode || statusCode >= 599) {
        logger.error("get post response failed, connection response code: " + statusCode + ", message: "
            + conn.getResponseMessage());
        return null;
      }

      is = conn.getInputStream();
      isr = new InputStreamReader(is);
      br = new BufferedReader(isr);
      String inputLine;
      StringBuilder response = new StringBuilder();
      while ((inputLine = br.readLine()) != null) {
        response.append(inputLine);
      }
      result = response.toString();
    } catch (IOException e) {
      logger.error("get post response failed, connection response code: " + e.getMessage());
    } finally {
      IOUtils.closeQuietly(output);
      IOUtils.closeQuietly(br);
      IOUtils.closeQuietly(isr);
      IOUtils.closeQuietly(is);
    }
    return result;
  }

  // 2. get access token
  /**
   * the access token is valid only for about 80 seconds
   * 
   * @param authBean
   * @return
   */
  private String generateOAuthAccessToken(SFAuthenticationBean authBean) {

    // no need to send post request again if smal2 assertion already exists
    if (authBean.getAssertion() == null) {
      authBean.setAssertion(generateSMALAssertion(authBean));
    }

    StringBuilder sb = new StringBuilder();
    sb.append("company_id=").append(authBean.getCompanyId());
    sb.append("&client_id=").append(authBean.getClientKey());
    sb.append("&grant_type=urn:ietf:params:oauth:grant-type:saml2-bearer");
    sb.append("&assertion=").append(authBean.getAssertion());
    String payload = sb.toString();

    String jsonString = getPostResponse(authBean.getTokenServiceURL(), payload);
    if (jsonString == null) {
      logger.error("get OAuth access token failed.");
    }
    JSONObject jo = JSONObject.fromObject(jsonString);
    return (String) jo.get("access_token");
  }

  // 3. validate access token
  private boolean isOAuthAccessTokenValid(String accessToken) {
    // TODO
    return false;
  }

  // 4. generate SMAL2 Bearer authentication for OAuth client connection
  private String generateBearerAuth(SFAuthenticationBean authBean) {
    String accessToken = authBean.getAccessToken();
    if (!isOAuthAccessTokenValid(accessToken)) {
      // token expired, refresh it
      authBean.setAccessToken(generateOAuthAccessToken(authBean));
    }
    return "Bearer " + authBean.getAccessToken();
  }

  private String generateBasicAuth(SFAuthenticationBean authBean) {
    return authBean.getBasicAuth();
  }

  private void disableSSLVerification(HttpsURLConnection connection) {
    connection.setHostnameVerifier(new HostnameVerifier() {
      public boolean verify(String hostname, SSLSession session) {
        return true;
      }
    });
  }

  public String getServiceURL() {
    String result = null;
    SFAuthenticationBean authBean = build();
    if (authBean != null) {
      result = formatURL(authBean.getServiceURL());
    }
    return result;
  }

  public String getAuthentication() {
    String result = null;
    SFAuthenticationBean authBean = build();
    if (authBean == null) {
      return result;
    }
    if (AUTH_TYPE_BASIC.equals(authBean.getAuthType())) {
      // basic authentication case
      result = generateBasicAuth(authBean);
    } else if (AUTH_TYPE_OAUTH.equals(authBean.getAuthType())) {
      // SAML2 OAuth case
      result = generateBearerAuth(authBean);
    }
    return result;
  }

  private String formatURL(String urlStr) {
    if (urlStr != null && !urlStr.endsWith("/")) {
      urlStr = urlStr.concat("/");
    }
    return urlStr;
  }
}
