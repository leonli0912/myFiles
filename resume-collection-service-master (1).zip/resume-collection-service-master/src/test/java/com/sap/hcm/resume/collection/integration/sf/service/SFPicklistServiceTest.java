package com.sap.hcm.resume.collection.integration.sf.service;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.olingo.odata2.api.edm.Edm;
import org.apache.olingo.odata2.api.edm.FullQualifiedName;
import org.apache.olingo.odata2.api.edm.provider.AnnotationAttribute;
import org.apache.olingo.odata2.api.edm.provider.EdmProvider;
import org.apache.olingo.odata2.api.edm.provider.EntityType;
import org.apache.olingo.odata2.api.edm.provider.NavigationProperty;
import org.apache.olingo.odata2.api.ep.entry.ODataEntry;
import org.apache.olingo.odata2.api.ep.feed.ODataDeltaFeed;
import org.apache.olingo.odata2.api.exception.ODataException;
import org.apache.olingo.odata2.core.edm.provider.EdmImplProv;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;

import com.sap.hcm.resume.collection.context.TestContext;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.sf.bean.QueryInfo;
import com.sap.hcm.resume.collection.integration.sf.bean.QueryOptionEnum;
import com.sap.hcm.resume.collection.integration.sf.bean.SFPicklistItem;
import com.sap.hcm.resume.collection.integration.sf.odata.SFODataService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { TestContext.class })
public class SFPicklistServiceTest {
  private SFPicklistService sFPicklistService;

  @Resource(name = "sfODataService")
  private SFODataService sfODataService;

  private Edm edm;

  @Before
  public void setUp() {
    reset(sfODataService);
    sFPicklistService = new SFPicklistService();
    ReflectionTestUtils.setField(sFPicklistService, "sfOdataService", sfODataService);
    edm = Mockito.mock(EdmImplProv.class);
  }

  @Test
  public void testGetPicklistNameWithPropNameNull() throws ServiceApplicationException {
    String propName = null;
    String entityTypeName = "efg";
    String result = sFPicklistService.getPicklistName(propName, entityTypeName);
  }

  @Test
  public void testGetPicklistNameWithPropName() throws ServiceApplicationException, ODataException {
    String propName = "manager";

    String entityName = "Candidate";

    EntityType entityType = new EntityType();
    entityType.setName(entityName);

    List<NavigationProperty> naviProps = new ArrayList<NavigationProperty>();
    NavigationProperty navi = new NavigationProperty();
    navi.setName("manager");
    List<AnnotationAttribute> annotationAttributes = new ArrayList<AnnotationAttribute>();
    AnnotationAttribute attr = new AnnotationAttribute();
    attr.setName("picklist");
    attr.setPrefix("sap");
    annotationAttributes.add(attr);
    navi.setAnnotationAttributes(annotationAttributes);
    naviProps.add(navi);
    entityType.setNavigationProperties(naviProps);

    EdmProvider edmProvider = Mockito.mock(EdmProvider.class);
    Mockito.when(((EdmImplProv) edm).getEdmProvider()).thenReturn(edmProvider);
    try {
      Mockito.when(edmProvider.getEntityType(new FullQualifiedName("SFOData", entityName))).thenReturn(entityType);
    } catch (Exception e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }

    when(sfODataService.getEdm()).thenReturn(edm);
    String result = sFPicklistService.getPicklistName(propName, entityName);
  }

  @Test(expected = ServiceApplicationException.class)
  public void testGetPicklistNameWithPropNameWithException() throws ServiceApplicationException, ODataException {
    String propName = "manager";

    String entityName = "Candidate";

    EntityType entityType = new EntityType();
    entityType.setName(entityName);

    List<NavigationProperty> naviProps = new ArrayList<NavigationProperty>();
    NavigationProperty navi = new NavigationProperty();
    navi.setName("manager");
    List<AnnotationAttribute> annotationAttributes = new ArrayList<AnnotationAttribute>();
    AnnotationAttribute attr = new AnnotationAttribute();
    attr.setName("picklist");
    attr.setPrefix("sap");
    annotationAttributes.add(attr);
    navi.setAnnotationAttributes(annotationAttributes);
    naviProps.add(navi);
    entityType.setNavigationProperties(naviProps);

    EdmProvider edmProvider = Mockito.mock(EdmProvider.class);
    Mockito.when(((EdmImplProv) edm).getEdmProvider()).thenReturn(edmProvider);
    try {
      Mockito.when(edmProvider.getEntityType(new FullQualifiedName("SFOData", entityName))).thenThrow(
          new ODataException());
    } catch (Exception e) {
      // TODO Auto-generated catch block
      e.printStackTrace();
    }

    when(sfODataService.getEdm()).thenReturn(edm);
    String result = sFPicklistService.getPicklistName(propName, entityName);
  }

  @Test
  public void testLoadPickListOption() throws ServiceApplicationException {
    String picklistName = "abc";
    String expand = "picklistOptions/picklistLabels&$select=picklistOptions/id,picklistOptions/status,picklistOptions/picklistLabels/label,picklistOptions/picklistLabels/locale";
    QueryInfo queryInfo = new QueryInfo("Picklist", picklistName);
    queryInfo.addQueryOption(QueryOptionEnum.EXPAND, expand);
    ODataEntry odataEntry = Mockito.mock(ODataEntry.class);
    when(sfODataService.readEntry(any(String.class), any(QueryInfo.class))).thenReturn(odataEntry);
    Map<String, Object> proMap = new HashMap<String, Object>();
    ODataDeltaFeed oddf = Mockito.mock(ODataDeltaFeed.class);
    proMap.put("picklistOptions", oddf);
    when(odataEntry.getProperties()).thenReturn(proMap);
    List<ODataEntry> optionList = new ArrayList<ODataEntry>();
    ODataEntry odataEntry1 = Mockito.mock(ODataEntry.class);
    optionList.add(odataEntry1);
    when(oddf.getEntries()).thenReturn(optionList);
    Map<String, Object> opProMap = new HashMap<String, Object>();
    opProMap.put("id", 123L);
    opProMap.put("status", "ACTIVE");
    ODataDeltaFeed Labels = Mockito.mock(ODataDeltaFeed.class);
    opProMap.put("picklistLabels", Labels);
    List<ODataEntry> el = new ArrayList<ODataEntry>();
    ODataEntry lb = Mockito.mock(ODataEntry.class);
    Map<String, Object> map1 = new HashMap<String, Object>();
    map1.put("label", "label");
    map1.put("locale", Locale.CHINA.toString());
    when(lb.getProperties()).thenReturn(map1);
    when(lb.getProperties()).thenReturn(map1);
    el.add(lb);
    when(Labels.getEntries()).thenReturn(el);
    when(odataEntry1.getProperties()).thenReturn(opProMap);
    List<SFPicklistItem> pickListItem = sFPicklistService.loadPickListOption(picklistName);
  }

  @Test(expected = ServiceApplicationException.class)
  public void testLoadPickListOptionWithError() throws ServiceApplicationException {
    String picklistName = "abc";
    String expand = "picklistOptions/picklistLabels&$select=picklistOptions/id,picklistOptions/status,picklistOptions/picklistLabels/label,picklistOptions/picklistLabels/locale";
    QueryInfo queryInfo = new QueryInfo("Picklist", picklistName);
    queryInfo.addQueryOption(QueryOptionEnum.EXPAND, expand);
    ODataEntry odataEntry = Mockito.mock(ODataEntry.class);
    when(sfODataService.readEntry(any(String.class), any(QueryInfo.class))).thenThrow(
        new ServiceApplicationException("abc"));

    List<SFPicklistItem> pickListItem = sFPicklistService.loadPickListOption(picklistName);
  }
}
