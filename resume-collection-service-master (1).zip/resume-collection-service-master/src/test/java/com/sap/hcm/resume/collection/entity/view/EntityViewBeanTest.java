package com.sap.hcm.resume.collection.entity.view;

import org.junit.Test;

import com.sap.hcm.resume.collection.util.BeanTestUtil;

public class EntityViewBeanTest {
  
    @Test
    public void testGetterSetter(){
      BeanTestUtil.registerBean4Test(CandidateBgCertificateVO.class);
      BeanTestUtil.registerBean4Test(CandidateBgEducationVO.class);
      BeanTestUtil.registerBean4Test(CandidateBgFamilyVO.class);
      BeanTestUtil.registerBean4Test(CandidateBgLanguageVO.class);
      BeanTestUtil.registerBean4Test(CandidateBgWorkExprVO.class);
      BeanTestUtil.registerBean4Test(CandidateProfileExtVO.class);
      BeanTestUtil.registerBean4Test(CandidateProfileVO.class);
      BeanTestUtil.registerBean4Test(JobApplyMappingVO.class);
      BeanTestUtil.registerBean4Test(JobRequisitionMappingVO.class);
      BeanTestUtil.registerBean4Test(UserCompanyMappingVO.class);
      
      BeanTestUtil.processBeanTest();
    }
}
