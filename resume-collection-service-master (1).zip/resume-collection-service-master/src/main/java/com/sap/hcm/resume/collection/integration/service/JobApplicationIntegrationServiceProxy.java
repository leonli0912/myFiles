package com.sap.hcm.resume.collection.integration.service;

import java.util.List;
import java.util.Locale;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sap.hcm.resume.collection.bean.BusinessEntityType;
import com.sap.hcm.resume.collection.bean.JobAppQuestionResponse;
import com.sap.hcm.resume.collection.entity.DataModelMapping;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;
import com.sap.hcm.resume.collection.entity.view.JobApplyMappingVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.bean.CandProfileDataModelMapping;
import com.sap.hcm.resume.collection.integration.sf.bean.QueryInfo;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJob;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJobApplicationVO;

@Service(value="jobApplicationIntegrationServiceProxy")
public class JobApplicationIntegrationServiceProxy implements JobApplicationIntegrationService{
  
  @Autowired
  IntegrationServiceFactoryManager factoryManager;
  
  private JobApplicationIntegrationService integrationService;
  
  @PostConstruct
  private void init(){
    IntegrationServiceFactory factory = factoryManager.getFactory();
    integrationService = (JobApplicationIntegrationService) factory.create(BusinessEntityType.JOBAPPLICATION);
  }
  
  @Override
  public WechatJobApplicationVO insertJobApplication(CandidateProfileVO candidateProfileVO,
      DataModelMapping mapping, WechatJob wechatJob, JobApplyMappingVO jobApplyMappingVO, CandProfileDataModelMapping profileMapping, List<JobAppQuestionResponse> questionResponses) throws ServiceApplicationException {
    return integrationService.insertJobApplication(candidateProfileVO, mapping, wechatJob, jobApplyMappingVO, profileMapping,questionResponses);
  }

  @Override
  public String getOdataFeedStringFromSF(QueryInfo queryInfo) throws ServiceApplicationException {
    return integrationService.getOdataFeedStringFromSF(queryInfo);
  }

  @Override
  public String queryApplicationStatus(String applicationId, Locale locale) throws ServiceApplicationException {
    return integrationService.queryApplicationStatus(applicationId, locale);
  }
}
