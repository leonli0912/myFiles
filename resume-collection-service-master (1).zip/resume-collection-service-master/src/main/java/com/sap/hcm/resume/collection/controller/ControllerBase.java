package com.sap.hcm.resume.collection.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sap.cloud.account.TenantContext;
import com.sap.hcm.resume.collection.bean.SimpleJsonResponse;
import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.hcp.HCPUserProvider;
import com.sap.hcm.resume.collection.service.CompanyInfoService;

/**
 * base controller
 * 
 * @author i065831
 *
 */
@Component
public class ControllerBase {

  @Autowired
  protected CompanyInfoService compInfoService;
  
  @Autowired
  protected HCPUserProvider hcpUserProvider;
  
  @Autowired
  protected TenantContext tanantContext;

  @ExceptionHandler(ServiceApplicationException.class)
  public @ResponseBody SimpleJsonResponse handleServiceApplicationException(ServiceApplicationException e) {
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(e.getCode());
    rsp.setMessage(e.getMessage());
    return rsp;
  }

  protected String validateCompanyAndUser(String companyId) {

    String viewName = "";
    // verify company Id
    CompanyInfo companyInfo = null;
    try {
      companyInfo = compInfoService.getCompanyInfo(companyId);
    } catch (ServiceApplicationException e) {
      viewName = "invalid_company";
    }

    if (companyInfo == null) {
      return "invalid_company";
    }
    return viewName;
  }

}
