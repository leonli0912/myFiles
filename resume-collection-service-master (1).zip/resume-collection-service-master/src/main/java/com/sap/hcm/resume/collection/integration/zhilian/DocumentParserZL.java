package com.sap.hcm.resume.collection.integration.zhilian;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.context.MessageSource;

import com.sap.hcm.resume.collection.entity.view.CandidateBgCertificateVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgEducationVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgLanguageVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgWorkExprVO;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.parser.HTMLDocumentParser;
import com.sap.hcm.resume.collection.util.CandidateDateUtil;
import com.sap.hcm.resume.collection.util.MappingUtil;

public class DocumentParserZL extends HTMLDocumentParser {

  public DocumentParserZL(MessageSource messageSource) {
    super(messageSource);
  }

  public static String EMPTY_SPACE = " ";

  public static String FIELD_SEPARATOR = "\\|";

  public static String DASH = "-";

  public static String COLON = ":";

  public static String SEMI_COLON = ";";

  @Override
  public CandidateProfileVO parseProfile(CandidateProfileVO candidateProfileVO,
      Document content) throws ServiceApplicationException {

    try {

      Elements summaryElements = content.getElementsByClass("summary");
      String regex = null;

      if (summaryElements.size() > 0) {

        Element summary = summaryElements.get(0);

        // parse name
        String nameRaw = "";
        Elements nameELs = summary.getElementsByTag("h1");
        if (nameELs.size() > 0) {
          nameRaw = nameELs.get(0).text();
          // lastName
          candidateProfileVO.setLastName(nameRaw.substring(0, 1));
          // firstName
          candidateProfileVO
              .setFirstName(nameRaw.substring(1, nameRaw.length()));
        }

        String summaryBodyWithoutName = summary.text().replace(nameRaw, "");
        String part1 = summaryBodyWithoutName.substring(0,
            summaryBodyWithoutName.indexOf("现居住于"));

        // parse gender
        String genderRaw = part1.split(FIELD_SEPARATOR)[0];
        if (genderRaw.equals("男")) {
          candidateProfileVO.setGender("Male");
        } else if (genderRaw.equals("女")) {
          candidateProfileVO.setGender("Female");
        } else {
          candidateProfileVO.setGender("Unkown");
        }

        int num = 1;
        // parser marriage
        if (part1.split(FIELD_SEPARATOR)[1].matches(".*月生")) {
          num = 1;
        }else{
          num = 2;
        }
          
          String marriageRaw = part1.split(FIELD_SEPARATOR)[1];
          if (marriageRaw.equals("已婚")) {
            candidateProfileVO.setMarriage("Y");
          } else {
            candidateProfileVO.setMarriage("N");
          }

          // parse date of birth
          String dobRaw = part1.split(FIELD_SEPARATOR)[num];
          // dateOfBirth
          candidateProfileVO.setDateOfBirth(CandidateDateUtil.formatDate(
              "yyyy年MM月生", "yyyy/MM/dd", dobRaw));

        // parse the HUKOU
        String houseHoldRaw = part1.split(FIELD_SEPARATOR)[3];
        regex = "(?<=户口：)\\S+";
        // houseHold 户口性质
        String houseHoldRow1 = MappingUtil.matchSingle(regex,houseHoldRaw);
        if(houseHoldRow1.indexOf("-")>=0){
          candidateProfileVO.setHousehold(MappingUtil.matchSingle(regex,
              houseHoldRaw).split(DASH)[1]);
        }else{
          candidateProfileVO.setHousehold(houseHoldRow1);
        }
        String part2 = summaryBodyWithoutName.substring(summaryBodyWithoutName
            .indexOf("现居住于"));
        String[] tokens = part2.trim().replace(" ", EMPTY_SPACE)
            .replace("：", EMPTY_SPACE).replace(":", EMPTY_SPACE).replace("|",EMPTY_SPACE).split("\\s+");
        String phoneRegex = "^[0-9]{11}$";
        for (int i = 0; i < tokens.length; i++) {
          if (tokens[i].startsWith("现居住于")) {
            if (i + 1 < tokens.length) {
              String location = tokens[i + 1];
              candidateProfileVO.setResidence(location);
            }
          }
          if (tokens[i].startsWith("身份证")||tokens[i].startsWith("护照")) {
            if (i + 1 < tokens.length) {
              String idNum = tokens[i + 1];
              candidateProfileVO.setIdentityCard(idNum);
            }
          }
          if(tokens[i].matches(phoneRegex)){
            if (i + 2 < tokens.length) {
              String mobile = tokens[i].trim();
              candidateProfileVO.setCellPhone(mobile);
            }
          }
          
          if (tokens[i].startsWith("E-mail")) {
            if (i + 1 < tokens.length) {
              String email = tokens[i + 1];
              candidateProfileVO.setContactEmail(email);
              candidateProfileVO.setPrimaryEmail(email);
            }
          }
        }
      }

      Elements detailElements = content.getElementsByTag("li");

      for (Element element : detailElements) {

        String data = element.text();

        if (data.indexOf("工作地区：") != -1) {
          regex = "(?<=工作地区：)\\S+";
          // preferredLoc
          candidateProfileVO.setPreferredLoc(MappingUtil.matchSingle(regex,
              data));
        } else if (data.indexOf("期望月薪：") != -1) {
          regex = "(?<=期望月薪：)\\S+";
          String minAnnualSal = MappingUtil.matchSingle(regex, data);
          if ("面议".equals(minAnnualSal.trim())) {
            // minAnnualSal
            candidateProfileVO.setMinAnnualSal("面议");
          } else if (minAnnualSal.indexOf("元/月以下") != -1) {
            regex = "\\d+(?=元/月以下)";
            minAnnualSal = MappingUtil.matchSingle(regex, minAnnualSal);
            // minAnnualSal
            candidateProfileVO.setMinAnnualSal(String.valueOf(Integer
                .valueOf(minAnnualSal) * 12));
          } else if (minAnnualSal.indexOf("元/月以上") != -1) {
            regex = "\\d+(?=元/月以上)";
            minAnnualSal = MappingUtil.matchSingle(regex, minAnnualSal);
            // minAnnualSal
            candidateProfileVO.setMinAnnualSal(String.valueOf(Integer
                .valueOf(minAnnualSal) * 12));
          } else {
            regex = "\\d+(?=-)";
            minAnnualSal = MappingUtil.matchSingle(regex, minAnnualSal);
            // minAnnualSal
            candidateProfileVO.setMinAnnualSal(String.valueOf(Integer
                .valueOf(minAnnualSal) * 12));
          }
        }
      }

    } catch (Exception e) {
      throw new ServiceApplicationException("Profile parse error with exception " + e.getMessage());
    }

    return candidateProfileVO;
  }

  @Override
  public CandidateProfileVO parseBackgroundWorkExp(
      CandidateProfileVO candidateProfileVO, Document content)
      throws ServiceApplicationException {

    try {

      List<CandidateBgWorkExprVO> candidateBgWorkExprVOList = new ArrayList<CandidateBgWorkExprVO>();

      Elements elements = content.getElementsByClass("work-experience");
      CandidateBgWorkExprVO candidateBgWorkExprVO = null;
      String regex = null;

      for (Element element : elements) {

        candidateBgWorkExprVO = new CandidateBgWorkExprVO();
        String periodRaw = element.children().get(0).text();

        String startDate = CandidateDateUtil.formatDate("yyyy/MM", "yyyy/MM/dd", periodRaw.split("--")[0].trim());

        candidateBgWorkExprVO.setStartDate(startDate);
        String endDate = periodRaw.split("--")[1].trim();
        if (endDate.equalsIgnoreCase("至今")) {
          candidateBgWorkExprVO.setEndDate("NOW");
          candidateBgWorkExprVO.setIsPresent(true);
        } else {
          candidateBgWorkExprVO.setEndDate(CandidateDateUtil.formatDate("yyyy/MM", "yyyy/MM/dd", periodRaw.split("--")[1].trim()));
          candidateBgWorkExprVO.setIsPresent(false);
        }

        String[] titleRaws = element.children().get(1).text()
            .split(FIELD_SEPARATOR);
        // employer 公司名称
        candidateBgWorkExprVO.setEmployer(titleRaws[0]);
        // jobTitle 职位
        candidateBgWorkExprVO.setJobTitle(titleRaws[titleRaws.length - 1]);

        String[] line3EL = element.children().get(2).text().split(FIELD_SEPARATOR);
        // businessType
        String businessTypeRaw = line3EL[0]; 
        
        regex = "(?<=行业类别： )\\S+";
        String businessType = MappingUtil.matchSingle(regex, businessTypeRaw);
        candidateBgWorkExprVO.setBusinessType(businessType);
        // parse salary range
        String salaryRaw = line3EL[line3EL.length - 1];

        regex = "(?<=职位月薪：)\\S+";
        String monthSalary = MappingUtil.matchSingle(regex, salaryRaw);
        if ("保密".equals(monthSalary)) {
          // salary
          candidateBgWorkExprVO.setSalary("0");
          // salaryEnd
          candidateBgWorkExprVO.setSalaryEnd("0");
        } else if (monthSalary.indexOf("元/月以下") != -1) {
          regex = "\\d+(?=元/月以下)";
          monthSalary = MappingUtil.matchSingle(regex, monthSalary);
          // salary
          candidateBgWorkExprVO.setSalary("0");
          // salaryEnd
          candidateBgWorkExprVO.setSalaryEnd(String.valueOf(Integer
              .valueOf(monthSalary) * 12));
        } else if (monthSalary.indexOf("元/月以上") != -1) {
          regex = "\\d+(?=元/月以上)";
          monthSalary = MappingUtil.matchSingle(regex, monthSalary);
          // salary
          candidateBgWorkExprVO.setSalary(String.valueOf(Integer
              .valueOf(monthSalary) * 12));
          // salaryEnd
          candidateBgWorkExprVO.setSalaryEnd("");
        } else {
          regex = "\\d+(?=-)";
          String minMonthSalary = MappingUtil.matchSingle(regex, monthSalary);
          // salary
          candidateBgWorkExprVO.setSalary(String.valueOf(Integer
              .valueOf(minMonthSalary) * 12));
          regex = "(?<=-)\\d+";
          String maxMonthSalary = MappingUtil.matchSingle(regex, monthSalary);
          // salaryEnd
          candidateBgWorkExprVO.setSalaryEnd(String.valueOf(Integer
              .valueOf(maxMonthSalary) * 12));
        }

        // parse description
        candidateBgWorkExprVO.setDescription(element.children().get(3).text()
            .replaceAll("工作描述：", "").trim());

        candidateBgWorkExprVOList.add(candidateBgWorkExprVO);

      }

      candidateProfileVO.setWorkExprs(candidateBgWorkExprVOList);

    } catch (Exception e) {
      throw new ServiceApplicationException("Profile parse error with exception: " + e.getMessage());
    }

    return candidateProfileVO;
  }

  @Override
  public CandidateProfileVO parseBackgroundEducation(
      CandidateProfileVO candidateProfileVO, Document content)
      throws ServiceApplicationException {

    try {

      List<CandidateBgEducationVO> candidateBgEducationVOList = new ArrayList<CandidateBgEducationVO>();

      Elements elements = content.getElementsByClass("education-background");
      CandidateBgEducationVO candidateBgEducationVO = null;

      for (Element element : elements) {

        candidateBgEducationVO = new CandidateBgEducationVO();

        // parse the begin date and end date
        String periodRaw = element.children().get(0).text();
        String beginRaw = periodRaw.split(DASH + DASH)[0].trim();
        String endRaw = periodRaw.split(DASH + DASH)[1].trim();
        if (beginRaw.matches("[\\d\\/]+")) {
          candidateBgEducationVO.setStartDate(CandidateDateUtil.formatDate("yyyy/MM", "yyyy/MM/dd", beginRaw));
        }
        if (endRaw.matches("[\\d\\/]+")) {
          candidateBgEducationVO.setEndDate(CandidateDateUtil.formatDate("yyyy/MM", "yyyy/MM/dd", endRaw));
        }else if(endRaw.equals("至今")){
          candidateBgEducationVO.setEndDate("NOW");
        }

        // parse the university and major
        String universityRaw = element.children().get(1).text();
        String school = universityRaw.split(FIELD_SEPARATOR)[0].trim();
        String major = universityRaw.split(FIELD_SEPARATOR)[1].trim();
        String degree = universityRaw.split(FIELD_SEPARATOR)[2].trim();
        candidateBgEducationVO.setSchool(school);
        candidateBgEducationVO.setMajor(major);
        candidateBgEducationVO.setDegree(degree);

        candidateBgEducationVOList.add(candidateBgEducationVO);
      }

      candidateProfileVO.setEducation(candidateBgEducationVOList);

    } catch (Exception e) {
      throw new ServiceApplicationException("Profile parse error with exception" + e.getMessage());
    }

    return candidateProfileVO;
  }

  @Override
  public CandidateProfileVO parseBackgroundLanguage(
      CandidateProfileVO candidateProfileVO, Document content)
      throws ServiceApplicationException {

    try {

      List<CandidateBgLanguageVO> candidateBgLanguageVOList = new ArrayList<CandidateBgLanguageVO>();

      Elements elements = content.getElementsByClass("language-skill");
      CandidateBgLanguageVO candidateBgLanguageVO = null;
      String regex = null;

      for (Element element : elements) {

        candidateBgLanguageVO = new CandidateBgLanguageVO();

        String data = element.text();
        String[] arrData = data.split("\\|");

        String arrData0 = arrData[0];
        regex = "(\\S+)\\s：读写能力(\\S+)";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(arrData0);
        if (matcher.find()) {
          // language
          candidateBgLanguageVO.setName(matcher.group(1));
          if (arrData.length > 1) {
            // readingProf&writingProf,writingProf is same with readingProf
            candidateBgLanguageVO.setReadingProf(matcher.group(2));
            candidateBgLanguageVO.setWritingProf(matcher.group(2));
          }

          String arrData1 = arrData[1];
          regex = "(?<=听说能力)\\S+";
          // speakingProf
          candidateBgLanguageVO.setSpeakingProf(MappingUtil.matchSingle(regex, arrData1));
          candidateBgLanguageVOList.add(candidateBgLanguageVO);
        }

      }

      candidateProfileVO.setLanguages(candidateBgLanguageVOList);

    } catch (Exception e) {
      throw new ServiceApplicationException("Profile parse error with exception " + e.getMessage());
    }

    return candidateProfileVO;
  }

  @Override
  public CandidateProfileVO parseBackgroundCertificate(
      CandidateProfileVO candidateProfileVO, Document content)
      throws ServiceApplicationException {

    try {

      List<CandidateBgCertificateVO> candidateBgCertificateVOList = new ArrayList<CandidateBgCertificateVO>();

      Elements elements = content.getElementsByClass("certificates");
      CandidateBgCertificateVO candidateBgCertificateVO = null;

      for (Element element : elements) {

        candidateBgCertificateVO = new CandidateBgCertificateVO();
        /**
         * yyyy/MM
         */
        String startDateRaw = element.child(0).text();
        String name = element.child(1).text();
        candidateBgCertificateVO.setStartDate(CandidateDateUtil.formatDate("yyyy/MM", "yyyy/MM/dd", startDateRaw));
        candidateBgCertificateVO.setName(name);

        candidateBgCertificateVOList.add(candidateBgCertificateVO);
      }

      candidateProfileVO.setCertificates(candidateBgCertificateVOList);

    } catch (Exception e) {
      throw new ServiceApplicationException("Profile parse error with exception " + e.getMessage());
    }

    return candidateProfileVO;
  }
    
}
