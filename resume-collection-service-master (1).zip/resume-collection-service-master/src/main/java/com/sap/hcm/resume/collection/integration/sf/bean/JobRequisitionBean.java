package com.sap.hcm.resume.collection.integration.sf.bean;

import java.io.Serializable;

public class JobRequisitionBean implements Serializable {

    private static final long serialVersionUID = -8924043107058972827L;
    
    private String jobReqId;
    
    private String jobTitle;
    
    private String lineManager;
    
    private String statusSetId;

    /**
     * @return the statusSetId
     */
    public String getStatusSetId() {
      return statusSetId;
    }

    /**
     * @param statusSetId the statusSetId to set
     */
    public void setStatusSetId(String statusSetId) {
      this.statusSetId = statusSetId;
    }

    /**
     * @return the jobReqId
     */
    public String getJobReqId() {
        return jobReqId;
    }

    /**
     * @param jobReqId the jobReqId to set
     */
    public void setJobReqId(String jobReqId) {
        this.jobReqId = jobReqId;
    }

    /**
     * @return the jobTitle
     */
    public String getJobTitle() {
        return jobTitle;
    }

    /**
     * @param jobTitle the jobTitle to set
     */
    public void setJobTitle(String jobTitle) {
        this.jobTitle = jobTitle;
    }

    /**
     * @return the lineManager
     */
    public String getLineManager() {
        return lineManager;
    }

    /**
     * @param lineManager the lineManager to set
     */
    public void setLineManager(String lineManager) {
        this.lineManager = lineManager;
    }

}
