package com.sap.hcm.resume.collection.integration.job51;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.MessageSource;
import org.springframework.util.StringUtils;

import com.sap.hcm.resume.collection.entity.view.CandidateBgCertificateVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgEducationVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgLanguageVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgWorkExprVO;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileExtVO;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.util.CandidateDateUtil;
import com.sap.hcm.resume.collection.util.CandidateFileUtil;
import com.sap.hcm.resume.collection.util.MappingUtil;

public class ResumeParser51V16 extends AbstractDocumentParser51 {

  private Logger logger = LoggerFactory.getLogger(this.getClass());

  public ResumeParser51V16(MessageSource messageSource) {
    super(messageSource);
  }

  @Override
  public CandidateProfileVO parseProfile(CandidateProfileVO candidateProfileVO, Document content)
      throws ServiceApplicationException {
    // TODO Auto-generated method stub
    CandidateProfileExtVO extProfile = new CandidateProfileExtVO();
    try {
      String regex = null;
      Element profileTable = null;
      Elements tableElements = content.getElementsByTag("table");
      for (Element tableElement : tableElements) {
        if(tableElement.childNodeSize() < 1){
          continue;
        }
        Elements trElements = tableElement.child(0).children();
        if (trElements.size() >= 2) {
          regex = "ID:\\d{0,100}";
          String id = MappingUtil.matchSingle(regex, trElements.get(0).text());
          regex = "\\S*?@\\S*?.\\S*";
          String email = MappingUtil.matchSingle(regex, trElements.get(1).text());
          if (!StringUtils.isEmpty(id) && !StringUtils.isEmpty(email)) {
            profileTable = tableElement;
            break;
          }
        }
      }
      if (profileTable == null) {
        throw new ServiceApplicationException("Email address is not exist in the resume.");
      }
      String basicInfo = CandidateFileUtil.formatHtmlText(profileTable.html(), false, false);
      if (basicInfo == null) {
        logger.error("failed to get basic information string from profile table of the html file.");
        return candidateProfileVO;
      }
      String[] rows = basicInfo.split("\\n");

      regex = ".*(?=流程状态)";
      String name = MappingUtil.matchSingle(regex, rows[0]);
      if (!StringUtils.isEmpty(name)) {
        if (name.length() > 3) {
          candidateProfileVO.setLastName(name.substring(0, 2));
          candidateProfileVO.setFirstName(name.substring(2));
        } else {
          candidateProfileVO.setLastName(name.substring(0, 1));
          candidateProfileVO.setFirstName(name.substring(1));
        }
        candidateProfileVO.setMiddleName("");
      }
      candidateProfileVO.setCellPhone(rows[2].trim());
      candidateProfileVO.setPrimaryEmail(rows[3].trim());
      candidateProfileVO.setContactEmail(rows[3].trim());
      String[] infos = rows[4].split("\\|");
      String gender = infos[0].trim();
      if ("男".equals(gender)) {
        candidateProfileVO.setGender("Male");
      } else if ("女".equals(gender)) {
        candidateProfileVO.setGender("Female");
      } else {
        candidateProfileVO.setGender("");
      }
      
      String birthRow = infos[1].trim();
      if (birthRow.indexOf("（") > 0) {
        String dob = birthRow.substring(birthRow.indexOf("（")+1, birthRow.length()-1);
        dob = dob.replace("年", "/").replace("月", "/").replace("日", "").replace(" ", "");
        candidateProfileVO.setDateOfBirth(dob.trim());
      } else {
        String dob = this.calculateDob(infos[1]);
        candidateProfileVO.setDateOfBirth(dob);
      }
      String residence = infos[2].replace("现居住", "").trim();
      candidateProfileVO.setResidence(residence);

      candidateProfileVO.setCountry("CN");
      // nationality 国籍
      candidateProfileVO.setNationality("");

      // ethnicity
      candidateProfileVO.setEthnicity("Asian");

      // get basic info
      Element basicInfoBox = this.getDocBlock(content, "个人信息");
      if (basicInfoBox != null) {
        String basicInfoRaw = CandidateFileUtil.formatHtmlText(basicInfoBox.html(), false, false);
        String[] rows1 = basicInfoRaw.split("\\n");
        for (int i = 0; i < rows1.length; i++) {
          if (rows1[i].contains("户口")) {
            String hukou = this.getColonRightValue(rows1[i]);
            candidateProfileVO.setHousehold(hukou);
          }
          if (rows1[i].contains("婚姻状况")) {
            String maritalSts = this.getColonRightValue(rows1[i]);
            if ("已婚".equalsIgnoreCase(maritalSts)) {
              candidateProfileVO.setMarriage("Y");
            } else {
              candidateProfileVO.setMarriage("N");
            }
          }
          if (rows1[i].startsWith("家庭地址")) {
            String addressRaw = this.getColonRightValue(rows1[i]);
            if (addressRaw.indexOf("(") >= 0) {
              String address = MappingUtil.matchSingle("[^\\(]+", addressRaw);
              candidateProfileVO.setAddress(address);

              String zipCodeRaw = MappingUtil.matchSingle("(?<=\\()[\\s\\S]+(?=\\))", addressRaw);
              String zipCode = this.getColonRightValue(zipCodeRaw);
              candidateProfileVO.setZipcode(zipCode);
            } else {
              candidateProfileVO.setAddress(addressRaw);
            }
          }
        }
      }

    } catch (Exception e) {
      throw new ServiceApplicationException("Profile parse error: " + e.getMessage());
    }
    candidateProfileVO.setExtProfile(extProfile);
    return candidateProfileVO;
  }

  @Override
  public CandidateProfileVO parseBackgroundWorkExp(CandidateProfileVO candidateProfileVO, Document content)
      throws ServiceApplicationException {
    List<CandidateBgWorkExprVO> exprList = new ArrayList<CandidateBgWorkExprVO>();
    try {
      Element exprBlock = this.getDocBlock(content, "工作经验");
      if (exprBlock != null) {
        String exprText = CandidateFileUtil.formatHtmlText(exprBlock.html(), false, false);
        if (!StringUtils.isEmpty(exprText)) {
          String regex = "\\d{4}/\\d{1,2}[\\s\\S]*?(?=\\d{4}/\\d{1,2}-\\d{4}/\\d{1,2}|$)";
          Pattern pattern = Pattern.compile(regex);
          Matcher matcher = pattern.matcher(exprText);

          CandidateBgWorkExprVO candidateBgWorkExprVO = null;
          while (matcher.find()) {
            candidateBgWorkExprVO = new CandidateBgWorkExprVO();
            String singleExpr = matcher.group();
            String[] rows = singleExpr.split("\\n");
            if (rows.length > 2) {

              // parse date and job title and department
              String dateAndCompanyRow = rows[0];
              regex = "\\d{4}/\\d{1,2}-(\\d{4}/\\d{1,2}|至今)";
              String date = MappingUtil.matchSingle(regex, dateAndCompanyRow);
              String[] dates = date.split("-");
              String startDate = CandidateDateUtil.formatDate("yyyy/MM", "yyyy/MM/dd", dates[0]);
              candidateBgWorkExprVO.setStartDate(startDate);
              if (dates[1].equals("至今")) {
                candidateBgWorkExprVO.setEndDate("NOW");
                candidateBgWorkExprVO.setIsPresent(true);
              } else {
                String endDate = CandidateDateUtil.formatDate("yyyy/MM", "yyyy/MM/dd", dates[1]);
                candidateBgWorkExprVO.setEndDate(endDate);
                candidateBgWorkExprVO.setIsPresent(false);
              }

              String companyRow = dateAndCompanyRow.replace(date, "");
              if (companyRow.lastIndexOf(")") == companyRow.length()-2) {
                int lastLeftbrackets = companyRow.lastIndexOf("(");
                String employer = companyRow.substring(0, lastLeftbrackets);
                candidateBgWorkExprVO.setEmployer(employer.trim());
              } else {
                candidateBgWorkExprVO.setEmployer(companyRow.trim());
              }
              
              String industryRow[] = rows[1].split("\\|");
              candidateBgWorkExprVO.setBusinessType(industryRow[0].trim());
              
              String titleAndDepartmentRow[] = rows[2].split("          ");
              candidateBgWorkExprVO.setJobTitle(titleAndDepartmentRow[1].trim());
              candidateBgWorkExprVO.setDepartment(titleAndDepartmentRow[0].trim());
            }

            String description = MappingUtil.matchSingle("(?<=工作描述：)[\\s\\S]+(?=(下属人数|汇报对象|离职原因|$))", singleExpr);
            if (description != null) {
              description = description.trim();
            }
            candidateBgWorkExprVO.setDescription(description);
            exprList.add(candidateBgWorkExprVO);
          }
        }
      }
      candidateProfileVO.setWorkExprs(exprList);
    } catch (Exception e) {
      throw new ServiceApplicationException("Profile work experience parse error" + e.getMessage());
    }
    return candidateProfileVO;
  }

  @Override
  public CandidateProfileVO parseBackgroundEducation(CandidateProfileVO candidateProfileVO, Document content)
      throws ServiceApplicationException {
    List<CandidateBgEducationVO> educList = new ArrayList<CandidateBgEducationVO>();
    try {
      Element educationBlock = this.getDocBlock(content, "教育经历");
      if (educationBlock != null) {
        String educText = CandidateFileUtil.formatHtmlText(educationBlock.html(), false, false);
        if (!StringUtils.isEmpty(educText)) {
          String regex = "\\d{4}/\\d{1,2}[\\s\\S]*?(?=\\d{4}/\\d{1,2}-\\d{4}/\\d{1,2}|$)";
          Pattern pattern = Pattern.compile(regex);
          Matcher matcher = pattern.matcher(educText);

          CandidateBgEducationVO candidateBgEducationVO = null;
          while (matcher.find()) {
            candidateBgEducationVO = new CandidateBgEducationVO();
            String entry = matcher.group();
            String[] rows = entry.split("\\n");
            if (rows.length >= 2) {
              // parse date and school
              String dateAndNameRow = rows[0];
              regex = "\\d{4}/\\d{1,2}-(\\d{4}/\\d{1,2}|至今)";
              String date = MappingUtil.matchSingle(regex, dateAndNameRow);
              String[] dates = date.split("-");
              String startDate = CandidateDateUtil.formatDate("yyyy/MM", "yyyy/MM/dd", dates[0]);
              candidateBgEducationVO.setStartDate(startDate);
              if (dates[1].equals("至今")) {
                String endDate = CandidateDateUtil.formatDate2String(new Date(), "yyyy/MM/dd");
                candidateBgEducationVO.setEndDate(endDate);
              } else {
                String endDate = CandidateDateUtil.formatDate("yyyy/MM", "yyyy/MM/dd", dates[1]);
                candidateBgEducationVO.setEndDate(endDate);
              }

              regex = "(?<=\\d{4}/\\d{1,2}-(\\d{4}/\\d{1,2}|至今)\\s+)[\\S\\s]+?(?=海外经历|$)";
              String school = MappingUtil.matchSingle(regex, dateAndNameRow);
              candidateBgEducationVO.setSchool(school.trim());

              // parse degree and major
              String majorAndDegree = rows[1];
              String[] fields = majorAndDegree.split("\\|");
              if (fields.length == 1) {
                candidateBgEducationVO.setDegree(fields[0].trim());
              }
              if (fields.length >= 2) {
                candidateBgEducationVO.setDegree(fields[0].trim());
                candidateBgEducationVO.setMajor(fields[1].trim());
              }
            }
            educList.add(candidateBgEducationVO);
          }
        }
      }
      candidateProfileVO.setEducation(educList);
    } catch (Exception e) {
      throw new ServiceApplicationException("Profile education parse error" + e.getMessage());
    }
    return candidateProfileVO;
  }

  @Override
  public CandidateProfileVO parseBackgroundLanguage(CandidateProfileVO candidateProfileVO, Document content)
      throws ServiceApplicationException {
    List<CandidateBgLanguageVO> lanList = new ArrayList<CandidateBgLanguageVO>();
    try {
      Element specialityBlock = this.getDocBlock(content, "技能特长");
      Element languageBlock = this.getSubDocBlock(specialityBlock, "技能/语言");
      if (languageBlock != null) {

        String languageText = CandidateFileUtil.formatHtmlText(languageBlock.html(), false, false);
        String[] rows = languageText.split("\\n");
        for (int i = 0; i < rows.length; i=i+2) {
          CandidateBgLanguageVO candidateBgLanguageVO = new CandidateBgLanguageVO();
          String language = rows[i].trim();
          if (!StringUtils.isEmpty(language)) {
            candidateBgLanguageVO.setName(language);
            String fluency = rows[i+1].trim();
            candidateBgLanguageVO.setReadingProf(fluency);
            candidateBgLanguageVO.setSpeakingProf(fluency);
            candidateBgLanguageVO.setWritingProf(fluency);
            lanList.add(candidateBgLanguageVO);
          }
        }
      }
      candidateProfileVO.setLanguages(lanList);
    } catch (Exception e) {
      throw new ServiceApplicationException("Profile language parse error" + e.getMessage());
    }
    return candidateProfileVO;
  }

  @Override
  public CandidateProfileVO parseBackgroundCertificate(CandidateProfileVO candidateProfileVO, Document content)
      throws ServiceApplicationException {
    List<CandidateBgCertificateVO> cerList = new ArrayList<CandidateBgCertificateVO>();
    try {
      Element specialityBlock = this.getDocBlock(content, "技能特长");
      Element certificateBlock = this.getSubDocBlock(specialityBlock, "证书");
      if (certificateBlock != null) {

        String certificateText = CandidateFileUtil.formatHtmlText(certificateBlock.html(), false, false);
        String[] rows = certificateText.split("\\n");
        for (String certificateLine : rows) {
          CandidateBgCertificateVO candidateBgCertificateVO = new CandidateBgCertificateVO();
          String regex = "\\d{4}/\\d{1,2}";
          String date = MappingUtil.matchSingle(regex, certificateLine);
          candidateBgCertificateVO.setStartDate(date + "/01");
          candidateBgCertificateVO.setEndDate(date + "/01");
          String name = certificateLine.replace(date, "");
          candidateBgCertificateVO.setName(name.trim());
          cerList.add(candidateBgCertificateVO);
        }
      }
      candidateProfileVO.setCertificates(cerList);
    } catch (Exception e) {
      throw new ServiceApplicationException("Profile language parse error" + e.getMessage());
    }
    return candidateProfileVO;
  }

  public Element getDocBlock(Element doc, String title) {
    if (doc == null) {
      return null;
    }
    Elements allTables = doc.getElementsByTag("table");
    Element selectTable = null;
    for (Element table : allTables) {
      Elements tableRows = table.getElementsByTag("tr");
      if (tableRows.size() > 0) {
        Element row = tableRows.first();
        if (row.text().startsWith(title)) {
          selectTable = table;
          break;
        } else {
          continue;
        }
      }
    }
    return selectTable;
  }
  
  public Element getSubDocBlock(Element doc, String title) {
    if (doc == null) {
      return null;
    }
    Element sourceTable = doc.getElementsByTag("table").get(1);
    Elements allTrs = sourceTable.getElementsByTag("tr");
    Element selectTr = null;
    for (int i = 0; i < allTrs.size(); i++) {
      Element tr = allTrs.get(i);
      if (tr.text().startsWith(title)) {
        selectTr = allTrs.get(i+1);
        break;
      } else {
        continue;
      }
    }
    return selectTr;
  }

}
