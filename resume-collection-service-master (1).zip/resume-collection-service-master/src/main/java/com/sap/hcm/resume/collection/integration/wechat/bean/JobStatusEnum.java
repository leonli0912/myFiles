package com.sap.hcm.resume.collection.integration.wechat.bean;

/**
 * job status
 * @author i065831
 *
 */
public enum JobStatusEnum {
	
	DRAFT(0),
	POSTED(1);
	
	private int code;
	
	JobStatusEnum(int code){
		this.code = code;
	}

	public int getCode() {
		return code;
	}
	
	
}
