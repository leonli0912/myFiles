package com.sap.hcm.resume.collection.integration.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.persistence.PersistenceException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sap.hcm.resume.collection.bean.CandidateProfileModel;
import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.bean.SimpleJsonResponse;
import com.sap.hcm.resume.collection.context.TestContext;
import com.sap.hcm.resume.collection.context.WebAppContext;
import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.entity.DataModelMapping;
import com.sap.hcm.resume.collection.entity.view.UserCompanyMappingVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.hcp.HCPUserProvider;
import com.sap.hcm.resume.collection.integration.bean.CandProfileDataModelMapping;
import com.sap.hcm.resume.collection.service.CompanyInfoService;
import com.sap.hcm.resume.collection.service.DataModelMappingService;
import com.sap.hcm.resume.collection.util.ChangeLogUtil;
import com.sap.hcm.resume.collection.util.MockHCPUser;
import com.sap.security.um.user.User;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { TestContext.class, WebAppContext.class })
public class CandidateDataModelControllerTest {

  private CandidateDataModelController controller;

  private DataModelMapping dataModelMapping;

  @Resource(type = WebApplicationContext.class)
  private WebApplicationContext webApplicationContext;

  @Autowired
  private DataModelMappingService mappingService;

  @Autowired
  protected HCPUserProvider hcpUserProvider;

  @Autowired
  private ChangeLogUtil changeLogUtil;
  
  @Autowired
  private CompanyInfoService compInfoService;
  
  @Autowired
  private Params params;

  @Before
  public void setUp() {
    controller = spy(new CandidateDataModelController());
    MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
    ReflectionTestUtils.setField(controller, "mappingService", mappingService);
    ReflectionTestUtils.setField(controller, "hcpUserProvider", hcpUserProvider);
    ReflectionTestUtils.setField(controller, "changeLogUtil", changeLogUtil);
    ReflectionTestUtils.setField(controller, "params", params);
    ReflectionTestUtils.setField(controller, "compInfoService", compInfoService);
    this.buildDataModelMapping();
  }

  private void buildDataModelMapping() {
    dataModelMapping = new DataModelMapping();
    dataModelMapping.setCompanyId("sap");
    dataModelMapping.setCreateBy("Ryan");
    dataModelMapping.setMappingContent(null);
    dataModelMapping.setMappingId((long) 123);
    dataModelMapping.setMappingName("mapping");
    dataModelMapping.setMappingType("candidate_dm_mapping");
    dataModelMapping.setTargetSystem("SF");
    dataModelMapping
        .setMappingContent(new String(
            "<data-model-mapping><languages><mapping-item><from>readingProf</from><to>readingProf</to><label>LB_READING_PROF</label><required>true</required><picklist>fluency</picklist>"
                + "</mapping-item></languages><picklist-option-mapping><picklist id='fluency'><option source='1' target='一般'/></picklist></picklist-option-mapping>"
                + "<profile><mapping-item><from>firstName</from><to>firstName</to><label>LB_FIRST_NAME</label><required>true</required></mapping-item></profile>"
                + "<workExprs><mapping-item><from>startDate</from><to>startDate</to><label>LB_STARTDATE</label><required>false</required></mapping-item></workExprs>"
                + "<certificates><mapping-item><from>name</from><to>name</to><label>LB_NAME</label><required>false</required></mapping-item></certificates>"
                + "<families><mapping-item><from>name</from><to>name</to><label>LB_NAME</label><required>false</required></mapping-item></families>"
                + "<education><mapping-item><from>major</from><to>major</to><label>LB_MAJOR</label><required>false</required></mapping-item></education>"
                + "</data-model-mapping>").getBytes());
  }

  @Test
  public void testGetCandidateDataModel() {
    CandidateProfileModel model = controller.getCandidateDataModel();
    Assert.assertNotEquals(null, model);
  }

  @Test(expected = ServiceApplicationException.class)
  public void testSaveDataModelMapping_ThrowException() throws Exception {
    HttpServletRequest mockRequest = mock(HttpServletRequest.class);
    UserCompanyMappingVO sysMapping = mock(UserCompanyMappingVO.class);
    Mockito.doThrow(ServiceApplicationException.class).when(sysMapping).getMapping();
    controller.saveDataModelMapping(mockRequest, sysMapping);
  }

  @Test
  public void testSaveDataModelMapping_Success() throws Exception {
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(0);
    rsp.setMessage("success");

    User loginUser = new MockHCPUser();

    HttpServletRequest mockRequest = mock(HttpServletRequest.class);
    UserCompanyMappingVO sysMapping = mock(UserCompanyMappingVO.class);
    CandProfileDataModelMapping mapping = mock(CandProfileDataModelMapping.class);
    DataModelMapping mapping1 = mock(DataModelMapping.class);
    mapping1.setMappingId(001L);
    Mockito.when(sysMapping.getMapping()).thenReturn(mapping);
    Mockito.doNothing().when(mapping).converFromPkOptionMappingStringtoBean();
    Mockito.when(hcpUserProvider.getLoginUser(mockRequest)).thenReturn(loginUser);
    Mockito.when(mappingService.saveDataModelMapping(loginUser.getName(), sysMapping, params.getCompanyId())).thenReturn(mapping1);
    CompanyInfo info = new CompanyInfo();
    info.setDmMappingId(001L);
    Mockito.when(compInfoService.getCompanyInfo(Mockito.any(String.class))).thenReturn(info);
    SimpleJsonResponse result = controller.saveDataModelMapping(mockRequest, sysMapping);
    assertEquals(new ObjectMapper().writeValueAsString(rsp), new ObjectMapper().writeValueAsString(result));
  }

  @SuppressWarnings("unchecked")
  @Test
  public void testSaveDataModelMapping_Failure() throws Exception {
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(-1);
    rsp.setMessage("failed");

    User loginUser = new MockHCPUser();

    HttpServletRequest mockRequest = mock(HttpServletRequest.class);
    UserCompanyMappingVO sysMapping = mock(UserCompanyMappingVO.class);
    CandProfileDataModelMapping mapping = mock(CandProfileDataModelMapping.class);
    DataModelMapping mapping1 = mock(DataModelMapping.class);
    
    Mockito.when(sysMapping.getMapping()).thenReturn(mapping);
    Mockito.doNothing().when(mapping).converFromPkOptionMappingStringtoBean();
    Mockito.when(hcpUserProvider.getLoginUser(mockRequest)).thenReturn(loginUser);
    Mockito.when(mockRequest.getParameter("companyId")).thenReturn("sap");
    Mockito.when(mappingService.saveDataModelMapping(Mockito.any(String.class), Mockito.any(UserCompanyMappingVO.class), Mockito.any(String.class))).thenThrow(PersistenceException.class);
    CompanyInfo info = new CompanyInfo();
    info.setDmMappingId(001L);
    Mockito.when(compInfoService.getCompanyInfo(Mockito.any(String.class))).thenReturn(info);
    SimpleJsonResponse result = controller.saveDataModelMapping(mockRequest, sysMapping);
    assertEquals(new ObjectMapper().writeValueAsString(rsp), new ObjectMapper().writeValueAsString(result));
  }

  @Test
  public void testNewDataModelMapping() {
    Mockito.when(mappingService.createEmptyMapping()).thenReturn(new CandProfileDataModelMapping());
    CandProfileDataModelMapping mapping = controller.newDataModelMapping();
    Assert.assertNotEquals(null, mapping);
  }

  @Test
  public void testGetDataModelMappingById_Null() throws ServiceApplicationException {
    Mockito.when(mappingService.getMappingById((long) 123)).thenReturn(null);
    CandProfileDataModelMapping result = controller.getDataModelMappingById((long) 123);
    Assert.assertEquals(null, result);
  }

  @Test
  public void testGetDataModelMappingById_Success() throws ServiceApplicationException {
    Mockito.when(mappingService.getMappingById((long) 123)).thenReturn(dataModelMapping);
    DataModelMappingService mapping = new DataModelMappingService();
    CandProfileDataModelMapping empMapping = mapping.createEmptyMapping();
    Mockito.when(mappingService.createEmptyMapping()).thenReturn(empMapping);
    CandProfileDataModelMapping result = controller.getDataModelMappingById((long) 123);
    Assert.assertNotEquals(null, result);
  }

  @SuppressWarnings("unchecked")
  @Test
  public void testGetDataModelMappingList() throws ServiceApplicationException {
    HttpServletRequest mockRequest = mock(HttpServletRequest.class);
    List<DataModelMapping> mList = new ArrayList<DataModelMapping>();
    mList.add(dataModelMapping);
    Mockito.when(mockRequest.getParameter("companyId")).thenReturn("sap");
    Mockito.when(mappingService.getMappingList(0, 10, "sap")).thenReturn(mList);
    Map<String, Object> result = controller.getDataModelMappingList(mockRequest, 0, 10);
    Assert.assertEquals(mList.size(), ((List<DataModelMapping>)result.get("entries")).size());
  }

  @Test
  public void testGetListEntry() throws ServiceApplicationException {
    MockHttpServletRequest mockRequest = new MockHttpServletRequest();

    Mockito.when(mappingService.getMappingListDetail((long) 123, "sap")).thenReturn(dataModelMapping);
    DataModelMapping result = controller.getListEntry(mockRequest, (long) 123);
    Assert.assertEquals(dataModelMapping.getCompanyId(), result.getCompanyId());
  }

  @Test
  public void testGetListEntry_Null() throws ServiceApplicationException {
    MockHttpServletRequest mockRequest = new MockHttpServletRequest();

    DataModelMapping result = controller.getListEntry(mockRequest, (long) 123);
    Assert.assertNotNull(result);
  }

  @Test
  public void testDeleteMappingById_Failure() throws JsonProcessingException, ServiceApplicationException {
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(-1);
    rsp.setMessage("failed");

    Mockito.when(mappingService.deleteMappingById(123L)).thenReturn(rsp.getCode());

    MockHttpServletRequest mockRequest = new MockHttpServletRequest();
    SimpleJsonResponse result = controller.deleteMappingById(mockRequest, 123L);
    assertEquals(new ObjectMapper().writeValueAsString(rsp), new ObjectMapper().writeValueAsString(result));
  }

  @Test
  public void testDeleteMappingById_Success() throws JsonProcessingException, ServiceApplicationException {
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(0);
    rsp.setMessage("success");

    Mockito.when(mappingService.deleteMappingById(123L)).thenReturn(rsp.getCode());

    MockHttpServletRequest mockRequest = new MockHttpServletRequest();
    User loginUser = new MockHCPUser();
    Mockito.when(hcpUserProvider.getLoginUser(mockRequest)).thenReturn(loginUser);

    Mockito.when(mappingService.getMappingById(123L)).thenReturn(dataModelMapping);
    
    CompanyInfo info = new CompanyInfo();
    info.setCompanyId(params.getCompanyId());
    Mockito.when(compInfoService.getCompanyInfo(params.getCompanyId())).thenReturn(info);

    SimpleJsonResponse result = controller.deleteMappingById(mockRequest, 123L);
    assertEquals(new ObjectMapper().writeValueAsString(rsp), new ObjectMapper().writeValueAsString(result));
  }

  @Test
  public void testExportMappingById_Success() throws ServiceApplicationException {
    HttpServletResponse response = mock(HttpServletResponse.class);
    Mockito.when(mappingService.getMappingById((long) 123)).thenReturn(dataModelMapping);

    ResponseEntity<byte[]> result = controller.exportMappingById((long) 123, response);
    assertEquals(HttpStatus.OK, result.getStatusCode());
  }

  @Test(expected = ServiceApplicationException.class)
  public void testExportMappingById_ThrowException() throws ServiceApplicationException {
    HttpServletResponse response = mock(HttpServletResponse.class);
    dataModelMapping.setMappingContent(null);
    Mockito.when(mappingService.getMappingById((long) 123)).thenReturn(dataModelMapping);

    controller.exportMappingById((long) 123, response);
  }

  @Test
  public void testImportMapping_Success() throws Exception {
    ClassPathResource resource = new ClassPathResource("/mapping/profile_model_mapping.xml");
    InputStream is = null;
    try {
      is = resource.getInputStream();
      String fileContent = IOUtils.toString(is, StandardCharsets.UTF_8.toString());
      MockMvc mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
      ResultActions result = mockMvc.perform(MockMvcRequestBuilders.fileUpload("/dm/import")
          .content(this.createMultipartContent("mapping.xml", "application/data", fileContent))
          .contentType("multipart/form-data; boundary=----WebKitFormBoundary8HC1OQgjqvtgc5tk"));
      result.andExpect(MockMvcResultMatchers.status().is(200));
      String content = result.andReturn().getResponse().getContentAsString();

      ObjectMapper om = new ObjectMapper();
      Map<?, ?> responseJson = om.readValue(content, Map.class);
      List<?> resultList = (List<?>) responseJson.get("profile");
      Assert.assertEquals(34, resultList.size());
    } catch (IOException e) {
    } finally {
      IOUtils.closeQuietly(is);
    }
  }

  @Test
  public void testImportMapping_EmptyContent() throws Exception {
    MockMvc mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
    ResultActions result = mockMvc.perform(MockMvcRequestBuilders.fileUpload("/dm/import").contentType(
        "multipart/form-data; boundary=----WebKitFormBoundary8HC1OQgjqvtgc5tk"));
    result.andExpect(MockMvcResultMatchers.status().is(200));
    String content = result.andReturn().getResponse().getContentAsString();
    Assert.assertEquals("", content);
  }

  private byte[] createMultipartContent(String fileName, String contentType, String fileContent) {
    String endline = "\r\n";
    String bondary = "----WebKitFormBoundary8HC1OQgjqvtgc5tk";
    String textFile = this.encodeTextFile(bondary, "\r\n", "file", fileName, contentType, fileContent);
    StringBuilder content = new StringBuilder(textFile.toString());
    content.append(endline);
    content.append(endline);
    content.append(endline);
    content.append("--");
    content.append(bondary);
    content.append("--");
    content.append(endline);
    return content.toString().getBytes();
  }

  private String encodeTextFile(String bondary, String endline, String name, String filename, String contentType,
      String content) {

    final StringBuilder sb = new StringBuilder();
    sb.append(endline);
    sb.append("--");
    sb.append(bondary);
    sb.append(endline);
    sb.append("Content-Disposition: form-data; name=\"");
    sb.append(name);
    sb.append("\"; filename=\"");
    sb.append(filename);
    sb.append("\"");
    sb.append(endline);
    sb.append("Content-Type: ");
    sb.append(contentType);
    sb.append(endline);
    sb.append(endline);
    sb.append(content);
    return sb.toString();
  }
}
