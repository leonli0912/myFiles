package com.sap.hcm.resume.collection.bean;

import org.junit.Assert;
import org.junit.Test;

public class BusinessEntityTypeTest {
  
  @Test
  public void testGetName(){
    BusinessEntityType type = BusinessEntityType.CANDIDATE;
    Assert.assertEquals("Candidate", type.getName());
  }
}
