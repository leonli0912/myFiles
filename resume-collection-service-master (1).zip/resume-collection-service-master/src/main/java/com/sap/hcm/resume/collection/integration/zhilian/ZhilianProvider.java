package com.sap.hcm.resume.collection.integration.zhilian;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.HttpClientUtils;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.apache.pdfbox.io.IOUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;

import com.sap.hcm.resume.collection.bean.ResumeInfo;
import com.sap.hcm.resume.collection.exception.AuthenticationFailedException;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.JobBoardBaseProvider;
import com.sap.hcm.resume.collection.integration.bean.ResumeDownloadBean;
import com.sap.hcm.resume.collection.util.CandidateFileUtil;

@Component(value = "zhilianProvider")
@Scope(value = "session", proxyMode = ScopedProxyMode.TARGET_CLASS)
public class ZhilianProvider extends JobBoardBaseProvider {

  public String getLoginUrl() {
    return "https://passport.zhaopin.com/";
  }

  public String getServiceUrl() {
    return "http://i.zhaopin.com/";
  }

  private String getDownloadUrlPartByLanguage(String url, int val) {
    return url.replaceAll("language=[^&]+", "language=" + val);
  }

  @Override
  public void preLogin() throws ServiceApplicationException {
    throw new ServiceApplicationException("Not Implemented");
  }

  @Override
  public void getVerifyCode(HttpServletRequest request) throws ServiceApplicationException {
    throw new ServiceApplicationException("Not Implemented");
  }

  @Override
  public List<ResumeDownloadBean> getResume(HttpServletRequest request, String username, String password,
      String captcha) throws ServiceApplicationException {

    this.cookieStore.clear();
    CloseableHttpClient httpClient = null;

    List<NameValuePair> urlParameters = new ArrayList<NameValuePair>();
    urlParameters.add(new BasicNameValuePair("bkurl", ""));
    urlParameters.add(new BasicNameValuePair("LoginName", username));
    urlParameters.add(new BasicNameValuePair("Password", password));
    urlParameters.add(new BasicNameValuePair("RememberMe", "false"));
    UrlEncodedFormEntity formEntity = null;
    try {
      formEntity = new UrlEncodedFormEntity(urlParameters);
    } catch (UnsupportedEncodingException e1) {
      throw new ServiceApplicationException(e1.getMessage());
    }

    List<ResumeDownloadBean> fileNameList = new ArrayList<ResumeDownloadBean>();

    // login
    String loginResponseText = null;
    HttpEntity loginEntity = null;
    try {
      httpClient = this.createHttpClient();
      HttpPost loginPost = new HttpPost(this.getLoginUrl());
      loginPost.setEntity(formEntity);
      HttpResponse loginResponse = httpClient.execute(loginPost);
      if (loginResponse == null) {
        HttpClientUtils.closeQuietly(httpClient);
        throw new ServiceApplicationException("failed to connect to zhilian");
      }
      this.setCookieStore(loginResponse);
      loginEntity = loginResponse.getEntity();
      loginResponseText = EntityUtils.toString(loginEntity);
    } catch (IOException e) {
      throw new ServiceApplicationException("failed to connect to zhilian");
    } finally {
      HttpClientUtils.closeQuietly(httpClient);
      EntityUtils.consumeQuietly(loginEntity);
    }
    if (loginResponseText != null) {
      if (loginResponseText.indexOf("我不需要修改，确认跳过") > 0) {
        // password in risk
        Pattern p1 = Pattern.compile("<a href=\"([^<>\"]*)\">我不需要修改，确认跳过</a>");
        Matcher m1 = p1.matcher(loginResponseText);
        while (m1.find()) {
          String continueUrl = m1.group(1);
          continueUrl = "https://passport.zhaopin.com" + continueUrl;
          // continue the current pwd
          try {
            httpClient = this.createHttpClient();
            httpClient.execute(new HttpGet(continueUrl));
          } catch (IOException e) {

          } finally {
            HttpClientUtils.closeQuietly(httpClient);
          }
        }
      } else if (loginResponseText.indexOf("您的操作有些频繁") >= 0) {
        throw new ServiceApplicationException(-1001,"too many login attempt found");
      } else if (loginResponseText.indexOf("用户登录_智联招聘") >= 0) {
        // login response
        // it has redirected to login page, means user/pwd is not correct
        throw new AuthenticationFailedException();
      } else if (loginResponseText.indexOf("您输入的密码与账号不匹配") >= 0){
        throw new ServiceApplicationException(-1001,"password error");
      } else if(loginResponseText.indexOf("手机号或邮箱不存在，请确认后重新输入！") >= 0){
        throw new ServiceApplicationException(-1001,"user name not exist");
      }
    }
    HttpResponse servicePageResponse = null;
    HttpResponse resumeResponse = null;

    try {
      // retrieve service page

      httpClient = this.createHttpClient();
      servicePageResponse = httpClient.execute(new HttpGet(this.getServiceUrl()));

      if (servicePageResponse != null && servicePageResponse.getEntity() != null) {
        this.setCookieStore(servicePageResponse);
        Document doc = Jsoup.parse(EntityUtils.toString(servicePageResponse.getEntity()));

        Elements resumes = doc.getElementsByClass("myTxt");
        Map<String, String> resumeLinkMap = new HashMap<String, String>();
        if (resumes != null && resumes.size() > 0) {
          for (Element element : resumes) {
            String extId = element.attr("data-ext_id");
            String resumeId = element.attr("data-resume_id");
            String versionNumber = element.attr("data-Version_Number");
            String language = element.attr("data-language_id");

            // language_id = 1 Chinese
            // language_id = 2 English
            String downloadLinkZh = "http://i.zhaopin.com/Home/resumeexport?" + "resumeNumber=" + extId + "&"
                + "resumeId=" + resumeId + "&" + "version=" + versionNumber + "&" + "language=" + language + "&dflag=2";
            resumeLinkMap.put(resumeId, downloadLinkZh);
          }
        }
        HttpClientUtils.closeQuietly(httpClient);

        if (resumeLinkMap.keySet().size() > 0) {
          for (String resumeId : resumeLinkMap.keySet()) {
            String downLoadLinkZH = this.getDownloadUrlPartByLanguage(resumeLinkMap.get(resumeId), 1);
            String downloadLinkEN = this.getDownloadUrlPartByLanguage(resumeLinkMap.get(resumeId), 2);

            httpClient = this.createHttpClient();
            resumeResponse = httpClient.execute(new HttpGet(downLoadLinkZH));

            if (resumeResponse != null && resumeResponse.getEntity() != null) {
              ResumeDownloadBean rdb = new ResumeDownloadBean();
              rdb.setLocale(Locale.CHINESE);
              rdb.setFileContent(IOUtils.toByteArray(resumeResponse.getEntity().getContent()));
              rdb.setFileName(null);
              rdb.setExternalResumeId(resumeId);
              fileNameList.add(rdb);
            }

            HttpClientUtils.closeQuietly(resumeResponse);
            HttpClientUtils.closeQuietly(httpClient);

            httpClient = this.createHttpClient();
            resumeResponse = httpClient.execute(new HttpGet(downloadLinkEN));
            if (resumeResponse != null && resumeResponse.getEntity() != null) {
              ResumeDownloadBean rdb = new ResumeDownloadBean();
              rdb.setLocale(Locale.ENGLISH);
              rdb.setFileName(null);
              rdb.setFileContent(IOUtils.toByteArray((resumeResponse.getEntity().getContent())));
              rdb.setExternalResumeId(resumeId);
              fileNameList.add(rdb);
            }
            HttpClientUtils.closeQuietly(resumeResponse);
            HttpClientUtils.closeQuietly(httpClient);
          }
        }
      }
    } catch (Exception e) {
      throw new ServiceApplicationException("failed from calling remote API");
    } finally {
      HttpClientUtils.closeQuietly(resumeResponse);
      HttpClientUtils.closeQuietly(httpClient);
    }

    return fileNameList;
  }

  @Override
  public ResumeInfo getFileContent(byte[] resource) throws ServiceApplicationException {
    ResumeInfo resumeInfo = new ResumeInfo();
    resumeInfo.setResumeExtension("html");
    resumeInfo.setHtmlDocument(CandidateFileUtil.getFileContentFromHtml(resource));
    return resumeInfo;
  }

}
