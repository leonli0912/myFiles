package com.sap.hcm.resume.collection.integration.controller;

import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.persistence.PersistenceException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.olingo.odata2.api.ep.EntityProviderException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sap.hcm.resume.collection.bean.ActionType;
import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.bean.SimpleJsonResponse;
import com.sap.hcm.resume.collection.controller.ControllerBase;
import com.sap.hcm.resume.collection.entity.DataModelMapping;
import com.sap.hcm.resume.collection.entity.view.JobApplyMappingVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.bean.ApplyDataModelMappingItem;
import com.sap.hcm.resume.collection.integration.sf.bean.SFPicklistItem;
import com.sap.hcm.resume.collection.integration.sf.bean.cdm.SFCDMConverter;
import com.sap.hcm.resume.collection.integration.sf.service.SFPicklistService;
import com.sap.hcm.resume.collection.service.DataModelMappingService;
import com.sap.hcm.resume.collection.util.CandidateFileUtil;
import com.sap.hcm.resume.collection.util.ChangeLogUtil;
import com.sap.hcm.resume.collection.util.MappingUtil;
import com.sap.security.um.user.User;

@Controller
@RequestMapping(value = "appl")
public class JobApplicationMappingController extends ControllerBase{
  
  private final Logger logger = LoggerFactory.getLogger(JobApplicationMappingController.class);

  @Autowired
  private DataModelMappingService dataModelMappingService;

  @Autowired
  private SFPicklistService sfPicklistService;
  
  @Autowired
  private ChangeLogUtil changeLogUtil;
  
  @Autowired
  private Params params;
  
  @RequestMapping(value = "uploadSFDataModel", method = RequestMethod.POST)
  public @ResponseBody List<ApplyDataModelMappingItem> uploadSFDataModel(HttpServletRequest request)
      throws FileUploadException, ServiceApplicationException {

    List<ApplyDataModelMappingItem> resultList = new ArrayList<ApplyDataModelMappingItem>();

    List<FileItem> items = CandidateFileUtil.handleFileUploadRequest(request);
    
    if (items != null && items.size() > 0) {
      for (FileItem item : items) {
        String filename = item.getName();
        String regex = ".*\\.xml";
        // check the file is xml file
        if (MappingUtil.matchSingle(regex, filename) != null) {
            // call the service to get result
            resultList = dataModelMappingService.loadNewApplyDataModelMapping(item.get());
            return resultList;
        }
      }
    }

    return resultList;

  }

  @RequestMapping(value = "saveJobApplicationDmConf", method = RequestMethod.POST)
  public @ResponseBody SimpleJsonResponse saveJobApplicationDataModelMapping(HttpServletRequest request,
      @RequestBody JobApplyMappingVO mappingResult) throws ServiceApplicationException {

    User user = hcpUserProvider.getLoginUser(request);
    if (user != null) {
      mappingResult.setCreateBy(user.getName());
    }
    SimpleJsonResponse rsp = new SimpleJsonResponse();

    try {
      String companyId = params.getCompanyId();
      DataModelMapping dmMapping = dataModelMappingService.saveApplyDataModelMapping(mappingResult, companyId);
      rsp.setCode(0);
      rsp.setMessage("success");
      changeLogUtil.saveCompanyChangeHistory(ActionType.EDT, user.getName(), "edit jobApplication mapping", companyId,
          mappingResult.getMappingName(), dmMapping.getMappingId().toString());
    } catch (PersistenceException e) {
      rsp.setCode(-1);
      rsp.setMessage("save data model failed");
      logger.error("save data model failed with: " + e.getMessage());
    }
    dataModelMappingService.renewJobApplicationPicklistCache();
    return rsp;
  }

  @RequestMapping(value = "loadJobApplicationDmConf", method = RequestMethod.GET)
  public @ResponseBody JobApplyMappingVO loadJobApplicationDataModelMapping(HttpServletRequest request)
      throws ServiceApplicationException {

    JobApplyMappingVO jobApplyMappingVO = new JobApplyMappingVO();
    String companyId = params.getCompanyId();
    jobApplyMappingVO = dataModelMappingService.getApplyDataModelMappingByCompanyId(companyId);
    return jobApplyMappingVO;
  }


  @RequestMapping(value = "picklistOptions", method = RequestMethod.GET)
  public @ResponseBody List<SFPicklistItem> loadPicklistOptions(HttpServletRequest request,
      @RequestParam(value = "picklist") String picklist,
      @RequestParam(value = "locale", defaultValue = "zh_CN", required = false) String locale)
      throws ServiceApplicationException, MalformedURLException {

    List<SFPicklistItem> pickList = new ArrayList<SFPicklistItem>();

    if ("en".equals(locale)) {
      locale = Locale.US.toString();
    }
    pickList = sfPicklistService.loadPickListOption(picklist);
    return pickList;
  }

  @RequestMapping(value = "picklistName", method = RequestMethod.GET)
  public @ResponseBody SimpleJsonResponse getPicklistName(HttpServletRequest request,
      @RequestParam(value = "propName", required = true) String propName,
      @RequestParam(value = "entityTypeName", required = true) String entityTypeName)
      throws ServiceApplicationException, EntityProviderException, IOException, MalformedURLException {

    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(-1);
    rsp.setMessage("");
    String picklistName = sfPicklistService.getPicklistName(propName, entityTypeName);
    rsp.setCode(0);
    rsp.setMessage(picklistName);

    return rsp;
  }
  
  @RequestMapping(value = "/{mappingId}/export", method = RequestMethod.GET)
  public ResponseEntity<byte[]> exportMappingById(@PathVariable(value = "mappingId") Long mappingId, HttpServletResponse response)
	  throws ServiceApplicationException {
	  DataModelMapping mapping = dataModelMappingService.getApplyDataModelMappingByMappingId(mappingId);
	  byte[] mappingContent = mapping.getMappingContent();
	  if (mappingContent != null) {
		  HttpHeaders headers = new HttpHeaders();
          headers.setContentType(MediaType.APPLICATION_XML);
          headers.setContentDispositionFormData("attachment","job_apply_model_mapping.xml");
          
          return new ResponseEntity<byte[]>(mappingContent,headers, HttpStatus.OK);
	  }else{
		  throw new ServiceApplicationException("file content is empty");
	  }
  }


  @RequestMapping(value = "/import", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
  public @ResponseBody String importMapping(HttpServletRequest request, HttpServletResponse response)
      throws ServiceApplicationException {

    String mappingTxt = "";
    List<FileItem> items = CandidateFileUtil.handleFileUploadRequest(request);
    if (items != null && items.size() > 0) {
      for (FileItem item : items) {
        String filename = item.getName();
        String regex = ".*\\.xml";
        // check the file is xml file
        if (filename != null && MappingUtil.matchSingle(regex, filename) != null) {
          try {
            List<ApplyDataModelMappingItem> mappingItem = SFCDMConverter.fromXMLByByte(item.get(),
                StandardCharsets.UTF_8.name());
            ObjectMapper om = new ObjectMapper();
            mappingTxt = om.writeValueAsString(mappingItem);
          } catch (Exception e) {
            logger.error("process upload file failed: " + e.getMessage());
            throw new ServiceApplicationException("process upload file failed");
          }
        }
      }
    }
    return mappingTxt;
  }
  
  @RequestMapping(value = "/renewPicklistCache")
  public @ResponseBody SimpleJsonResponse renewPicklistCache()
      throws ServiceApplicationException, MalformedURLException {
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp = dataModelMappingService.renewJobApplicationPicklistCache();
    return rsp;
  }

}
