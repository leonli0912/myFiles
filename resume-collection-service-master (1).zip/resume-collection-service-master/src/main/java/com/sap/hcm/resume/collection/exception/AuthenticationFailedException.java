package com.sap.hcm.resume.collection.exception;

/**
 * 
 * @author i065831
 *
 */
public class AuthenticationFailedException extends ServiceApplicationException {

  public static String ERROR_MESSAGE_KEY = "ERROR_MSG_USER_PWD_NOT_CORRECT";
  
  /**
   * serialVersion UID
   */
  private static final long serialVersionUID = 1L;
  
  public AuthenticationFailedException() {
    super(-1001, ERROR_MESSAGE_KEY);
  }

}
