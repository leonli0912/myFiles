package com.sap.hcm.resume.collection.integration.wechat.bean;

import java.io.Serializable;

public class WechatImportResult implements Serializable{
    
    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = -9148053671062691993L;

    /**
     * 1 for success
     * 0 for failure 
     */
    private int status;
    
    private String message;
    
    private Long candidateId;

    /**
     * @return the status
     */
    public int getStatus() {
        return status;
    }

    /**
     * @param status the status to set
     */
    public void setStatus(int status) {
        this.status = status;
    }

    /**
     * @return the message
     */
    public String getMessage() {
        return message;
    }

    /**
     * @param message the message to set
     */
    public void setMessage(String message) {
        this.message = message;
    }

    /**
     * @return the candidateId
     */
    public Long getCandidateId() {
        return candidateId;
    }

    /**
     * @param candidateId the candidateId to set
     */
    public void setCandidateId(Long candidateId) {
        this.candidateId = candidateId;
    }
    
}
