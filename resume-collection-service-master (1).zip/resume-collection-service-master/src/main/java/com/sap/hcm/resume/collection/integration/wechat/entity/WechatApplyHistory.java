package com.sap.hcm.resume.collection.integration.wechat.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "WECHAT_APPLY_HISTORY")
@Embeddable
public class WechatApplyHistory {

  @Id
  @GeneratedValue(strategy = GenerationType.TABLE, generator = "wechat_apply_history_seq")
  @TableGenerator(initialValue = 1, table = "SEQUENCE", name = "wechat_apply_history_seq", pkColumnName = "SEQ_NAME", valueColumnName = "SEQ_COUNT", pkColumnValue = "WECHAT_APPLY_HISTORY_PK", allocationSize = 1)
  @Column(name = "apply_history_id")
  private Long applyHistoryId;

  @Column(name = "job_id")
  private Long jobId;

  @Column(name = "wechat_id")
  private String wechatId;

  @Column(name = "company_id")
  private String companyId;

  @Column(name = "jobTitle", length = 50)
  private String jobTitle;

  @Column(name = "apply_email", length = 100)
  private String applyEmail;

  @Column(name = "apply_date", length = 10)
  private String applyDate;

  @Column(name = "apply_status", length = 100)
  private String applyStatus;

  @Temporal(TemporalType.DATE)
  @Column(name = "lastmodify")
  private Date lastModify;

  @Column(name = "SF_JOB_APPID", length = 38)
  private String sfjobApplicationId;

  @Column(name = "ext_job_id", length = 50)
  private String externalJobId;

  public String getExternalJobId() {
    return externalJobId;
  }

  public void setExternalJobId(String externalJobId) {
    this.externalJobId = externalJobId;
  }

  /**
   * @return the applyHistoryId
   */
  public Long getApplyHistoryId() {
    return applyHistoryId;
  }

  /**
   * @param applyHistoryId
   *          the applyHistoryId to set
   */
  public void setApplyHistoryId(Long applyHistoryId) {
    this.applyHistoryId = applyHistoryId;
  }

  /**
   * @return the jobId
   */
  public Long getJobId() {
    return jobId;
  }

  /**
   * @param jobId
   *          the jobId to set
   */
  public void setJobId(Long jobId) {
    this.jobId = jobId;
  }

  /**
   * @return the wechatId
   */
  public String getWechatId() {
    return wechatId;
  }

  /**
   * @param wechatId
   *          the wechatId to set
   */
  public void setWechatId(String wechatId) {
    this.wechatId = wechatId;
  }

  /**
   * @return the companyId
   */
  public String getCompanyId() {
    return companyId;
  }

  /**
   * @param companyId
   *          the companyId to set
   */
  public void setCompanyId(String companyId) {
    this.companyId = companyId;
  }

  /**
   * @return the jobTitle
   */
  public String getJobTitle() {
    return jobTitle;
  }

  /**
   * @param jobTitle
   *          the jobTitle to set
   */
  public void setJobTitle(String jobTitle) {
    this.jobTitle = jobTitle;
  }

  /**
   * @return the applyEmail
   */
  public String getApplyEmail() {
    return applyEmail;
  }

  /**
   * @param applyEmail
   *          the applyEmail to set
   */
  public void setApplyEmail(String applyEmail) {
    this.applyEmail = applyEmail;
  }

  /**
   * @return the applyDate
   */
  public String getApplyDate() {
    return applyDate;
  }

  /**
   * @param applyDate
   *          the applyDate to set
   */
  public void setApplyDate(String applyDate) {
    this.applyDate = applyDate;
  }

  /**
   * @return the applyStatus
   */
  public String getApplyStatus() {
    return applyStatus;
  }

  /**
   * @param applyStatus
   *          the applyStatus to set
   */
  public void setApplyStatus(String applyStatus) {
    this.applyStatus = applyStatus;
  }

  /**
   * @return the lastModify
   */
  public Date getLastModify() {
    return lastModify;
  }

  /**
   * @param lastModify
   *          the lastModify to set
   */
  public void setLastModify(Date lastModify) {
    this.lastModify = lastModify;
  }

  public String getSfjobApplicationId() {
    return sfjobApplicationId;
  }

  public void setSfjobApplicationId(String sfjobApplicationId) {
    this.sfjobApplicationId = sfjobApplicationId;
  }

}
