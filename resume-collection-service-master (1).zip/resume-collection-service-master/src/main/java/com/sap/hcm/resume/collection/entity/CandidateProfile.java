package com.sap.hcm.resume.collection.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import com.sap.hcm.resume.collection.annotation.ProfileAttribute;
import com.sap.hcm.resume.collection.util.I18nMessages;

/**
 * candidate profile table
 * @author i065831
 *
 */
@Entity
@Table(name="CANDIDATE_PROFILE")
public class CandidateProfile implements Serializable{

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 3076344025960353297L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.TABLE, generator = "candiate_seq")
	@TableGenerator(initialValue = 1, table = "SEQUENCE", name = "candiate_seq", pkColumnName = "SEQ_NAME", valueColumnName = "SEQ_COUNT", pkColumnValue = "CANDIDATE_PK", allocationSize = 1)
	@Column(name = "candidate_id")
	@ProfileAttribute(name="candidateId", type=Long.class)
	private Long candidateId;
	
    @Column(name="company_id", length=100)
	private String companyId;
	
	@ProfileAttribute(name="firstName", type=String.class, label=I18nMessages.LABEL_FIRST_NAME)
	@Column(name="first_name", length=100)
	private String firstName;
	
	@ProfileAttribute(name="lastName", type=String.class, label=I18nMessages.LABEL_LAST_NAME)
	@Column(name="last_name", length=100)
	private String lastName;
	
	@ProfileAttribute(name="middleName", type=String.class, label=I18nMessages.LABEL_MIDDLE_NAME)
	@Column(name="middle_name", length=100)
	private String middleName;
	
	@ProfileAttribute(name="englishName", type=String.class, label=I18nMessages.LABEL_ENGLISH_NAME)
	@Column(name="english_name", length=100)
	private String englishName;
	
	@ProfileAttribute(name="primaryEmail", type=String.class, label=I18nMessages.LABEL_PRIMARY_EMAIL)
	@Column(name="primary_email", length=100)
	private String primaryEmail;

	@ProfileAttribute(name="contactEmail", type=String.class, label=I18nMessages.LABEL_CONTACT_EMAIL)
	@Column(name="contact_email", length=100)
	private String contactEmail;
	
	@ProfileAttribute(name="gender", type=String.class, label=I18nMessages.LABEL_GENDER)
	@Column(name="gender", length=10)
	private String gender;
	
	@ProfileAttribute(name="dateOfBirth", type=String.class, label=I18nMessages.LABEL_DATE_OF_BIRTH)
	@Column(name="date_of_birth", length=10)
	private String dateOfBirth;
	
	@ProfileAttribute(name="cellPhone", type=String.class, label=I18nMessages.LABEL_CELLPHONE)
	@Column(name="cellphone",length=20)
	private String cellPhone;
	
	@ProfileAttribute(name="nationality", type=String.class, label=I18nMessages.LABEL_NATIONALITY)
	@Column(name="nationality",length=100)
	private String nationality;
	
	@ProfileAttribute(name="ethnicity", type=String.class, label=I18nMessages.LABEL_ETHNICITY)
	@Column(name="ethnicity",length=100)
	private String ethnicity;
	
	@ProfileAttribute(name="residence", type=String.class, label=I18nMessages.LABEL_RESIDENCE)
	@Column(name="residence",length=200)
	private String residence;
	
	@ProfileAttribute(name="household", type=String.class, label=I18nMessages.LABEL_HOUSEHOLD)
	@Column(name="household",length=200)
	private String household;
	
	@ProfileAttribute(name="identityCard", type=String.class, label=I18nMessages.LABEL_IDENTITY_CARD)
	@Column(name="identity_card",length=30)
	private String identityCard;
	
	@ProfileAttribute(name="passport", type=String.class, label=I18nMessages.LABEL_PASSPORT)
	@Column(name="passport",length=30)
	private String passport;
	
	@ProfileAttribute(name="address", type=String.class, label=I18nMessages.LABEL_ADDRESS)
	@Column(name="address",length=200)
	private String address;
	
	@ProfileAttribute(name="zipcode", type=String.class, label=I18nMessages.LABEL_ZIPCODE)
	@Column(name="zipcode",length=20)
	private String zipcode;

	@ProfileAttribute(name="phone", type=String.class, label=I18nMessages.LABEL_PHONE)
	@Column(name="phone",length=20)
	private String phone;
	
	@ProfileAttribute(name="country", type=String.class, label=I18nMessages.LABEL_COUNTRY)
	@Column(name="country",length=20)
	private String country;
	
	@ProfileAttribute(name="marriage", type=String.class, label=I18nMessages.LABEL_MARRIAGE)
	@Column(name="marriage",length=10)
	private String marriage;
	
	@ProfileAttribute(name="minAnnualSal", type=String.class, label=I18nMessages.LABEL_MIN_ANNUAL_SALARY)
	@Column(name="minAnnualSal",length=10)
	private String minAnnualSal;
	
	@ProfileAttribute(name="preferredLoc", type=String.class, label=I18nMessages.LABEL_PEREFER_LOCATION)
	@Column(name="preferredLoc",length=20)
	private String preferredLoc;
	
	@ProfileAttribute(name="veteranStatus", type=String.class, label=I18nMessages.LABEL_VETERANSTATUS)
	@Column(name="veteranStatus",length=10)
	private String veteranStatus;
	
	@ProfileAttribute(name="currency", type=String.class, label=I18nMessages.LABEL_CURRENCY)
	@Column(name="currency",length=5)
	private String currency;
	
	@Temporal(TemporalType.DATE)
	@Column(name="lastmodify")
	private Date lastModify;

	/**
	 * @return the candidateId
	 */
	public Long getCandidateId() {
		return candidateId;
	}

	/**
	 * @param candidateId the candidateId to set
	 */
	public void setCandidateId(Long candidateId) {
		this.candidateId = candidateId;
	}

	/**
     * @return the companyId
     */
    public String getCompanyId() {
      return companyId;
    }
  
    /**
     * @param companyId the companyId to set
     */
    public void setCompanyId(String companyId) {
      this.companyId = companyId;
    }

  /**
	 * @return the firstName
	 */
	public String getFirstName() {
		return firstName;
	}

	/**
	 * @param firstName the firstName to set
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	/**
	 * @return the lastName
	 */
	public String getLastName() {
		return lastName;
	}

	/**
	 * @param lastName the lastName to set
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	/**
	 * @return the middleName
	 */
	public String getMiddleName() {
		return middleName;
	}

	/**
	 * @param middleName the middleName to set
	 */
	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}

	/**
	 * @return the englishName
	 */
	public String getEnglishName() {
		return englishName;
	}

	/**
	 * @param englishName the englishName to set
	 */
	public void setEnglishName(String englishName) {
		this.englishName = englishName;
	}

	/**
	 * @return the primaryEmail
	 */
	public String getPrimaryEmail() {
		return primaryEmail;
	}

	/**
	 * @param primaryEmail the primaryEmail to set
	 */
	public void setPrimaryEmail(String primaryEmail) {
		this.primaryEmail = primaryEmail;
	}

	/**
	 * @return the contactEmail
	 */
	public String getContactEmail() {
		return contactEmail;
	}

	/**
	 * @param contactEmail the contactEmail to set
	 */
	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}

	/**
	 * @return the gender
	 */
	public String getGender() {
		return gender;
	}

	/**
	 * @param gender the gender to set
	 */
	public void setGender(String gender) {
		this.gender = gender;
	}

	/**
	 * @return the dateOfBirth
	 */
	public String getDateOfBirth() {
		return dateOfBirth;
	}

	/**
	 * @param dateOfBirth the dateOfBirth to set
	 */
	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	/**
	 * @return the cellPhone
	 */
	public String getCellPhone() {
		return cellPhone;
	}

	/**
	 * @param cellPhone the cellPhone to set
	 */
	public void setCellPhone(String cellPhone) {
		this.cellPhone = cellPhone;
	}

	/**
	 * @return the nationality
	 */
	public String getNationality() {
		return nationality;
	}

	/**
	 * @param nationality the nationality to set
	 */
	public void setNationality(String nationality) {
		this.nationality = nationality;
	}

	/**
	 * @return the ethnicity
	 */
	public String getEthnicity() {
		return ethnicity;
	}

	/**
	 * @param ethnicity the ethnicity to set
	 */
	public void setEthnicity(String ethnicity) {
		this.ethnicity = ethnicity;
	}

	/**
	 * @return the residence
	 */
	public String getResidence() {
		return residence;
	}

	/**
	 * @param residence the residence to set
	 */
	public void setResidence(String residence) {
		this.residence = residence;
	}

	/**
	 * @return the household
	 */
	public String getHousehold() {
		return household;
	}

	/**
	 * @param household the household to set
	 */
	public void setHousehold(String household) {
		this.household = household;
	}

	/**
	 * @return the identityCard
	 */
	public String getIdentityCard() {
		return identityCard;
	}

	/**
	 * @param identityCard the identityCard to set
	 */
	public void setIdentityCard(String identityCard) {
		this.identityCard = identityCard;
	}

	/**
	 * @return the passport
	 */
	public String getPassport() {
		return passport;
	}

	/**
	 * @param passport the passport to set
	 */
	public void setPassport(String passport) {
		this.passport = passport;
	}

	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}

	/**
	 * @return the zipcode
	 */
	public String getZipcode() {
		return zipcode;
	}

	/**
	 * @param zipcode the zipcode to set
	 */
	public void setZipcode(String zipcode) {
		this.zipcode = zipcode;
	}

	/**
	 * @return the phone
	 */
	public String getPhone() {
		return phone;
	}

	/**
	 * @param phone the phone to set
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
	/**
	 * @return the country
	 */
	public String getCountry() {
		return country;
	}

	/**
	 * @param country the country to set
	 */
	public void setCountry(String country) {
		this.country = country;
	}
	
	/**
	 * @return the marriage
	 */
	public String getMarriage() {
		return marriage;
	}

	/**
	 * @param marriage the marriage to set
	 */
	public void setMarriage(String marriage) {
		this.marriage = marriage;
	}

	/**
	 * @return the minAnnualSal
	 */
	public String getMinAnnualSal() {
		return minAnnualSal;
	}

	/**
	 * @param minAnnualSal the minAnnualSal to set
	 */
	public void setMinAnnualSal(String minAnnualSal) {
		this.minAnnualSal = minAnnualSal;
	}

	/**
	 * @return the preferredLoc
	 */
	public String getPreferredLoc() {
		return preferredLoc;
	}

	/**
	 * @param preferredLoc the preferredLoc to set
	 */
	public void setPreferredLoc(String preferredLoc) {
		this.preferredLoc = preferredLoc;
	}
	
	/**
	 * @return the veteranStatus
	 */
	public String getVeteranStatus() {
		return veteranStatus;
	}

	/**
	 * @param veteranStatus the veteranStatus to set
	 */
	public void setVeteranStatus(String veteranStatus) {
		this.veteranStatus = veteranStatus;
	}

	/**
	 * @return the currency
	 */
	public String getCurrency() {
		return currency;
	}

	/**
	 * @param currency the currency to set
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}

	/**
	 * @return the lastModify
	 */
	public Date getLastModify() {
		return lastModify;
	}

	/**
	 * @param lastModify the lastModify to set
	 */
	public void setLastModify(Date lastModify) {
		this.lastModify = lastModify;
	}
	
	
}
