package com.sap.hcm.resume.collection.integration.service;

import com.sap.hcm.resume.collection.entity.DataModelMapping;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;

/**
 * @author I075908 SAP
 */
public interface CandidateIntegrationService extends IntegrationService {
  Long getCandidateId(String key) throws ServiceApplicationException;

  /**
   * @param candidateProfileVO
   * @param mapping
   * @return
   * @throws ServiceApplicationException
   */
  CandidateProfileVO insertCandidate(CandidateProfileVO candidateProfileVO, DataModelMapping mapping)
      throws ServiceApplicationException;

}
