package com.sap.hcm.resume.collection.integration.bean;

import java.io.Serializable;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

@XStreamAlias("data-mapping-overwrite")
public class DataMappingOverwrite implements Serializable{
  
  /**
   * serial version UID
   */
  private static final long serialVersionUID = 1154285309414634620L;
  
  @XStreamImplicit(itemFieldName="rule")
  public List<String> rules;

  /**
   * @return the rules
   */
  public List<String> getRules() {
    return rules;
  }

  /**
   * @param rules the rules to set
   */
  public void setRules(List<String> rules) {
    this.rules = rules;
  }


}
