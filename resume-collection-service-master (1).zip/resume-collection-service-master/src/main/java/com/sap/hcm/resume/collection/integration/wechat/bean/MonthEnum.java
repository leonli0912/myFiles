package com.sap.hcm.resume.collection.integration.wechat.bean;

public enum MonthEnum {
    
    UNKNOWN(0, "Unknown"),
    JANUARY(1, "January"),
    February(2, "February"),
    March(3, "March"),
    April(4, "April"),
    May(5, "May"),
    June(6, "June"),
    JULY(7, "July"),
    AUGUST(8, "August"),
    SEPTEMBER(9, "September"),
    OCTOBER(10, "October"),
    NOVEMBER(11, "November"),
    DECEMBER(12, "December");
    
    private int range;
    private String label;
    
    MonthEnum(int range, String label) {
        this.range = range;
        this.label = label;
    }

    /**
     * @return the range
     */
    public int getRange() {
        return range;
    }

    /**
     * @param range the range to set
     */
    public void setRange(int range) {
        this.range = range;
    }

    /**
     * @return the label
     */
    public String getLabel() {
        return label;
    }

    /**
     * @param label the label to set
     */
    public void setLabel(String label) {
        this.label = label;
    }
    
    public static int getRangeByLabel(String label){
        for (MonthEnum degreeRange : MonthEnum.values()) {
            if(degreeRange.getLabel().equals(label)){
                return degreeRange.getRange();
            }
        }
        return MonthEnum.UNKNOWN.getRange();
    }
    
    public static String getLabelByRange(int range){
        for (MonthEnum degreeRange : MonthEnum.values()) {
            if(degreeRange.getRange() == range){
                return degreeRange.getLabel();
            }
        }
        return MonthEnum.UNKNOWN.getLabel();
    }
    
}
