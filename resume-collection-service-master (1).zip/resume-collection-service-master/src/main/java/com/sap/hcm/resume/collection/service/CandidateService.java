package com.sap.hcm.resume.collection.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.sap.hcm.resume.collection.entity.DataModelMapping;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.service.CandidateIntegrationService;

@Component
public class CandidateService {

  @Autowired
  @Qualifier(value="candidateIntegrationServiceProxy")
  private CandidateIntegrationService integrationService;

  public Long getCandidateId(String key) throws ServiceApplicationException {
    return integrationService.getCandidateId(key);
  }
  
  public CandidateProfileVO insertCandidate(CandidateProfileVO candidateProfileVO, DataModelMapping mapping)
      throws ServiceApplicationException {
    return integrationService.insertCandidate(candidateProfileVO, mapping);
  }
}
