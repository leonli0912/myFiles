package com.sap.hcm.resume.collection.integration.wechat.bean;

import java.io.Serializable;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("menu")
public class WechatMenuContent implements Serializable{

  /**
   * 
   */
  private static final long serialVersionUID = 3001176179545552625L;

  public List<WechatMenuItem> getWechatMenuItem() {
    return wechatMenuItem;
  }

  public void setWechatMenuItem(List<WechatMenuItem> wechatMenuItem) {
    this.wechatMenuItem = wechatMenuItem;
  }

  private List<WechatMenuItem> wechatMenuItem;
  
  
}
