package com.sap.hcm.resume.collection.integration.bean;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;

@XStreamAlias("option")
public class DataMappingPicklistOption implements Serializable{
    
    
    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 9202069509198575526L;
    
    @XStreamAsAttribute
    private String source;
    
    @XStreamAsAttribute
    private String target;

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getTarget() {
        return target;
    }

    public void setTarget(String target) {
        this.target = target;
    }
    
}
