package com.sap.hcm.resume.collection.integration.bean;

import org.junit.Assert;
import org.junit.Test;

import com.sap.hcm.resume.collection.entity.view.JobApplyMappingVO;


public class JobApplyMappingVOTest {
  
  @Test
  public void testSetGetter(){
    JobApplyMappingVO vo = new JobApplyMappingVO();
    
    vo.setCreateBy("ryan");
    vo.setId(1L);
    vo.setItemList(null);
    vo.setMappingName("test");
    vo.setTargetSystem("SF");
    
    Assert.assertEquals(vo.getCreateBy(), "ryan");
    Assert.assertEquals(vo.getId().toString(), "1");
    Assert.assertEquals(vo.getItemList(), null);
    Assert.assertEquals(vo.getMappingName(), "test");
    Assert.assertEquals(vo.getTargetSystem(),"SF");
  }
}
