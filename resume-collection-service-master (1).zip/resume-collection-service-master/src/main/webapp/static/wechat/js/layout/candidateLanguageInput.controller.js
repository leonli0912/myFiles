sap.ui.define([
               'static/wechat/js/layout/ResumeInputUtil',
               'sap/ui/core/mvc/Controller',
               'sap/m/MessageBox'
               ], function(ResumeInputUtil, Controller, MessageBox){
	"use strict";
	var candidateLanguageInput = Controller.extend("static.wechat.js.layout.candidateLanguageInput",{
		_candidateId : null,
		_langId : null,
		_jobId: null,
		_mapping: [],
		_inputs: [],
		_profileLan: null,

	/**
	* Called when a controller is instantiated and its View controls (if available) are already created.
	* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
	* @memberOf resume-collection-service.candidateLanguageInput
	*/
		onInit: function() {

			this._router = sap.ui.core.UIComponent.getRouterFor(this);
			var that = this;

			this._router.getRoute("candidateLanguageInput").attachPatternMatched(function(oEvent){
				var query = oEvent.getParameter("arguments")['?query'];
				if (query && query.jobId) {
					that._jobId = query.jobId;
				}else{
					that._jobId = null;
				}
				if(query && query.profileLan){
					that._profileLan = query.profileLan;
				}
				that._candidateId = oEvent.getParameter("arguments").candidateId;
				var lanModel = new sap.ui.model.resource.ResourceModel({bundleName:"static.i18n.i18n",bundleLocale:that._profileLan});
				that.getView().setModel(lanModel, "pi18n");
				if (oEvent.getParameter("arguments").langId != -1) {
					that._langId = oEvent.getParameter("arguments").langId;
					var oLanguageModel = new sap.ui.model.json.JSONModel("cv/editLanguage?candidateId=" + that._candidateId + "&langId=" + that._langId);
					var that2 = that;
					oLanguageModel.attachRequestCompleted(function(oEvent) {
						that2.getView().byId("candidateLanguageInputPage").setModel(oLanguageModel);
					});
				} else {

					that._langId = null;
					that.getView().byId("candidateLanguageInputPage").setModel(new sap.ui.model.json.JSONModel());
				}
				var listModel = new sap.ui.model.json.JSONModel("static/wechat/js/json/language_list.json");
				that.getView().setModel(listModel, "dpList");

				// attach handlers for validation errors
				sap.ui.getCore().attachValidationError(function (evt) {
					var control = evt.getParameter("element");
					control.getParent().addStyleClass("inputListItemErrorClass");
					MessageBox.alert(this.getView().getModel("wi18n").getResourceBundle().getText("ERROR_MSG_CANDIDATE_INPUT_INVALID"));
				});
				sap.ui.getCore().attachValidationSuccess(function (evt) {
					var control = evt.getParameter("element");
					control.getParent().removeStyleClass("inputListItemErrorClass");
				});
				
				var resumeInputUtil = new ResumeInputUtil();
			    var profilePanel = that.getView().byId("candidateLanguageInput");
				that._inputs = resumeInputUtil.buildGenericProfilePage("languages", profilePanel ,that.getView().getModel("pi18n"),that._profileLan);
			})
		},

		onSave : function() {

			var that = this;
			var jsonData = that.getView().byId("candidateLanguageInputPage").getModel().getData();
			var cfg = {
				type : 'POST',
				data: JSON.stringify(jsonData),
				dataType : 'json',
				contentType : 'application/json;charset=UTF-8'
			};
			cfg.url = "cv/saveLanguage?candidateId=" + this._candidateId;
			if (this._langId) {
				cfg.url = cfg.url +  "&langId=" + this._langId;
			}
			var resumeInputUtil = new ResumeInputUtil();
			if(resumeInputUtil.validateRequiredInputs(that._inputs, that.getView().getModel("wi18n"))){
				$.ajax(cfg).success(function() {
			    	if(that._jobId) {
			    	that._router.navTo("candidatePreview",{candidateId:that._candidateId, query:{jobId:that._jobId,profileLan:that._profileLan}});
			    	}else{
			    		that._router.navTo("candidatePreview",{candidateId:that._candidateId,query:{profileLan:that._profileLan}});
			    	}
			    });
			}
		},

		translatEnumLabel:function(val){
			return this.getView().getModel("wi18n").getResourceBundle().getText(val);
		},

		proLanTranslat:function(val){
			return this.getView().getModel("pi18n").getResourceBundle().getText(val);
		},

		onCancel : function() {

			var oHistory = sap.ui.core.routing.History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("jobList", true);
			}
		}

	/**
	* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
	* (NOT before the first rendering! onInit() is used for that one!).
	* @memberOf resume-collection-service.candidateLanguageInput
	*/
//		onBeforeRendering: function() {
	//
//		},

	/**
	* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
	* This hook is the same one that SAPUI5 controls get after being rendered.
	* @memberOf resume-collection-service.candidateLanguageInput
	*/
//		onAfterRendering: function() {
	//
//		},

	/**
	* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
	* @memberOf resume-collection-service.candidateLanguageInput
	*/
//		onExit: function() {
	//
//		}
	});

	return candidateLanguageInput;
});
