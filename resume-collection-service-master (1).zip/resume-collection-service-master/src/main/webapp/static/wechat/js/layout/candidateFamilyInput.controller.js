sap.ui.define([
               'static/wechat/js/layout/ResumeInputUtil',
               'sap/ui/core/mvc/Controller',
               'sap/m/MessageBox'
               ], function(ResumeInputUtil, Controller, MessageBox){
	"user strict";
	var candidateFamilyInput = Controller.extend("static.wechat.js.layout.candidateFamilyInput", {
		_candidateId : null,
		_famId : null,
		_jobId: null,
		_profileLan: null,
		_inputs:[],

	/**
	* Called when a controller is instantiated and its View controls (if available) are already created.
	* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
	* @memberOf resume-collection-service.candidateFamilyInput
	*/
		onInit: function() {

			this._router = sap.ui.core.UIComponent.getRouterFor(this);
			var that = this;

			this._router.getRoute("candidateFamilyInput").attachPatternMatched(function(oEvent){
				var query = oEvent.getParameter("arguments")['?query'];
				if(query && query.jobId) {
					that._jobId = query.jobId;
				}else{
					that._jobId = null;
				}
				if(query && query.profileLan){
					that._profileLan = query.profileLan;
				}
				that._candidateId = oEvent.getParameter("arguments").candidateId;
				if (oEvent.getParameter("arguments").famId != -1) {

					that._famId = oEvent.getParameter("arguments").famId;
					var oFamilyModel = new sap.ui.model.json.JSONModel("cv/editFamily?candidateId=" + that._candidateId + "&famId=" + that._famId);
					that.getView().byId("candidateFamilyInputPage").setModel(oFamilyModel);
				} else {

					that._famId = null;
					that.getView().byId("candidateFamilyInputPage").setModel(new sap.ui.model.json.JSONModel());
				}

				var lanModel = new sap.ui.model.resource.ResourceModel({bundleName:"static.i18n.i18n",bundleLocale:that._profileLan});
				that.getView().setModel(lanModel, "pi18n");

				// attach handlers for validation errors
				sap.ui.getCore().attachValidationError(function (evt) {
					var control = evt.getParameter("element");
					control.getParent().addStyleClass("inputListItemErrorClass");
					MessageBox.alert(this.getView().getModel("wi18n").getResourceBundle().getText("ERROR_MSG_CANDIDATE_INPUT_INVALID"));
				});
				sap.ui.getCore().attachValidationSuccess(function (evt) {
					var control = evt.getParameter("element");
					control.getParent().removeStyleClass("inputListItemErrorClass");
				});
				
				var resumeInputUtil = new ResumeInputUtil();
			    var profilePanel = that.getView().byId("candidateFamiliesInput");
				that._inputs = resumeInputUtil.buildGenericProfilePage("families", profilePanel ,that.getView().getModel("pi18n"),that._profileLan);
			})
		},

		onSave : function() {

			var that = this;
			var jsonData = that.getView().byId("candidateFamilyInputPage").getModel().getData();
			var cfg = {
				type : 'POST',
				data: JSON.stringify(jsonData),
				dataType : 'json',
				contentType : 'application/json;charset=UTF-8'
			};
			cfg.url = "cv/saveFamily?candidateId=" + this._candidateId;
			if (this._famId) {
				cfg.url = cfg.url +  "&famId=" + this._famId;
			}
			var resumeInputUtil = new ResumeInputUtil();
			if(resumeInputUtil.validateRequiredInputs(that._inputs, that.getView().getModel("wi18n"))){
				$.ajax(cfg).success(function() {
			    	if(that._jobId) {
			    		that._router.navTo("candidatePreview",{candidateId:that._candidateId, query:{jobId:that._jobId,profileLan:that._profileLan}});
			    	}else{
			    		that._router.navTo("candidatePreview",{candidateId:that._candidateId,query:{profileLan:that._profileLan}});
			    	}
			    });
			}

		},

		validate : function(){
			if (this._inputs.length == 0){
				return true;
			}
			var that = this;
			var canContinue = true;
			jQuery.each(this._inputs, function (i, input) {
				if(input instanceof sap.m.Input || input instanceof sap.m.DatePicker){
					if (!input.getValue()){
						input.getParent().addStyleClass("inputListItemErrorClass");
						canContinue = false;
					}
				}else if(input instanceof sap.m.Select){
					if(!input.getSelectedKey()){
						input.getParent().addStyleClass("inputListItemErrorClass");
						canContinue = false;
					}
				}
			});
			if(!canContinue){
				MessageBox.alert(this.getView().getModel("wi18n").getResourceBundle().getText("ERROR_MSG_CANDIDATE_INPUT_EMPTY"));
			}

			return canContinue;

		},

		onCancel : function() {

			var oHistory = sap.ui.core.routing.History.getInstance();
			var sPreviousHash = oHistory.getPreviousHash();

			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("jobList", true);
			}
		}

	/**
	* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
	* (NOT before the first rendering! onInit() is used for that one!).
	* @memberOf resume-collection-service.candidateFamilyInput
	*/
//		onBeforeRendering: function() {
	//
//		},

	/**
	* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
	* This hook is the same one that SAPUI5 controls get after being rendered.
	* @memberOf resume-collection-service.candidateFamilyInput
	*/
//		onAfterRendering: function() {
	//
//		},

	/**
	* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
	* @memberOf resume-collection-service.candidateFamilyInput
	*/
//		onExit: function() {
	//
//		}
	});
	return candidateFamilyInput;
});
