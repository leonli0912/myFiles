package com.sap.hcm.resume.collection.integration.job51;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.message.BasicHeader;
import org.jsoup.nodes.Document;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.BlockJUnit4ClassRunner;
import org.mockito.Matchers;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mock.web.MockHttpServletRequest;

import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.HttpRequestMatcher;
import com.sap.hcm.resume.collection.integration.MockHttpEntity;
import com.sap.hcm.resume.collection.integration.bean.ResumeDownloadBean;

@RunWith(PowerMockRunner.class)
@PowerMockRunnerDelegate(BlockJUnit4ClassRunner.class)
@PrepareForTest(Job51Provider.class)
public class Job51ProviderTest {

  private Job51Provider job51Provider;

  private CloseableHttpClient httpClient = null;

  @Before
  public void setUp() throws Exception {
    job51Provider = PowerMockito.spy(new Job51Provider());
    httpClient = Mockito.mock(CloseableHttpClient.class);

    PowerMockito.doReturn(httpClient).when(job51Provider, "createHttpClient");
  }

  @Test
  public void testPreLoginJob51Success() throws Exception {
    CloseableHttpResponse response = Mockito.mock(CloseableHttpResponse.class);
    Mockito.when(httpClient.execute(Mockito.any(HttpGet.class))).thenReturn(response);
    job51Provider.preLogin();
  }

  @Test(expected = ServiceApplicationException.class)
  public void testPreLoginJob51Failed() throws Exception {
    Mockito.when(httpClient.execute(Mockito.any(HttpGet.class))).thenThrow(new RuntimeException("eee"));
    job51Provider.preLogin();
  }

  @Test(expected = ServiceApplicationException.class)
  public void testGetResumeFailedByConnectFailed() throws Exception {
    MockHttpServletRequest mockRequest = new MockHttpServletRequest();

    HttpRequestMatcher loginPost = new HttpRequestMatcher(Job51Provider.LOGIN_URL);
    Mockito.when(httpClient.execute(Matchers.argThat(loginPost))).thenReturn(null);

    job51Provider.getResume(mockRequest, "test", "1234", "1234");
  }

  @Test(expected = ServiceApplicationException.class)
  public void testGetResumeFailedByInvalidUserPass() throws Exception {
    CloseableHttpResponse loginResponse = Mockito.mock(CloseableHttpResponse.class);
    MockHttpServletRequest mockRequest = new MockHttpServletRequest();

    HttpRequestMatcher loginPost = new HttpRequestMatcher(Job51Provider.LOGIN_URL);
    Mockito.when(httpClient.execute(Matchers.argThat(loginPost))).thenReturn(loginResponse);

    HttpEntity mockLoginResponseEntity = new MockHttpEntity("application/json", "{message: -7018}");
    Mockito.when(loginResponse.getEntity()).thenReturn(mockLoginResponseEntity);

    job51Provider.getResume(mockRequest, "test", "1234", "1234");
  }

  @Test(expected = ServiceApplicationException.class)
  public void testGetResumeFailedByIOException() throws Exception {

    MockHttpServletRequest mockRequest = new MockHttpServletRequest();

    HttpRequestMatcher loginPost = new HttpRequestMatcher(Job51Provider.LOGIN_URL);
    Mockito.when(httpClient.execute(Matchers.argThat(loginPost))).thenThrow(new IOException("io exception"));

    job51Provider.getResume(mockRequest, "test", "1234", "1234");
  }

  @Test(expected = ServiceApplicationException.class)
  public void testGetResumeFailedByWrongVerifyCode() throws Exception {

    CloseableHttpResponse loginResponse = Mockito.mock(CloseableHttpResponse.class);
    MockHttpServletRequest mockRequest = new MockHttpServletRequest();

    HttpRequestMatcher loginPost = new HttpRequestMatcher(Job51Provider.LOGIN_URL);
    Mockito.when(httpClient.execute(Matchers.argThat(loginPost))).thenReturn(loginResponse);

    Header header = new BasicHeader("Set-Cookie",
        "JSESSIONID=EB91B59A77CBA5192E0468B8AB60FFBD40C1CA58CED9E7C31BEE6F40E33E0566");
    Header[] headers = new Header[1];
    headers[0] = header;
    Mockito.when(loginResponse.getHeaders("Set-Cookie")).thenReturn(headers);

    HttpEntity mockLoginResponseEntity = new MockHttpEntity("application/json", "test");
    Mockito.when(loginResponse.getEntity()).thenReturn(mockLoginResponseEntity);

    job51Provider.getResume(mockRequest, "test", "1234", "1234");
  }

  @Test
  public void testGetResumeSuccess() throws ClientProtocolException, IOException, ServiceApplicationException {

    // login
    CloseableHttpResponse loginResponse = Mockito.mock(CloseableHttpResponse.class);
    MockHttpServletRequest mockRequest = new MockHttpServletRequest();

    HttpRequestMatcher loginPost = new HttpRequestMatcher(Job51Provider.LOGIN_URL);
    Mockito.when(httpClient.execute(Matchers.argThat(loginPost))).thenReturn(loginResponse);

    Header header = new BasicHeader("Set-Cookie",
        "JSESSIONID=EB91B59A77CBA5192E0468B8AB60FFBD40C1CA58CED9E7C31BEE6F40E33E0566");
    Header[] headers = new Header[1];
    headers[0] = header;
    Mockito.when(loginResponse.getHeaders("Set-Cookie")).thenReturn(headers);

    HttpEntity mockLoginResponseEntity = new MockHttpEntity("application/json", "{userinfo:'hahaha'}");
    Mockito.when(loginResponse.getEntity()).thenReturn(mockLoginResponseEntity);

    // get resume and account
    CloseableHttpResponse getResumeAndAccountResponse = Mockito.mock(CloseableHttpResponse.class);
    HttpRequestMatcher resumeAndAccountGet = new HttpRequestMatcher(Job51Provider.GET_RESUME_AND_ACCCOUNT_URL);
    Mockito.when(httpClient.execute(Matchers.argThat(resumeAndAccountGet))).thenReturn(getResumeAndAccountResponse);

    String mockResumeLink = "<a href=\"javascript:RefreshresumeAll(49288235,'0','http://my.51job.com');\" style=\"cursor:pointer;\" class=\"icon18 iconRefreshGrey\"></a>";
    HttpEntity mockRusumeAndAccountEntity = new MockHttpEntity("text/plain", mockResumeLink);
    Mockito.when(getResumeAndAccountResponse.getEntity()).thenReturn(mockRusumeAndAccountEntity);

    // get resume file
    CloseableHttpResponse downloadRsp = Mockito.mock(CloseableHttpResponse.class);
    HttpRequestMatcher downloadPost = new HttpRequestMatcher(Job51Provider.DOWNLOAD_RESUME_URL);
    Mockito.when(httpClient.execute(Matchers.argThat(downloadPost))).thenReturn(downloadRsp);

    HttpEntity mockDownloadResponseEntity = new MockHttpEntity("text/plain", "resume content");
    Mockito.when(downloadRsp.getEntity()).thenReturn(mockDownloadResponseEntity);

    List<ResumeDownloadBean> beanList = job51Provider.getResume(mockRequest, "test", "1234", "1234");
    Assert.assertEquals(beanList.size(), 2);
  }

  @Test
  public void testGetVerifyCode() throws ClientProtocolException, IOException, ServiceApplicationException {
    CloseableHttpResponse response = Mockito.mock(CloseableHttpResponse.class);
    Mockito.when(httpClient.execute(Mockito.any(HttpGet.class))).thenReturn(response);

    MockHttpServletRequest mockRequest = new MockHttpServletRequest();
    ClassPathResource image = new ClassPathResource("/images/test.png");
    HttpEntity mockGetVerifyCodeEntity = new MockHttpEntity("image/png", image.getInputStream());
    Mockito.when(response.getEntity()).thenReturn(mockGetVerifyCodeEntity);
    job51Provider.getVerifyCode(mockRequest);
  }

  @Test
  public void testGetFileContent() throws ServiceApplicationException, IOException {
    ClassPathResource resume = new ClassPathResource("resumes/51-mht.doc");
    InputStream is = null;
    try {
      is = resume.getInputStream();
      Document content = job51Provider.getFileContent(IOUtils.toByteArray(is)).getHtmlDocument();
      Assert.assertNotNull(content);
    } catch (IOException e) {
    } finally {
      IOUtils.closeQuietly(is);
    }
  }

  @Test
  public void testSetCookie() {
    HttpResponse response = Mockito.mock(HttpResponse.class);
    Header[] headers = new Header[1];
    headers[0] = new BasicHeader("Set-Cookie",
        "CUSTOMER=test; domain=sap.com; max-age=10000; path=/; expires=Wednesday, 09-Nov-2099 23:12:40 GMT; comment=test");

    Mockito.when(response.getHeaders("Set-Cookie")).thenReturn(headers);
    job51Provider.setCookieStore(response);
    String value = job51Provider.getCookieValue("CUSTOMER");
    Assert.assertEquals(value, "test");
  }
}
