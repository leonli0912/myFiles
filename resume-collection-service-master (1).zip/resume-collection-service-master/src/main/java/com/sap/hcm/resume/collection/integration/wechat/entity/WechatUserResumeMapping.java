package com.sap.hcm.resume.collection.integration.wechat.entity;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="WECHAT_RESUME_MAPPING")
@Embeddable
public class WechatUserResumeMapping {
    
    @Id
    @Column(name="wechat_id")
    private String wechatId;
    
    @Id
    @Column(name="candidate_id")
    private Long candidateId;
    
    @Id
    @Column(name="company_id")
    private String companyId;
    
    @Column(name="resume_name", length=100)
    private String resumeName;
    
    @Column(name="vendor_name", length=50)
    private String vendorName;
    
    @Column(name="language", length=10)
    private String language;
    
    @Column(name="external_resume_id", length=50)
    private String externalResumeId;
    

    /**
     * @return the wechatId
     */
    public String getWechatId() {
        return wechatId;
    }
    /**
     * @param wechatId the wechatId to set
     */
    public void setWechatId(String wechatId) {
        this.wechatId = wechatId;
    }
    /**
     * @return the companyId
     */
    public String getCompanyId() {
        return companyId;
    }
    /**
     * @param companyId the companyId to set
     */
    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }
    /**
     * @return the resumeName
     */
    public String getResumeName() {
        return resumeName;
    }
    /**
     * @param resumeName the resumeName to set
     */
    public void setResumeName(String resumeName) {
        this.resumeName = resumeName;
    }
    /**
     * @return the candidateId
     */
    public Long getCandidateId() {
        return candidateId;
    }
    /**
     * @param candidateId the candidateId to set
     */
    public void setCandidateId(Long candidateId) {
        this.candidateId = candidateId;
    }
    /**
     * @return the vendorName
     */
    public String getVendorName() {
        return vendorName;
    }
    /**
     * @param vendorName the vendorName to set
     */
    public void setVendorName(String vendorName) {
        this.vendorName = vendorName;
    }
    /**
     * @return the language
     */
    public String getLanguage() {
        return language;
    }
    /**
     * @param language the language to set
     */
    public void setLanguage(String language) {
        this.language = language;
    }
    /**
     * @return the externalResumeId
     */
    public String getExternalResumeId() {
        return externalResumeId;
    }
    /**
     * @param externalResumeId the externalResumeId to set
     */
    public void setExternalResumeId(String externalResumeId) {
        this.externalResumeId = externalResumeId;
    }
}
