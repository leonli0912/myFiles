package com.sap.hcm.resume.collection.integration.wechat.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "WECHAT_AUTH")
public class WechatAuth {

  @Id
  @Column(name = "open_id")
  private String openId;
  
  @Id
  @Column(name = "company_id")
  private String companyId;
  
  @Column(name = "primary_email")
  private String primaryEmail;

  @Column(name = "create_at")
  @Temporal(TemporalType.DATE)
  private Date createAt;

  @Column(name = "lastmodify")
  @Temporal(TemporalType.DATE)
  private Date lastModify;

  /**
   * @return the openId
   */
  public String getOpenId() {
    return openId;
  }

  /**
   * @param openId the openId to set
   */
  public void setOpenId(String openId) {
    this.openId = openId;
  }

  /**
   * @return the primaryEmail
   */
  public String getPrimaryEmail() {
    return primaryEmail;
  }

  /**
   * @param primaryEmail the primaryEmail to set
   */
  public void setPrimaryEmail(String primaryEmail) {
    this.primaryEmail = primaryEmail;
  }

  /**
   * @return the companyId
   */
  public String getCompanyId() {
    return companyId;
  }

  /**
   * @param companyId the companyId to set
   */
  public void setCompanyId(String companyId) {
    this.companyId = companyId;
  }

  /**
   * @return the createAt
   */
  public Date getCreateAt() {
    return createAt;
  }

  /**
   * @param createAt the createAt to set
   */
  public void setCreateAt(Date createAt) {
    this.createAt = createAt;
  }

  /**
   * @return the lastModify
   */
  public Date getLastModify() {
    return lastModify;
  }

  /**
   * @param lastModify the lastModify to set
   */
  public void setLastModify(Date lastModify) {
    this.lastModify = lastModify;
  }
}
