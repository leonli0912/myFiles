
package com.sap.hcm.resume.collection.security;

import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockHttpSession;

/**
 * @author I324117
 * SAP
 */
public class CreateCsrfTokenInterceptorTest {
  
  private CreateCsrfTokenInterceptor createCsrfToken;
  
  @Before
  public void setUp(){
    createCsrfToken = new CreateCsrfTokenInterceptor();
  }

  @Test
  public void testPreHandle() throws Exception{
    MockHttpServletRequest request = new MockHttpServletRequest();
    MockHttpServletResponse response = new MockHttpServletResponse();
    Object handler = new Object();
    MockHttpSession session = new MockHttpSession();
    session.setAttribute(CsrfTokenManager.CSRF_PARAM_NAME, null);
    request.setSession(session);
    assertEquals(true,createCsrfToken.preHandle(request, response, handler));
  }
}
