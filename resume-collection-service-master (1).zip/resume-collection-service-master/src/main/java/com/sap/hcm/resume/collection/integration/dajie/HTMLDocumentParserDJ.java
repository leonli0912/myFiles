package com.sap.hcm.resume.collection.integration.dajie;

import java.util.ArrayList;
import java.util.List;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.context.MessageSource;
import org.springframework.util.StringUtils;

import com.sap.hcm.resume.collection.entity.view.CandidateBgCertificateVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgEducationVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgLanguageVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgWorkExprVO;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.parser.HTMLDocumentParser;
import com.sap.hcm.resume.collection.util.CandidateDateUtil;
import com.sap.hcm.resume.collection.util.MappingUtil;

public class HTMLDocumentParserDJ extends HTMLDocumentParser {

    public HTMLDocumentParserDJ(MessageSource messageSource) {
      super(messageSource);
    }
    
    private static List<String> HEAD_LINES = new ArrayList<String>();
    
    private static final String DAJE_DATE_FORMAT = "yyyy-M";
    
    private static final String DEFAULT_DATE_FORMAT = "yyyy/MM/dd";
    
    private static final String SPACE = " ";
//    private static final String JOB_COMPANY_SEPARATOR = "\\u00A0\\u00A0";

    static {
        HEAD_LINES.add("关于我");
        HEAD_LINES.add("工作经历");
        HEAD_LINES.add("语言能力");
        HEAD_LINES.add("教育经历");
        HEAD_LINES.add("证书");
        HEAD_LINES.add("专长");
        HEAD_LINES.add("IT技能");
        HEAD_LINES.add("项目经验");
        HEAD_LINES.add("培训经历");
        HEAD_LINES.add("校内职务");
        HEAD_LINES.add("校内奖励");
        HEAD_LINES.add("实习经历");
        HEAD_LINES.add("求职经历");
        HEAD_LINES.add("其他信息");
        HEAD_LINES.add("附件/作品");
        HEAD_LINES.add("圈子信息");
    }

    @Override
    public CandidateProfileVO parseProfile(CandidateProfileVO candidateProfileVO, Document document)
            throws ServiceApplicationException {

        Element documentBody = document.select("html>body>div>div>table").get(0);

        Elements rows = documentBody.children().get(0).children();
        Element resumeBody = null;
        for (Element row : rows) {
            if (row.text().matches(".*手机.*邮箱.*")) {
                resumeBody = row;
                break;
            }
        }

        if (resumeBody != null) {
          Elements sections = resumeBody.select("table");
          // including name, company, title
          Element basicInfo2 = sections.get(0);
          if (basicInfo2 != null && basicInfo2.select("tr").size() > 0) {
            String nameGendorAge = basicInfo2.select("tr").get(0).text().replaceAll("（", "(").replaceAll("）", ")");
            String name = nameGendorAge.replaceAll("\\(.*\\)", "");
            candidateProfileVO.setFirstName(name.substring(1));
            //by default use the first letter as last name
            candidateProfileVO.setLastName(name.substring(0,1));
            
            String gendorAge = MappingUtil.matchSingle("\\(.*\\)", nameGendorAge);
            if (gendorAge.indexOf("男") >= 0) {
              candidateProfileVO.setGender("Male");
            } else {
              candidateProfileVO.setGender("Female");
            }
            
            String currentStatus = basicInfo2.select("tr").get(1).text();
            String statuses[] = currentStatus.split("·");
            for (String sts : statuses) {
              if (sts.indexOf("现居") >= 0) {
                String residence = sts.trim().replace("现居", "");
                candidateProfileVO.setResidence(residence);
              }
            }
            
            String cellPhone = basicInfo2.select("tr").get(2).text();
            String phoneNum = MappingUtil.matchSingle("(\\d+)", cellPhone);
            candidateProfileVO.setCellPhone(phoneNum);
            
            String email = basicInfo2.select("tr").get(3).text();
            email = email.replace("邮箱：", "");
            candidateProfileVO.setContactEmail(email);
            candidateProfileVO.setPrimaryEmail(email);
          }
        }

        candidateProfileVO.setMarriage("N");
        candidateProfileVO.setCurrency("CNY");
        candidateProfileVO.setCountry("CN");
        return candidateProfileVO;
    }

    @Override
    public CandidateProfileVO parseBackgroundWorkExp(CandidateProfileVO candidateProfileVO, Document document)
            throws ServiceApplicationException {

        Element documentBody = document.select("html>body>div>div>table").get(0);

        Elements rows = documentBody.children().get(0).children();
        Element resumeBody = null;
        for (Element row : rows) {
            if (row.text().matches(".*手机.*邮箱.*")) {
                resumeBody = row.select("table").get(1);
            }
        }

        Elements elements = this.findElementsByHeader("工作经历", resumeBody);
        if (elements != null && elements.size() > 0) {
            List<CandidateBgWorkExprVO> workExprs = new ArrayList<CandidateBgWorkExprVO>();
            for (Element el : elements) {
              
                if(!el.text().matches("\\d{4}-\\d{1,2}.*")){
                  continue;
                }
                CandidateBgWorkExprVO bgWorkExprVO = new CandidateBgWorkExprVO();
                String startEndDateRaw = el.child(0).text().trim();
                String[] split = startEndDateRaw.split("至");
                String startDate = split[0].trim();
                bgWorkExprVO.setStartDate(this.formateDate(startDate));
                String endDate = split[1].trim();
                bgWorkExprVO.setEndDate(this.formateDate(endDate));
                if ("今".equals(endDate)) {
                    bgWorkExprVO.setIsPresent(true);
                }

                // parse jobtitle and employer
                Element expr1 = el.child(1).select("tr").get(0);
                String jobTitleAndCompany = expr1.text();
                jobTitleAndCompany = jobTitleAndCompany.substring(0, jobTitleAndCompany.lastIndexOf("（")).replaceAll(
                        "\\s+", SPACE);
                String jobTitle = MappingUtil.matchSingle("\\A(\\S+)\\s*\\u00A0{2}", jobTitleAndCompany);
                String employer = jobTitleAndCompany.replace(jobTitle, "");

                // remove the chinese space ascii 160
                jobTitle = jobTitle.replaceAll("\\u00A0", "");

                bgWorkExprVO.setEmployer(employer);
                bgWorkExprVO.setJobTitle(jobTitle);

                if ("今".equals(endDate)) {
                    bgWorkExprVO.setPresentEmployer(employer);
                }

                // parse department
                if(el.child(1).select("tr").size() > 1){
                    Element depart = el.child(1).select("tr").get(1);
                    String[] parts = depart.text().split("丨");
                    for (String part : parts) {
                        if(part.indexOf("所在部门") >= 0){
                            String department = part.replaceAll("所在部门：", "");
                            bgWorkExprVO.setDepartment(department);
                        }
                        if(part.indexOf("薪水") >= 0){
                            String salaryMonth = MappingUtil.matchSingle("\\d+", part);
                            bgWorkExprVO.setSalary(salaryMonth);
                            bgWorkExprVO.setSalaryEnd(salaryMonth);
                        }
                    }
                }
                
                //parse description
                if(el.child(1).select("tr").size() > 2){
                    Element description = el.child(1).select("tr").get(2);
                    bgWorkExprVO.setDescription(description.text());
                }
                
                workExprs.add(bgWorkExprVO);
            }
            candidateProfileVO.setWorkExprs(workExprs);
        }
        return candidateProfileVO;
    }

    @Override
    public CandidateProfileVO parseBackgroundEducation(CandidateProfileVO candidateProfileVO, Document document)
            throws ServiceApplicationException {

        Element documentBody = document.select("html>body>div>div>table").get(0);

        Elements rows = documentBody.children().get(0).children();
        Element resumeBody = null;
        for (Element row : rows) {
            if (row.text().matches(".*手机.*邮箱.*")) {
                resumeBody = row.select("table").get(1);
            }
        }

        Elements elements = this.findElementsByHeader("教育经历", resumeBody);
        if (elements != null && elements.size() > 0) {
            List<CandidateBgEducationVO> eduList = new ArrayList<CandidateBgEducationVO>();
            for (Element el : elements) {
              
              if(!el.text().matches("\\d{4}-\\d{1,2}.*")){
                continue;
              }

                CandidateBgEducationVO eduVO = new CandidateBgEducationVO();
                String startEndDateRaw = el.child(0).text().trim();
                String[] split = startEndDateRaw.split("至");
                String startDate = split[0].trim();
                eduVO.setStartDate(this.formateDate(startDate));

                String endDate = split[1].trim();
                eduVO.setEndDate(this.formateDate(endDate));

                // parse school title
                Element school = el.child(1).select("tr").get(0);
                String major = MappingUtil.matchSingle("\\A(\\S+)\\s*\\u00A0{2}", school.text().trim());
                String university = school.text().trim().replace(major, "");

                // remove the chinese space ascii 160
                major = major.replaceAll("\\u00A0", "").trim();
                eduVO.setMajor(major);
                eduVO.setSchool(university);

                // parse degree
                Element degree = el.child(1).select("tr").get(1);
                eduVO.setDegree(degree.text());

                eduList.add(eduVO);
            }
            candidateProfileVO.setEducation(eduList);
        }

        return candidateProfileVO;
    }

    @Override
    public CandidateProfileVO parseBackgroundLanguage(CandidateProfileVO candidateProfileVO, Document document)
            throws ServiceApplicationException {

        Element documentBody = document.select("html>body>div>div>table").get(0);
        
        Elements rows = documentBody.children().get(0).children();
        Element resumeBody = null;
        for (Element row : rows) {
            if (row.text().matches(".*手机.*邮箱.*")) {
                resumeBody = row.select("table").get(1);
            }
        }

        Elements elements = this.findElementsByHeader("语言能力", resumeBody);
        if (elements != null && elements.size() > 0) {
            List<CandidateBgLanguageVO> langList = new ArrayList<CandidateBgLanguageVO>();
            
            for (Element el : elements) {
                
               
                String title = el.select("table tr").get(0).text();
                if(!StringUtils.isEmpty(title)){
                    
                    CandidateBgLanguageVO langVO = new CandidateBgLanguageVO();
                    langVO.setName(title);
                    
                    //parse language proficiency
                    String profi = el.select("table tr").get(1).text();
                    String[] pros = profi.split("\\u00A0\\u00A0");
                    for (String pro : pros) {
                        if(pro.trim().indexOf("听说") >= 0){
                           String readingProf = pro.trim().replace("听说：", "");
                           langVO.setReadingProf(this.mapLanguageFluency(readingProf));
                           langVO.setSpeakingProf(this.mapLanguageFluency(readingProf));
                           
                        }else if(pro.trim().indexOf("读写") >= 0){
                           String writingProf = pro.trim().replace("读写：", "");
                           langVO.setWritingProf(this.mapLanguageFluency(writingProf));
                        }
                    }
                    
                    langList.add(langVO);
                }
                
            }
            
            candidateProfileVO.setLanguages(langList);
        }
        return candidateProfileVO;
    }

    @Override
    public CandidateProfileVO parseBackgroundCertificate(CandidateProfileVO candidateProfileVO, Document document)
            throws ServiceApplicationException {

        Element documentBody = document.select("html>body>div>div>table").get(0);

        Elements rows = documentBody.children().get(0).children();
        Element resumeBody = null;
        for (Element row : rows) {
            if (row.text().matches(".*手机.*邮箱.*")) {
                resumeBody = row.select("table").get(1);
            }
        }

        Elements elements = this.findElementsByHeader("证书", resumeBody);
        if(elements != null && elements.size() > 0){
            List<CandidateBgCertificateVO> certList = new ArrayList<CandidateBgCertificateVO>();
            for (Element el : elements) {
                String certTxt = el.select("table tr").get(0).text();
                String[] certs = certTxt.split("\\u00A0\\u00A0");
                for (String cert : certs) {
                    CandidateBgCertificateVO certVO = new CandidateBgCertificateVO();
                    certVO.setName(cert.trim());
                    certList.add(certVO);
                }
            }
            candidateProfileVO.setCertificates(certList);
        }
        
        return candidateProfileVO;
    }

    /**
     * 
     * @param headerTitle
     * @param source
     * @return
     */
    private Elements findElementsByHeader(String headerTitle, Element source) {
        Elements filterEls = new Elements();
        Elements trs = source.child(0).children();
        int startIndex = -1;
        for (int i = 0; i < trs.size(); i++) {
            Element el = trs.get(i);
            String content = el.text().trim();
            if (headerTitle.equals(content)) {
                startIndex = i;
            }
            if (startIndex != -1 && i >= startIndex && !HEAD_LINES.contains(content)) {
                if (!StringUtils.isEmpty(content)) {
                    filterEls.add(el);
                }
            }
            if (HEAD_LINES.contains(content) && !headerTitle.equals(content)) {
                startIndex = -1;
            }
        }
        return filterEls;
    }
    
    /**
     * 
     * @param strDate
     * @return
     */
    private String formateDate(String strDate){
        return CandidateDateUtil.formatDate(DAJE_DATE_FORMAT, DEFAULT_DATE_FORMAT, strDate);
    }
    
    private String mapLanguageFluency(String level){
        if("良好".equals(level) || "精通".equals(level)){
            return level;
        }else{
            return "一般";
        }
    }
    
}
