package com.sap.hcm.resume.collection.integration.controller;

import java.net.MalformedURLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;

import javax.persistence.PersistenceException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sap.hcm.resume.collection.bean.ActionType;
import com.sap.hcm.resume.collection.bean.CandidateProfileModel;
import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.bean.SimpleJsonResponse;
import com.sap.hcm.resume.collection.controller.ControllerBase;
import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.entity.DataModelMapping;
import com.sap.hcm.resume.collection.entity.view.UserCompanyMappingVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.bean.CandProfileDataModelMapping;
import com.sap.hcm.resume.collection.integration.bean.DataModelMappingItem;
import com.sap.hcm.resume.collection.integration.xml.DataModelMappingXMLConverter;
import com.sap.hcm.resume.collection.service.DataModelMappingService;
import com.sap.hcm.resume.collection.util.CandidateDataModelBuilder;
import com.sap.hcm.resume.collection.util.CandidateFileUtil;
import com.sap.hcm.resume.collection.util.ChangeLogUtil;
import com.sap.hcm.resume.collection.util.MappingUtil;
import com.sap.security.um.user.User;

/**
 * candidate profile data model controller
 * 
 * @author i065831
 */
@Controller
@RequestMapping("/dm")
public class CandidateDataModelController extends ControllerBase {

  private final Logger logger = LoggerFactory.getLogger(CandidateDataModelController.class);

  @Autowired
  private DataModelMappingService mappingService;

  @Autowired
  private Params params;

  @Autowired
  private ChangeLogUtil changeLogUtil;

  @RequestMapping(value = "/get", method = RequestMethod.GET)
  public @ResponseBody CandidateProfileModel getCandidateDataModel() {

    // check login
    CandidateProfileModel model = CandidateDataModelBuilder.getInstance().build();
    return model;
  }

  @RequestMapping(value = "/save", method = RequestMethod.POST)
  public @ResponseBody SimpleJsonResponse saveDataModelMapping(HttpServletRequest request,
      @RequestBody UserCompanyMappingVO sysMapping) throws ServiceApplicationException {

    // validate picklist option mapping
    try {
      sysMapping.getMapping().converFromPkOptionMappingStringtoBean();
    } catch (Exception e) {
      throw new ServiceApplicationException("Invalid picklist option mapping template");
    }

    User user = hcpUserProvider.getLoginUser(request);
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    ActionType actionType = null;
    String content = null;
    if (sysMapping.getId() == null) {
      actionType = ActionType.ADD;
      content = "add candidate profile mapping";
    } else {
      actionType = ActionType.EDT;
      content = "edit candidate profile mapping";
    }
    String companyId = params.getCompanyId();
    String mappingId = null;
    try {
      mappingId = mappingService.saveDataModelMapping(user == null ? null : user.getName(), sysMapping, companyId)
          .getMappingId().toString();
      rsp.setCode(0);
      rsp.setMessage("success");
      try {
        changeLogUtil.saveCompanyChangeHistory(actionType, user.getName(), content, companyId,
            sysMapping.getMappingName(), mappingId);
      } catch (ServiceApplicationException e) {
        logger.error("save candidate profile mapping edit/add history " + e.getMessage());
      }
    } catch (PersistenceException e) {
      rsp.setCode(-1);
      rsp.setMessage("failed");
      logger.error("save candidate data model mapping with error" + e.getMessage());
    }
    CompanyInfo info = compInfoService.getCompanyInfo(companyId);
    if (!StringUtils.isEmpty(mappingId) && mappingId.equals(String.valueOf(info.getDmMappingId()))) {
      mappingService.renewCandidateProfilePicklistCache();
    }
    return rsp;
  }

  @RequestMapping(value = "/new", method = RequestMethod.GET)
  public @ResponseBody CandProfileDataModelMapping newDataModelMapping() {
    return mappingService.createEmptyMapping();
  }

  @RequestMapping(value = "/{mappingId}", method = RequestMethod.GET)
  public @ResponseBody CandProfileDataModelMapping getDataModelMappingById(
      @PathVariable(value = "mappingId") Long mappingId) throws ServiceApplicationException {

    DataModelMapping mapping = mappingService.getMappingById(mappingId);
    if (mapping != null) {
      CandProfileDataModelMapping dbMapping = DataModelMappingXMLConverter.fromXML(mapping.toXML());
      CandProfileDataModelMapping empMapping = mappingService.createEmptyMapping();
      this.updateDataMappingChange(dbMapping, empMapping);
      return dbMapping;
    }
    return null;
  }

  @RequestMapping(value = "active/{mappingId}", method = RequestMethod.GET)
  public @ResponseBody SimpleJsonResponse activeMapping(HttpServletRequest request,
      @PathVariable(value = "mappingId") Long mappingId) throws ServiceApplicationException {
    SimpleJsonResponse rsp = new SimpleJsonResponse();

    String companyId = params.getCompanyId();

    CompanyInfo info = compInfoService.getCompanyInfo(companyId);
    info.setDmMappingId(mappingId);
    compInfoService.saveCompanyInfo(info);
    
    mappingService.renewCandidateProfilePicklistCache();

    rsp.setCode(0);
    rsp.setMessage("success");
    return rsp;
  }

  private int getNewMaximuSeq(SortedSet<DataModelMappingItem> itemSet) {
    return itemSet.last().getSeq() + 1;
  }

  /**
   * update data model mapping to reflect the change
   * 
   * @param dbMapping
   * @param empMapping
   */
  private void updateDataMappingChange(CandProfileDataModelMapping dbMapping, CandProfileDataModelMapping empMapping) {
    SortedSet<DataModelMappingItem> profileItems = empMapping.getProfile();
    for (DataModelMappingItem itm : profileItems) {
      if (dbMapping.getProfile().contains(itm)) {
        continue;
      } else {
        itm.setSeq(this.getNewMaximuSeq(dbMapping.getProfile()));
        dbMapping.getProfile().add(itm);
      }
    }

    SortedSet<DataModelMappingItem> workExpr = empMapping.getWorkExprs();
    for (DataModelMappingItem itm : workExpr) {
      if (dbMapping.getWorkExprs().contains(itm)) {
        continue;
      } else {
        itm.setSeq(this.getNewMaximuSeq(dbMapping.getWorkExprs()));
        dbMapping.getWorkExprs().add(itm);
      }
    }

    SortedSet<DataModelMappingItem> education = empMapping.getEducation();
    for (DataModelMappingItem itm : education) {
      if (dbMapping.getEducation().contains(itm)) {
        continue;
      } else {
        itm.setSeq(this.getNewMaximuSeq(dbMapping.getEducation()));
        dbMapping.getEducation().add(itm);
      }
    }

    SortedSet<DataModelMappingItem> certs = empMapping.getCertificates();
    for (DataModelMappingItem itm : certs) {
      if (dbMapping.getCertificates().contains(itm)) {
        continue;
      } else {
        itm.setSeq(this.getNewMaximuSeq(dbMapping.getCertificates()));
        dbMapping.getCertificates().add(itm);
      }
    }

    Set<DataModelMappingItem> langs = empMapping.getLanguages();
    for (DataModelMappingItem itm : langs) {
      if (dbMapping.getLanguages().contains(itm)) {
        continue;
      } else {
        itm.setSeq(this.getNewMaximuSeq(dbMapping.getLanguages()));
        dbMapping.getLanguages().add(itm);
      }
    }

    Set<DataModelMappingItem> families = empMapping.getFamilies();
    for (DataModelMappingItem itm : families) {
      if (dbMapping.getFamilies().contains(itm)) {
        continue;
      } else {
        itm.setSeq(this.getNewMaximuSeq(dbMapping.getFamilies()));
        dbMapping.getFamilies().add(itm);
      }
    }
  }

  @RequestMapping(value = "/list", method = RequestMethod.GET)
  public @ResponseBody Map<String, Object> getDataModelMappingList(HttpServletRequest request,
      @RequestParam(value = "skip", defaultValue = "0", required = false) int skip,
      @RequestParam(value = "top", defaultValue = "10", required = false) int top) throws ServiceApplicationException {
    String companyId = params.getCompanyId();
    Map<String, Object> containerMap = new HashMap<String, Object>();
    List<DataModelMapping> mList = mappingService.getMappingList(skip, top, companyId);

    CompanyInfo compInfo = this.compInfoService.getCompanyInfo(companyId);
    containerMap.put("entries", mList);
    containerMap.put("active", compInfo.getDmMappingId());
    return containerMap;
  }

  @RequestMapping(value = "/list/{mappingId}", method = RequestMethod.GET)
  public @ResponseBody DataModelMapping getListEntry(HttpServletRequest request,
      @PathVariable(value = "mappingId") Long mappingId) throws ServiceApplicationException {
    String companyId = params.getCompanyId();
    if (StringUtils.isEmpty(companyId)) {
      throw new ServiceApplicationException("session is expired");
    }
    DataModelMapping userCompanySimpleMappingVO = null;
    userCompanySimpleMappingVO = mappingService.getMappingListDetail(mappingId, companyId);
    return userCompanySimpleMappingVO;
  }

  @RequestMapping(value = "/delete/{mappingId}", method = RequestMethod.DELETE)
  public @ResponseBody SimpleJsonResponse deleteMappingById(HttpServletRequest request,
      @PathVariable(value = "mappingId") Long mappingId) throws ServiceApplicationException {
    String mappingName = mappingService.getMappingById(mappingId).getMappingName();
    int res = mappingService.deleteMappingById(mappingId);
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    if (res < 0) {
      rsp.setCode(-1);
      rsp.setMessage("failed");
    } else {
      rsp.setCode(0);
      rsp.setMessage("success");
      String companyId = params.getCompanyId();
      CompanyInfo info = compInfoService.getCompanyInfo(companyId);
      if (info.getDmMappingId() != null && mappingId.equals(info.getDmMappingId())) {
        // delete active mapping
        info.setDmMappingId(null);
        compInfoService.saveCompanyInfo(info);
      }
      try {
        changeLogUtil.saveCompanyChangeHistory(ActionType.DEL, hcpUserProvider.getLoginUser(request).getName(),
            "delete candidate profile", params.getCompanyId(), mappingName, mappingId.toString());
      } catch (ServiceApplicationException e) {
        logger.error("save candidate profile mapping delete history " + e.getMessage());
      }
    }
    return rsp;
  }

  @RequestMapping(value = "/export/{mappingId}", method = RequestMethod.GET)
  public ResponseEntity<byte[]> exportMappingById(@PathVariable(value = "mappingId") Long mappingId,
      HttpServletResponse response) throws ServiceApplicationException {
    DataModelMapping mapping = mappingService.getMappingById(mappingId);
    byte[] mappingContent = mapping.getMappingContent();
    if (mappingContent != null) {

      HttpHeaders headers = new HttpHeaders();
      headers.setContentType(MediaType.APPLICATION_XML);
      headers.setContentDispositionFormData("attachment", "profile_model_mapping.xml");

      return new ResponseEntity<byte[]>(mappingContent, headers, HttpStatus.OK);
    } else {
      throw new ServiceApplicationException("file content is empty");
    }
  }

  /**
   * upload the mapping config
   * 
   * @param request
   * @param response
   * @return
   * @throws ServiceApplicationException
   */
  @RequestMapping(value = "/import", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
  public @ResponseBody String importMapping(HttpServletRequest request, HttpServletResponse response)
      throws ServiceApplicationException {

    String mappingTxt = "";
    List<FileItem> items = CandidateFileUtil.handleFileUploadRequest(request);
    if (items != null && items.size() > 0) {
      for (FileItem item : items) {
        String filename = item.getName();
        String regex = ".*\\.xml";
        // check the file is xml file
        if (filename != null && !StringUtils.isEmpty(MappingUtil.matchSingle(regex, filename))) {
          try {
            CandProfileDataModelMapping mapping = DataModelMappingXMLConverter.fromByte(item.get());
            ObjectMapper om = new ObjectMapper();
            mappingTxt = om.writeValueAsString(mapping);
          } catch (Exception e) {
            logger.error("process upload file failed: " + e.getMessage());
            throw new ServiceApplicationException("process upload file failed");
          }
        }
      }
    }
    return mappingTxt;
  }

  @RequestMapping(value = "/renewPicklistCache")
  public @ResponseBody SimpleJsonResponse renewPicklistCache() throws ServiceApplicationException,
      MalformedURLException {
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp = mappingService.renewCandidateProfilePicklistCache();
    return rsp;

  }

}
