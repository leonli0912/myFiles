package com.sap.hcm.resume.collection.integration.sf.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedSet;
import java.util.TreeSet;

import javax.annotation.Resource;
import javax.persistence.EntityExistsException;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mockito;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;

import com.sap.hcm.resume.collection.context.TestContext;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.bean.ApplyDataModelMappingItem;
import com.sap.hcm.resume.collection.integration.bean.CandProfileDataModelMapping;
import com.sap.hcm.resume.collection.integration.bean.DataModelMappingItem;
import com.sap.hcm.resume.collection.integration.bean.JobReqDataModelMappingItem;
import com.sap.hcm.resume.collection.integration.sf.bean.SFPicklistCacheEntityType;
import com.sap.hcm.resume.collection.integration.sf.bean.SFPicklistItem;
import com.sap.hcm.resume.collection.integration.sf.entity.SFPicklistCache;
import com.sap.hcm.resume.collection.service.DataModelMappingService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { TestContext.class })
public class SFPicklistCacheServiceTest {

  @Resource(name = "entityManager")
  private EntityManager entityManager;

  private SFPicklistCacheService sFPicklistCacheService;

  @Resource(name = "dataModelMappingService")
  private DataModelMappingService dmMappingService;

  @Before
  public void setUp() {
    reset(entityManager);
    sFPicklistCacheService = new SFPicklistCacheService();
    ReflectionTestUtils.setField(sFPicklistCacheService, "entityManager", entityManager);
    ReflectionTestUtils.setField(sFPicklistCacheService, "dmMappingService", dmMappingService);
  }

  @Test
  public void testDeletePicklistCacheSuccess() throws ServiceApplicationException {
    Integer expect = new Integer(1);

    String companyId = "sap";
    String entityType = SFPicklistCacheEntityType.CANDIDATE.toString();
    String sel = "delete from SFPicklistCache pk where pk.companyId = :companyId and pk.entityType = :entityType";
    Query simpleQuery = Mockito.mock(Query.class);
    when(entityManager.createQuery(sel)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("companyId", companyId)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("entityType", entityType)).thenReturn(simpleQuery);
    when(simpleQuery.executeUpdate()).thenReturn(new Integer(2));

    Integer result = sFPicklistCacheService.deletePicklistCache(companyId, entityType);
    assertEquals(expect, result);
  }

  @Test
  public void testDeletePicklistCacheFailed() throws ServiceApplicationException {
    Integer expect = new Integer(-1);

    String companyId = "sap";
    String entityType = SFPicklistCacheEntityType.CANDIDATE.toString();
    String sel = "delete from SFPicklistCache pk where pk.companyId = :companyId and pk.entityType = :entityType";
    Query simpleQuery = Mockito.mock(Query.class);
    when(entityManager.createQuery(sel)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("companyId", companyId)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("entityType", entityType)).thenReturn(simpleQuery);
    when(simpleQuery.executeUpdate()).thenThrow(new PersistenceException());

    Integer result = sFPicklistCacheService.deletePicklistCache(companyId, entityType);
    assertEquals(expect, result);
  }

  @Test
  public void testDeletePicklistCacheByNameSuccess() throws ServiceApplicationException {
    Integer expect = new Integer(1);

    String companyId = "sap";
    String entityType = SFPicklistCacheEntityType.CANDIDATE.toString();
    String picklistName = "picklistName";

    String sel = "delete from SFPicklistCache pk where pk.companyId = :companyId and pk.pklName = :pklName and pk.entityType = :entityType";
    Query simpleQuery = Mockito.mock(Query.class);
    when(entityManager.createQuery(sel)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("companyId", companyId)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("picklistName", picklistName)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("entityType", entityType)).thenReturn(simpleQuery);
    when(simpleQuery.executeUpdate()).thenReturn(new Integer(2));

    Integer result = sFPicklistCacheService.deletePicklistCacheByName(companyId, picklistName, entityType);
    assertEquals(expect, result);
  }

  @Test
  public void testDeletePicklistCacheByNameFailed() throws ServiceApplicationException {
    Integer expect = new Integer(-1);

    String companyId = "sap";
    String picklistName = "picklistName";
    String entityType = SFPicklistCacheEntityType.CANDIDATE.toString();

    String sel = "delete from SFPicklistCache pk where pk.companyId = :companyId and pk.pklName = :pklName and pk.entityType = :entityType";
    Query simpleQuery = Mockito.mock(Query.class);
    when(entityManager.createQuery(sel)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("companyId", companyId)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("picklistName", picklistName)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("entityType", entityType)).thenReturn(simpleQuery);
    when(simpleQuery.executeUpdate()).thenThrow(new PersistenceException());

    Integer result = sFPicklistCacheService.deletePicklistCacheByName(companyId, picklistName, entityType);
    assertEquals(expect, result);
  }

  @Test
  public void testSavePickListCacheSuccess() throws ServiceApplicationException {
    Integer expect = new Integer(1);

    String companyId = "sap";
    String picklistName = "picklistName";
    String entityType = SFPicklistCacheEntityType.CANDIDATE.toString();

    List<SFPicklistItem> pkItems = new ArrayList<SFPicklistItem>();
    SFPicklistItem item = new SFPicklistItem();
    pkItems.add(item);
    SFPicklistCache cache = new SFPicklistCache();
    String sel = "delete from SFPicklistCache pk where pk.companyId = :companyId and pk.pklName = :pklName and pk.entityType = :entityType";
    Query simpleQuery = Mockito.mock(Query.class);
    when(entityManager.createQuery(sel)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("companyId", companyId)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("picklistName", picklistName)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("entityType", entityType)).thenReturn(simpleQuery);
    when(simpleQuery.executeUpdate()).thenReturn(new Integer(1));
    Mockito.doNothing().when(entityManager).persist(cache);

    Integer result = sFPicklistCacheService.savePickListCache(pkItems, picklistName, companyId, entityType);
    assertEquals(expect, result);
  }

  @Test
  public void testSavePickListCacheSuccessItemListIsEmpty() throws ServiceApplicationException {
    Integer expect = new Integer(1);

    String companyId = "sap";
    String picklistName = "picklistName";
    String entityType = SFPicklistCacheEntityType.CANDIDATE.toString();

    List<SFPicklistItem> pkItems = new ArrayList<SFPicklistItem>();
    String sel = "delete from SFPicklistCache pk where pk.companyId = :companyId and pk.pklName = :pklName and pk.entityType = :entityType";
    Query simpleQuery = Mockito.mock(Query.class);
    when(entityManager.createQuery(sel)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("companyId", companyId)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("picklistName", picklistName)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("entityType", entityType)).thenReturn(simpleQuery);
    when(simpleQuery.executeUpdate()).thenReturn(new Integer(1));

    Integer result = sFPicklistCacheService.savePickListCache(pkItems, picklistName, companyId, entityType);
    assertEquals(expect, result);
  }

  @Test
  public void testSavePickListCacheSuccessNoDataDeleted() throws ServiceApplicationException {
    Integer expect = new Integer(1);

    String companyId = "sap";
    String picklistName = "picklistName";
    String entityType = SFPicklistCacheEntityType.CANDIDATE.toString();

    List<SFPicklistItem> pkItems = new ArrayList<SFPicklistItem>();
    String sel = "delete from SFPicklistCache pk where pk.companyId = :companyId and pk.pklName = :pklName and pk.entityType = :entityType";
    Query simpleQuery = Mockito.mock(Query.class);
    when(entityManager.createQuery(sel)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("companyId", companyId)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("picklistName", picklistName)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("entityType", entityType)).thenReturn(simpleQuery);
    when(simpleQuery.executeUpdate()).thenThrow(new PersistenceException());

    Integer result = sFPicklistCacheService.savePickListCache(pkItems, picklistName, companyId, entityType);
    assertEquals(expect, result);
  }

  @Test
  public void testSavePickListCacheSuccessParamIsNull() throws ServiceApplicationException {
    Integer expect = new Integer(1);

    String companyId = "sap";
    String picklistName = "picklistName";
    String entityType = SFPicklistCacheEntityType.CANDIDATE.toString();

    Integer result = sFPicklistCacheService.savePickListCache(null, picklistName, companyId, entityType);
    assertEquals(expect, result);
  }

  @Test
  public void testSavePickListCacheFailed() throws ServiceApplicationException {
    Integer expect = new Integer(-1);

    String companyId = "sap";
    String picklistName = "picklistName";
    String entityType = SFPicklistCacheEntityType.CANDIDATE.toString();

    List<SFPicklistItem> pkItems = new ArrayList<SFPicklistItem>();
    SFPicklistItem item = new SFPicklistItem();
    pkItems.add(item);
    String sel = "delete from SFPicklistCache pk where pk.companyId = :companyId and pk.pklName = :pklName and pk.entityType = :entityType";
    Query simpleQuery = Mockito.mock(Query.class);
    when(entityManager.createQuery(sel)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("companyId", companyId)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("picklistName", picklistName)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("entityType", entityType)).thenReturn(simpleQuery);
    when(simpleQuery.executeUpdate()).thenReturn(new Integer(1));
    Mockito.doThrow(new EntityExistsException()).when(entityManager).persist(Matchers.any());

    Integer result = sFPicklistCacheService.savePickListCache(pkItems, picklistName, companyId, entityType);
    assertEquals(expect, result);
  }

  @SuppressWarnings("unchecked")
  @Test
  public void testGetPicklistOptionsByNameSuccess() throws ServiceApplicationException {
    List<SFPicklistItem> expect = new ArrayList<SFPicklistItem>();
    SFPicklistItem item = new SFPicklistItem();
    item.setLabel("pickListLabel");
    expect.add(item);

    String companyId = "sap";
    String pklName = "pklName";
    String locale = "CN";
    List<SFPicklistCache> cacheList = new ArrayList<SFPicklistCache>();
    SFPicklistCache cache = new SFPicklistCache();
    cache.setPklLabel("pickListLabel");
    cacheList.add(cache);

    String entityType = SFPicklistCacheEntityType.CANDIDATE.toString();

    String sel = "select pk from SFPicklistCache pk where pk.companyId = :companyId and pk.entityType = :entityType and pk.pklName = :pklName and pk.locale = :locale";
    TypedQuery<SFPicklistCache> typeQuery = (TypedQuery<SFPicklistCache>) Mockito.mock(TypedQuery.class);
    when(entityManager.createQuery(sel, SFPicklistCache.class)).thenReturn(typeQuery);
    when(typeQuery.setParameter("companyId", companyId)).thenReturn(typeQuery);
    when(typeQuery.setParameter("pklName", pklName)).thenReturn(typeQuery);
    when(typeQuery.setParameter("locale", locale)).thenReturn(typeQuery);
    when(typeQuery.setParameter("entityType", entityType)).thenReturn(typeQuery);
    when(typeQuery.getResultList()).thenReturn(cacheList);

    List<SFPicklistItem> result = sFPicklistCacheService.getPicklistOptionsByName(companyId, pklName, locale,
        entityType);
    assertEquals(expect.get(0).getLabel(), result.get(0).getLabel());
  }

  @SuppressWarnings("unchecked")
  @Test
  public void testGetPicklistOptionsByNameSuccessParamIsAllEmpty() throws ServiceApplicationException {
    List<SFPicklistItem> expect = new ArrayList<SFPicklistItem>();

    String companyId = "";
    String pklName = "";
    String locale = "";
    String entityType = SFPicklistCacheEntityType.CANDIDATE.toString();

    List<SFPicklistCache> cacheList = new ArrayList<SFPicklistCache>();
    String sel = "select pk from SFPicklistCache pk where pk.companyId = :companyId and pk.entityType = :entityType";
    TypedQuery<SFPicklistCache> typeQuery = (TypedQuery<SFPicklistCache>) Mockito.mock(TypedQuery.class);
    when(entityManager.createQuery(sel, SFPicklistCache.class)).thenReturn(typeQuery);
    when(typeQuery.setParameter("companyId", companyId)).thenReturn(typeQuery);
    when(typeQuery.setParameter("pklName", pklName)).thenReturn(typeQuery);
    when(typeQuery.setParameter("locale", locale)).thenReturn(typeQuery);
    when(typeQuery.setParameter("entityType", entityType)).thenReturn(typeQuery);
    when(typeQuery.getResultList()).thenReturn(cacheList);

    List<SFPicklistItem> result = sFPicklistCacheService.getPicklistOptionsByName(companyId, pklName, locale,
        entityType);
    assertEquals(expect, result);
  }

  @SuppressWarnings("unchecked")
  @Test
  public void testGetPicklistOptionsByNameSuccessQueryResultIsNull() throws ServiceApplicationException {
    List<SFPicklistItem> expect = new ArrayList<SFPicklistItem>();

    String companyId = "";
    String pklName = "";
    String locale = "";
    String entityType = SFPicklistCacheEntityType.CANDIDATE.toString();

    String sel = "select pk from SFPicklistCache pk where pk.companyId = :companyId and pk.entityType = :entityType";
    TypedQuery<SFPicklistCache> typeQuery = (TypedQuery<SFPicklistCache>) Mockito.mock(TypedQuery.class);
    when(entityManager.createQuery(sel, SFPicklistCache.class)).thenReturn(typeQuery);
    when(typeQuery.setParameter("companyId", companyId)).thenReturn(typeQuery);
    when(typeQuery.setParameter("pklName", pklName)).thenReturn(typeQuery);
    when(typeQuery.setParameter("locale", locale)).thenReturn(typeQuery);
    when(typeQuery.setParameter("entityType", entityType)).thenReturn(typeQuery);
    when(typeQuery.getResultList()).thenReturn(null);

    List<SFPicklistItem> result = sFPicklistCacheService.getPicklistOptionsByName(companyId, pklName, locale,
        entityType);
    assertEquals(expect, result);
  }

  @SuppressWarnings("unchecked")
  @Test
  public void testGetPicklistOptionsSuccess() throws ServiceApplicationException {
    Map<String, List<SFPicklistItem>> expect = new HashMap<String, List<SFPicklistItem>>();
    List<SFPicklistItem> list = new ArrayList<SFPicklistItem>();
    SFPicklistItem pickListItem = new SFPicklistItem();
    pickListItem.setLabel("pickListLabel");
    list.add(pickListItem);
    expect.put("city", list);

    String companyId = "sap";
    String pklName = "pklName";
    String locale = "CN";
    Set<JobReqDataModelMappingItem> items = new HashSet<JobReqDataModelMappingItem>();
    JobReqDataModelMappingItem item = new JobReqDataModelMappingItem();
    item.setPicklist("city");
    item.setSourceField("city");
    items.add(item);
    List<SFPicklistCache> cacheList = new ArrayList<SFPicklistCache>();
    SFPicklistCache cache = new SFPicklistCache();
    cache.setPklLabel("pickListLabel");
    cacheList.add(cache);
    when(dmMappingService.getPicklistForJobRequisition(companyId, false)).thenReturn(items);

    String entityType = SFPicklistCacheEntityType.CANDIDATE.toString();
    String sel = "select pk from SFPicklistCache pk where pk.companyId = :companyId and pk.entityType = :entityType and pk.pklName = :pklName and pk.locale = :locale";
    TypedQuery<SFPicklistCache> typeQuery = (TypedQuery<SFPicklistCache>) Mockito.mock(TypedQuery.class);
    when(entityManager.createQuery(sel, SFPicklistCache.class)).thenReturn(typeQuery);
    when(typeQuery.setParameter("companyId", companyId)).thenReturn(typeQuery);
    when(typeQuery.setParameter("pklName", pklName)).thenReturn(typeQuery);
    when(typeQuery.setParameter("locale", locale)).thenReturn(typeQuery);
    when(typeQuery.setParameter("entityType", entityType)).thenReturn(typeQuery);
    when(typeQuery.getResultList()).thenReturn(cacheList);

    Map<String, List<SFPicklistItem>> result = sFPicklistCacheService.getPicklistOptions(companyId, locale, entityType);
    assertEquals(expect.get("city").get(0).getLabel(), result.get("city").get(0).getLabel());
  }

  @Test
  public void testGetPicklistOptionsSuccessJobReqDataModelMappingItemIsNull() throws ServiceApplicationException {
    Map<String, List<SFPicklistItem>> expect = new HashMap<String, List<SFPicklistItem>>();

    String companyId = "sap";
    String locale = "CN";
    String entityType = SFPicklistCacheEntityType.CANDIDATE.toString();
    when(dmMappingService.getPicklistForJobRequisition(companyId, false)).thenReturn(null);

    Map<String, List<SFPicklistItem>> result = sFPicklistCacheService.getPicklistOptions(companyId, locale, entityType);
    assertEquals(expect, result);
  }

  @Test
  public void testGetPicklistOptionsSuccessJobReqDataModelMappingItemIsEmpty() throws ServiceApplicationException {
    Map<String, List<SFPicklistItem>> expect = new HashMap<String, List<SFPicklistItem>>();

    String companyId = "sap";
    String locale = "CN";
    String entityType = SFPicklistCacheEntityType.CANDIDATE.toString();
    Set<JobReqDataModelMappingItem> items = new HashSet<JobReqDataModelMappingItem>();
    when(dmMappingService.getPicklistForJobRequisition(companyId, false)).thenReturn(items);

    Map<String, List<SFPicklistItem>> result = sFPicklistCacheService.getPicklistOptions(companyId, locale, entityType);
    assertEquals(expect, result);
  }

  @Test
  public void testGetPKLLabelByOptionIdSuccess() throws ServiceApplicationException {
    String expect = "city";

    String companyId = "sap";
    String pklName = "pklName";
    Long optionId = new Long(1);
    String locale = "CN";
    SFPicklistCache plc = new SFPicklistCache();
    plc.setPklLabel("city");
    String sel = "select pk from SFPicklistCache pk where pk.companyId = :companyId and pk.pklOptionId = :optionId and pk.locale = :locale and pk.pklName = :pklName and pk.entityType = :entityType";
    Query simpleQuery = Mockito.mock(Query.class);
    when(entityManager.createQuery(sel)).thenReturn(simpleQuery);
    String entityType = SFPicklistCacheEntityType.CANDIDATE.toString();
    when(simpleQuery.setParameter("companyId", companyId)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("optionId", optionId)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("locale", locale)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("pklName", pklName)).thenReturn(simpleQuery);
    when(simpleQuery.getSingleResult()).thenReturn(plc);

    String result = sFPicklistCacheService.getPKLLabelByOptionId(pklName, companyId, optionId, locale, entityType);
    assertEquals(expect, result);
  }

  @Test
  public void testGetPicklistLocales() {
    String companyId = "SAP";
    String entityType = "abc";
    String sql = "select distinct pk.locale from SFPicklistCache pk where pk.companyId = :companyId and pk.entityType = :entityType";
    Query simpleQuery = Mockito.mock(Query.class);
    when(entityManager.createQuery(sql)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("companyId", companyId)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("entityType", entityType)).thenReturn(simpleQuery);
    List<String> resultList = new ArrayList<String>();
    resultList.add("cn");
    when(simpleQuery.getResultList()).thenReturn(resultList);
    List<String> list = sFPicklistCacheService.getPicklistLocales(companyId, entityType);
    assertEquals(resultList.get(0), list.get(0));
  }

  @Test
  public void testGetJobApplPicklistOptions() throws ServiceApplicationException {
    String companyId = "sap";
    String locale = "cn";
    String entityType = "abc";
    String picklist = "efg";
    Set<ApplyDataModelMappingItem> items = new HashSet<ApplyDataModelMappingItem>();
    ApplyDataModelMappingItem applyDataModelMappingItem = new ApplyDataModelMappingItem();
    applyDataModelMappingItem.setPicklist(picklist);
    items.add(applyDataModelMappingItem);
    List<SFPicklistItem> pkItemList = new ArrayList<SFPicklistItem>();
    SFPicklistItem sfPicklistItem = new SFPicklistItem();
    pkItemList.add(sfPicklistItem);
    when(dmMappingService.getPicklistForJobApplication(companyId)).thenReturn(items);
    // when(
    // sFPicklistCacheService.getPicklistOptionsByName(companyId, items.iterator().next().getPicklist(), locale,
    // entityType)).thenReturn(pkItemList);

    String sel = "select pk from SFPicklistCache pk where pk.companyId = :companyId and pk.entityType = :entityType and pk.pklName = :pklName and pk.locale = :locale";
    TypedQuery<SFPicklistCache> typeQuery = (TypedQuery<SFPicklistCache>) Mockito.mock(TypedQuery.class);
    when(entityManager.createQuery(sel, SFPicklistCache.class)).thenReturn(typeQuery);
    when(typeQuery.setParameter("companyId", companyId)).thenReturn(typeQuery);
    when(typeQuery.setParameter("pklName", items.iterator().next().getPicklist())).thenReturn(typeQuery);
    when(typeQuery.setParameter("locale", locale)).thenReturn(typeQuery);
    when(typeQuery.setParameter("entityType", entityType)).thenReturn(typeQuery);

    List<SFPicklistCache> cacheList = new ArrayList<SFPicklistCache>();
    SFPicklistCache cache = new SFPicklistCache();
    cache.setPklLabel("pickListLabel");
    cacheList.add(cache);

    when(typeQuery.getResultList()).thenReturn(cacheList);

    Map<String, List<SFPicklistItem>> picklistMap = sFPicklistCacheService.getJobApplPicklistOptions(companyId, locale,
        entityType);
  }

  @Test
  public void testGetCandidatePicklistOptions() throws ServiceApplicationException {
    String companyId = "sap";
    String locale = "cn";
    String entityType = "abc";
    Long mappingId = 123L;
    String picklist = "efg";

    CandProfileDataModelMapping candMapping = new CandProfileDataModelMapping();
    SortedSet<DataModelMappingItem> profile = new TreeSet<DataModelMappingItem>();
    SortedSet<DataModelMappingItem> workExprs = new TreeSet<DataModelMappingItem>();
    SortedSet<DataModelMappingItem> education = new TreeSet<DataModelMappingItem>();
    SortedSet<DataModelMappingItem> languages = new TreeSet<DataModelMappingItem>();
    SortedSet<DataModelMappingItem> certificates = new TreeSet<DataModelMappingItem>();
    SortedSet<DataModelMappingItem> families = new TreeSet<DataModelMappingItem>();

    DataModelMappingItem dmmi = new DataModelMappingItem();
    dmmi.setPicklist(picklist);

    profile.add(dmmi);
    workExprs.add(dmmi);
    education.add(dmmi);
    languages.add(dmmi);
    certificates.add(dmmi);
    families.add(dmmi);

    candMapping.setProfile(profile);
    candMapping.setWorkExprs(workExprs);
    candMapping.setEducation(education);
    candMapping.setLanguages(languages);
    candMapping.setCertificates(certificates);
    candMapping.setFamilies(families);

    when(dmMappingService.getCandidateProfileDataModelMappingById(mappingId)).thenReturn(candMapping);

    String sel = "select pk from SFPicklistCache pk where pk.companyId = :companyId and pk.entityType = :entityType and pk.pklName = :pklName and pk.locale = :locale";
    TypedQuery<SFPicklistCache> typeQuery = (TypedQuery<SFPicklistCache>) Mockito.mock(TypedQuery.class);
    when(entityManager.createQuery(sel, SFPicklistCache.class)).thenReturn(typeQuery);
    when(typeQuery.setParameter("companyId", companyId)).thenReturn(typeQuery);
    when(typeQuery.setParameter("pklName", picklist)).thenReturn(typeQuery);
    when(typeQuery.setParameter("locale", locale)).thenReturn(typeQuery);
    when(typeQuery.setParameter("entityType", entityType)).thenReturn(typeQuery);

    List<SFPicklistCache> cacheList = new ArrayList<SFPicklistCache>();
    SFPicklistCache cache = new SFPicklistCache();
    cache.setPklLabel("pickListLabel");
    cacheList.add(cache);

    when(typeQuery.getResultList()).thenReturn(cacheList);

    Map<String, List<SFPicklistItem>> picklistMap = sFPicklistCacheService.getCandidatePicklistOptions(companyId,
        mappingId, locale, entityType);
  }
}
