package com.sap.hcm.resume.collection.integration.service;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sap.hcm.resume.collection.bean.BusinessEntityType;
import com.sap.hcm.resume.collection.entity.DataModelMapping;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;

/**
 * @author I075908 SAP
 */
@Service(value="candidateIntegrationServiceProxy")
public class CandidateIntegrationServiceProxy implements CandidateIntegrationService {

  @Autowired
  IntegrationServiceFactoryManager factoryManager;

  private CandidateIntegrationService integrationService;

  @PostConstruct
  private void init() {
    IntegrationServiceFactory factory = factoryManager.getFactory();
    integrationService = (CandidateIntegrationService) factory.create(BusinessEntityType.CANDIDATE);
  }

  public Long getCandidateId(String key) throws ServiceApplicationException {
    return integrationService.getCandidateId(key);
  }

  @Override
  public CandidateProfileVO insertCandidate(CandidateProfileVO candidateProfileVO, DataModelMapping mapping)
      throws ServiceApplicationException {
    return integrationService.insertCandidate(candidateProfileVO,mapping);
  }
}
