package com.sap.hcm.resume.collection.entity.view;

/**
 * candidate background type Enum This Enum type will be stored in the
 * CandidateBackground Table
 * 
 * @author i065831
 *
 */
public enum CandidateBgTypeEnum {

	WORK_EXPR, EDUCATION, LANGUAGE, CERTIFICATE, FAMILY;

}
