package com.sap.hcm.resume.collection.integration.zhilian;

import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.jsoup.nodes.Document;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.context.MessageSource;
import org.springframework.core.io.ClassPathResource;

import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.util.CandidateFileUtil;

/**
 * @author I324117 SAP
 */
public class EnglishDocumentParserZLTest {

  @Test
  public void testParseProfile() throws ServiceApplicationException, IOException {
    MessageSource ms = Mockito.mock(MessageSource.class);

    // Mockito.when(ms.getMessage(Mockito.anyString(), Mockito.any(Object[].class), Mockito.any(Locale.class)))
    // .thenReturn("test");
    ClassPathResource resume = new ClassPathResource("resumes/parser/zhilian_DOC_Parser_EN_1.htm");

    EnglishDocumentParserZL parser = new EnglishDocumentParserZL(ms);
    CandidateProfileVO profileVO = new CandidateProfileVO();
    InputStream is = null;
    try {
      is = resume.getInputStream();

      Document resumeContent = CandidateFileUtil.getFileContentFromHtml(IOUtils.toByteArray(is));
      profileVO = parser.parseProfile(profileVO, resumeContent);
      profileVO = parser.parseBackgroundWorkExp(profileVO, resumeContent);
      profileVO = parser.parseBackgroundCertificate(profileVO, resumeContent);
      profileVO = parser.parseBackgroundEducation(profileVO, resumeContent);
      profileVO = parser.parseBackgroundLanguage(profileVO, resumeContent);

      Assert.assertEquals(profileVO.getCellPhone(), "12345678987");
      Assert.assertEquals(profileVO.getWorkExprs().get(0).getEmployer(), "SAP");
      Assert.assertEquals(profileVO.getEducation().size(), 1);
      Assert.assertEquals(profileVO.getLanguages().size(), 2);
    } catch (IOException e) {
    } finally {
      IOUtils.closeQuietly(is);
    }
  }
}
