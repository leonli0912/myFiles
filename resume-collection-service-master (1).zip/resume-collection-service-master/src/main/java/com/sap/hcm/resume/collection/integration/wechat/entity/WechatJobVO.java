package com.sap.hcm.resume.collection.integration.wechat.entity;

import java.io.Serializable;
import java.nio.charset.StandardCharsets;

import org.springframework.beans.BeanUtils;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;

@JsonIgnoreProperties("description")
public class WechatJobVO extends WechatJob implements Serializable{

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = -1970563306363619060L;
    
    public String strJobDescription;
    
    /**
     * @return the strJobDescription
     */
    public String getStrJobDescription() {
        return strJobDescription;
    }

    /**
     * @param strJobDescription the strJobDescription to set
     */
    public void setStrJobDescription(String strJobDescription) {
        this.strJobDescription = strJobDescription;
    }
    
    public static WechatJobVO fromWechatJobEntity(WechatJob job){
        WechatJobVO vo = new WechatJobVO();
        BeanUtils.copyProperties(job, vo);
        vo.setStrJobDescription(job.getJobDescription() != null ? new String(job.getJobDescription(), StandardCharsets.UTF_8) : "");
        return vo;
    }
    
    public WechatJob toWechatJobEntity(){
        WechatJob job = new WechatJob();
        BeanUtils.copyProperties(this, job);
        
        if(this.getStrJobDescription() != null){
            job.setJobDescription(this.getStrJobDescription().getBytes(StandardCharsets.UTF_8));
        }
        return job;
    }

}
