sap.ui.define([ 'sap/m/MessageBox', 'static/job/js/layout/JobBaseEditController', 'sap/ui/model/json/JSONModel' ],
		function(MessageBox, JobBaseEditController, JSONModel) {
			"use strict";

			var jobPublishController = JobBaseEditController.extend("static.job.js.layout.jobPublish", {

				/**
				 * Called when a controller is instantiated and its View
				 * controls (if available) are already created. Can be used to
				 * modify the View before it is displayed, to bind event
				 * handlers and do other one-time initialization.
				 * 
				 * @memberOf resume-collection-service.jp
				 */
				onInit : function() {

					this._router = sap.ui.core.UIComponent.getRouterFor(this);
					var that = this;

					this._router.attachRoutePatternMatched(this.prepareData, this);

					// attach handlers for validation errors
					sap.ui.getCore().attachValidationError(function(evt) {
						var control = evt.getParameter("element");
						if (control && control.setValueState) {
							control.setValueState("Error");
						}
					});
					sap.ui.getCore().attachValidationSuccess(function(evt) {
						var control = evt.getParameter("element");
						if (control && control.setValueState) {
							control.setValueState("None");
						}
					});

				},

				prepareData : function(oEvent) {

					var emptyModel = new sap.ui.model.json.JSONModel();
					this.getView().setModel(emptyModel);
					this.addVideoElement(null);
					this.setupData(oEvent);
				},

				doUpload : function(oEvent) {

					var oFileUploader = this.getView().byId("fileUploader");
					oFileUploader.setUploadUrl("job/uploadVideo");
					oFileUploader.upload();
					oFileUploader.clear();

				},

				onSave : function() {
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					this._router = sap.ui.core.UIComponent.getRouterFor(this);
					var that = this;
					var jsonData = that.getView().getModel().getData();
					if (this.validate()) {
						jsonData.status = 0;
						var cfg = {
							type : 'POST',
							data : JSON.stringify(jsonData),
							dataType : 'json',
							contentType : 'application/json;charset=UTF-8'
						};
						cfg.url = "job/save";
						$.ajax(cfg).success(function(data) {
							if (data.code === 0) {
								sap.m.MessageBox.success(data.message + " "  + that.translatEnumLabel("JOB_SAVED_SUCCESSFULLY"), {
									styleClass : bCompact ? "sapUiSizeCompact" : "",
									onClose : function(oAction) {
										if (oAction === "OK") {
											that._router.navTo("maintainJob", true);
										}
									}
								});

							} else {
								sap.m.MessageBox.error(data.message, {
									styleClass : bCompact ? "sapUiSizeCompact" : ""
								});
							}
						});
					}
				},

				onPublish : function() {
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					this._router = sap.ui.core.UIComponent.getRouterFor(this);
					var that = this;
					var jsonData = that.getView().getModel().getData();
					if (this.validate()) {
						jsonData.status = 1;
						var cfg = {
							type : 'POST',
							data : JSON.stringify(jsonData),
							dataType : 'json',
							contentType : 'application/json;charset=UTF-8'
						};
						cfg.url = "job/save";
						$.ajax(cfg).success(function(data) {
							if (data.code === 0) {
								sap.m.MessageBox.success(data.message +  " " + that.translatEnumLabel("JOB_PUBLISHED_SUCCESSFULLY"), {
									styleClass : bCompact ? "sapUiSizeCompact" : "",
									onClose : function(oAction) {
										if (oAction === "OK") {
											that._router.navTo("maintainJob", true);
										}
									}
								});
							} else {
								sap.m.MessageBox.error(data.message, {
									styleClass : bCompact ? "sapUiSizeCompact" : ""
								});
							}
						});
					}
				},

				onCancel : function() {

					var oHistory = sap.ui.core.routing.History.getInstance();
					var sPreviousHash = oHistory.getPreviousHash();

					if (sPreviousHash !== undefined) {
						window.history.go(-1);
					} else {
						var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
						oRouter.navTo("maintainJob", true);
					}
				},

				handleSelectionChange : function(oEvent) {
					var changedItem = oEvent.getParameter("changedItem");
					var isSelected = oEvent.getParameter("selected");

					var state = "Selected";
					if (!isSelected) {
						state = "Deselected"
					}

				},

				handleSelectionFinish : function(oEvent) {
					var selectedItems = oEvent.getParameter("selectedItems");
					var messageText = "Event 'selectionFinished': [";

					for (var i = 0; i < selectedItems.length; i++) {
						messageText += "'" + selectedItems[i].getText() + "'";
						if (i != selectedItems.length - 1) {
							messageText += ",";
						}
					}

					messageText += "]";

					alert(messageText);

				},

				translatEnumLabel : function(val) {
					return this.getView().getModel("wi18n").getResourceBundle().getText(val);
				},

				alertMsg : function(requiredMsg) {
					var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
					sap.m.MessageBox.alert(requiredMsg, {
						styleClass : bCompact ? "sapUiSizeCompact" : ""
					});
				},
				
				onAfterRendering: function(){
					var label = this.getView().byId("ReqIdLabel");
					label.setText(label.getText() + " " + "(" + this.translatEnumLabel("INPUT_RANGE_FOR_BATCH_PUBLISH") + ")");
					
				}
				
			});
			return jobPublishController;
		});
