package com.sap.hcm.resume.collection.integration.liepin;

import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;

import org.apache.commons.io.IOUtils;
import org.jsoup.nodes.Document;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.context.MessageSource;
import org.springframework.core.io.ClassPathResource;

import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.util.CandidateFileUtil;

public class ResumeParserLPTest {

  @Test
  public void testParseCNResumeContent() throws ServiceApplicationException, IOException {
    MessageSource ms = Mockito.mock(MessageSource.class);

    Mockito.when(ms.getMessage(Mockito.anyString(), Mockito.any(Object[].class), Mockito.any(Locale.class)))
        .thenReturn("英语");
    ClassPathResource resume = new ClassPathResource("resumes/parser/LIEPIN_TEST_CN.doc");

    ResumeParserLP parser = new ResumeParserLP(ms);

    CandidateProfileVO profileVO = new CandidateProfileVO();
    InputStream is = null;
    try {
      is = resume.getInputStream();
      Document resumeContent = CandidateFileUtil.getFileContentFromHtml(IOUtils.toByteArray(is));
      profileVO = parser.parseProfile(profileVO, resumeContent);
      profileVO = parser.parseBackgroundWorkExp(profileVO, resumeContent);
      profileVO = parser.parseBackgroundCertificate(profileVO, resumeContent);
      profileVO = parser.parseBackgroundEducation(profileVO, resumeContent);
      profileVO = parser.parseBackgroundLanguage(profileVO, resumeContent);

      Assert.assertEquals(profileVO.getCellPhone(), "13761223842");
      Assert.assertEquals(profileVO.getWorkExprs().size(), 3);
      Assert.assertEquals(profileVO.getEducation().size(), 2);
      Assert.assertEquals(profileVO.getLanguages().size(), 2);
      Assert.assertEquals(profileVO.getCertificates(), null);
    } catch (IOException e) {
    } finally {
      IOUtils.closeQuietly(is);
    }
  }

  @Test
  public void testParseENResumeContent() throws ServiceApplicationException, IOException {
    MessageSource ms = Mockito.mock(MessageSource.class);

    Mockito.when(ms.getMessage(Mockito.anyString(), Mockito.any(Object[].class), Mockito.any(Locale.class)))
        .thenReturn("英语");
    ClassPathResource resume = new ClassPathResource("resumes/parser/LIEPIN_TEST_EN.doc");

    ResumeParserLP parser = new ResumeParserLP(ms);

    CandidateProfileVO profileVO = new CandidateProfileVO();
    InputStream is = null;
    try {
      is = resume.getInputStream();
      Document resumeContent = CandidateFileUtil.getFileContentFromHtml(IOUtils.toByteArray(is));
      profileVO = parser.parseProfile(profileVO, resumeContent);
      profileVO = parser.parseBackgroundWorkExp(profileVO, resumeContent);
      profileVO = parser.parseBackgroundCertificate(profileVO, resumeContent);
      profileVO = parser.parseBackgroundEducation(profileVO, resumeContent);
      profileVO = parser.parseBackgroundLanguage(profileVO, resumeContent);

      Assert.assertEquals(profileVO.getCellPhone(), "13761223842");
      Assert.assertEquals(profileVO.getWorkExprs().size(), 1);
      Assert.assertEquals(profileVO.getEducation().size(), 1);
      Assert.assertEquals(profileVO.getLanguages().size(), 1);
      Assert.assertEquals(profileVO.getCertificates(), null);
    } catch (IOException e) {
    } finally {
      IOUtils.closeQuietly(is);
    }
  }
}
