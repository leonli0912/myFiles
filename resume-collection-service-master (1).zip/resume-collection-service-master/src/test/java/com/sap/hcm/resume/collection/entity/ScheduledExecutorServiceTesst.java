package com.sap.hcm.resume.collection.entity;

import org.junit.Test;

public class ScheduledExecutorServiceTesst {
  
  @Test
  public void testScheduleStartAndStop(){
    ThreadPoolListener lis = new ThreadPoolListener();
    lis.contextInitialized(null);
    lis.contextDestroyed(null);
  }
}
