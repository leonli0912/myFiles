jQuery.sap.registerModulePath('com.sap.rcs', 'static/js/');
sap.ui.define([
               'com/sap/rcs/UserInfoUtil',
               'sap/ui/core/mvc/Controller',
               'sap/m/MessageBox'
               ], function(UserInfoUtil, Controller, MessageBox){

		var appLauncher = Controller.extend("static.js.layout.appLauncher", {

			_oTiles:[
				{
					icon:"doc-attachment",
					title:"LB_LAUNCHER_TILE_RESUME_COLLECTION",
					info: "LB_LAUNCHER_TILE_RESUME_COLLECTION_INFO",
					showNumber:false,
					visible:true
				},
				{
					icon:"company-view",
					title:"LB_LAUNCHER_TILE_MAINTAIN_COMPANY",
					info: "LB_LAUNCHER_TILE_MAINTAIN_COMPANY_INFO",
					showNumber:false,
					visible:true
				},
				{
					icon:"opportunities",
					title:"LB_LAUNCHER_TILE_MAINTIAN_JOB",
					info: "LB_LAUNCHER_TILE_MAINTIAN_JOB_INFO",
					showNumber:true,
					visible:false
				},
				{
					icon:"line-chart",
					title:"LB_LAUNCHER_TILE_REPORT",
					info: "LB_LAUNCHER_TILE_REPORT_INFO",
					showNumber:true,
					visible:false
				}
			],
			userInfoUtil: new UserInfoUtil(),
			_currentUser:{},
		/**
		* Called when a controller is instantiated and its View controls (if available) are already created.
		* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		* @memberOf static.js.layout.templateConfig
		*/
			onInit : function() {
				var oUserModel = this.userInfoUtil.getUserInfo();
				this.getView().byId("laucherShell").setModel(oUserModel,"user");
				var result = oUserModel.getData();
				if(!result || (result.code && result.code == "-1")){
					location.href="denied";
				}else{
					this._currentUser = oUserModel.getData();
					//has company assigned
					if(this._currentUser.company){
						this._oTiles[2].visible=true;
						this._oTiles[2].number = this._currentUser.jobCount;
						this._oTiles[3].visible=true;
						this._oTiles[3].number = this._currentUser.userCount;
						this.updateUIAppearence(this._currentUser.company);
					}
					if(!this._currentUser.isUserInRole){
						this._oTiles[1].visible=false;
					}
					var oModel = new sap.ui.model.json.JSONModel();
					var cont = this.getView().byId("tileContainer");
					oModel.setData({tileCollection: this._oTiles});
					cont.setModel(oModel);
				}
			},

			updateUIAppearence: function(company){
				this.getView().byId("laucherShell").setIcon(this.formatImageData(company.logoId));
				var oText = this.getView().byId("companyIdText");
				oText.setText(company.name);
			},
			handleTilePress: function(oEvent){

				var companyId = this.getView().byId("laucherShell").getModel("user").getData().company.id;

				var sPath = oEvent.getSource().getBindingContext().sPath;
				var idx = sPath.match(/\d+$/)[0];
				var entry = this.getView().byId("tileContainer").getModel().getData().tileCollection[idx];

				var tileTitle = entry.title;
				if( tileTitle === "LB_LAUNCHER_TILE_RESUME_COLLECTION"){
					location.href="import";
				}
				if(tileTitle === "LB_LAUNCHER_TILE_MAINTAIN_COMPANY"){
					location.href="company/maintain";
				}

				if(tileTitle === "LB_LAUNCHER_TILE_MAINTIAN_JOB"){
					location.href="job/maintain";
				}

				if(tileTitle === "LB_LAUNCHER_TILE_REPORT"){
					location.href="report/maintain";
				}
			},

			formatImageData:function(data){
				return this.userInfoUtil.formatLogoPath(data);
			},
		/**
		* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		* (NOT before the first rendering! onInit() is used for that one!).
		* @memberOf resume-collection-service.templateConfig
		*/
			onBeforeRendering: function() {
			},

			handleUserItemPressed: function(oEvent){
				this.userInfoUtil.logout(oEvent);
			},

			handlePressDocuments:function(oEvent){
				window.open("https://uacp2.hana.ondemand.com/viewer/product/SLH_social_media_integration_recruiting_service/1701/en-US","_blank");
			},

			translateText:function(val){
				if(!val) return ;
				return sap.ui.getCore().getModel("i18n").getResourceBundle().getText(val);
			},
		/**
		* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		* This hook is the same one that SAPUI5 controls get after being rendered.
		* @memberOf resume-collection-service.templateConfig
		*/
		//	onAfterRendering: function() {
		//
		//	},

		/**
		* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		* @memberOf resume-collection-service.templateConfig
		*/
			onExit: function() {

			}

		});

		return appLauncher;
});
