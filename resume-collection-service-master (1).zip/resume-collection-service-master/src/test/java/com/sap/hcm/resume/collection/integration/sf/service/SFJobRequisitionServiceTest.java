package com.sap.hcm.resume.collection.integration.sf.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;

import com.sap.hcm.resume.collection.bean.CompanyIdInfo;
import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.context.TestContext;
import com.sap.hcm.resume.collection.context.WebAppContext;
import com.sap.hcm.resume.collection.entity.ChangeLog;
import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.entity.view.JobRequisitionMappingVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.bean.JobReqDataModelMapping;
import com.sap.hcm.resume.collection.integration.sf.SFOdataFormatter;
import com.sap.hcm.resume.collection.integration.sf.bean.QueryInfo;
import com.sap.hcm.resume.collection.integration.sf.odata.SFAuthentication;
import com.sap.hcm.resume.collection.integration.sf.odata.SFODataService;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJob;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatJobScreeningQuestionChoiceService;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatJobScreeningQuestionService;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatJobService;
import com.sap.hcm.resume.collection.service.CompanyInfoService;
import com.sap.hcm.resume.collection.service.DataModelMappingService;
import com.sap.hcm.resume.collection.util.ChangeLogUtil;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { TestContext.class, WebAppContext.class })
public class SFJobRequisitionServiceTest {

  private SFJobRequisitionService sfJobRequisitionService;

  @Autowired
  private SFODataService sfOdataService;

  @Autowired
  private CompanyInfoService companyInfoService;

  @Autowired
  private ChangeLogUtil changeLogUtil;

  @Autowired
  private DataModelMappingService mappingService;

  @Autowired
  SFAuthentication sfAuth;

  @Autowired
  private Params params;

  @Autowired
  private CompanyIdInfo companyIdInfo;

  @Autowired
  private WechatJobService wechatJobService;

  @Autowired
  private WechatJobScreeningQuestionService wechatJobScreeningQuestionService;

  @Autowired
  private WechatJobScreeningQuestionChoiceService wechatJobScreeningQuestionChoiceService;

  @Autowired
  private SFOdataFormatter sfOdataFormatter;

  private JobReqDataModelMapping jobReqMapping = null;

  private String jobRequisitioonJsonString = null;

  private JobRequisitionMappingVO mapping = null;

  @Before
  public void setUp() {
    reset(companyInfoService);
    sfJobRequisitionService = spy(new SFJobRequisitionService());
    ReflectionTestUtils.setField(sfJobRequisitionService, "sfOdataService", sfOdataService);
    ReflectionTestUtils.setField(sfJobRequisitionService, "changeLogUtil", changeLogUtil);
    ReflectionTestUtils.setField(sfJobRequisitionService, "companyInfoService", companyInfoService);
    ReflectionTestUtils.setField(sfJobRequisitionService, "mappingService", mappingService);
    ReflectionTestUtils.setField(sfJobRequisitionService, "sfAuth", sfAuth);
    ReflectionTestUtils.setField(sfJobRequisitionService, "params", params);
    ReflectionTestUtils.setField(sfJobRequisitionService, "companyIdInfo", companyIdInfo);
    ReflectionTestUtils.setField(sfJobRequisitionService, "sfOdataFormatter", sfOdataFormatter);
    ReflectionTestUtils.setField(sfJobRequisitionService, "wechatJobService", wechatJobService);
    ReflectionTestUtils.setField(sfJobRequisitionService, "wechatJobScreeningQuestionService",
        wechatJobScreeningQuestionService);
    ReflectionTestUtils.setField(sfJobRequisitionService, "wechatJobScreeningQuestionChoiceService",
        wechatJobScreeningQuestionChoiceService);
    this.prepareData();
  }

  private void prepareData() {
    mapping = new JobRequisitionMappingVO();
    String content = "<jobreq-model-mapping><items>"
        + "<jobreq-mapping-item><sourceField>externalJobId</sourceField><sfDmField>jobReqId</sfDmField><label>LB_JOBREQ</label><filterable>false</filterable></jobreq-mapping-item>"
        + "<jobreq-mapping-item><sourceField>jobTitle</sourceField><sfDmField>jobReqLocale/jobTitle</sfDmField><label>LB_JOBREQ</label><filterable>false</filterable></jobreq-mapping-item>"
        + "<jobreq-mapping-item><sourceField>country</sourceField><sfDmField>country</sfDmField><label>LB_COUNTRY</label><filterable>false</filterable><displayInWeChat>true</displayInWeChat></jobreq-mapping-item>"
        + "<jobreq-mapping-item><sourceField>city</sourceField><sfDmField>custCity</sfDmField><label>LB_CITY</label><filterable>false</filterable><picklist>custCity</picklist><displayInWeChat>true</displayInWeChat></jobreq-mapping-item>"
        + "<jobreq-mapping-item><sourceField>employmentType</sourceField><sfDmField>jobReqLocaleExtra/partFullTime</sfDmField><label>EMPLOYMENT_TYPE</label><filterable>true</filterable></jobreq-mapping-item>"
        + "</items></jobreq-model-mapping>";
    jobReqMapping = JobReqDataModelMapping.fromXML(content);
    mapping.setMapping(jobReqMapping);

    InputStream input = null;
    try {
      ClassPathResource feed = new ClassPathResource("/mapping/job_req_feed.json");
      input = feed.getInputStream();
      jobRequisitioonJsonString = IOUtils.toString(input, StandardCharsets.UTF_8.toString());
    } catch (IOException e) {
    } finally {
      IOUtils.closeQuietly(input);
    }
  }

  @Test
  public void testGetJobRequisitionWithDoubleEntries() throws ServiceApplicationException, IOException {
    Map<String, String> expect = new HashMap<String, String>();
    expect.put("loadedJobIdList", "19621");
    expect.put("passedJobIdList", "19641");
    expect.put("failedJobIdList", "");
    expect.put("loaded", Integer.toString(1));
    expect.put("passed", Integer.toString(1));
    expect.put("failed", Integer.toString(0));

    params.setCompanyId("sap");
    ReflectionTestUtils.setField(sfJobRequisitionService, "params", params);

    // Prepare Data
    CompanyInfo info = new CompanyInfo();
    info.setJobStatuses("EMPTY,ACTIVE");

    // Mock necessary steps
    when(companyInfoService.getCompanyInfo("sap")).thenReturn(info);
    when(mappingService.getJobRequisitionMappingById("sap", (long) 1)).thenReturn(mapping);
    when(sfOdataService.readFeedAsString(any(String.class), any(QueryInfo.class)))
        .thenReturn(jobRequisitioonJsonString);
    WechatJob job = new WechatJob();
    job.setExternalJobId("19621");
    when(
        sfOdataFormatter.formatJobReqFromSF2Local(any(WechatJob.class), any(HashMap.class),
            any(JobRequisitionMappingVO.class))).thenReturn(job);
    Map<String, String> result = sfJobRequisitionService.getJobRequisition("1", "2016-10-22", "2016-10-27",
        "19621,19641");
    assertEquals(expect.get("loadedJobIdList"), result.get("loadedJobIdList"));
    assertEquals(expect.get("passedJobIdList"), result.get("passedJobIdList"));
    assertEquals(expect.get("failedJobIdList"), result.get("failedJobIdList"));
    assertEquals(expect.get("loaded"), result.get("loaded"));
    assertEquals(expect.get("passed"), result.get("passed"));
    assertEquals(expect.get("failed"), result.get("failed"));
  }

  @Test
  public void testGetJobRequisitionWithoutJobStatus() throws ServiceApplicationException, IOException {
    Map<String, String> expect = new HashMap<String, String>();
    expect.put("loadedJobIdList", "");
    expect.put("passedJobIdList", "19621,19641");
    expect.put("failedJobIdList", "");
    expect.put("loaded", Integer.toString(0));
    expect.put("passed", Integer.toString(2));
    expect.put("failed", Integer.toString(0));

    params.setCompanyId("sap");
    ReflectionTestUtils.setField(sfJobRequisitionService, "params", params);

    // Prepare Data
    CompanyInfo info = new CompanyInfo();
    info.setJobStatuses("");

    // Mock necessary steps
    when(companyInfoService.getCompanyInfo("sap")).thenReturn(info);
    when(mappingService.getJobRequisitionMappingById("sap", (long) 1)).thenReturn(mapping);
    when(sfOdataService.readFeedAsString(any(String.class), any(QueryInfo.class)))
        .thenReturn(jobRequisitioonJsonString);

    Map<String, String> result = sfJobRequisitionService.getJobRequisition("1", "2016-10-22", "2016-10-27",
        "19621,19641");
    assertEquals(expect.get("loadedJobIdList"), result.get("loadedJobIdList"));
    assertEquals(expect.get("passedJobIdList"), result.get("passedJobIdList"));
    assertEquals(expect.get("failedJobIdList"), result.get("failedJobIdList"));
    assertEquals(expect.get("loaded"), result.get("loaded"));
    assertEquals(expect.get("passed"), result.get("passed"));
    assertEquals(expect.get("failed"), result.get("failed"));
  }

  @Test
  public void testGetJobRequisitionWithSingleEntry() throws ServiceApplicationException, IOException {
    InputStream input = null;
    try {
      ClassPathResource feed = new ClassPathResource("/mapping/job_req_single_entry.json");
      input = feed.getInputStream();
      jobRequisitioonJsonString = null;
      jobRequisitioonJsonString = IOUtils.toString(input, StandardCharsets.UTF_8.toString());
    } catch (IOException e) {
    } finally {
      IOUtils.closeQuietly(input);
    }

    params.setCompanyId("sap");
    ReflectionTestUtils.setField(sfJobRequisitionService, "params", params);

    Map<String, String> expect = new HashMap<String, String>();
    expect.put("loadedJobIdList", "19621");
    expect.put("passedJobIdList", "");
    expect.put("failedJobIdList", "");
    expect.put("loaded", Integer.toString(1));
    expect.put("passed", Integer.toString(0));
    expect.put("failed", Integer.toString(0));

    // Prepare Data
    CompanyInfo info = new CompanyInfo();
    info.setJobStatuses("EMPTY");

    // Mock necessary steps
    when(companyInfoService.getCompanyInfo("sap")).thenReturn(info);
    when(mappingService.getJobRequisitionMappingById("sap", (long) 1)).thenReturn(mapping);
    when(sfOdataService.readFeedAsString(any(String.class), any(QueryInfo.class)))
        .thenReturn(jobRequisitioonJsonString);
    WechatJob job = new WechatJob();
    job.setExternalJobId("19621");
    when(
        sfOdataFormatter.formatJobReqFromSF2Local(any(WechatJob.class), any(HashMap.class),
            any(JobRequisitionMappingVO.class))).thenReturn(job);

    Map<String, String> result = sfJobRequisitionService.getJobRequisition("1", "2016-10-22", "2016-10-27", "19621");
    assertEquals(expect.get("loadedJobIdList"), result.get("loadedJobIdList"));
    assertEquals(expect.get("passedJobIdList"), result.get("passedJobIdList"));
    assertEquals(expect.get("failedJobIdList"), result.get("failedJobIdList"));
    assertEquals(expect.get("loaded"), result.get("loaded"));
    assertEquals(expect.get("passed"), result.get("passed"));
    assertEquals(expect.get("failed"), result.get("failed"));
  }

  @Test
  public void testGetJobRequisitionWithDateRange() throws ServiceApplicationException, IOException {
    Map<String, String> expect = new HashMap<String, String>();
    expect.put("loadedJobIdList", "19621");
    expect.put("passedJobIdList", "19641");
    expect.put("failedJobIdList", "");
    expect.put("loaded", Integer.toString(1));
    expect.put("passed", Integer.toString(1));
    expect.put("failed", Integer.toString(0));

    params.setCompanyId("sap");
    ReflectionTestUtils.setField(sfJobRequisitionService, "params", params);

    // Prepare Data
    CompanyInfo info = new CompanyInfo();
    info.setJobStatuses("EMPTY");

    // Mock necessary steps
    when(companyInfoService.getCompanyInfo("sap")).thenReturn(info);
    when(mappingService.getJobRequisitionMappingById("sap", (long) 1)).thenReturn(mapping);
    when(sfOdataService.readFeedAsString(any(String.class), any(QueryInfo.class)))
        .thenReturn(jobRequisitioonJsonString);
    WechatJob job = new WechatJob();
    job.setExternalJobId("19621");
    when(
        sfOdataFormatter.formatJobReqFromSF2Local(any(WechatJob.class), any(HashMap.class),
            any(JobRequisitionMappingVO.class))).thenReturn(job);
    Map<String, String> result = sfJobRequisitionService.getJobRequisition("1", "2016-10-22", "2016-10-27", "");
    assertEquals(expect.get("loadedJobIdList"), result.get("loadedJobIdList"));
    assertEquals(expect.get("passedJobIdList"), result.get("passedJobIdList"));
    assertEquals(expect.get("failedJobIdList"), result.get("failedJobIdList"));
    assertEquals(expect.get("loaded"), result.get("loaded"));
    assertEquals(expect.get("passed"), result.get("passed"));
    assertEquals(expect.get("failed"), result.get("failed"));
  }

  @Test(expected = ServiceApplicationException.class)
  public void testGetJobRequisitionErrorWithEmptyCompanyId() throws ServiceApplicationException {
    params.setCompanyId(null);
    ReflectionTestUtils.setField(sfJobRequisitionService, "params", params);
    Map<String, String> result = sfJobRequisitionService.getJobRequisition("1", "2016-10-22", "2016-10-27", "");
  }

  @Test
  public void testGetJobRequisitionErrorWithInvalidCompanyInfo() throws ServiceApplicationException {
    params.setCompanyId("sap");
    ReflectionTestUtils.setField(sfJobRequisitionService, "params", params);
    when(companyInfoService.getCompanyInfo("sap")).thenReturn(null);
    Map<String, String> result = sfJobRequisitionService.getJobRequisition("1", "2016-10-22", "2016-10-27", "");
  }

  @Test
  public void testGetJobRequisitionErrorWithInvalidJobReqMappingId() throws ServiceApplicationException {
    params.setCompanyId("sap");
    ReflectionTestUtils.setField(sfJobRequisitionService, "params", params);
    CompanyInfo info = new CompanyInfo();
    info.setJobStatuses("EMPTY");
    when(companyInfoService.getCompanyInfo("sap")).thenReturn(info);
    when(mappingService.getJobRequisitionMappingById("sap", (long) 1)).thenReturn(null);
    Map<String, String> result = sfJobRequisitionService.getJobRequisition("1", "2016-10-22", "2016-10-27", "");
  }

  @Test
  public void testSyncJobRequisitionWithCompanyIdEmpty() throws ServiceApplicationException {
    sfJobRequisitionService.syncJobRequisition(null);
  }

  @Test
  public void testSyncJobRequisitionWithJobReqMappingIdEmpty() throws ServiceApplicationException {
    CompanyInfo info = new CompanyInfo();
    when(companyInfoService.getCompanyInfo("sap")).thenReturn(info);
    sfJobRequisitionService.syncJobRequisition("sap");
  }

  @Test
  public void testSyncJobRequisitionWithJobReqMappingNull() throws ServiceApplicationException {
    CompanyInfo info = new CompanyInfo();
    info.setJobReqMappingId(1L);
    when(companyInfoService.getCompanyInfo("sap")).thenReturn(info);
    when(mappingService.getJobRequisitionMappingById("sap", (long) 1)).thenReturn(null);
    sfJobRequisitionService.syncJobRequisition("sap");
  }

  @Test
  public void testSyncJobRequisitionWithJobReqMapping() throws ServiceApplicationException, IOException {
    CompanyInfo info = new CompanyInfo();
    info.setJobReqMappingId(1L);
    info.setJobStatuses("EMPTY,ACTIVE");
    when(companyInfoService.getCompanyInfo("sap")).thenReturn(info);
    when(mappingService.getJobRequisitionMappingById("sap", (long) 1)).thenReturn(mapping);
    when(sfOdataService.readFeedAsString(any(String.class), any(QueryInfo.class)))
        .thenReturn(jobRequisitioonJsonString);

    WechatJob job = new WechatJob();
    job.setExternalJobId("19621");
    when(
        sfOdataFormatter.formatJobReqFromSF2Local(any(WechatJob.class), any(HashMap.class),
            any(JobRequisitionMappingVO.class))).thenReturn(job);
    ChangeLog cl = new ChangeLog();
    when(changeLogUtil.savejobSyncHistory(any(String.class), any(String.class))).thenReturn(cl);
    when(companyInfoService.saveCompanyInfo(any(CompanyInfo.class))).thenReturn(info);
    sfJobRequisitionService.syncJobRequisition("sap");
  }

  @Test
  public void testGetJobRequisitionForSearch() throws ServiceApplicationException, IOException {
    String condition = null;
    params.setCompanyId("sap");
    ReflectionTestUtils.setField(sfJobRequisitionService, "params", params);
    CompanyInfo info = new CompanyInfo();
    info.setJobStatuses("EMPTY,ACTIVE");
    when(companyInfoService.getCompanyInfo("sap")).thenReturn(info);
    when(sfOdataService.readFeedAsString(any(String.class), any(QueryInfo.class)))
        .thenReturn(jobRequisitioonJsonString);
    Map<String, Object> result = sfJobRequisitionService.getJobRequisitionForSearch(condition);
  }
}
