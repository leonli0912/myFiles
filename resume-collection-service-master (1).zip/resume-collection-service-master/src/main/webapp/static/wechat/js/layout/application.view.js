sap.ui.jsview("static.wechat.js.layout.application", {

	/** Specifies the Controller belonging to this View. 
	* In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	* @memberOf resume-collection-service.application
	*/ 
	getControllerName : function() {
		return "static.wechat.js.layout.application";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	* Since the Controller is given to this method, its event handlers can be attached right away. 
	* @memberOf resume-collection-service.application
	*/ 
	createContent : function(oController) {
		this.setDisplayBlock(true);
		var app =  new sap.m.App("navContainer");
		return app;
	}

});
