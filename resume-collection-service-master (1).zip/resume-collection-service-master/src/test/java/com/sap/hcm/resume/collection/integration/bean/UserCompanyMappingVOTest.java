package com.sap.hcm.resume.collection.integration.bean;

import org.junit.Assert;
import org.junit.Test;

import com.sap.hcm.resume.collection.entity.view.UserCompanyMappingVO;


public class UserCompanyMappingVOTest {
  
  @Test
  public void testSetGetter(){
    UserCompanyMappingVO vo = new UserCompanyMappingVO();
    
    vo.setId(1L);
    vo.setIntegrationBean(null);
    vo.setMapping(null);
    vo.setMappingName("test");
    vo.setTargetSystem("SF");
    
    Assert.assertEquals(vo.getId().toString(), "1");
    Assert.assertEquals(vo.getIntegrationBean(), null);
    Assert.assertEquals(vo.getMapping(), null);
    Assert.assertEquals(vo.getMappingName(), "test");
    Assert.assertEquals(vo.getTargetSystem(), "SF");
  }
}
