package com.sap.hcm.resume.collection.integration;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.net.ssl.SSLContext;
import javax.servlet.http.HttpServletRequest;

import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.client.CookieStore;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContextBuilder;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.cookie.Cookie;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.cookie.BasicClientCookie;

import com.sap.hcm.resume.collection.bean.ResumeInfo;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.bean.ResumeDownloadBean;

public abstract class JobBoardBaseProvider {

  protected CookieStore cookieStore = new BasicCookieStore();

  public abstract void preLogin() throws ServiceApplicationException;

  public abstract void getVerifyCode(HttpServletRequest request) throws ServiceApplicationException;

  public abstract ResumeInfo getFileContent(byte[] content) throws ServiceApplicationException;

  public abstract List<ResumeDownloadBean> getResume(HttpServletRequest request, String username, String password,
      String captcha) throws ServiceApplicationException;

  public void setCookieStore(HttpResponse httpResponse) {

    Header[] headers = httpResponse.getHeaders("Set-Cookie");
    if (headers != null && headers.length > 0) {
      for (int i = 0; i < headers.length; i++) {
        String setCookie = headers[i].getValue();
        try {
          BasicClientCookie cookie = this.parseRawCookie(setCookie);
          if (!cookie.isExpired(new Date())) {
            this.cookieStore.addCookie(cookie);
          }
        } catch (Exception e) {
          // do nothing
        }
      }
    }
    this.cookieStore.clearExpired(new Date());
  }

  /**
   * parse cookie
   * 
   * @param rawCookie
   * @return
   * @throws Exception
   */
  BasicClientCookie parseRawCookie(String rawCookie) throws Exception {
    String[] rawCookieParams = rawCookie.split(";");

    String[] rawCookieNameAndValue = rawCookieParams[0].split("=");
    if (rawCookieNameAndValue.length != 2) {
      throw new Exception("Invalid cookie: missing name and value.");
    }

    String cookieName = rawCookieNameAndValue[0].trim();
    String cookieValue = rawCookieNameAndValue[1].trim();
    BasicClientCookie cookie = new BasicClientCookie(cookieName, cookieValue);
    for (int i = 1; i < rawCookieParams.length; i++) {
      String rawCookieParamNameAndValue[] = rawCookieParams[i].trim().split("=");

      String paramName = rawCookieParamNameAndValue[0].trim();

      if (paramName.equalsIgnoreCase("secure")) {
        cookie.setSecure(true);
      } else {
        if (rawCookieParamNameAndValue.length != 2) {
          throw new Exception("Invalid cookie: attribute not a flag or missing value.");
        }

        String paramValue = rawCookieParamNameAndValue[1].trim();

        if (paramName.equalsIgnoreCase("expires")) {
          Date expiryDate = new SimpleDateFormat("EEE, dd-MMM-yyyy hh:mm:ss z", Locale.US).parse(paramValue);
          cookie.setExpiryDate(expiryDate);
        } else if (paramName.equalsIgnoreCase("max-age")) {
          long maxAge = Long.parseLong(paramValue);
          Date expiryDate = new Date(System.currentTimeMillis() + maxAge);
          cookie.setExpiryDate(expiryDate);
        } else if (paramName.equalsIgnoreCase("domain")) {
          cookie.setDomain(paramValue);
        } else if (paramName.equalsIgnoreCase("path")) {
          cookie.setPath(paramValue);
        } else if (paramName.equalsIgnoreCase("comment")) {
          cookie.setPath(paramValue);
        } else {
          throw new Exception("Invalid cookie: invalid attribute name.");
        }
      }
    }

    return cookie;
  }

  public String getCookieValue(String name) {
    if (this.cookieStore != null && this.cookieStore.getCookies() != null) {
      for (Cookie cookie : this.cookieStore.getCookies()) {
        if (cookie.getName().equalsIgnoreCase(name)) {
          return cookie.getValue();
        }
      }
    }
    return null;
  }

  /**
   * 
   * @param password
   * @return
   */
  public String encryptPwd(String password) {

    String md5 = "";

    try {
      MessageDigest md = MessageDigest.getInstance("MD5");
      md.update(password.getBytes());
      byte b[] = md.digest();
      int i;

      StringBuffer buf = new StringBuffer("");
      for (int offset = 0; offset < b.length; offset++) {
        i = b[offset];
        if (i < 0)
          i += 256;
        if (i < 16)
          buf.append("0");
        buf.append(Integer.toHexString(i));
      }

      md5 = buf.toString();// 32 byte encrypt

    } catch (NoSuchAlgorithmException e) {
      e.printStackTrace();
    }
    return md5;
  }
  

  /**
   * create http client
   * 
   * @return
   */
  protected CloseableHttpClient createHttpClient() {
    
    HttpClientBuilder httpClientBuilder = HttpClients.custom().useSystemProperties().setDefaultCookieStore(cookieStore);
    SSLContext sslContext;
    try {
      sslContext = new SSLContextBuilder().loadTrustMaterial(null, new TrustStrategy() {
        public boolean isTrusted(X509Certificate[] chain, String authType) {
          return true;
        }
      }).build();
      SSLConnectionSocketFactory sslsf = new SSLConnectionSocketFactory(sslContext);
      httpClientBuilder.setSSLSocketFactory(sslsf);
      httpClientBuilder.setHostnameVerifier(SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
    } catch (KeyManagementException | NoSuchAlgorithmException | KeyStoreException e) {
      //
    }
    return httpClientBuilder.build();
  }
}
