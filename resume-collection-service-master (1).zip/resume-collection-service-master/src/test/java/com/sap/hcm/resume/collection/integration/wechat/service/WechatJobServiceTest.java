package com.sap.hcm.resume.collection.integration.wechat.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import javax.annotation.Resource;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;

import com.sap.hcm.resume.collection.bean.FilterListItem;
import com.sap.hcm.resume.collection.bean.KeyLabelBean;
import com.sap.hcm.resume.collection.context.TestContext;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.bean.JobReqDataModelMappingItem;
import com.sap.hcm.resume.collection.integration.sf.bean.SFPicklistCacheEntityType;
import com.sap.hcm.resume.collection.integration.sf.bean.SFPicklistItem;
import com.sap.hcm.resume.collection.integration.sf.service.SFPicklistCacheService;
import com.sap.hcm.resume.collection.integration.wechat.bean.JobDynSearchBean;
import com.sap.hcm.resume.collection.integration.wechat.bean.JobDynSearchBeanItem;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatApplyHistory;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJob;
import com.sap.hcm.resume.collection.service.DataModelMappingService;
import com.sap.hcm.resume.test.MockApplicationConfig;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { TestContext.class })
public class WechatJobServiceTest {

  @Resource(name = "entityManager")
  private EntityManager entityManager;

  @Resource(name = "dataModelMappingService")
  private DataModelMappingService dataModelMappingService;

  @Resource(name = "pklCacheService")
  private SFPicklistCacheService pklCacheService;

  private WechatJobService wechatJobService;

  @Before
  public void setUp() {
    reset(entityManager);
    wechatJobService = new WechatJobService();
    ReflectionTestUtils.setField(wechatJobService, "entityManager", entityManager);
    ReflectionTestUtils.setField(wechatJobService, "dmMappingService", dataModelMappingService);
    ReflectionTestUtils.setField(wechatJobService, "pklCacheService", pklCacheService);
  }

  @Test
  public void testFindJobByIdSuccess() throws ServiceApplicationException {
    WechatJob job = new WechatJob();
    Long jobId = new Long(001);
    when(entityManager.find(WechatJob.class, jobId)).thenReturn(job);
    WechatJob resultJob = wechatJobService.findJobById(jobId);
    assertEquals(job, resultJob);
  }

  @Test
  public void testFindJobByIdFailed() throws ServiceApplicationException {
    Long jobId = new Long(001);
    ReflectionTestUtils.setField(wechatJobService, "entityManager", null);
    try {
      wechatJobService.findJobById(jobId);
    } catch (Exception ex) {
      assertEquals("unable to load given job detail", ex.getMessage());
      assertTrue(ex instanceof ServiceApplicationException);
    }
  }

  @Test
  public void testFindJobByReqIdSuccess() throws ServiceApplicationException {
    List<WechatJob> jobList = new ArrayList<WechatJob>();
    WechatJob wechatJob = new WechatJob();
    jobList.add(wechatJob);
    String externalJobId = "001";
    String companyId = "sap";
    String sel = "select h from WechatJob h where h.externalJobId = :externalJobId and h.companyId = :companyId";
    TypedQuery<WechatJob> mockedTypedQuery = MockApplicationConfig.fluentMock(TypedQuery.class);
    when(entityManager.createQuery(sel, WechatJob.class)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("externalJobId", externalJobId)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("companyId", companyId)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.getResultList()).thenReturn(jobList);
    WechatJob job = wechatJobService.findJobByReqId(externalJobId, companyId);
    assertEquals(job, wechatJob);
  }

  @Test
  public void testFindJobByReqIdFailed() throws ServiceApplicationException {
    List<WechatJob> jobList = new ArrayList<WechatJob>();
    String externalJobId = "001";
    String companyId = "sap";
    String sel = "select h from WechatJob h where h.externalJobId = :externalJobId and h.companyId = :companyId";
    TypedQuery<WechatJob> mockedTypedQuery = MockApplicationConfig.fluentMock(TypedQuery.class);
    when(entityManager.createQuery(sel, WechatJob.class)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("externalJobId", externalJobId)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("companyId", companyId)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.getResultList()).thenReturn(jobList);
    WechatJob job = wechatJobService.findJobByReqId(externalJobId, companyId);
    assertEquals(job, null);
  }

  @Test
  public void testSaveJobSuccessForCreate() throws ServiceApplicationException {
    WechatJob job = new WechatJob();
    job.setExternalJobId("001");
    job.setCompanyId("sap");
    String sel = "select h from WechatJob h where h.externalJobId = :externalJobId and h.companyId = :companyId";
    TypedQuery<WechatJob> mockedTypedQuery = MockApplicationConfig.fluentMock(TypedQuery.class);
    when(entityManager.createQuery(sel, WechatJob.class)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("externalJobId", "001")).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("companyId", "sap")).thenReturn(mockedTypedQuery);
    when(entityManager.merge(job)).thenReturn(job);
    WechatJob resultJob = wechatJobService.saveJob(job);
    assertEquals(job, resultJob);
  }

  @Test
  public void testSaveJobSuccessForUpdate() throws ServiceApplicationException {
    WechatJob job = new WechatJob();
    job.setExternalJobId("001");
    job.setCompanyId("sap");
    job.setJobId(new Long(1));
    WechatJob existJob = new WechatJob();
    existJob.setExternalJobId("001");
    existJob.setCompanyId("sap");
    existJob.setJobId(new Long(1));
    List<WechatJob> jobList = new ArrayList<WechatJob>();
    jobList.add(existJob);
    String sel = "select h from WechatJob h where h.externalJobId = :externalJobId and h.companyId = :companyId";
    TypedQuery<WechatJob> mockedTypedQuery = MockApplicationConfig.fluentMock(TypedQuery.class);
    when(entityManager.createQuery(sel, WechatJob.class)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("externalJobId", "001")).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("companyId", "sap")).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.getResultList()).thenReturn(jobList);
    when(entityManager.merge(job)).thenReturn(job);
    WechatJob resultJob = wechatJobService.saveJob(job);
    assertEquals(job, resultJob);
  }

  @Test
  public void testSaveJobFailed() throws ServiceApplicationException {
    WechatJob job = new WechatJob();
    job.setExternalJobId("001");
    job.setCompanyId("sap");
    job.setJobId(new Long(2));
    WechatJob existJob = new WechatJob();
    existJob.setExternalJobId("001");
    existJob.setCompanyId("sap");
    existJob.setJobId(new Long(1));
    List<WechatJob> jobList = new ArrayList<WechatJob>();
    jobList.add(existJob);
    String sel = "select h from WechatJob h where h.externalJobId = :externalJobId and h.companyId = :companyId";
    TypedQuery<WechatJob> mockedTypedQuery = MockApplicationConfig.fluentMock(TypedQuery.class);
    when(entityManager.createQuery(sel, WechatJob.class)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("externalJobId", "001")).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("companyId", "sap")).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.getResultList()).thenReturn(jobList);
    when(entityManager.merge(job)).thenReturn(job);
    try {
      wechatJobService.saveJob(job);
    } catch (Exception ex) {
      assertEquals("Requisition ID is exist", ex.getMessage());
      assertTrue(ex instanceof ServiceApplicationException);
    }
  }

  @Test
  public void testSaveSFJobSuccess() throws ServiceApplicationException {
    WechatJob job = new WechatJob();
    job.setExternalJobId("001");
    job.setCompanyId("sap");
    String sel = "select h from WechatJob h where h.externalJobId = :externalJobId and h.companyId = :companyId";
    TypedQuery<WechatJob> mockedTypedQuery = MockApplicationConfig.fluentMock(TypedQuery.class);
    when(entityManager.createQuery(sel, WechatJob.class)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("externalJobId", "001")).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("companyId", "sap")).thenReturn(mockedTypedQuery);
    when(entityManager.merge(job)).thenReturn(job);
    WechatJob resultJob = wechatJobService.saveSFJob(job);
    assertEquals(job, resultJob);
  }

  @Test
  public void testSaveSFJobFailed() throws ServiceApplicationException {
    WechatJob job = new WechatJob();
    job.setExternalJobId("001");
    job.setCompanyId("sap");
    job.setJobId(new Long(1));
    WechatJob existJob = new WechatJob();
    existJob.setExternalJobId("001");
    existJob.setCompanyId("sap");
    existJob.setJobId(new Long(1));
    List<WechatJob> jobList = new ArrayList<WechatJob>();
    jobList.add(existJob);
    String sel = "select h from WechatJob h where h.externalJobId = :externalJobId and h.companyId = :companyId";
    TypedQuery<WechatJob> mockedTypedQuery = MockApplicationConfig.fluentMock(TypedQuery.class);
    when(entityManager.createQuery(sel, WechatJob.class)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("externalJobId", "001")).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("companyId", "sap")).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.getResultList()).thenReturn(jobList);
    when(entityManager.merge(job)).thenReturn(job);
    WechatJob resultJob = wechatJobService.saveSFJob(job);
    assertEquals(job, resultJob);
  }

  @Test
  public void testFindApplyHistorySuccess() throws ServiceApplicationException {
    List<WechatApplyHistory> applyHistoryList = new ArrayList<WechatApplyHistory>();
    String wechatId = "w001";
    String companyId = "sap";
    String sel = "select h from WechatApplyHistory h where h.wechatId = :wechatId AND h.companyId = :companyId order by h.applyHistoryId desc";
    TypedQuery<WechatApplyHistory> mockedTypedQuery = MockApplicationConfig.fluentMock(TypedQuery.class);
    when(entityManager.createQuery(sel, WechatApplyHistory.class)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("wechatId", wechatId)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("companyId", companyId)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.getResultList()).thenReturn(applyHistoryList);
    List<WechatApplyHistory> resultList = wechatJobService.findApplyHistory(wechatId, companyId, null);
    assertEquals(resultList, applyHistoryList);
  }

  @Test
  public void testFindApplyHistoryFailed() throws ServiceApplicationException {
    String wechatId = "w001";
    String companyId = "sap";
    try {
      wechatJobService.findApplyHistory(wechatId, companyId, null);
    } catch (Exception ex) {
      assertEquals("unable to load apply history", ex.getMessage());
      assertTrue(ex instanceof ServiceApplicationException);
    }
  }

  @Test
  public void testGetAppIdSuccess() throws ServiceApplicationException {
    WechatApplyHistory applyHistory = new WechatApplyHistory();
    applyHistory.setSfjobApplicationId("SF001");
    String wechatId = "w001";
    String companyId = "sap";
    Long jobId = new Long(1);
    String sel = "select h from WechatApplyHistory h where h.wechatId = :wechatId AND h.companyId = :companyId AND h.applyHistoryId = :applyHistoryId order by h.applyHistoryId desc";
    Query simpleQuery = Mockito.mock(Query.class);
    when(entityManager.createQuery(sel)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("wechatId", wechatId)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("companyId", companyId)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("jobId", jobId)).thenReturn(simpleQuery);
    when(simpleQuery.getSingleResult()).thenReturn(applyHistory);
    String result = wechatJobService.getAppId(wechatId, companyId, jobId);
    assertEquals(result, "SF001");
  }

  @Test
  public void testGetAppIdFailed() throws ServiceApplicationException {
    String wechatId = "w001";
    String companyId = "sap";
    Long jobId = new Long(1);
    try {
      wechatJobService.getAppId(wechatId, companyId, jobId);
    } catch (Exception ex) {
      assertEquals("unable to load apply history", ex.getMessage());
      assertTrue(ex instanceof ServiceApplicationException);
    }
  }

  @Test
  public void testFindApplyHistoryForCheckSuccess() throws ServiceApplicationException {
    List<WechatApplyHistory> applyHistoryList = new ArrayList<WechatApplyHistory>();
    String applyEmail = "aa@bb.com";
    String extJobId = "234";
    String sel = "select h from WechatApplyHistory h where h.applyEmail = :applyEmail AND h.externalJobId = :externalJobId";
    TypedQuery<WechatApplyHistory> mockedTypedQuery = MockApplicationConfig.fluentMock(TypedQuery.class);
    when(entityManager.createQuery(sel, WechatApplyHistory.class)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("applyEmail", applyEmail)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("externalJobId", extJobId)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.getResultList()).thenReturn(applyHistoryList);
    List<WechatApplyHistory> resultList = wechatJobService.findApplyHistoryForCheck(applyEmail, extJobId);
    assertEquals(resultList, applyHistoryList);
  }

  @Test
  public void testFindApplyHistoryForCheckFailed() throws ServiceApplicationException {
    String applyEmail = "aa@bb.com";
    String extJobId = "234";
    try {
      wechatJobService.findApplyHistoryForCheck(applyEmail, extJobId);
    } catch (Exception ex) {
      assertEquals("unable to load apply history", ex.getMessage());
      assertTrue(ex instanceof ServiceApplicationException);
    }
  }

  @Test
  public void testSaveHistory() throws ServiceApplicationException {
    WechatApplyHistory wechatApplyHistory = new WechatApplyHistory();
    wechatJobService.saveHistory(wechatApplyHistory);
  }

  @Test
  public void testSaveStatusSuccess() throws ServiceApplicationException {
    String wechatId = "w001";
    String companyId = "sap";
    Long applyHistoryId = new Long(1);
    String status = "1";
    String sel = "update WechatApplyHistory h set h.applyStatus=:status where h.wechatId = :wechatId AND h.companyId = :companyId AND h.applyHistoryId = :applyHistoryId";
    Query simpleQuery = Mockito.mock(Query.class);
    when(entityManager.createQuery(sel)).thenReturn(simpleQuery);
    wechatJobService.saveStatus(wechatId, companyId, applyHistoryId, status);
  }

  @Test
  public void testSaveStatusFailed() throws ServiceApplicationException {
    String wechatId = "w001";
    String companyId = "sap";
    Long applyHistoryId = new Long(1);
    String status = "1";
    try {
      wechatJobService.saveStatus(wechatId, companyId, applyHistoryId, status);
    } catch (Exception ex) {
      assertEquals("unable to update the sfjobApplicationId", ex.getMessage());
      assertTrue(ex instanceof ServiceApplicationException);
    }
  }

  @Test
  public void testFindDistinctValuesOfSuccess() throws ServiceApplicationException {
    List<String> values = new ArrayList<String>();
    String companyId = "sap";
    String fieldName = "companyId";
    String sel = "select distinct j." + fieldName + " from WechatJob j where j.companyId = :companyId and j."
        + fieldName + " IS NOT NULL";
    TypedQuery<String> mockedTypedQuery = MockApplicationConfig.fluentMock(TypedQuery.class);
    when(entityManager.createQuery(sel, String.class)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("companyId", companyId)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.getResultList()).thenReturn(values);
    List<String> resultList = wechatJobService.findDistinctValuesOf(fieldName, companyId);
    assertEquals(resultList, values);
  }

  @Test
  public void testFindDistinctValuesOfFailed() throws ServiceApplicationException {
    List<String> values = new ArrayList<String>();
    String companyId = "sap";
    String fieldName = "companyId";
    List<String> resultList = wechatJobService.findDistinctValuesOf(fieldName, companyId);
    assertEquals(resultList, values);
  }

  @Test
  public void testFindDistinctValuesOfEmptyParam() throws ServiceApplicationException {
    List<String> values = new ArrayList<String>();
    String companyId = "";
    String fieldName = "companyId";
    List<String> resultList = wechatJobService.findDistinctValuesOf(fieldName, companyId);
    assertEquals(resultList, values);
  }

  @Test
  public void testDeleteJobByIdSuccess() throws ServiceApplicationException {
    Long jobId = new Long(1);
    String sel = "delete from WechatJob j where j.jobId = :jobId";
    Query simpleQuery = Mockito.mock(Query.class);
    when(entityManager.createQuery(sel)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("jobId", jobId)).thenReturn(simpleQuery);
    when(simpleQuery.executeUpdate()).thenReturn(new Integer(1));
    Integer result = wechatJobService.deleteJobById(jobId);
    assertEquals(result, new Integer(1));
  }

  @Test
  public void testDeleteJobByIdFailed() throws ServiceApplicationException {
    Long jobId = new Long(1);
    String sel = "delete from WechatJob j where j.jobId = :jobId";
    Query simpleQuery = Mockito.mock(Query.class);
    when(entityManager.createQuery(sel)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("jobId", jobId)).thenReturn(simpleQuery);
    when(simpleQuery.executeUpdate()).thenThrow(new PersistenceException());
    Integer result = wechatJobService.deleteJobById(jobId);
    assertEquals(result, new Integer(-1));
  }

  @Test
  public void testGetJobInfoListSuccessWithFilter() throws ServiceApplicationException {
    List<WechatJob> jobInfoList = new ArrayList<WechatJob>();
    JobDynSearchBean searchBean = new JobDynSearchBean();
    List<JobDynSearchBeanItem> items = new ArrayList<JobDynSearchBeanItem>();
    JobDynSearchBeanItem item = new JobDynSearchBeanItem();
    item.setType("location");
    items.add(item);
    searchBean.setItems(items);
    searchBean.setInputFilterValue("abc");
    searchBean.setOrderBy("externalJobId desc");
    String companyId = "sap";
    String inputFilterValue = "abc";
    String sel = "select j from WechatJob j where j.companyId = :companyId and j.location in :location AND ( LOWER(j.jobTitle) like LOWER(:inputFilterValue) OR j.externalJobId like :externalId) AND ((j.postStartDate <= CURRENT_DATE AND j.postEndDate >= CURRENT_DATE) OR (j.postStartDate <= CURRENT_DATE AND j.postEndDate = null) OR (j.postStartDate = null AND j.postEndDate = null)) order by length(j.externalJobId) desc, j.externalJobId desc";
    TypedQuery<WechatJob> mockedTypedQuery = MockApplicationConfig.fluentMock(TypedQuery.class);
    when(entityManager.createQuery(sel, WechatJob.class)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("companyId", companyId)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("inputFilterValue", inputFilterValue)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("externalId", inputFilterValue)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("location", "location")).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setFirstResult(1)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setMaxResults(10)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.getResultList()).thenReturn(jobInfoList);
    List<WechatJob> resultList = wechatJobService.getJobInfoList(searchBean);
    assertEquals(resultList, jobInfoList);
  }

  @Test
  public void testGetJobInfoListSuccessWithoutFilter() throws ServiceApplicationException {
    List<WechatJob> jobInfoList = new ArrayList<WechatJob>();
    JobDynSearchBean searchBean = new JobDynSearchBean();
    List<JobDynSearchBeanItem> items = new ArrayList<JobDynSearchBeanItem>();
    searchBean.setItems(items);
    searchBean.setOrderBy("externalJobId asc");
    String companyId = "sap";
    String inputFilterValue = "abc";
    String status = "1";
    String sel = "select j from WechatJob j where j.companyId = :companyId AND ((j.postStartDate <= CURRENT_DATE AND j.postEndDate >= CURRENT_DATE) OR (j.postStartDate <= CURRENT_DATE AND j.postEndDate = null) OR (j.postStartDate = null AND j.postEndDate = null)) order by length(j.externalJobId) asc, j.externalJobId asc";
    TypedQuery<WechatJob> mockedTypedQuery = MockApplicationConfig.fluentMock(TypedQuery.class);
    when(entityManager.createQuery(sel, WechatJob.class)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("companyId", companyId)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("inputFilterValue", inputFilterValue)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("externalId", inputFilterValue)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("status", status)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("location", "location")).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setFirstResult(1)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setMaxResults(10)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.getResultList()).thenReturn(jobInfoList);
    List<WechatJob> resultList = wechatJobService.getJobInfoList(searchBean);
    assertEquals(resultList, jobInfoList);
  }

  @Test
  public void testGetJobInfoListSuccessWithOrderby() throws ServiceApplicationException {
    List<WechatJob> jobInfoList = new ArrayList<WechatJob>();
    JobDynSearchBean searchBean = new JobDynSearchBean();
    List<JobDynSearchBeanItem> items = new ArrayList<JobDynSearchBeanItem>();
    searchBean.setItems(items);
    searchBean.setOrderBy("location asc");
    String companyId = "sap";
    String inputFilterValue = "abc";
    String status = "1";
    String sel = "select j from WechatJob j where j.companyId = :companyId AND ((j.postStartDate <= CURRENT_DATE AND j.postEndDate >= CURRENT_DATE) OR (j.postStartDate <= CURRENT_DATE AND j.postEndDate = null) OR (j.postStartDate = null AND j.postEndDate = null)) order by j.location asc";
    TypedQuery<WechatJob> mockedTypedQuery = MockApplicationConfig.fluentMock(TypedQuery.class);
    when(entityManager.createQuery(sel, WechatJob.class)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("companyId", companyId)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("inputFilterValue", inputFilterValue)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("externalId", inputFilterValue)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("status", status)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("location", "location")).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setFirstResult(1)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setMaxResults(10)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.getResultList()).thenReturn(jobInfoList);
    List<WechatJob> resultList = wechatJobService.getJobInfoList(searchBean);
    assertEquals(resultList, jobInfoList);
  }

  @Test
  public void testGetJobInfoListSuccessWithoutOrderby() throws ServiceApplicationException {
    List<WechatJob> jobInfoList = new ArrayList<WechatJob>();
    JobDynSearchBean searchBean = new JobDynSearchBean();
    String companyId = "sap";
    String inputFilterValue = "abc";
    String status = "1";
    String sel = "select j from WechatJob j where j.companyId = :companyId AND ((j.postStartDate <= CURRENT_DATE AND j.postEndDate >= CURRENT_DATE) OR (j.postStartDate <= CURRENT_DATE AND j.postEndDate = null) OR (j.postStartDate = null AND j.postEndDate = null)) order by j.";
    TypedQuery<WechatJob> mockedTypedQuery = MockApplicationConfig.fluentMock(TypedQuery.class);
    when(entityManager.createQuery(sel, WechatJob.class)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("companyId", companyId)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("inputFilterValue", inputFilterValue)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("externalId", inputFilterValue)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("status", status)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("location", "location")).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setFirstResult(1)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setMaxResults(10)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.getResultList()).thenReturn(jobInfoList);
    List<WechatJob> resultList = wechatJobService.getJobInfoList(searchBean);
    assertEquals(resultList, jobInfoList);
  }

  @Test
  public void testGetJobInfoListFailed() throws ServiceApplicationException {
    JobDynSearchBean searchBean = new JobDynSearchBean();
    try {
      wechatJobService.getJobInfoList(searchBean);
    } catch (Exception ex) {
      assertTrue(ex.getMessage().contains("failed to read job list"));
      assertTrue(ex instanceof ServiceApplicationException);
    }
  }

  @Test
  public void testGetTotalCountSuccess() throws ServiceApplicationException {
    JobDynSearchBean searchBean = new JobDynSearchBean();
    String companyId = "sap";
    String sel = "select count(j) from WechatJob j where j.companyId = :companyId AND ((j.postStartDate <= CURRENT_DATE AND j.postEndDate >= CURRENT_DATE) OR (j.postStartDate <= CURRENT_DATE AND j.postEndDate = null) OR (j.postStartDate = null AND j.postEndDate = null))";
    TypedQuery<WechatJob> mockedTypedQuery = MockApplicationConfig.fluentMock(TypedQuery.class);
    when(entityManager.createQuery(sel, WechatJob.class)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("companyId", companyId)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.getSingleResult()).thenReturn(null);
    Long result = wechatJobService.getTotalCount(searchBean);
    assertEquals(result, null);
  }

  @Test
  public void testGetTotalCountFailed() throws ServiceApplicationException {
    JobDynSearchBean searchBean = new JobDynSearchBean();
    try {
      wechatJobService.getTotalCount(searchBean);
    } catch (Exception ex) {
      assertTrue(ex.getMessage().contains("failed to read job list"));
      assertTrue(ex instanceof ServiceApplicationException);
    }
  }

  @Test
  public void testGetApplyHistoryStaticsByYearSuccess() throws ServiceApplicationException {
    List<KeyLabelBean> keyLabelBeanList = new ArrayList<KeyLabelBean>();
    KeyLabelBean bean = new KeyLabelBean();
    bean.setKey("key");
    bean.setLabel("label");
    bean.setAdditionalText("key");
    keyLabelBeanList.add(bean);
    List<Object> rows = new ArrayList<Object>();
    String[] arrRow = { "key", "label" };
    rows.add(arrRow);
    String companyId = "sap";
    String functionType = "1";
    String sel = "select count(h.wechatId) as num , FUNCTION('YEAR',h.applyDate) as year from WechatApplyHistory h where h.companyId = :companyId group by FUNCTION('YEAR',h.applyDate)";
    Query simpleQuery = Mockito.mock(Query.class);
    when(entityManager.createQuery(sel)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("companyId", companyId)).thenReturn(simpleQuery);
    when(simpleQuery.getResultList()).thenReturn(rows);
    String sel2 = "select count(h.logId) as num , FUNCTION('YEAR',h.createAt) as year from ExceptionLog h where h.companyId = :companyId and h.functionType = :functionType group by FUNCTION('YEAR',h.createAt)";
    when(entityManager.createQuery(sel2)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("companyId", companyId)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("functionType", functionType)).thenReturn(simpleQuery);
    when(simpleQuery.getResultList()).thenReturn(rows);
    List<KeyLabelBean> result = wechatJobService.getApplyHistoryStaticsByYear(companyId);
    assertEquals(result, keyLabelBeanList);
  }

  @Test
  public void testGetApplyHistoryStaticsByYearSuccessEmptyParam() throws ServiceApplicationException {
    List<KeyLabelBean> keyLabelBeanList = new ArrayList<KeyLabelBean>();
    KeyLabelBean bean = new KeyLabelBean();
    bean.setKey("key");
    bean.setLabel("label");
    keyLabelBeanList.add(bean);
    List<Object> rows = new ArrayList<Object>();
    String[] arrRow = { "key", "label" };
    rows.add(arrRow);
    List<Object> rows2 = new ArrayList<Object>();
    String[] arrRow2 = { null, null };
    rows2.add(arrRow2);
    String companyId = "";
    String functionType = "1";
    String sel = "select count(h.wechatId) as num , FUNCTION('YEAR',h.applyDate) as year from WechatApplyHistory h where h.companyId = :companyId group by FUNCTION('YEAR',h.applyDate)";
    Query simpleQuery = Mockito.mock(Query.class);
    when(entityManager.createQuery(sel)).thenReturn(simpleQuery);
    when(simpleQuery.getResultList()).thenReturn(rows);
    String sel2 = "select count(h.logId) as num , FUNCTION('YEAR',h.createAt) as year from ExceptionLog h where h.companyId = :companyId and h.functionType = :functionType group by FUNCTION('YEAR',h.createAt)";
    Query query2 = MockApplicationConfig.fluentMock(Query.class);
    when(entityManager.createQuery(sel2)).thenReturn(query2);
    when(query2.setParameter("functionType", functionType)).thenReturn(query2);
    when(query2.getResultList()).thenReturn(rows2);
    List<KeyLabelBean> result = wechatJobService.getApplyHistoryStaticsByYear(companyId);
    assertEquals(result, keyLabelBeanList);
  }

  @Test
  public void testGetApplyHistoryStaticsByYearSuccessIsNull() throws ServiceApplicationException {
    List<KeyLabelBean> keyLabelBeanList = new ArrayList<KeyLabelBean>();
    KeyLabelBean bean = new KeyLabelBean();
    bean.setKey("key");
    bean.setLabel("label");
    bean.setAdditionalText("");
    keyLabelBeanList.add(bean);
    List<Object> rows = new ArrayList<Object>();
    String[] arrRow = { "key", "label" };
    rows.add(arrRow);
    List<Object> rows2 = new ArrayList<Object>();
    String[] arrRow2 = { null, "label" };
    rows2.add(arrRow2);
    String companyId = "";
    String functionType = "1";
    String sel = "select count(h.wechatId) as num , FUNCTION('YEAR',h.applyDate) as year from WechatApplyHistory h where h.companyId = :companyId group by FUNCTION('YEAR',h.applyDate)";
    Query simpleQuery = Mockito.mock(Query.class);
    when(entityManager.createQuery(sel)).thenReturn(simpleQuery);
    when(simpleQuery.getResultList()).thenReturn(rows);
    String sel2 = "select count(h.logId) as num , FUNCTION('YEAR',h.createAt) as year from ExceptionLog h where h.companyId = :companyId and h.functionType = :functionType group by FUNCTION('YEAR',h.createAt)";
    Query query2 = MockApplicationConfig.fluentMock(Query.class);
    when(entityManager.createQuery(sel2)).thenReturn(query2);
    when(query2.setParameter("functionType", functionType)).thenReturn(query2);
    when(query2.getResultList()).thenReturn(rows2);
    List<KeyLabelBean> result = wechatJobService.getApplyHistoryStaticsByYear(companyId);
    assertEquals(result, keyLabelBeanList);
  }

  @Test
  public void testGetApplyHistoryStaticsByYearSuccessNoDataSelected() throws ServiceApplicationException {
    List<KeyLabelBean> keyLabelBeanList = new ArrayList<KeyLabelBean>();
    KeyLabelBean bean = new KeyLabelBean();
    bean.setKey("");
    bean.setLabel("");
    keyLabelBeanList.add(bean);
    List<Object> rows = new ArrayList<Object>();
    String[] arrRow = { null, null };
    rows.add(arrRow);
    List<Object> rows2 = new ArrayList<Object>();
    String[] arrRow2 = { null, "label" };
    rows2.add(arrRow2);
    String companyId = "";
    String functionType = "1";
    String sel = "select count(h.wechatId) as num , FUNCTION('YEAR',h.applyDate) as year from WechatApplyHistory h where h.companyId = :companyId group by FUNCTION('YEAR',h.applyDate)";
    Query simpleQuery = Mockito.mock(Query.class);
    when(entityManager.createQuery(sel)).thenReturn(simpleQuery);
    when(simpleQuery.getResultList()).thenReturn(rows);
    String sel2 = "select count(h.logId) as num , FUNCTION('YEAR',h.createAt) as year from ExceptionLog h where h.companyId = :companyId and h.functionType = :functionType group by FUNCTION('YEAR',h.createAt)";
    Query query2 = MockApplicationConfig.fluentMock(Query.class);
    when(entityManager.createQuery(sel2)).thenReturn(query2);
    when(query2.setParameter("functionType", functionType)).thenReturn(query2);
    when(query2.getResultList()).thenReturn(rows2);
    List<KeyLabelBean> result = wechatJobService.getApplyHistoryStaticsByYear(companyId);
    assertEquals(result, keyLabelBeanList);
  }

  @Test
  public void testGetApplyHistoryStaticsByYearSuccessNoRows() throws ServiceApplicationException {
    List<KeyLabelBean> keyLabelBeanList = new ArrayList<KeyLabelBean>();
    String companyId = "";
    String functionType = "1";
    List<Object> rows = new ArrayList<Object>();
    List<Object> rows2 = new ArrayList<Object>();
    String sel = "select count(h.wechatId) as num , FUNCTION('YEAR',h.applyDate) as year from WechatApplyHistory h where h.companyId = :companyId group by FUNCTION('YEAR',h.applyDate)";
    Query simpleQuery = Mockito.mock(Query.class);
    when(entityManager.createQuery(sel)).thenReturn(simpleQuery);
    when(simpleQuery.getResultList()).thenReturn(rows);
    String sel2 = "select count(h.logId) as num , FUNCTION('YEAR',h.createAt) as year from ExceptionLog h where h.companyId = :companyId and h.functionType = :functionType group by FUNCTION('YEAR',h.createAt)";
    Query query2 = MockApplicationConfig.fluentMock(Query.class);
    when(entityManager.createQuery(sel2)).thenReturn(query2);
    when(query2.setParameter("functionType", functionType)).thenReturn(query2);
    when(query2.getResultList()).thenReturn(rows2);
    List<KeyLabelBean> result = wechatJobService.getApplyHistoryStaticsByYear(companyId);
    assertEquals(result, keyLabelBeanList);
  }

  @Test
  public void testGetApplyHistoryStaticsByYearSuccessRowIsNull() throws ServiceApplicationException {
    List<KeyLabelBean> keyLabelBeanList = new ArrayList<KeyLabelBean>();
    String companyId = "";
    String functionType = "1";
    String sel = "select count(h.wechatId) as num , FUNCTION('YEAR',h.applyDate) as year from WechatApplyHistory h where h.companyId = :companyId group by FUNCTION('YEAR',h.applyDate)";
    Query simpleQuery = Mockito.mock(Query.class);
    when(entityManager.createQuery(sel)).thenReturn(simpleQuery);
    when(simpleQuery.getResultList()).thenReturn(null);
    String sel2 = "select count(h.logId) as num , FUNCTION('YEAR',h.createAt) as year from ExceptionLog h where h.companyId = :companyId and h.functionType = :functionType group by FUNCTION('YEAR',h.createAt)";
    Query query2 = MockApplicationConfig.fluentMock(Query.class);
    when(entityManager.createQuery(sel2)).thenReturn(query2);
    when(query2.setParameter("functionType", functionType)).thenReturn(query2);
    when(query2.getResultList()).thenReturn(null);
    List<KeyLabelBean> result = wechatJobService.getApplyHistoryStaticsByYear(companyId);
    assertEquals(result, keyLabelBeanList);
  }

  @Test
  public void testGetTotalWechatUserNumberSuccess() throws ServiceApplicationException {
    String companyId = "sap";
    List<Long> rows = new ArrayList<Long>();
    rows.add(new Long(1));
    String sel = "select count(h.wechatId) as num from WechatUser h where h.companyId = :companyId";
    Query simpleQuery = Mockito.mock(Query.class);
    when(entityManager.createQuery(sel)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("companyId", companyId)).thenReturn(simpleQuery);
    when(simpleQuery.getResultList()).thenReturn(rows);
    Long result = wechatJobService.getTotalWechatUserNumber(companyId);
    assertEquals(result, new Long(1));
  }

  @Test
  public void testGetTotalWechatUserNumberSuccessRowIsNull() throws ServiceApplicationException {
    String companyId = "sap";
    String sel = "select count(h.wechatId) as num from WechatUser h where h.companyId = :companyId";
    Query simpleQuery = Mockito.mock(Query.class);
    when(entityManager.createQuery(sel)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("companyId", companyId)).thenReturn(simpleQuery);
    when(simpleQuery.getResultList()).thenReturn(null);
    Long result = wechatJobService.getTotalWechatUserNumber(companyId);
    assertEquals(result, new Long(0));
  }

  @Test
  public void testGetTotalWechatUserNumberSuccessNoRows() throws ServiceApplicationException {
    String companyId = "sap";
    List<Long> rows = new ArrayList<Long>();
    String sel = "select count(h.wechatId) as num from WechatUser h where h.companyId = :companyId";
    Query simpleQuery = Mockito.mock(Query.class);
    when(entityManager.createQuery(sel)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("companyId", companyId)).thenReturn(simpleQuery);
    when(simpleQuery.getResultList()).thenReturn(rows);
    Long result = wechatJobService.getTotalWechatUserNumber(companyId);
    assertEquals(result, new Long(0));
  }

  @Test
  public void testGetTotalWechatUserNumberSuccessEmptyParam() throws ServiceApplicationException {
    String companyId = "";
    List<Long> rows = new ArrayList<Long>();
    String sel = "select count(h.wechatId) as num from WechatUser h where h.companyId = :companyId";
    Query simpleQuery = Mockito.mock(Query.class);
    when(entityManager.createQuery(sel)).thenReturn(simpleQuery);
    when(simpleQuery.getResultList()).thenReturn(rows);
    Long result = wechatJobService.getTotalWechatUserNumber(companyId);
    assertEquals(result, new Long(0));
  }

  @Test
  public void testGetApplyHistoryStaticsByMonthSuccess() throws ServiceApplicationException {
    List<KeyLabelBean> keyLabelBeanList = new ArrayList<KeyLabelBean>();
    KeyLabelBean bean = new KeyLabelBean();
    bean.setKey("2016");
    bean.setLabel("February");
    bean.setAdditionalText("2016");
    keyLabelBeanList.add(bean);
    List<Object> rows = new ArrayList<Object>();
    String[] arrRow = { "2016", "2" };
    rows.add(arrRow);
    List<Object> rows2 = new ArrayList<Object>();
    String[] arrRow2 = { "2016", "2" };
    rows2.add(arrRow2);
    String companyId = "sap";
    String year = "2016";
    String functionType = "1";
    String sel = "select count(h.wechatId) as num , FUNCTION('MONTH',h.applyDate) as month from WechatApplyHistory h where h.companyId = :companyId and FUNCTION('YEAR',h.applyDate) = :year group by FUNCTION('MONTH',h.applyDate) order by month";
    Query simpleQuery = Mockito.mock(Query.class);
    when(entityManager.createQuery(sel)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("companyId", companyId)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("year", year)).thenReturn(simpleQuery);
    when(simpleQuery.getResultList()).thenReturn(rows);
    String sel2 = "select count(h.logId) as num , FUNCTION('MONTH',h.createAt) as month from ExceptionLog h where h.companyId = :companyId and h.functionType = :functionType and FUNCTION('YEAR',h.createAt) = :year group by FUNCTION('MONTH',h.createAt) order by month";
    Query query2 = MockApplicationConfig.fluentMock(Query.class);
    when(entityManager.createQuery(sel2)).thenReturn(query2);
    when(query2.setParameter("companyId", companyId)).thenReturn(query2);
    when(query2.setParameter("year", year)).thenReturn(query2);
    when(query2.setParameter("functionType", functionType)).thenReturn(query2);
    when(query2.getResultList()).thenReturn(rows2);
    List<KeyLabelBean> result = wechatJobService.getApplyHistoryStaticsByMonth(companyId, year);
    assertEquals(result, keyLabelBeanList);
  }

  @Test
  public void testGetApplyHistoryStaticsByMonthSuccessKeyIsNull() throws ServiceApplicationException {
    List<KeyLabelBean> keyLabelBeanList = new ArrayList<KeyLabelBean>();
    KeyLabelBean bean = new KeyLabelBean();
    bean.setKey("2016");
    bean.setLabel("February");
    bean.setAdditionalText("");
    keyLabelBeanList.add(bean);
    List<Object> rows = new ArrayList<Object>();
    String[] arrRow = { "2016", "2" };
    rows.add(arrRow);
    List<Object> rows2 = new ArrayList<Object>();
    String[] arrRow2 = { null, "2" };
    rows2.add(arrRow2);
    String companyId = "sap";
    String year = "2016";
    String functionType = "1";
    String sel = "select count(h.wechatId) as num , FUNCTION('MONTH',h.applyDate) as month from WechatApplyHistory h where h.companyId = :companyId and FUNCTION('YEAR',h.applyDate) = :year group by FUNCTION('MONTH',h.applyDate) order by month";
    Query simpleQuery = Mockito.mock(Query.class);
    when(entityManager.createQuery(sel)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("companyId", companyId)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("year", year)).thenReturn(simpleQuery);
    when(simpleQuery.getResultList()).thenReturn(rows);
    String sel2 = "select count(h.logId) as num , FUNCTION('MONTH',h.createAt) as month from ExceptionLog h where h.companyId = :companyId and h.functionType = :functionType and FUNCTION('YEAR',h.createAt) = :year group by FUNCTION('MONTH',h.createAt) order by month";
    Query query2 = MockApplicationConfig.fluentMock(Query.class);
    when(entityManager.createQuery(sel2)).thenReturn(query2);
    when(query2.setParameter("companyId", companyId)).thenReturn(query2);
    when(query2.setParameter("year", year)).thenReturn(query2);
    when(query2.setParameter("functionType", functionType)).thenReturn(query2);
    when(query2.getResultList()).thenReturn(rows2);
    List<KeyLabelBean> result = wechatJobService.getApplyHistoryStaticsByMonth(companyId, year);
    assertEquals(result, keyLabelBeanList);
  }

  @Test
  public void testGetApplyHistoryStaticsByMonthSuccessMonthNotEqual() throws ServiceApplicationException {
    List<KeyLabelBean> keyLabelBeanList = new ArrayList<KeyLabelBean>();
    KeyLabelBean bean = new KeyLabelBean();
    bean.setKey("2016");
    bean.setLabel("February");
    keyLabelBeanList.add(bean);
    List<Object> rows = new ArrayList<Object>();
    String[] arrRow = { "2016", "2" };
    rows.add(arrRow);
    List<Object> rows2 = new ArrayList<Object>();
    String[] arrRow2 = { "2016", null };
    rows2.add(arrRow2);
    String companyId = "sap";
    String year = "2016";
    String functionType = "1";
    String sel = "select count(h.wechatId) as num , FUNCTION('MONTH',h.applyDate) as month from WechatApplyHistory h where h.companyId = :companyId and FUNCTION('YEAR',h.applyDate) = :year group by FUNCTION('MONTH',h.applyDate) order by month";
    Query simpleQuery = Mockito.mock(Query.class);
    when(entityManager.createQuery(sel)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("companyId", companyId)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("year", year)).thenReturn(simpleQuery);
    when(simpleQuery.getResultList()).thenReturn(rows);
    String sel2 = "select count(h.logId) as num , FUNCTION('MONTH',h.createAt) as month from ExceptionLog h where h.companyId = :companyId and h.functionType = :functionType and FUNCTION('YEAR',h.createAt) = :year group by FUNCTION('MONTH',h.createAt) order by month";
    Query query2 = MockApplicationConfig.fluentMock(Query.class);
    when(entityManager.createQuery(sel2)).thenReturn(query2);
    when(query2.setParameter("companyId", companyId)).thenReturn(query2);
    when(query2.setParameter("year", year)).thenReturn(query2);
    when(query2.setParameter("functionType", functionType)).thenReturn(query2);
    when(query2.getResultList()).thenReturn(rows2);
    List<KeyLabelBean> result = wechatJobService.getApplyHistoryStaticsByMonth(companyId, year);
    assertEquals(result, keyLabelBeanList);
  }

  @Test
  public void testGetApplyHistoryStaticsByMonthSuccessMonthIsNull() throws ServiceApplicationException {
    List<KeyLabelBean> keyLabelBeanList = new ArrayList<KeyLabelBean>();
    KeyLabelBean bean = new KeyLabelBean();
    bean.setKey("");
    bean.setLabel("Unknown");
    keyLabelBeanList.add(bean);
    List<Object> rows = new ArrayList<Object>();
    String[] arrRow = { null, null };
    rows.add(arrRow);
    List<Object> rows2 = new ArrayList<Object>();
    String[] arrRow2 = { "2016", "2" };
    rows2.add(arrRow2);
    String companyId = "sap";
    String year = "2016";
    String functionType = "1";
    String sel = "select count(h.wechatId) as num , FUNCTION('MONTH',h.applyDate) as month from WechatApplyHistory h where h.companyId = :companyId and FUNCTION('YEAR',h.applyDate) = :year group by FUNCTION('MONTH',h.applyDate) order by month";
    Query simpleQuery = Mockito.mock(Query.class);
    when(entityManager.createQuery(sel)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("companyId", companyId)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("year", year)).thenReturn(simpleQuery);
    when(simpleQuery.getResultList()).thenReturn(rows);
    String sel2 = "select count(h.logId) as num , FUNCTION('MONTH',h.createAt) as month from ExceptionLog h where h.companyId = :companyId and h.functionType = :functionType and FUNCTION('YEAR',h.createAt) = :year group by FUNCTION('MONTH',h.createAt) order by month";
    Query query2 = MockApplicationConfig.fluentMock(Query.class);
    when(entityManager.createQuery(sel2)).thenReturn(query2);
    when(query2.setParameter("companyId", companyId)).thenReturn(query2);
    when(query2.setParameter("year", year)).thenReturn(query2);
    when(query2.setParameter("functionType", functionType)).thenReturn(query2);
    when(query2.getResultList()).thenReturn(rows2);
    List<KeyLabelBean> result = wechatJobService.getApplyHistoryStaticsByMonth(companyId, year);
    assertEquals(result, keyLabelBeanList);
  }

  @Test
  public void testGetApplyHistoryStaticsByMonthSuccessRowsIsEmpty() throws ServiceApplicationException {
    List<KeyLabelBean> keyLabelBeanList = new ArrayList<KeyLabelBean>();
    List<Object> rows = new ArrayList<Object>();
    List<Object> rows2 = new ArrayList<Object>();
    String companyId = "sap";
    String year = "2016";
    String functionType = "1";
    String sel = "select count(h.wechatId) as num , FUNCTION('MONTH',h.applyDate) as month from WechatApplyHistory h where h.companyId = :companyId and FUNCTION('YEAR',h.applyDate) = :year group by FUNCTION('MONTH',h.applyDate) order by month";
    Query simpleQuery = Mockito.mock(Query.class);
    when(entityManager.createQuery(sel)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("companyId", companyId)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("year", year)).thenReturn(simpleQuery);
    when(simpleQuery.getResultList()).thenReturn(rows);
    String sel2 = "select count(h.logId) as num , FUNCTION('MONTH',h.createAt) as month from ExceptionLog h where h.companyId = :companyId and h.functionType = :functionType and FUNCTION('YEAR',h.createAt) = :year group by FUNCTION('MONTH',h.createAt) order by month";
    Query query2 = MockApplicationConfig.fluentMock(Query.class);
    when(entityManager.createQuery(sel2)).thenReturn(query2);
    when(query2.setParameter("companyId", companyId)).thenReturn(query2);
    when(query2.setParameter("year", year)).thenReturn(query2);
    when(query2.setParameter("functionType", functionType)).thenReturn(query2);
    when(query2.getResultList()).thenReturn(rows2);
    List<KeyLabelBean> result = wechatJobService.getApplyHistoryStaticsByMonth(companyId, year);
    assertEquals(result, keyLabelBeanList);
  }

  @Test
  public void testGetApplyHistoryStaticsByMonthSuccessRowsIsNull() throws ServiceApplicationException {
    List<KeyLabelBean> keyLabelBeanList = new ArrayList<KeyLabelBean>();
    String companyId = "sap";
    String year = "2016";
    String functionType = "1";
    String sel = "select count(h.wechatId) as num , FUNCTION('MONTH',h.applyDate) as month from WechatApplyHistory h where h.companyId = :companyId and FUNCTION('YEAR',h.applyDate) = :year group by FUNCTION('MONTH',h.applyDate) order by month";
    Query simpleQuery = Mockito.mock(Query.class);
    when(entityManager.createQuery(sel)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("companyId", companyId)).thenReturn(simpleQuery);
    when(simpleQuery.setParameter("year", year)).thenReturn(simpleQuery);
    when(simpleQuery.getResultList()).thenReturn(null);
    String sel2 = "select count(h.logId) as num , FUNCTION('MONTH',h.createAt) as month from ExceptionLog h where h.companyId = :companyId and h.functionType = :functionType and FUNCTION('YEAR',h.createAt) = :year group by FUNCTION('MONTH',h.createAt) order by month";
    Query query2 = MockApplicationConfig.fluentMock(Query.class);
    when(entityManager.createQuery(sel2)).thenReturn(query2);
    when(query2.setParameter("companyId", companyId)).thenReturn(query2);
    when(query2.setParameter("year", year)).thenReturn(query2);
    when(query2.setParameter("functionType", functionType)).thenReturn(query2);
    when(query2.getResultList()).thenReturn(null);
    List<KeyLabelBean> result = wechatJobService.getApplyHistoryStaticsByMonth(companyId, year);
    assertEquals(result, keyLabelBeanList);
  }

  @Test
  public void testGetApplyHistoryStaticsByMonthSuccessParamIsEmpty() throws ServiceApplicationException {
    List<KeyLabelBean> keyLabelBeanList = new ArrayList<KeyLabelBean>();
    List<Object> rows = new ArrayList<Object>();
    List<Object> rows2 = new ArrayList<Object>();
    String companyId = "";
    String year = "";
    String functionType = "1";
    String sel = "select count(h.wechatId) as num , FUNCTION('MONTH',h.applyDate) as month from WechatApplyHistory h where h.companyId = :companyId and FUNCTION('YEAR',h.applyDate) = :year group by FUNCTION('MONTH',h.applyDate) order by month";
    Query simpleQuery = Mockito.mock(Query.class);
    when(entityManager.createQuery(sel)).thenReturn(simpleQuery);
    when(simpleQuery.getResultList()).thenReturn(rows);
    String sel2 = "select count(h.logId) as num , FUNCTION('MONTH',h.createAt) as month from ExceptionLog h where h.companyId = :companyId and h.functionType = :functionType and FUNCTION('YEAR',h.createAt) = :year group by FUNCTION('MONTH',h.createAt) order by month";
    Query query2 = MockApplicationConfig.fluentMock(Query.class);
    when(entityManager.createQuery(sel2)).thenReturn(query2);
    when(query2.setParameter("functionType", functionType)).thenReturn(query2);
    when(query2.getResultList()).thenReturn(rows2);
    List<KeyLabelBean> result = wechatJobService.getApplyHistoryStaticsByMonth(companyId, year);
    assertEquals(result, keyLabelBeanList);
  }

  @Test
  public void testGetFilterListByConfigWithPicklist() throws ServiceApplicationException {
    String companyId = "sap";
    Locale locale = Locale.CHINA;
    String picklistName = "heheda";
    String label = "haha";
    Set<JobReqDataModelMappingItem> fieldSet = new HashSet<JobReqDataModelMappingItem>();
    JobReqDataModelMappingItem mappingItem = new JobReqDataModelMappingItem();
    mappingItem.setPicklist(picklistName);
    fieldSet.add(mappingItem);
    when(dataModelMappingService.getFilterableFieldsForJobRequisition(companyId)).thenReturn(fieldSet);
    List<SFPicklistItem> itemList = new ArrayList<SFPicklistItem>();
    SFPicklistItem pkItem = new SFPicklistItem();
    pkItem.setLabel(label);
    itemList.add(pkItem);
    when(
        pklCacheService.getPicklistOptionsByName(companyId, picklistName, locale.toString(),
            SFPicklistCacheEntityType.JOB_REQUISITION.name())).thenReturn(itemList);
    List<FilterListItem> result = wechatJobService.getFilterListByConfig(companyId, locale);
    assertEquals(label, result.get(0).getValues().get(0).getLabel());
  }

  @Test
  public void testGetFilterListByConfigWithoutPicklist() throws ServiceApplicationException {
    String companyId = "sap";
    Locale locale = Locale.CHINA;
    String picklistName = "heheda";
    String label = "haha";
    List<String> values = new ArrayList<String>();
    values.add(label);
    values.add("123 iuy");
    values.add("45 adf");
    String fieldName = "companyId";
    String sel = "select distinct j." + fieldName + " from WechatJob j where j.companyId = :companyId and j."
        + fieldName + " IS NOT NULL";
    TypedQuery<String> mockedTypedQuery = MockApplicationConfig.fluentMock(TypedQuery.class);
    when(entityManager.createQuery(sel, String.class)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.setParameter("companyId", companyId)).thenReturn(mockedTypedQuery);
    when(mockedTypedQuery.getResultList()).thenReturn(values);

    Set<JobReqDataModelMappingItem> fieldSet = new HashSet<JobReqDataModelMappingItem>();
    JobReqDataModelMappingItem mappingItem = new JobReqDataModelMappingItem();
    mappingItem.setSourceField(fieldName);
    fieldSet.add(mappingItem);
    when(dataModelMappingService.getFilterableFieldsForJobRequisition(companyId)).thenReturn(fieldSet);
    List<SFPicklistItem> itemList = new ArrayList<SFPicklistItem>();
    SFPicklistItem pkItem = new SFPicklistItem();
    pkItem.setLabel(label);
    itemList.add(pkItem);
    when(
        pklCacheService.getPicklistOptionsByName(companyId, picklistName, locale.toString(),
            SFPicklistCacheEntityType.JOB_REQUISITION.name())).thenReturn(itemList);
    List<FilterListItem> result = wechatJobService.getFilterListByConfig(companyId, locale);
    assertEquals("45 adf", result.get(0).getValues().get(0).getLabel());
  }
}
