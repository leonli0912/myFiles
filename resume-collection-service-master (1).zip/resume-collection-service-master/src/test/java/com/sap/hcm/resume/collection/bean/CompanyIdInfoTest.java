package com.sap.hcm.resume.collection.bean;

import org.junit.Assert;
import org.junit.Test;

public class CompanyIdInfoTest {
  
  @Test
  public void testGetterSetter(){
    CompanyIdInfo idInfo = new CompanyIdInfo();
    idInfo.setCompanyId("sap");
    Assert.assertEquals("sap", idInfo.getCompanyId());
  }
}
