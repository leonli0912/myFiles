package com.sap.hcm.resume.collection.service;

import java.text.ParseException;

import org.quartz.Job;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.quartz.CronTriggerFactoryBean;
import org.springframework.scheduling.quartz.MethodInvokingJobDetailFactoryBean;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.scheduling.JobTriggerBean;

@Service
public class JobSchedulerService {

  private static final Logger logger = LoggerFactory.getLogger(JobSchedulerService.class);

  @Autowired
  @Qualifier(value="jobRequisitionSynchronizeScheduler")
  private Job jobRequisitionSynchronizeScheduler;
  
  @Autowired
  private JobTriggerBean jobTriggerBean;
  
  public void resetJob(CompanyInfo companyInfo) throws ServiceApplicationException {

    try {
      MethodInvokingJobDetailFactoryBean methodInvokingJobDetailFactoryBean = new MethodInvokingJobDetailFactoryBean();
      methodInvokingJobDetailFactoryBean.setTargetObject(jobRequisitionSynchronizeScheduler);
      methodInvokingJobDetailFactoryBean.setTargetMethod("work");
      methodInvokingJobDetailFactoryBean.setConcurrent(false);
      methodInvokingJobDetailFactoryBean.setName(companyInfo.getCompanyId() + "_Job");
      String[] arguments = new String[]{companyInfo.getCompanyId()};
      methodInvokingJobDetailFactoryBean.setArguments(arguments);
      methodInvokingJobDetailFactoryBean.afterPropertiesSet();
      
      CronTriggerFactoryBean cronTriggerFactoryBean = new CronTriggerFactoryBean();
      cronTriggerFactoryBean.setJobDetail(methodInvokingJobDetailFactoryBean.getObject());
      String cronExpression = companyInfo.getTriggerExpression();
      if (StringUtils.isEmpty(cronExpression)) {
        cronExpression = "0 0 0 * * ?";
      }
      cronTriggerFactoryBean.setCronExpression(cronExpression);
      cronTriggerFactoryBean.setName(companyInfo.getCompanyId() + "_Trigger");
      cronTriggerFactoryBean.afterPropertiesSet();
      
      Scheduler scheduler = jobTriggerBean.getSchedulerFactoryBean().getScheduler();
      JobKey jobKey = new JobKey(companyInfo.getCompanyId() + "_Job");
      if (scheduler.checkExists(jobKey)) {
        scheduler.deleteJob(jobKey);
      }
      scheduler.scheduleJob(methodInvokingJobDetailFactoryBean.getObject(), cronTriggerFactoryBean.getObject());
    } catch (ParseException e) {
      logger.error("save company failed with error " + e.getMessage());
      throw new ServiceApplicationException("save company failed");
    } catch (SchedulerException | ClassNotFoundException | NoSuchMethodException e) {
      logger.error("save company failed with error " + e.getMessage());
      throw new ServiceApplicationException("save company failed");
    }
  }
}
