
package com.sap.hcm.resume.collection.entity.view;

import java.io.Serializable;

import com.thoughtworks.xstream.annotations.XStreamAlias;

/**
 * @author I324117
 * SAP
 */
@XStreamAlias("apply-required-field")
public class JobApplicationRequiredFieldVO implements Serializable {

  /**
   * serialVersionUID
   */
  private static final long serialVersionUID = 4435598422228021861L;
  
  private Long candidateId;
  private String fieldName;
  private String fieldValue;
  private String fieldLabel;
  private String picklist;
  public Long getCandidateId() {
    return candidateId;
  }
  public void setCandidateId(Long candidateId) {
    this.candidateId = candidateId;
  }
  public String getFieldName() {
    return fieldName;
  }
  public void setFieldName(String fieldName) {
    this.fieldName = fieldName;
  }
  public String getFieldLabel() {
    return fieldLabel;
  }
  public void setFieldLabel(String fieldLabel) {
    this.fieldLabel = fieldLabel;
  }
  public String getFieldValue() {
    return fieldValue;
  }
  public void setFieldValue(String fieldValue) {
    this.fieldValue = fieldValue;
  }

  public String getPicklist() {
    return picklist;
  }
  public void setPicklist(String picklist) {
    this.picklist = picklist;
  }


  

}
