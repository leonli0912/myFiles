sap.ui.define([], function(){
	"use strict";

  var UserInfoUtil = function(){
    this.menu;
  };

  UserInfoUtil.prototype.formatLogoPath = function(val){
    if(val){
      return "photo/"+val;
    }
    return "static/img/SAPLogo.png";
  }

		UserInfoUtil.prototype.createShell = function(content, baseUrl){

			var userModel = this.getUserInfo();
			var oShell = new sap.ui.unified.Shell("main-shell",{
					icon:{path:'user>/company/logoId', formatter:this.formatLogoPath},
					content: content,
					search:new sap.m.Title({
						text:"{i18n>ApplicationTitle}",
						width:"100%",
						textAlign:"Center"
					}),
					headItems:[
						new sap.ui.unified.ShellHeadItem({
							icon:"sap-icon://home",
							tooltip:"Home",
							press:function(){
								location.href = baseUrl;
							}
						})
					],
					headEndItems:[
						new sap.ui.unified.ShellHeadItem({
							icon:"sap-icon://documents",
							tooltip:"documents",
							press:function(){
								window.open("https://uacp2.hana.ondemand.com/viewer/#/product/SLH_social_media_integration_recruiting_service/1609/en-US","_blank");
							}
						})
					],
					user: new sap.ui.unified.ShellHeadUserItem("userInfo",{
						image:"sap-icon://person-placeholder",
						username:"{user>/name}",
						press:jQuery.proxy(this.logout, this)
					})
			});
			oShell.setModel(userModel,"user");
			return oShell;
	}

  UserInfoUtil.prototype.getUserInfo = function(){
    var userInfoUrl = "user/info";
    var oUserModel = new sap.ui.model.json.JSONModel();
		oUserModel.loadData(userInfoUrl,null,false);
    return oUserModel;
  }

  UserInfoUtil.prototype.logout = function(oEvent){
    var oButton = oEvent.getSource();
    if (!this.menu) {
			this.menu = sap.ui.xmlfragment(
				"static.js.layout.shellUserMenu",
				this
			);

      this.menu.attachItemSelect(function(){
        var item = oEvent.getParameter("item");
				if(item.getIcon() === "sap-icon://log"){
					this.proceedLogout();
				}
      }, this);
		}

		var eDock = sap.ui.core.Popup.Dock;
		this.menu.open(this._bKeyboard, oButton, eDock.BeginTop, eDock.BeginBottom, oButton);
  }

  UserInfoUtil.prototype.proceedLogout = function(){
    //fire log out request
//    jQuery.ajax({
//      url:"user/logout",
//      method:"GET"
//    }).success(function(data){
//      if(data == "true"){
//        location.href="";
//      }
//    })
    location.href="user/logout";
  }

  return UserInfoUtil;
});
