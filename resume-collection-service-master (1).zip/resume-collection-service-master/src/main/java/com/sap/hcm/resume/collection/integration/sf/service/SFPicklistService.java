package com.sap.hcm.resume.collection.integration.sf.service;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.apache.olingo.odata2.api.edm.Edm;
import org.apache.olingo.odata2.api.edm.FullQualifiedName;
import org.apache.olingo.odata2.api.edm.provider.AnnotationAttribute;
import org.apache.olingo.odata2.api.edm.provider.EntityType;
import org.apache.olingo.odata2.api.edm.provider.NavigationProperty;
import org.apache.olingo.odata2.api.ep.entry.ODataEntry;
import org.apache.olingo.odata2.api.ep.feed.ODataDeltaFeed;
import org.apache.olingo.odata2.api.exception.ODataException;
import org.apache.olingo.odata2.core.edm.provider.EdmImplProv;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.sf.bean.QueryInfo;
import com.sap.hcm.resume.collection.integration.sf.bean.QueryOptionEnum;
import com.sap.hcm.resume.collection.integration.sf.bean.SFPicklistCacheEntityType;
import com.sap.hcm.resume.collection.integration.sf.bean.SFPicklistItem;
import com.sap.hcm.resume.collection.integration.sf.odata.SFODataService;

@Service
public class SFPicklistService {

  @Autowired
  private SFODataService sfOdataService;
  
  @Autowired
  private SFPicklistCacheService pklCacheService;
  
  @Autowired
  private Params params;

  private Logger logger = LoggerFactory.getLogger(this.getClass());

  /**
   * @param edm
   * @param integrationBean
   * @param pickListName
   * @param localeList
   * @return
   * @throws ServiceApplicationException
   */
  public List<SFPicklistItem> loadPickListOption(String pickListName) throws ServiceApplicationException {
    // String picklistUrl = integrationBean.getUrl()
    // + "Picklist('"
    // + pickListName
    // +
    // "')?$expand=picklistOptions/picklistLabels&$select=picklistOptions/id,picklistOptions/status,picklistOptions/picklistLabels/label,picklistOptions/picklistLabels/locale";

    String expand = "picklistOptions/picklistLabels&$select=picklistOptions/id,picklistOptions/status,picklistOptions/picklistLabels/label,picklistOptions/picklistLabels/locale";
    List<SFPicklistItem> picklistItemList = new ArrayList<SFPicklistItem>();
    List<String> localeList = getSupportedLocaleList();
    InputStream content = null;
    try {
      QueryInfo queryInfo = new QueryInfo("Picklist", pickListName);
      queryInfo.addQueryOption(QueryOptionEnum.EXPAND, expand);

      ODataEntry odataEntry = sfOdataService.readEntry(SFODataService.APPLICATION_JSON, queryInfo);

      Map<String, Object> proMap = odataEntry.getProperties();
      ODataDeltaFeed options = (ODataDeltaFeed) proMap.get("picklistOptions");
      List<ODataEntry> optionList = options.getEntries();
      for (ODataEntry op : optionList) {

        Map<String, Object> opProMap = op.getProperties();
        Long optionId = (Long) opProMap.get("id");
        String status = (String) opProMap.get("status");
        // keep only the active one
        if (!"ACTIVE".equalsIgnoreCase(status)) {
          continue;
        }

        ODataDeltaFeed Labels = (ODataDeltaFeed) opProMap.get("picklistLabels");
        for (ODataEntry lb : Labels.getEntries()) {
          String label = (String) lb.getProperties().get("label");
          String locale = (String) lb.getProperties().get("locale");

          if (localeList != null && !localeList.isEmpty()) {
            if (localeList.contains(locale)) {
              SFPicklistItem picklistItem = new SFPicklistItem();
              picklistItem.setOptionId(optionId);
              picklistItem.setLabel(label);
              picklistItem.setLocale(locale);
              picklistItemList.add(picklistItem);
            } else {
              continue;
            }
          } else {
            SFPicklistItem picklistItem = new SFPicklistItem();
            picklistItem.setOptionId(optionId);
            picklistItem.setLabel(label);
            picklistItem.setLocale(locale);
            picklistItemList.add(picklistItem);
          }

        }
      }

      return picklistItemList;
    } catch (Exception e) {
      logger.error("Failed to read picklist value: " + pickListName + " with exception e: " + e.getMessage());
      throw new ServiceApplicationException("unable to load the picklist options of :" + pickListName);
    } finally {
      IOUtils.closeQuietly(content);
    }
  }

  /**
   * 
   * @param edm
   * @param propName
   * @param entityTypeName
   * @return
   * @throws ServiceApplicationException
   */
  public String getPicklistName(String propName, String entityTypeName)
      throws ServiceApplicationException {
    String picklist = null;
    String picklistAnnoName = "picklist";
    String picklistAnnoPrefix = "sap";
    if (propName == null) {
      return picklist;
    }
    Edm edm = sfOdataService.getEdm();
    try {
      EntityType entityType = ((EdmImplProv) edm).getEdmProvider().getEntityType(
          new FullQualifiedName("SFOData", entityTypeName));
      List<NavigationProperty> naviProps = entityType.getNavigationProperties();
      if (naviProps != null && !naviProps.isEmpty()) {
        for (NavigationProperty navi : naviProps) {
          if (propName.equals(navi.getName())) {

            List<AnnotationAttribute> attrList = navi.getAnnotationAttributes();
            if (attrList != null && !attrList.isEmpty()) {
              for (AnnotationAttribute attr : attrList) {
                if (picklistAnnoName.equals(attr.getName()) && picklistAnnoPrefix.equals(attr.getPrefix())) {
                  picklist = attr.getText();
                }
              }
            }
            break;
          }
        }
      }
    } catch (ODataException e) {
      throw new ServiceApplicationException("Failed to load entity type: " + e.getMessage());
    }
    return picklist;
  }
  
 
  /**
   * get locale List
   * 
   * @return
   */
  private List<String> getSupportedLocaleList() {
    String localeCN = Locale.CHINA.toString();
    String localeUS = Locale.US.toString();
    List<String> localeList = new ArrayList<String>();
    localeList.add(localeCN);
    localeList.add(localeUS);
    return localeList;
  }
  
  public String validateLocale(String locale){
    if ("zh".equals(locale)) {
      locale = "zh_CN";
    } else if ("en".equals(locale)) {
      locale = "en_US";
    }
    boolean isFindLocale = false;

    List<String> picklistLocaleList = pklCacheService.getPicklistLocales(params.getCompanyId(),
        SFPicklistCacheEntityType.CANDIDATE.name());
    if (!picklistLocaleList.isEmpty()) {
      if (picklistLocaleList.indexOf(locale) == -1) {
        for (String pickListLocale : picklistLocaleList) {
          if (pickListLocale.contains(locale.split("_")[0])) {
            locale = pickListLocale;
            isFindLocale = true;
          }
        }
      } else {
        isFindLocale = true;
      }
      if (!isFindLocale) {
        locale = "en_US";
      }
    }
    return locale;
  }
}
