package com.sap.hcm.resume.collection.integration.sf.cdm;

import org.junit.Assert;
import org.junit.Test;

import com.sap.hcm.resume.collection.integration.sf.bean.cdm.SFCDMFieldEnumLabel;

public class SFCDMFieldEnumLabelTest {
  
  @Test
  public void testGetterSetter(){
    SFCDMFieldEnumLabel label = new SFCDMFieldEnumLabel();
    label.setLang("lang");
    label.setText("text");
    
    Assert.assertEquals("lang", label.getLang());
    Assert.assertEquals("text", label.getText());
  }
}
