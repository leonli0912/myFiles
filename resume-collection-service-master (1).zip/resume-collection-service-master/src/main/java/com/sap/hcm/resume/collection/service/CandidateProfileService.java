package com.sap.hcm.resume.collection.service;

import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.entity.CandidateBackground;
import com.sap.hcm.resume.collection.entity.CandidateProfile;
import com.sap.hcm.resume.collection.entity.CandidateProfileExt;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileExtVO;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;
import com.sap.hcm.resume.collection.entity.view.JobApplicationRequiredFieldVO;
import com.sap.hcm.resume.collection.entity.view.JobApplyMappingVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.bean.ApplyDataModelMappingItem;
import com.sap.hcm.resume.collection.util.CandidateDateUtil;
import com.sap.hcm.resume.collection.util.CandidateFileUtil;
import com.sap.hcm.resume.collection.util.CandidateProfileHelper;
import com.sap.hcm.resume.collection.xml.RequiredFieldXMLConverter;

@Service
public class CandidateProfileService {

  @PersistenceContext
  private EntityManager entityManager;

  @Autowired
  private CandidateProfileHelper candidateProfileHelper;

  @Autowired
  private DataModelMappingService dataModelMappingService;

  @Autowired
  private Params params;

  public CandidateProfileVO saveCandidateProfile(CandidateProfileVO profileVO) throws ServiceApplicationException {
    CandidateProfile profile = new CandidateProfile();
    CandidateProfileExtVO extProfile = profileVO.getExtProfile();
    if (extProfile == null) {
      extProfile = new CandidateProfileExtVO();
    }

    extProfile = CandidateFileUtil.handleSpecialFields(extProfile, profileVO);
    profileVO.setExtProfile(extProfile);

    List<CandidateProfileExt> extProfileList = new ArrayList<CandidateProfileExt>();
    List<CandidateBackground> backgroundList = new ArrayList<CandidateBackground>();

    candidateProfileHelper.convertFromProfileUI2DB(profileVO, profile, extProfileList, backgroundList);

    try {
      // additional value set
      profile.setContactEmail(profile.getPrimaryEmail());
      profile.setCountry("CN");

      // save the profile first
      profile = entityManager.merge(profile);
      // update candidateId
      Long candidateId = profile.getCandidateId();

      // save the ext profile
      if (extProfileList.size() > 0) {
        for (CandidateProfileExt ext : extProfileList) {
          ext.setCandidateId(candidateId);
          entityManager.merge(ext);
        }
      }

      // save the background element
      if (backgroundList.size() > 0) {
        for (CandidateBackground bg : backgroundList) {
          bg.setCandidateId(candidateId);
          entityManager.merge(bg);
        }
      }
      profileVO.setCandidateId(candidateId);
    } catch (PersistenceException e) {
      throw new ServiceApplicationException("Error happened when persist the data");
    }
    return profileVO;
  }

  public void saveRequiredFieldsFromCandidateProfileExtVO(Long candidateId,
      List<JobApplicationRequiredFieldVO> fieldList) throws ServiceApplicationException {
    if (candidateId != null && fieldList != null) {
      CandidateProfileExt ext = new CandidateProfileExt();
      ext.setCandidateId(candidateId);
      ext.setCompanyId(params.getCompanyId());
      ext.setParamName("requiredFields");
      ext.setBlobValue(RequiredFieldXMLConverter.convertFromBgElementToXML(fieldList).getBytes(StandardCharsets.UTF_8));
      try {
        entityManager.merge(ext);
      } catch (Exception ex) {
        throw new ServiceApplicationException("unable to save the JobApplicationRequiredField");
      }
    }
  }

  private byte[] getRequiredFieldsFromCandidateProfileExtVO(Long candidateId) {
    byte[] result = null;
    try {
      Query queryProfile = entityManager
          .createQuery(
              "select pfe from CandidateProfileExt pfe where pfe.candidateId = :candidateId and pfe.paramName = 'requiredFields'",
              CandidateProfileExt.class);
      queryProfile.setParameter("candidateId", candidateId);
      CandidateProfileExt candidateProfileExt = (CandidateProfileExt) queryProfile.getSingleResult();
      result = candidateProfileExt.getBlobValue();
    } catch (NoResultException e) {
      return result;
    }
    return result;
  }

  /**
   * find candidate profile by primary email
   * 
   * @param email
   * @return
   */
  public CandidateProfile findCandidateProfileByPrimaryEmail(String email) {
    Query queryProfile = entityManager.createQuery(
        "select pf from CandidateProfile pf where pf.primaryEmail = :primaryEmail", CandidateProfile.class);
    queryProfile.setParameter("primaryEmail", email);

    CandidateProfile profile = (CandidateProfile) queryProfile.getSingleResult();
    return profile;
  }

  public CandidateProfileVO getCandidateProfileById(Long candidateId) {
    CandidateProfileVO profileVO = new CandidateProfileVO();
    CandidateProfile profile = entityManager.find(CandidateProfile.class, candidateId);
    if (profile != null) {
      // get candidate extended profile
      TypedQuery<CandidateProfileExt> queryProfileExt = entityManager.createQuery(
          "select ext from CandidateProfileExt ext where ext.candidateId = :candidateId", CandidateProfileExt.class);
      queryProfileExt.setParameter("candidateId", candidateId);
      List<CandidateProfileExt> extList = queryProfileExt.getResultList();

      // get candidate background
      TypedQuery<CandidateBackground> queryBg = entityManager.createQuery(
          "select bg from CandidateBackground bg where bg.candidateId = :candidateId", CandidateBackground.class);
      queryBg.setParameter("candidateId", candidateId);
      List<CandidateBackground> bgList = queryBg.getResultList();

      profileVO = candidateProfileHelper.convertFromProfileDB2UI(profile, extList, bgList);
    }
    return profileVO;

  }

  /**
   * remove the candidate profile by candidateId
   * 
   * @param candidateId
   */
  public int deleteCandidateProfileById(Long candidateId) {

    int res = -1;

    String deleteProfile = "delete from CandidateProfile p where p.candidateId = :candidateId";
    String deleteExtProfile = "delete from CandidateProfileExt ext where ext.candidateId = :candidateId";
    String deleteBackground = "delete from CandidateBackground bg where bg.candidateId = :candidateId";

    try {

      Query delProfileQuery = entityManager.createQuery(deleteProfile);
      delProfileQuery.setParameter("candidateId", candidateId);
      delProfileQuery.executeUpdate();

      Query delExtProfile = entityManager.createQuery(deleteExtProfile);
      delExtProfile.setParameter("candidateId", candidateId);
      delExtProfile.executeUpdate();

      Query delBackground = entityManager.createQuery(deleteBackground);
      delBackground.setParameter("candidateId", candidateId);
      delBackground.executeUpdate();

      res = 1;
    } catch (PersistenceException e) {
      res = -1;
    }
    return res;

  }

  /**
   * add throw candidate profile
   * 
   * @param candidateProfileVO
   * @param candidateId
   * @return
   * @throws ServiceApplicationException
   * @throws ParseException
   */
  public CandidateProfileVO modifyCandidateProfile(CandidateProfileVO candidateProfileVO, Long candidateId)
      throws ServiceApplicationException, ParseException {
    candidateProfileVO.setCandidateId(candidateId);
    candidateProfileVO.setLastModify(new Date());
    return this.saveCandidateProfile(candidateProfileVO);
  }

  @SuppressWarnings("unchecked")
  public List<JobApplicationRequiredFieldVO> getJobApplicationReqFieldsById(Long candidateId) {

    List<JobApplicationRequiredFieldVO> fieldVOList = new ArrayList<JobApplicationRequiredFieldVO>();
    JobApplyMappingVO jobApplyMappingVO = dataModelMappingService.getApplyDataModelMappingByCompanyId(params
        .getCompanyId());
    if (jobApplyMappingVO != null && jobApplyMappingVO.getItemList() != null) {
      for (ApplyDataModelMappingItem appItem : jobApplyMappingVO.getItemList()) {
        if ("candidateInput".equals(appItem.getSourceNameType())) {
          JobApplicationRequiredFieldVO jobApplicationRequiredFieldVO = new JobApplicationRequiredFieldVO();
          jobApplicationRequiredFieldVO.setCandidateId(candidateId);
          
          String label = candidateProfileHelper.getTranslatedLabel(appItem, params.getLocale());
          jobApplicationRequiredFieldVO.setFieldLabel(label);
          jobApplicationRequiredFieldVO.setFieldName(appItem.getSfDmField());
          jobApplicationRequiredFieldVO.setPicklist(appItem.getPicklist());
          fieldVOList.add(jobApplicationRequiredFieldVO);
        }
      }
    }
    if (candidateId != null) {
      byte[] reqFields = this.getRequiredFieldsFromCandidateProfileExtVO(candidateId);
      if (reqFields != null) {
        List<JobApplicationRequiredFieldVO> fieldVOListFromXML = (List<JobApplicationRequiredFieldVO>) RequiredFieldXMLConverter
            .convertFromXMLToBgElement(new String(reqFields, StandardCharsets.UTF_8));
        for (int i = 0; i < fieldVOList.size(); i++) {
          for (JobApplicationRequiredFieldVO fieldVOFromXML : fieldVOListFromXML) {
            if (fieldVOList.get(i).getFieldName().equals(fieldVOFromXML.getFieldName())) {
              fieldVOList.get(i).setFieldValue(fieldVOFromXML.getFieldValue());
            }
          }
        }
      }
    }

    return fieldVOList;
  }
  
  
  
  /**
   * remove the candidate profile by candidateId
   * 
   * @param candidateId
   */
  public int deleteOverdueCandidate() {
    int res = 0;
    String sel = "select pf from CandidateProfile pf where pf.lastModify < :lastModify";
    TypedQuery<CandidateProfile> query = entityManager.createQuery(sel, CandidateProfile.class);
    query.setParameter("lastModify", CandidateDateUtil.formatDate2DateMinus6Months());
    List<CandidateProfile> profileList = query.getResultList();
    for (CandidateProfile profile : profileList) {
      deleteCandidateProfileById(profile.getCandidateId());
      res++;
    }
    return res;
  }

}
