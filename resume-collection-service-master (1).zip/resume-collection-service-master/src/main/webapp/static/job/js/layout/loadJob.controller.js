jQuery.sap.require("sap.m.MessageBox");
sap.ui.controller("static.job.js.layout.loadJob", {

	/**
	 * Called when a controller is instantiated and its View controls (if
	 * available) are already created. Can be used to modify the View before it
	 * is displayed, to bind event handlers and do other one-time
	 * initialization.
	 *
	 * @memberOf resume-collection-service.loadJob
	 */

	// var bValid;
	sFrom : null,
	sTo : null,
	bValid : null,

	onInit : function() {
		this._iEvent = 0;
	},

	/**
	 * Similar to onAfterRendering, but this hook is invoked before the
	 * controller's View is re-rendered (NOT before the first rendering!
	 * onInit() is used for that one!).
	 *
	 * @memberOf resume-collection-service.loadJob
	 */
	// onBeforeRendering: function() {
	//
	// },
	/**
	 * Called when the View has been rendered (so its HTML is part of the
	 * document). Post-rendering manipulations of the HTML could be done here.
	 * This hook is the same one that SAPUI5 controls get after being rendered.
	 *
	 * @memberOf resume-collection-service.loadJob
	 */
	// onAfterRendering: function() {
	//
	// },
	/**
	 * Called when the Controller is destroyed. Use this one to free resources
	 * and finalize activities.
	 *
	 * @memberOf resume-collection-service.loadJob
	 */
	// onExit: function() {
	//
	// }
	onLoadJob : function(oEvent) {
		var messagePanel = this.getView().byId("messagePanel");
		messagePanel.destroyContent();
		this._router = sap.ui.core.UIComponent.getRouterFor(this);
		var that = this;
		var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;

		var view = this.getView();
		var reqId = view.byId("reqId").getValue();
		
		var cfg = {
			type : 'POST',
			dataType : 'json',
			contentType : 'application/json;charset=UTF-8'
		};

		this.sFrom = this.getView().byId("sStartDate").getValue();
		this.sTo = this.getView().byId("sEndDate").getValue();

		if (!this.sFrom) {
			this.sFrom = "";
		}
		if (!this.sTo) {
			this.sTo = "";
		}

		cfg.url = "job/loadJob";
		view.setBusy(true);
		cfg.url = cfg.url + "?reqId=" + reqId +  "&updateFrom=" + this.sFrom + "&updateTo="
				+ this.sTo;
		
		var successTitle = that.translateText("JOB_LOADED_SUCCESSFULLY_FROM_SF");
		
		var failedTitle = that.translateText("JOB_LOADED_FAIL");
		
		var byPassedTitle = that.translateText("JOB_BYPASSED_FROM_SF");

		var noJobLoadTitle = that.translateText("NO_JOB_LOADED");
		$.ajax(cfg).success(function(data) {
			view.setBusy(false);
			var  successItems = data.loadedJobIdList;
			var  byPassItems = data.passedJobIdList;
			var  failedItems = data.failedJobIdList;
			that._addMsgStip(successItems,data.loaded + " " + successTitle + ":\n","Success");
            that._addMsgStip(failedItems,data.failed + " " + failedTitle+":\n","Error");
			that._addMsgStip(byPassItems,data.passed + " " + byPassedTitle +  ":\n","Warning");
			if(successItems.length == 0 && byPassItems.length == 0 && failedItems.length ==0){
				failedItems = noJobLoadTitle;
				 that._addMsgStip(failedItems,"","Warning");
			}

		});
	},
	_addMsgStip: function(items,itemStatus,msgStripType){
        var messagePanel = this.getView().byId("messagePanel");
        if(items){
                var itemMsg=items;
                var oMsgStrip = new sap.m.MessageStrip({
                        text:itemStatus+itemMsg,
                        showCloseButton: true,
                        showIcon: true,
                        type: msgStripType
                });    
                oMsgStrip.addStyleClass("sapUiMediumMarginBottom")
                messagePanel.addContent(oMsgStrip);
        }
	},

	translateText : function(val) {
		return this.getView().getModel("wi18n").getResourceBundle().getText(val);
	},
	onButtonPress : function() {
		this._router = sap.ui.core.UIComponent.getRouterFor(this);
		var that = this;
		that._router.navTo("maintainJob", true);
	},
	showVideoInfoMessage : function(oEvent) {
		// create popover
		if (!this._oPopover) {
			this._oPopover = sap.ui.xmlfragment("static.job.js.layout.videoUploadHelp", this);
			this.getView().addDependent(this._oPopover);
		}

		// delay because addDependent will do a async rerendering and the actionSheet will immediately close without it.
		this._oPopover.openBy(oEvent.getSource());

	},
	handleClosePress : function(oEvent) {
		this._oPopover.close();
	}
});
