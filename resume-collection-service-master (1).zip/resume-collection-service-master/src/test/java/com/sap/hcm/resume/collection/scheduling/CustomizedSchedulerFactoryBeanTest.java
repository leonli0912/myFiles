package com.sap.hcm.resume.collection.scheduling;

import static org.junit.Assert.fail;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;

import com.sap.hcm.resume.collection.context.TestContext;
import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.service.CompanyInfoService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { TestContext.class })
public class CustomizedSchedulerFactoryBeanTest {

  @Autowired
  @Qualifier(value="jobRequisitionSynchronizeScheduler")
  private JobRequisitionSynchronizeScheduler jobRequisitionSynchronizeScheduler;

  @Autowired
  @Qualifier(value="changeLogCleanScheduler")
  private ChangeLogCleanScheduler changeLogCleanScheduler;

  @Autowired
  private CompanyInfoService companyInfoService;
  
  @Autowired
  private JobTriggerBean jobTriggerBean;
  
  private CustomizedSchedulerFactoryBean customizedSchedulerFactoryBean;
  
  @Before
  public void setUp() {
    reset(jobRequisitionSynchronizeScheduler);
    reset(changeLogCleanScheduler);
    reset(companyInfoService);
    reset(jobTriggerBean);
    customizedSchedulerFactoryBean = new CustomizedSchedulerFactoryBean();
    ReflectionTestUtils.setField(customizedSchedulerFactoryBean, "jobRequisitionSynchronizeScheduler", jobRequisitionSynchronizeScheduler);
    ReflectionTestUtils.setField(customizedSchedulerFactoryBean, "changeLogCleanScheduler", changeLogCleanScheduler);
    ReflectionTestUtils.setField(customizedSchedulerFactoryBean, "companyInfoService", companyInfoService);
    ReflectionTestUtils.setField(customizedSchedulerFactoryBean, "jobTriggerBean", jobTriggerBean);
  }
  
  @Test
  public void testTriggerSuccess() throws ServiceApplicationException {
    try {
      List<CompanyInfo> companyInfoList = new ArrayList<CompanyInfo>();
      CompanyInfo info = new CompanyInfo();
      info.setCompanyId("sap");
      info.setTriggerExpression("0 0 0 * * ?");
      companyInfoList.add(info);
      when(companyInfoService.findAllCompany()).thenReturn(companyInfoList);
      customizedSchedulerFactoryBean.trigger();
    } catch(Exception e) {
      fail();
    }
  }
  
  @Test
  public void testTriggerExpressionIsNull() throws ServiceApplicationException {
    try {
      List<CompanyInfo> companyInfoList = new ArrayList<CompanyInfo>();
      CompanyInfo info = new CompanyInfo();
      info.setCompanyId("sap");
      companyInfoList.add(info);
      when(companyInfoService.findAllCompany()).thenReturn(companyInfoList);
      customizedSchedulerFactoryBean.trigger();
    } catch(Exception e) {
      fail();
    }
  }
}
