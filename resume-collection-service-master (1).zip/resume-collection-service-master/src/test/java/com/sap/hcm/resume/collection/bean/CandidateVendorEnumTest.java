package com.sap.hcm.resume.collection.bean;

import org.junit.Assert;
import org.junit.Test;

public class CandidateVendorEnumTest {
  
  @Test
  public void testValidVendor(){
    CandidateVendorEnum vendor = CandidateVendorEnum.fromVendorCode("ZHILIAN");
    Assert.assertEquals(vendor.getVendorName(), "智联招聘");
  }
  
  @Test
  public void testInValidVendor(){
    CandidateVendorEnum vendor = CandidateVendorEnum.fromVendorCode("XXX");
    Assert.assertNull(vendor);
  }
  
  
}
