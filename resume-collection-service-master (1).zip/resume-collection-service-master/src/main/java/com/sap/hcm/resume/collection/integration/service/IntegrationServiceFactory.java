package com.sap.hcm.resume.collection.integration.service;

import com.sap.hcm.resume.collection.bean.BusinessEntityType;

/**
 * @author I075908 SAP
 */
public interface IntegrationServiceFactory {
  IntegrationService create(BusinessEntityType type);
}
