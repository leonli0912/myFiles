package com.sap.hcm.resume.collection.bean;

import org.junit.Assert;
import org.junit.Test;

public class JobReqScreeningQuestionTest {
  
  @Test
  public void testGetterSetter(){
    JobReqScreeningQuestion req = new JobReqScreeningQuestion();
    req.setChoices(null);
    req.setMaxLength("10");
    req.setQuestionId("123");
    req.setQuestionName("question");
    req.setQuestionOrder("1");
    req.setQuestionType("type");
    req.setRequired(true);
    
    Assert.assertEquals("10", req.getMaxLength());
    Assert.assertNull(req.getChoices());
    Assert.assertEquals("123", req.getQuestionId());
    Assert.assertEquals("question", req.getQuestionName());
    Assert.assertEquals("1", req.getQuestionOrder());
    Assert.assertEquals("type", req.getQuestionType());
    Assert.assertEquals(true, req.isRequired());
  }
}
