package com.sap.hcm.resume.collection.bean;

import java.util.Locale;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;

/**
 * @author I073999 SAP
 */
@Component
@Scope(value = "session", proxyMode = ScopedProxyMode.TARGET_CLASS)
public class Params {
  
  private String companyId;
  
  private String wechatOpenId;
  
  /**
   * add a new global variant , user Email
   */
  private String userEmail;
  
  private Locale locale;
  
  public String getCompanyId() {
    return companyId;
  }

  public void setCompanyId(String companyId) {
    this.companyId = companyId;
  }

  /**
   * @return the wechatId
   */
  public String getWechatOpenId() {
    return wechatOpenId;
  }

  /**
   * @param wechatId the wechatId to set
   */
  public void setWechatOpenId(String wechatId) {
    this.wechatOpenId = wechatId;
  }

  /**
   * @return the locale
   */
  public Locale getLocale() {
    return locale;
  }

  /**
   * @param locale the locale to set
   */
  public void setLocale(Locale locale) {
    this.locale = locale;
  }

  /**
   * @return the userEmail
   */
  public String getUserEmail() {
    return userEmail;
  }

  /**
   * @param userEmail the userEmail to set
   */
  public void setUserEmail(String userEmail) {
    this.userEmail = userEmail;
  }
  
  
}
