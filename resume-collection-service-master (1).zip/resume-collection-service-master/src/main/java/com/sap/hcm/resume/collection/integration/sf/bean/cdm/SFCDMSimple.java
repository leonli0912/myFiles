package com.sap.hcm.resume.collection.integration.sf.bean.cdm;

import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;
import com.thoughtworks.xstream.annotations.XStreamOmitField;

/**
 * 
 * only part of the SF candidate application template , 
 * we only consider field definition here
 * @author i065831
 *
 */
@XStreamAlias("candidate-data-model")
public class SFCDMSimple {
    
    @XStreamAlias("template-name")
    public String templateName;
    
    @XStreamOmitField
    @XStreamAlias("template-desc")
    private Object ignoredElement;
    
    @XStreamOmitField
    @XStreamAlias("template-lastmodified")
    private Object ignoredElement2;
    
    @XStreamOmitField
    @XStreamAlias("field-permission")
    private Object ignoredElement3;
    
    @XStreamOmitField
    @XStreamAlias("button-permission")
    private Object ignoredElement4;
    
    @XStreamOmitField
    @XStreamAlias("field-attr-override")
    private Object ignoredElement5;
    
    @XStreamOmitField
    @XStreamAlias("candidate-summary-display-options-config")
    private Object ignoredElement6;
    
    @XStreamImplicit(itemFieldName="field-definition")
    public List<SFCDMFieldDefinition> fieldDefinition;

    public List<SFCDMFieldDefinition> getFieldDefinition() {
        return fieldDefinition;
    }

    public void setFieldDefinition(List<SFCDMFieldDefinition> fieldDefinition) {
        this.fieldDefinition = fieldDefinition;
    }

    public String getTemplateName() {
        return templateName;
    }

    public void setTemplateName(String templateName) {
        this.templateName = templateName;
    }
}
