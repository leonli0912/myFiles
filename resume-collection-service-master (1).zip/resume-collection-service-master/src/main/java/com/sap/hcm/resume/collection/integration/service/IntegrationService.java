package com.sap.hcm.resume.collection.integration.service;

/**
 * @author I075908 SAP
 */
public interface IntegrationService {

}
