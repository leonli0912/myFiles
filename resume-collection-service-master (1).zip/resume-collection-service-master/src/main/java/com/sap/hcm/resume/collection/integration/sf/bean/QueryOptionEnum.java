package com.sap.hcm.resume.collection.integration.sf.bean;

/**
 * @author I075908 SAP
 */
public enum QueryOptionEnum {
  SELECT("$select"),
  FILTER("$filter"),
  EXPAND("$expand"),
  COUNT("$count"),
  ORDERBY("$orderby"),
  TOP("$top"),
  SKIP("$skip");

  private final String name;

  QueryOptionEnum(String name) {
    this.name = name;
  };

  public String getName() {
    return this.name;
  }
}
