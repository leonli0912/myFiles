package com.sap.hcm.resume.collection.entity.view;

import java.io.Serializable;

import com.sap.hcm.resume.collection.integration.bean.JobReqDataModelMapping;

/**
 * for job requisition data model mapping
 * @author i065831
 *
 */
public class JobRequisitionMappingVO implements Serializable{
    
    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = -925698629864859694L;

    private Long id;
    
    private String mappingName;
    
    private String targetSystem;
        
    private JobReqDataModelMapping mapping;
    
    private String createBy;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getMappingName() {
        return mappingName;
    }

    public void setMappingName(String mappingName) {
        this.mappingName = mappingName;
    }

    public String getTargetSystem() {
        return targetSystem;
    }

    public void setTargetSystem(String targetSystem) {
        this.targetSystem = targetSystem;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    /**
     * @return the mapping
     */
    public JobReqDataModelMapping getMapping() {
        return mapping;
    }

    /**
     * @param mapping the mapping to set
     */
    public void setMapping(JobReqDataModelMapping mapping) {
        this.mapping = mapping;
    }
}
