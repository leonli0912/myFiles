package com.sap.hcm.resume.collection.controller;

import static org.mockito.Matchers.any;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.io.IOUtils;
import org.apache.olingo.odata2.api.ep.entry.ODataEntry;
import org.apache.olingo.odata2.api.ep.feed.ODataFeed;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sap.hcm.resume.collection.bean.ImportResultBean;
import com.sap.hcm.resume.collection.context.TestContext;
import com.sap.hcm.resume.collection.context.WebAppContext;
import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.entity.DataModelMapping;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.service.ResumeService;
import com.sap.hcm.resume.collection.service.CandidateService;
import com.sap.hcm.resume.collection.service.CompanyInfoService;
import com.sap.hcm.resume.collection.service.DataModelMappingService;
import com.sap.hcm.resume.collection.util.CandidateFileUtil;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { TestContext.class, WebAppContext.class })
public class CandidateResumeControllerTest {

  @Autowired
  private DataModelMappingService mappingService;

  @Autowired
  private CompanyInfoService compInfoService;

  @Autowired
  private WebApplicationContext webApplicationContext;

  @Autowired
  private CandidateService candidateService;

  @Autowired
  private ResumeService resumeService;

  @Before
  public void setUp() {

  }

  @SuppressWarnings("rawtypes")
  @Test
  public void testUploadWithInvalidFile() throws Exception {
    String vendor = "job51";
    Long mappingId = 5L;
    String jobId = "1";
    String statusSetId = "2";

    DataModelMapping mapping = new DataModelMapping();
    mapping.setTargetSystem("SF");
    mapping.setMappingId(mappingId);
    when(mappingService.getMappingById(mappingId)).thenReturn(mapping);

    CompanyInfo compInfo = new CompanyInfo();
    compInfo.setCompanyId("sap");
    compInfo.setDmMappingId(1L);
    when(compInfoService.getCompanyInfo("sap")).thenReturn(compInfo);

    MockMvc mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
    ResultActions result = mockMvc.perform(MockMvcRequestBuilders.fileUpload("/upload")
        .content(this.createMultipartContent("resume", "application/data", "whatevercontent"))
        .contentType("multipart/form-data; boundary=----WebKitFormBoundary8HC1OQgjqvtgc5tk").param("vendor", vendor)
        .param("template", "JOB51_2015")
        .param("jobId", jobId).param("statusSetId", statusSetId));

    result.andExpect(MockMvcResultMatchers.status().is(200));
    String content = result.andReturn().getResponse().getContentAsString();

    ObjectMapper om = new ObjectMapper();
    Map responseJson = om.readValue(content, Map.class);
    List resultList = (List) responseJson.get("results");
    Assert.assertEquals(resultList.size(), 1);

  }
  
  @Test
  public void testUploadWithoutMapping() throws ServiceApplicationException{
    String vendor = "job51";
    String jobId = "1";
    String statusSetId = "2";
    String template = "JOB51_2015";

    CompanyInfo compInfo = new CompanyInfo();
    compInfo.setCompanyId("sap");
    when(compInfoService.getCompanyInfo("sap")).thenReturn(compInfo);

    ImportResultBean importResult = new ImportResultBean();
    importResult.setImportStatus("error");
    when(resumeService.processFile(any(FileItem.class), any(HttpServletRequest.class), any(String.class),
        any(String.class), any(DataModelMapping.class), any(String.class), any(String.class))).thenReturn(importResult);
    
    MockMvc mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
    
    try {
      mockMvc.perform(MockMvcRequestBuilders.fileUpload("/upload")
          .contentType("multipart/form-data; boundary=----WebKitFormBoundary8HC1OQgjqvtgc5tk").param("vendor", vendor)
          .param("template", template).param("jobId", jobId).param("statusSetId", statusSetId));
    } catch (Exception e) {
      Assert.assertEquals(ServiceApplicationException.class, e.getClass());
    }

  }
  
  
  @SuppressWarnings("rawtypes")
  @Test
  public void testUploadWithoutFile() throws Exception {
    String vendor = "job51";
    String jobId = "1";
    Long mappingId = 5L;
    String statusSetId = "2";
    String template = "JOB51_2015";

    DataModelMapping mapping = new DataModelMapping();
    mapping.setTargetSystem("SF");
    when(mappingService.getMappingById(5L)).thenReturn(mapping);

    CompanyInfo compInfo = new CompanyInfo();
    compInfo.setCompanyId("sap");
    compInfo.setDmMappingId(mappingId);
    when(compInfoService.getCompanyInfo("sap")).thenReturn(compInfo);

    ImportResultBean importResult = new ImportResultBean();
    importResult.setImportStatus("error");
    when(resumeService.processFile(any(FileItem.class), any(HttpServletRequest.class), any(String.class),
        any(String.class), any(DataModelMapping.class), any(String.class), any(String.class))).thenReturn(importResult);
    
    MockMvc mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
    
    ResultActions result = mockMvc.perform(MockMvcRequestBuilders.fileUpload("/upload")
        .contentType("multipart/form-data; boundary=----WebKitFormBoundary8HC1OQgjqvtgc5tk").param("vendor", vendor)
        .param("template", template).param("jobId", jobId).param("statusSetId", statusSetId));

    result.andExpect(MockMvcResultMatchers.status().is(200));
    String content = result.andReturn().getResponse().getContentAsString();

    ObjectMapper om = new ObjectMapper();
    Map responseJson = om.readValue(content, Map.class);
    List resultList = (List) responseJson.get("results");
    Assert.assertEquals(resultList.size(), 0);
  }

  @SuppressWarnings("rawtypes")
  @Test
  public void testUploadWith51JobFile() throws Exception {
    String vendor = "job51";
    String jobId = "1";
    String statusSetId = "2";
    String email = "rippleruiruidfdfd@163.com";

    DataModelMapping mapping = new DataModelMapping();
    mapping.setTargetSystem("SF");
    when(mappingService.getMappingById(5L)).thenReturn(mapping);

    CompanyInfo compInfo = new CompanyInfo();
    compInfo.setDmMappingId(5L);
    compInfo.setCompanyId("sap");
    when(compInfoService.getCompanyInfo("sap")).thenReturn(compInfo);

    ClassPathResource resource = new ClassPathResource("/resumes/51job.html");
    InputStream is = null;
    try {
      is = resource.getInputStream();
      String charsetName = CandidateFileUtil.getCharsetName(IOUtils.toByteArray(is));
      String fileContent = IOUtils.toString(is, charsetName);

      ODataFeed odataFeed = Mockito.mock(ODataFeed.class);

      when(candidateService.getCandidateId(email)).thenReturn(null);

      List<ODataEntry> entryList = new ArrayList<ODataEntry>();
      ODataEntry entry = Mockito.mock(ODataEntry.class);
      entryList.add(entry);
      when(odataFeed.getEntries()).thenReturn(entryList);
      
      ImportResultBean importResult = new ImportResultBean();
      importResult.setImportStatus("success");
      when(resumeService.processFile(any(FileItem.class), any(HttpServletRequest.class), any(String.class),
          any(String.class), any(DataModelMapping.class), any(String.class), any(String.class))).thenReturn(importResult);
      
      
      MockMvc mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
      ResultActions result = mockMvc.perform(MockMvcRequestBuilders.fileUpload("/upload")
          .content(this.createMultipartContent("resume", "application/data", fileContent))
          .contentType("multipart/form-data; boundary=----WebKitFormBoundary8HC1OQgjqvtgc5tk").param("vendor", vendor)
          .param("template", "")
          .param("jobId", jobId).param("statusSetId", statusSetId));

      result.andExpect(MockMvcResultMatchers.status().is(200));
      String content = result.andReturn().getResponse().getContentAsString();

      ObjectMapper om = new ObjectMapper();
      Map responseJson = om.readValue(content, Map.class);
      List resultList = (List) responseJson.get("results");
      Assert.assertEquals(resultList.size(), 1);

      Map singleEntry = (Map) resultList.get(0);
      Assert.assertEquals(singleEntry.get("importStatus"), "success");
    } catch (IOException e) {
    } finally {
      IOUtils.closeQuietly(is);
    }
  }

  private byte[] createMultipartContent(String fileName, String contentType, String fileContent) {
    String endline = "\r\n";
    String bondary = "----WebKitFormBoundary8HC1OQgjqvtgc5tk";
    String textFile = this.encodeTextFile(bondary, "\r\n", "file", fileName, contentType, fileContent);
    StringBuilder content = new StringBuilder(textFile.toString());
    content.append(endline);
    content.append(endline);
    content.append(endline);
    content.append("--");
    content.append(bondary);
    content.append("--");
    content.append(endline);
    return content.toString().getBytes();
  }

  private String encodeTextFile(String bondary, String endline, String name, String filename, String contentType,
      String content) {

    final StringBuilder sb = new StringBuilder();
    sb.append(endline);
    sb.append("--");
    sb.append(bondary);
    sb.append(endline);
    sb.append("Content-Disposition: form-data; name=\"");
    sb.append(name);
    sb.append("\"; filename=\"");
    sb.append(filename);
    sb.append("\"");
    sb.append(endline);
    sb.append("Content-Type: ");
    sb.append(contentType);
    sb.append(endline);
    sb.append(endline);
    sb.append(content);
    return sb.toString();
  }

}
