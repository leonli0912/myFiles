package com.sap.hcm.resume.collection.bean;

/**
 * @author I075908 SAP
 */
public enum BusinessEntityType {
  CANDIDATE("Candidate"),
  JOBREQUISITION("JobRequisition"),
  JOBAPPLICATION("JobApplication");

  private String name;

  private BusinessEntityType(String name) {
    this.name = name;
  }

  public String getName() {
    return name;
  }
}
