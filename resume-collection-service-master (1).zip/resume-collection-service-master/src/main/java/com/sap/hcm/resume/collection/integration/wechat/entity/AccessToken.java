package com.sap.hcm.resume.collection.integration.wechat.entity;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class AccessToken {

  private String access_token;

  private int expires_in;

  private long createTime;

  private String companyId;

  public AccessToken(String companyId) {
    this.companyId = companyId;
  }

  public static class AccessTokenHolder {
    static Map<String, AccessToken> tokenMap = new HashMap<String, AccessToken>();

    public static AccessToken getInstance(String companyId) {
      return AccessTokenHolder.tokenMap.get(companyId);
    }

    public static void saveAccessToken(String token, String companyId) {
      AccessToken acctoken = AccessTokenHolder.tokenMap.get(companyId);
      if (acctoken == null) {
        acctoken = new AccessToken(companyId);
        acctoken.setCreateTime(new Date().getTime());
        acctoken.setAccess_token(token);
        AccessTokenHolder.tokenMap.put(companyId, acctoken);
      }
    }

    public static void removeToken(String companyId) {
      AccessTokenHolder.tokenMap.remove(companyId);
    }
  }

  public boolean isExpired() {

    long time = new Date().getTime();
    if (this.createTime <= 0) {
      return true;
    }

    if (this.createTime / 1000 + 7200 < time / 1000) {
      return true;
    }
    return false;

  }

  public long getCreateTime() {
    return createTime;
  }

  public void setCreateTime(long createTime) {
    this.createTime = createTime;
  }

  public String getAccess_token() {
    return access_token;
  }

  public void setAccess_token(String access_token) {
    this.access_token = access_token;
  }

  public int getExpires_in() {
    return expires_in;
  }

  public void setExpires_in(int expires_in) {
    this.expires_in = expires_in;
  }

  /**
   * @return the companyId
   */
  public String getCompanyId() {
    return companyId;
  }

  /**
   * @param companyId
   *          the companyId to set
   */
  public void setCompanyId(String companyId) {
    this.companyId = companyId;
  }

}
