package com.sap.hcm.resume.collection.integration.bean;

import static org.mockito.Mockito.spy;

import java.util.List;
import java.util.SortedSet;
import java.util.TreeSet;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;

import com.sap.hcm.resume.collection.context.TestContext;
import com.sap.hcm.resume.collection.context.WebAppContext;
import com.sap.hcm.resume.collection.integration.sf.bean.SFPicklist;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { TestContext.class, WebAppContext.class })
public class CandProfileDataModelMappingTest {
	
	private CandProfileDataModelMapping mapping;
	private DataMappingPkOptionMapping picklistOptionMapping;  
	private DataMappingOverwrite dataMappingOverwrites;
	private TreeSet<DataModelMappingItem> testList;
	
	@Before
	public void setUp(){
		mapping = spy(new CandProfileDataModelMapping());
		picklistOptionMapping = Mockito.mock(DataMappingPkOptionMapping.class);
		dataMappingOverwrites = Mockito.mock(DataMappingOverwrite.class);
		ReflectionTestUtils.setField(mapping, "picklistOptionMapping", picklistOptionMapping);
		ReflectionTestUtils.setField(mapping, "dataMappingOverwrites", dataMappingOverwrites);
		
		testList= new TreeSet<DataModelMappingItem>();
		DataModelMappingItem itemJobTitle = new DataModelMappingItem();
		itemJobTitle.setFrom("jobTitle");
		itemJobTitle.setTo("Position");
		itemJobTitle.setLabel("Job Title");
		itemJobTitle.setRequired(true);
		itemJobTitle.setPicklist("position");
		testList.add(itemJobTitle);
	}
	@Test
	public void testGetterSetter(){
	  
	    SortedSet<DataModelMappingItem> resultList;
		
		mapping.setProfile(testList);
		resultList = mapping.getProfile();
		Assert.assertEquals(1, resultList.size());
		
		mapping.setWorkExprs(testList);
		resultList = mapping.getWorkExprs();
		Assert.assertEquals(1, resultList.size());
		
		mapping.setLanguages(testList);;
		resultList = mapping.getLanguages();
		Assert.assertEquals(1, resultList.size());
		
		mapping.setCertificates(testList);;
		resultList = mapping.getCertificates();
		Assert.assertEquals(1, resultList.size());
		
		mapping.setFamilies(testList);;
		resultList = mapping.getFamilies();
		Assert.assertEquals(1, resultList.size());
		
		mapping.setEducation(testList);;
		resultList = mapping.getEducation();
		Assert.assertEquals(1, resultList.size());
		
		mapping.setAliases(null);
		Assert.assertEquals(null, mapping.getAliases());
		
		mapping.setDataMappingOverwrites(null);
		Assert.assertEquals(null, mapping.getDataMappingOverwrites());
		
		mapping.setPicklistOptionMapping(null);
		Assert.assertEquals(null, mapping.getPicklistOptionMapping());
		
		mapping.setPkOptionMappingString(null);
		Assert.assertEquals(null, mapping.getPkOptionMappingString());
	}
	
	@Test 
	public void testPicklists(){
		mapping.setProfile(testList);	
		mapping.setWorkExprs(testList);
		mapping.setLanguages(testList);
		mapping.setCertificates(testList);
		mapping.setFamilies(testList);
		mapping.setEducation(testList);
		
		List<SFPicklist> result = mapping.picklists();
		Assert.assertEquals(6, result.size());
	}
}
