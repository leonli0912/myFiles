jQuery.sap.declare("com.sap.rcs.wechat.Component");

sap.ui.core.UIComponent.extend("com.sap.rcs.wechat.Component",{
	metadata:{
		routing:{
			config : {
				viewType:"XML",
				viewPath:"static.wechat.js.layout",
				targetControl:"navContainer",
				targetAggregation:"pages",
				controlAggregation: "pages",
				controlId: "navContainer",
				routerClass: "sap.m.routing.Router",
				transition: "slide",
				clearTaget:false,
				bypassed: {
					target: "notFound"
				}
			},
			routes:[
			        {
			        	pattern:"",
			        	name:"jobList",
			        	target:"jobList",
			        },
			        {
			        	pattern:"personalCenter",
			        	name:"personalCenter",
			        	target:"personalCenter",
			        },
			        {
			        	pattern:"jobApplyHistory:?query:",
			        	name:"jobApplyHistory",
			        	target:"jobApplyHistory",
			        },
			        {
			        	pattern:"resumeChangeHistory:?query:",
			        	name:"resumeChangeHistory",
			        	target:"resumeChangeHistory",
			        },
			        {
			        	pattern:"interviewInfo:?query:",
			        	name:"interviewInfo",
			        	target:"interviewInfo",
			        },
			        {
			        	pattern:"internalEmailBinding",
			        	name:"internalEmailBinding",
			        	target:"internalEmailBinding",
			        },
			        {
			        	pattern:"baiduCloudFileList",
			        	name:"baiduCloudFileList",
			        	target:"baiduCloudFileList",
			        },
			        {
			        	pattern:"jobdetail/{jobId}",
			        	name:"jobDetail",
			        	target:"jobDetail",
			        },
			        {
     	        	   pattern:"jobapply:?query:",
     	        	   name:"jobApply",
     	        	   target:"jobApply"
     	            },
			        {
     	        	   pattern:"candidateList:?query:",
     	        	   name:"candidateList",
     	        	   target:"candidateList"
     	            },
			        {
			        	pattern:"candidatePreview/{candidateId}:?query:",
			        	name:"candidatePreview",
			        	target:"candidatePreview",
			        	subroutes:[
			        	           {
			        	        	   pattern:"candidate/:candidateId:/candidateInput:?query:",
			        	        	   name:"candidateInput",
			        	        	   target:"candidateInput"
			        	           },
			        	           {
			        	        	   pattern:"candidate/:candidateId:/candidateWorkExpInput/:workExpId::?query:",
			        	        	   name:"candidateWorkExpInput",
			        	        	   target:"candidateWorkExpInput"
			        	           },
			        	           {
			        	        	   pattern:"candidate/:candidateId:/candidateEducationInput/:educId::?query:",
			        	        	   name:"candidateEducationInput",
			        	        	   target:"candidateEducationInput"
			        	           },
			        	           {
			        	        	   pattern:"candidate/:candidateId:/candidateLanguageInput/:langId::?query:",
			        	        	   name:"candidateLanguageInput",
			        	        	   target:"candidateLanguageInput"
			        	           },
			        	           {
			        	        	   pattern:"candidate/:candidateId:/candidateCertificateInput/:certId::?query:",
			        	        	   name:"candidateCertificateInput",
			        	        	   target:"candidateCertificateInput"
			        	           },
			        	           {
			        	        	   pattern:"candidate/:candidateId:/candidateFamilyInput/:famId::?query:",
			        	        	   name:"candidateFamilyInput",
			        	        	   target:"candidateFamilyInput"
			        	           }
			        	           ]
			        },
			        {
     	        	   pattern:"auth/{vendorName}:?query:",
     	        	   name:"UserAuthorize",
     	        	   target:"UserAuthorize"
     	           	},
			        {
			        	pattern:"jobPublish",
			        	name:"jobPublish",
			        	target:"jobPublish",
			        }
			],
			targets: {
				
				"jobList": {
					"viewName": "jobList",
				},
				"personalCenter": {
					"viewName": "personalCenter",
				},
				"jobApplyHistory": {
					"viewName": "jobApplyHistory",
				},
				"resumeChangeHistory": {
					"viewName": "resumeChangeHistory",
				},
				"internalEmailBinding": {
					"viewName": "internalEmailBinding",
				},
				"jobDetail": {
					"viewName": "jobDetail",
				},
				"jobApply": {
					"viewName": "jobApply",
				},
				"candidateList": {
					"viewName": "candidateList",
				},
				"candidatePreview": {
					"viewName": "candidatePreview",
				},
				"candidateInput": {
					"viewName": "candidateInput",
				},
				"candidateWorkExpInput": {
					"viewName": "candidateWorkExpInput",
				},
				"candidateEducationInput": {
					"viewName": "candidateEducationInput",
				},
				"candidateLanguageInput": {
					"viewName": "candidateLanguageInput",
				},
				"candidateCertificateInput": {
					"viewName": "candidateCertificateInput",
				},
				"candidateFamilyInput": {
					"viewName": "candidateFamilyInput",
				},
				"UserAuthorize": {
					"viewName": "UserAuthorize",
				},
				"jobPublish": {
					"viewName": "jobPublish",
				},
				"baiduCloudFileList": {
					"viewName": "baiduCloudFileList",
				},
				"interviewInfo": {
					"viewName": "interviewInfo",
				},
	            "notFound": {
	                "viewName": "notFound"
	             }
			}
		}
	},
	
	_currentJobId:null,
	
	getCurrentJobId:function(){
		return this._currentJobId
	},
	
	setCurrentJobId:function(jobId){
		this._currentJobId = jobId;
	}
	
});

com.sap.rcs.wechat.Component.prototype.init = function(){
	jQuery.sap.require("sap.ui.core.routing.History");
	jQuery.sap.require("sap.m.routing.RouteMatchedHandler");
	
	sap.ui.core.UIComponent.prototype.init.apply(this);
	
	jQuery.sap.require("jquery.sap.resources");
	var sLocale = sap.ui.getCore().getConfiguration().getLanguage();
	var resModel = new sap.ui.model.resource.ResourceModel({bundleName:"static.i18n.i18n",bundleLocale:sLocale});
	var resWechatModel = new sap.ui.model.resource.ResourceModel({bundleName:"static.i18n.wechat.i18n",bundleLocale:sLocale});
	//update the page title
	window.document.title = resWechatModel.getResourceBundle().getText("ApplicationTitle");
	this.setModel(resModel, "i18n");
	this.setModel(resWechatModel, "wi18n");
	
	var router = this.getRouter();
	this.routeHandler = new sap.m.routing.RouteMatchedHandler(router);
	router.initialize();
}

com.sap.rcs.wechat.Component.prototype.destroy = function(){
	if(this.routeHandler){
		this.routeHandler.destroy();
	}
	sap.ui.core.UIComponent.destroy.apply(this,arguments);
};

com.sap.rcs.wechat.Component.prototype.createContent = function(){
	this.view = sap.ui.view({id:"rcsWechatApplication",viewName:"static.wechat.js.layout.application",type:sap.ui.core.mvc.ViewType.JS});
	return this.view;
};

com.sap.rcs.wechat.Component.prototype.onAfterRendering = function(){
	sap.ui.core.UIComponent.prototype.onAfterRendering.apply(this);
	setTimeout(function(){
		hidePageLoading();
	},200);
}
