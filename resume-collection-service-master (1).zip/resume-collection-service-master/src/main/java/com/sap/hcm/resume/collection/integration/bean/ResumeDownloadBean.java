package com.sap.hcm.resume.collection.integration.bean;

import java.io.Serializable;
import java.util.Locale;

/**
 * 
 * @author i065831
 *
 */
public class ResumeDownloadBean implements Serializable{
    
    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 4604802607612900518L;
    
    private Locale locale;
    
    private String fileName;

    private String externalResumeId;
    
    private byte[] fileContent;
    

    /**
     * @return the fileName
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * @param fileName the fileName to set
     */
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    /**
     * @return the locale
     */
    public Locale getLocale() {
        return locale;
    }

    /**
     * @param locale the locale to set
     */
    public void setLocale(Locale locale) {
        this.locale = locale;
    }

    /**
     * @return the externalResumeId
     */
    public String getExternalResumeId() {
        return externalResumeId;
    }

    /**
     * @param externalResumeId the externalResumeId to set
     */
    public void setExternalResumeId(String externalResumeId) {
        this.externalResumeId = externalResumeId;
    }

    /**
     * @return the fileContent
     */
    public byte[] getFileContent() {
      return fileContent;
    }

    /**
     * @param fileContent the fileContent to set
     */
    public void setFileContent(byte[] fileContent) {
      this.fileContent = fileContent;
    }
}
