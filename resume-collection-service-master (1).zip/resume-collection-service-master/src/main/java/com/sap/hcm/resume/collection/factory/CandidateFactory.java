package com.sap.hcm.resume.collection.factory;

import java.util.Locale;

import org.springframework.context.MessageSource;

import com.sap.hcm.resume.collection.bean.CandidateVendorEnum;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.dajie.HTMLDocumentParserDJ;
import com.sap.hcm.resume.collection.integration.job51.ChineseDocumentParser51;
import com.sap.hcm.resume.collection.integration.job51.EnglishDocumentParser51;
import com.sap.hcm.resume.collection.integration.job51.ResumeParser51;
import com.sap.hcm.resume.collection.integration.job51.ResumeParser51V16;
import com.sap.hcm.resume.collection.integration.liepin.ResumeParserLP;
import com.sap.hcm.resume.collection.integration.zhilian.DocumentParserZL;
import com.sap.hcm.resume.collection.integration.zhilian.EnglishDocumentParserZL;
import com.sap.hcm.resume.collection.integration.zhilian.ResumeParserZL;
import com.sap.hcm.resume.collection.parser.DocumentParserAdapter;

public class CandidateFactory {

  public static DocumentParserAdapter getResumeParserInstance(MessageSource messageSource, String boardName,
      String template) throws ServiceApplicationException {

    if (CandidateVendorEnum.ZHILIAN.toString().equalsIgnoreCase(boardName)) {
      return new DocumentParserAdapter(null, new ResumeParserZL(messageSource));
    } else if (CandidateVendorEnum.JOB51.toString().equalsIgnoreCase(boardName)) {

       if ("51Job_2016".equals(template)) {
        return new DocumentParserAdapter(new ResumeParser51V16(messageSource),null);
      }else{
        return new DocumentParserAdapter(null, new ResumeParser51(messageSource));
      }
    }
    throw new ServiceApplicationException(
        "parser for : " + boardName + " with template :" + template + " is not supported");

  }

  public static DocumentParserAdapter getDocumentParserInstance(MessageSource messageSource, String boardName,
      Locale locale) {

    if (CandidateVendorEnum.ZHILIAN.toString().equalsIgnoreCase(boardName) && locale == Locale.CHINESE) {
      return new DocumentParserAdapter(new DocumentParserZL(messageSource), null);

    } else if (CandidateVendorEnum.ZHILIAN.toString().equalsIgnoreCase(boardName) && locale == Locale.ENGLISH) {
      return new DocumentParserAdapter(new EnglishDocumentParserZL(messageSource), null);

    } else if (CandidateVendorEnum.LIEPIN.toString().equalsIgnoreCase(boardName)) {
      return new DocumentParserAdapter(new ResumeParserLP(messageSource), null);

    } else if (CandidateVendorEnum.DAJIE.toString().equalsIgnoreCase(boardName)) {
      return new DocumentParserAdapter(new HTMLDocumentParserDJ(messageSource), null);

    } else if (CandidateVendorEnum.JOB51.toString().equalsIgnoreCase(boardName) && locale == Locale.CHINESE) {
      return new DocumentParserAdapter(new ChineseDocumentParser51(messageSource), null);

    } else if (CandidateVendorEnum.JOB51.toString().equalsIgnoreCase(boardName) && locale == Locale.ENGLISH) {
      return new DocumentParserAdapter(new EnglishDocumentParser51(messageSource), null);
    } else {
      return null;
    }

  }
}
