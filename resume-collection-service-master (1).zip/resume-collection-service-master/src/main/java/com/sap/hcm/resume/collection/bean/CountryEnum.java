package com.sap.hcm.resume.collection.bean;

import org.springframework.jmx.export.annotation.ManagedAttribute;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedOperationParameter;
import org.springframework.jmx.export.annotation.ManagedResource;

@ManagedResource(objectName="bean:name=CountryEnum", description="Country Enumeration")
public enum CountryEnum {
	
	CN("China"),
	IN("India");
	
	private String countryName;
	
	/**
	 * @return the countryName
	 */
	@ManagedAttribute(description="Country Name")
	public String getCountryName() {
		return countryName;
	}

	CountryEnum(String countryName){
		this.countryName = countryName;
	}
	
	@ManagedOperation(description="Retrieve instance by Country Name")
	@ManagedOperationParameter(name="countryName", description="Country Name")
	public static CountryEnum fromCountryName(String countryName){
		for(CountryEnum ce : CountryEnum.values()){
			if(ce.getCountryName().equals(countryName)){
				return ce;
			}
		}
		return null;
	}
	
	@ManagedOperation(description="Retrieve instance by Country Code")
	@ManagedOperationParameter(name="countryCode", description="Country Code")
	public static CountryEnum fromCountryCode(String countryCode){
		for(CountryEnum ce : CountryEnum.values()){
			if(ce.name().equals(countryCode)){
				return ce;
			}
		}
		return null;
	}
	
}
