package com.sap.hcm.resume.collection.bean;

import org.junit.Assert;
import org.junit.Test;


public class CountryEnumTest {
  
  @Test
  public void testCountryChina(){
    CountryEnum china = CountryEnum.CN;
    Assert.assertEquals(china.getCountryName(), "China");
  }
  
  @Test
  public void testValidCountry(){
    CountryEnum china = CountryEnum.fromCountryCode("CN");
    CountryEnum china2 = CountryEnum.fromCountryName("China");
    Assert.assertEquals(china, china2);
  }
  
  @Test
  public void testInvalidCountry(){
    CountryEnum country = CountryEnum.fromCountryCode("XX");
    CountryEnum country1 = CountryEnum.fromCountryName("XX");
    Assert.assertNull(country);
    Assert.assertNull(country1);
  }
}
