package com.sap.hcm.resume.collection.integration.sf.bean.cdm;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamAsAttribute;
import com.thoughtworks.xstream.annotations.XStreamConverter;
import com.thoughtworks.xstream.converters.extended.ToAttributedValueConverter;

@XStreamAlias("enum-label")
@XStreamConverter(value=ToAttributedValueConverter.class, strings={"text"})
public class SFCDMFieldEnumLabel {
    
    @XStreamAsAttribute
    public String lang;
    
    public String text;

    public String getLang() {
        return lang;
    }

    public void setLang(String lang) {
        this.lang = lang;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }
}
