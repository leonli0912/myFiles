jQuery.sap.require("sap.m.MessageBox");
jQuery.sap.require("sap.m.MessageToast");
sap.ui.controller("static.wechat.js.layout.internalEmailBinding", {

	/**
	 * Called when a controller is instantiated and its View controls (if
	 * available) are already created. Can be used to modify the View before it
	 * is displayed, to bind event handlers and do other one-time
	 * initialization.
	 *
	 * @memberOf resume-collection-service.internalEmailBinding
	 */

	 _postfix:null,
	 _user_portrait_upload:"wphoto/picture/upload",

	onInit : function() {
		this._router = sap.ui.core.UIComponent.getRouterFor(this);
		var that = this;
		this._router.getRoute("internalEmailBinding").attachPatternMatched(function(oEvent){
		var oModel = new sap.ui.model.json.JSONModel("wechatuser/user");
		that.getView().setModel(oModel);
		var that1 = that;
		oModel.attachRequestCompleted(function(oEvent) {
			var photoId = oModel.getData().userInfo.photoId;
			that1.getView().byId("internalEmail").setValueState("None");
			that1.getView().byId("verifyCodeInput").setValueState("None");
			that1.getView().byId("verifyCodeInput").setValue("");
			that1._postfix ="@" + oModel.getData().companyInfo.emailPostfix
			if(oModel.getData().userInfo.internalEmail){
				oModel.getData().userInfo.internalEmail = oModel.getData().userInfo.internalEmail.split("@")[0];
			}
			if (!photoId) {
				var uData = {
					iconUrl : "static/img/photoNotAvailable.gif",
					postfix : that1._postfix
				};
			} else {
				var uData = {
					iconUrl : "wphoto/" + photoId + "?random=" + that1.generateRandomValue(),
					postfix : that1._postfix
				}
			}
			var nickName = oModel.getData().userInfo.nickName;
			if(!nickName) {
				uData.wechatUserName=that1.translateText("LB_WECHAT_USER");
			}else{
				uData.wechatUserName=nickName;
			}
			oModel.setData(uData, true);
			
		})

		that.getView().byId("portraitUploader").setUploadUrl(
				that._user_portrait_upload + "?height=200&width=200&sizeLimit=false");
		var emailModel = new sap.ui.model.json.JSONModel();
		emailModel.loadData("wechatuser/checkUserExist",null,false);
		var emailData = emailModel.getData();
		that.getView().setModel(emailModel,"email");
		});
	},

	onButtonPress : function() {
		var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		oRouter.navTo("personalCenter");
	},
	editPortrait: function(){
		$("#"+this.getView().getId()+"--portraitUploader-fu").click();
	},
	doPortraitUpload:function(oEvent){
		this.showBusyIndicator();
	},
	handleUploadComplete : function(oEvent) {
		this.hideBusyIndicator();
		var rsp = oEvent.getParameter("response");
		if (rsp) {
			rsp = rsp.match(/{.*}/)[0];
			if (rsp) {
				var code = parseInt(JSON.parse(rsp).code);
				if (code == 0) {
					var imageData = JSON.parse(rsp).message;
					var viewData = this.getView().getModel().getData();
					viewData.portrait = imageData;
					viewData.iconUrl = "wphoto/temp/" + imageData + "?random=" + this.generateRandomValue();
					this.getView().getModel().setData(viewData);
				}
			}
		}
	},

	saveUserInfo : function() {
		var that = this;
		var viewData = this.getView().getModel().getData();
		var verifyCode = this.getView().byId("verifyCodeInput").getValue();
		if(viewData.userInfo.internalEmail != "" && viewData.userInfo.internalEmail != null){
			viewData.userInfo.internalEmail = viewData.userInfo.internalEmail + this._postfix;
		}
		jQuery.ajax({
			url: "wechatuser/userinfo/save?verifyCode="+verifyCode,
			method:"POST",
			data:JSON.stringify(viewData.userInfo),
			contentType : 'application/json;charset=UTF-8'
		}).success(function(data){
			if(data && data.code < 0){
				var bCompact = !!that.getView().$().closest(".sapUiSizeCompact").length;
				sap.m.MessageBox.error(
					data.message,
					{
						styleClass: bCompact? "sapUiSizeCompact" : ""
					}
				);
				that.getView().byId("verifyCodeInput").setValueState("Error");
			}else{
				that.getView().byId("verifyCodeInput").setValueState("None");
				sap.m.MessageToast.show(that.translateText("USER_INFO_SAVE_SUCCESS_MESSAGE"));
			}
		})

	},

	setEmailContentVisible: function(val){
//		if(!val || val == "@" || val == "@null"){
//			return false;
//		}
		return false;
	},

	hideBusyIndicator : function() {
		sap.ui.core.BusyIndicator.hide();
	},

	showBusyIndicator : function () {
		sap.ui.core.BusyIndicator.show(0);
	},

	translateText : function(val) {
		return this.getView().getModel("wi18n").getResourceBundle().getText(val);
	},

	sendVerifyCode: function(){
		var viewData = this.getView().getModel().getData();
		var that = this;
		if(viewData.userInfo.internalEmail != null && viewData.userInfo.internalEmail != ""){
			jQuery.ajax({
				url: "wechatuser/sendEmail?email="+viewData.userInfo.internalEmail + this._postfix
				      + "&random=" + that.generateRandomValue(),
				method:"POST",
				contentType : 'application/json;charset=UTF-8'
			}).success(function(data){
				if(data && data.code < 0){
					var bCompact = !!that.getView().$().closest(".sapUiSizeCompact").length;
					sap.m.MessageBox.error(
						data.message,
						{
							styleClass: bCompact? "sapUiSizeCompact" : ""
						}
					);
					that.getView().byId("internalEmail").setValueState("Error");
				}else{
					that.getView().byId("internalEmail").setValueState("None");
					sap.m.MessageToast.show("A verify code has been sent to the written email, " +
							"please input the verify code you recieved " +
							"in below input to finish the verficiation.");
				}
			})
		}

	},

	generateRandomValue : function(){
		var array = new Uint32Array(1);
		window.crypto.getRandomValues(array);
		return array[0];
	},
/**
 * Similar to onAfterRendering, but this hook is invoked before the controller's
 * View is re-rendered (NOT before the first rendering! onInit() is used for
 * that one!).
 *
 * @memberOf resume-collection-service.internalEmailBinding
 */
// onBeforeRendering: function() {
//
// },
/**
 * Called when the View has been rendered (so its HTML is part of the document).
 * Post-rendering manipulations of the HTML could be done here. This hook is the
 * same one that SAPUI5 controls get after being rendered.
 *
 * @memberOf resume-collection-service.internalEmailBinding
 */
// onAfterRendering: function() {
//
// },
/**
 * Called when the Controller is destroyed. Use this one to free resources and
 * finalize activities.
 *
 * @memberOf resume-collection-service.internalEmailBinding
 */
// onExit: function() {
//
// }
});
