package com.sap.hcm.resume.collection.integration.sf.odata;

/**
 * @author I075908 SAP
 */
public class SFODataConstants {
  public static final String METADATA = "$metadata";

  public static final String APPLICATION_XML = "application/xml";
  
  public static final String APPLICATION_JSON = "application/json";

  // Candidate
  public static final String CANDIDATE_ENTITSET = "Candidate";

  public static final String CANDIDATE_ID = "candidateId";

  public static final String CANDIDATE_PRIMARY_EMAIL = "primaryEmail";
  
  // destination configuration
  public static final String SF_DESTINATION_NAME = "SF_ODATA";

  public static final String AUTH_TYPE_BASIC = "BasicAuthentication";

  public static final String AUTH_TYPE_OAUTH = "OAuth2SAMLBearerAssertion";
}