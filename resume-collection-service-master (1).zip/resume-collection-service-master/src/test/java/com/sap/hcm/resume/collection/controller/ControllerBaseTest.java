package com.sap.hcm.resume.collection.controller;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.test.util.ReflectionTestUtils;

import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.service.CompanyInfoService;


public class ControllerBaseTest {
  
  private CompanyInfoService compInfoService;
  
  private ControllerBase controllberBase;
  
  @Before
  public void setUp() {
    compInfoService = Mockito.mock(CompanyInfoService.class);
    controllberBase = new ControllerBase();
    ReflectionTestUtils.setField(controllberBase, "compInfoService", compInfoService);
  }
  
  @Test
  public void testValidateCompanyAndUser() throws ServiceApplicationException{
    CompanyInfo compInfo = new CompanyInfo();
    Mockito.when(compInfoService.getCompanyInfo("test")).thenReturn(compInfo);
    String result = controllberBase.validateCompanyAndUser("test");
    Assert.assertEquals(result, "");
  }
  
  @Test
  public void testValidateCompanyAndUserInvalid() throws ServiceApplicationException{
    Mockito.when(compInfoService.getCompanyInfo("test")).thenThrow(new ServiceApplicationException("test"));
    String result = controllberBase.validateCompanyAndUser("test");
    Assert.assertEquals(result, "invalid_company");
  }
  
  @Test
  public void testValidateCompanyAndUserNull() throws ServiceApplicationException{
    CompanyInfo compInfo = null;
    Mockito.when(compInfoService.getCompanyInfo("test")).thenReturn(compInfo);
    String result = controllberBase.validateCompanyAndUser("test");
    Assert.assertEquals(result, "invalid_company");
  }
}
