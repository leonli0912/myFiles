package com.sap.hcm.resume.collection.factory;

import static org.junit.Assert.assertEquals;

import java.util.Locale;

import javax.annotation.Resource;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.context.MessageSource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.sap.hcm.resume.collection.context.TestContext;
import com.sap.hcm.resume.collection.context.WebAppContext;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.parser.DocumentParserAdapter;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { TestContext.class, WebAppContext.class })
public class CandidateFactoryTest {

  @Resource(name = "messageSource")
  private MessageSource messageSource;

  @Test
  public void testGetResumeParserInstance_ZHILIAN() throws ServiceApplicationException {
    DocumentParserAdapter parse = CandidateFactory.getResumeParserInstance(messageSource, "ZHILIAN", null);
    assertEquals(parse.getClass(), DocumentParserAdapter.class);
  }

  @Test
  public void testGetResumeParserInstance_51JOB() throws ServiceApplicationException {
    DocumentParserAdapter parse = CandidateFactory.getResumeParserInstance(messageSource, "JOB51", null);
    assertEquals(parse.getClass(), DocumentParserAdapter.class);
  }

  @Test(expected=ServiceApplicationException.class)
  public void testGetResumeParserInstance_OTHERS() throws ServiceApplicationException {
    CandidateFactory.getResumeParserInstance(messageSource, "HEHEHE", null);
  }

  @Test
  public void testGetDocumentParserInstance_ZHILIAN_ZH() {
    DocumentParserAdapter parser = CandidateFactory.getDocumentParserInstance(messageSource, "ZHILIAN", Locale.CHINESE);
    assertEquals(parser.getClass(), DocumentParserAdapter.class);
  }

  @Test
  public void testGetDocumentParserInstance_ZHILIAN_EN() {
    DocumentParserAdapter parser = CandidateFactory.getDocumentParserInstance(messageSource, "ZHILIAN", Locale.ENGLISH);
    assertEquals(parser.getClass(), DocumentParserAdapter.class);
  }

  @Test
  public void testGetDocumentParserInstance_LIEPIN() {
    DocumentParserAdapter parser = CandidateFactory.getDocumentParserInstance(messageSource, "LIEPIN", Locale.ENGLISH);
    assertEquals(parser.getClass(), DocumentParserAdapter.class);
  }

  @Test
  public void testGetDocumentParserInstance_DAJIE() {
    DocumentParserAdapter parser = CandidateFactory.getDocumentParserInstance(messageSource, "DAJIE", Locale.ENGLISH);
    assertEquals(parser.getClass(), DocumentParserAdapter.class);
  }

  @Test
  public void testGetDocumentParserInstance_JOB51_CH() {
    DocumentParserAdapter parser = CandidateFactory.getDocumentParserInstance(messageSource, "JOB51", Locale.CHINESE);
    assertEquals(parser.getClass(), DocumentParserAdapter.class);
  }

  @Test
  public void testGetDocumentParserInstance_JOB51_EN() {
    DocumentParserAdapter parser = CandidateFactory.getDocumentParserInstance(messageSource, "JOB51", Locale.ENGLISH);
    assertEquals(parser.getClass(), DocumentParserAdapter.class);
  }

  @Test
  public void testGetDocumentParserInstance_OTHERS() {
    DocumentParserAdapter parser = CandidateFactory.getDocumentParserInstance(messageSource, "HEHEHE", Locale.ENGLISH);
    assertEquals(parser, null);
  }
}