package com.sap.hcm.resume.collection.integration.wechat.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.context.WebApplicationContext;

import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.bean.SimpleJsonResponse;
import com.sap.hcm.resume.collection.context.TestContext;
import com.sap.hcm.resume.collection.context.WebAppContext;
import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.entity.Photo;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatApplyHistory;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatUser;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatJobService;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatUserService;
import com.sap.hcm.resume.collection.integration.wechat.util.Constraints;
import com.sap.hcm.resume.collection.service.CompanyInfoService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { TestContext.class, WebAppContext.class })
public class UserInfoControllerTest {
  @Resource(type = WebApplicationContext.class)
  private WebApplicationContext webApplicationContext;

  @Resource(name = "wechatJobService")
  private WechatJobService wechatJobService;

  @Resource(name = "wechatUserService")
  private WechatUserService wechatUserService;

  @Resource(name = "companyInfoService")
  private CompanyInfoService companyInfoService;

  private UserInfoController userInfoController;

  @Autowired
  private Params params;

  @Before
  public void setUp() {
    reset(wechatJobService);
    reset(wechatUserService);
    MockitoAnnotations.initMocks(this);
    userInfoController = spy(new UserInfoController());
    params.setCompanyId("sap");
    params.setWechatOpenId("openid");
    params.setUserEmail("abc@sap.com");
    ReflectionTestUtils.setField(userInfoController, "wechatJobService", wechatJobService);
    ReflectionTestUtils.setField(userInfoController, "wechatUserService", wechatUserService);
    ReflectionTestUtils.setField(userInfoController, "compInfoService", companyInfoService);
    ReflectionTestUtils.setField(userInfoController, "params", params);
  }

  @Test
  public void testGetPreloginInfo() throws Exception {
    Map<String, Object> result = new HashMap<String, Object>();
    MockHttpSession session = new MockHttpSession();
    String companyId = "sap";
    WechatUser wechatUser = new WechatUser();
    wechatUser.setNickname("jeremy");
    String userMail = "abc@sap.com";
    when(wechatUserService.getUserInfoByEmail(userMail, companyId)).thenReturn(wechatUser);
    CompanyInfo companyInfo = new CompanyInfo();
    companyInfo.setCompanyId(companyId);
    when(companyInfoService.getCompanyInfo(companyId)).thenReturn(companyInfo);
    result = userInfoController.getUserInfoList(session);
    WechatUser actualUser = (WechatUser) result.get("userInfo");
    assertEquals(wechatUser.getNickname(), actualUser.getNickname());
    CompanyInfo actualComp = (CompanyInfo) result.get("companyInfo");
    assertEquals(actualComp.getCompanyId(), actualComp.getCompanyId());
  }

  @Test
  public void testbindInternalEmailSuccess() throws Exception {
    WechatUser inputWechatUserInfo = new WechatUser();
    MockHttpSession session = new MockHttpSession();
    WechatUser returnWechatUserInfo = new WechatUser();

    String wechatId = "wechatabc";
    String companyId = "sap";
    String verifyCodeInput = "1234";
    Long photoId = 123L;
    inputWechatUserInfo.setWechatId(wechatId);
    inputWechatUserInfo.setPhotoId(photoId);
    when(wechatUserService.getUserInfoByEmail(wechatId, companyId)).thenReturn(inputWechatUserInfo);
    inputWechatUserInfo.setInternalEmail("heheda@sap.com");
    session.setAttribute(Constraints.SESSION_KEY_VERIFICATION_CODE, verifyCodeInput);
    byte[] item = "heheda".getBytes();
    session.setAttribute(wechatId + "_logo", item);

    Photo photo = new Photo();
    photo.setPhotoId(photoId);
    photo.setContent(item);
    photo.setCategory("wechat_portrait");
    when(wechatUserService.saveImg(any(Photo.class))).thenReturn(photo);
    when(wechatUserService.saveWechatUser(inputWechatUserInfo)).thenReturn(inputWechatUserInfo);
    returnWechatUserInfo = userInfoController.bindInternalEmail(session, inputWechatUserInfo, verifyCodeInput);
    assertEquals(inputWechatUserInfo.getNickname(), returnWechatUserInfo.getNickname());
  }

  // @Test(expected = ServiceApplicationException.class)
  // public void testbindInternalEmailFailWithVerifyCodeEmpty() throws Exception {
  // WechatUser inputWechatUserInfo = new WechatUser();
  // WechatUser anoInputWechatUserInfo = new WechatUser();
  // MockHttpSession session = new MockHttpSession();
  // WechatUser returnWechatUserInfo = new WechatUser();
  //
  // String wechatId = "wechatabc";
  // String companyId = "sap";
  // String verifyCodeInput = "";
  // Long photoId = 123L;
  // inputWechatUserInfo.setWechatId(wechatId);
  // inputWechatUserInfo.setPhotoId(photoId);
  // inputWechatUserInfo.setInternalEmail("abc");
  // anoInputWechatUserInfo.setWechatId(wechatId);
  // anoInputWechatUserInfo.setPhotoId(photoId);
  // anoInputWechatUserInfo.setInternalEmail("efg");
  // when(wechatUserService.getUserInfoByWechatId(wechatId, companyId)).thenReturn(inputWechatUserInfo);
  // session.setAttribute(Constraints.SESSION_KEY_VERIFICATION_CODE, verifyCodeInput);
  // session.setAttribute(Constraints.SESSION_KEY_WECHAT_COMPANY_ID, companyId);
  // byte[] item = "heheda".getBytes();
  // session.setAttribute(wechatId + "_logo", item);
  //
  // Photo photo = new Photo();
  // photo.setPhotoId(photoId);
  // photo.setContent(item);
  // photo.setCategory("wechat_portrait");
  // when(wechatUserService.saveImg(any(Photo.class))).thenReturn(photo);
  // returnWechatUserInfo = userInfoController.bindInternalEmail(session, anoInputWechatUserInfo, verifyCodeInput);
  // }
  //
  // @Test(expected = ServiceApplicationException.class)
  // public void testbindInternalEmailFailWithVerifyCodeNotMatch() throws Exception {
  // WechatUser inputWechatUserInfo = new WechatUser();
  // WechatUser anoInputWechatUserInfo = new WechatUser();
  // MockHttpSession session = new MockHttpSession();
  // WechatUser returnWechatUserInfo = new WechatUser();
  //
  // String wechatId = "wechatabc";
  // String companyId = "sap";
  // String verifyCodeInput = "heheda";
  // Long photoId = 123L;
  // inputWechatUserInfo.setWechatId(wechatId);
  // inputWechatUserInfo.setPhotoId(photoId);
  // inputWechatUserInfo.setInternalEmail("abc");
  // anoInputWechatUserInfo.setWechatId(wechatId);
  // anoInputWechatUserInfo.setPhotoId(photoId);
  // anoInputWechatUserInfo.setInternalEmail("efg");
  // when(wechatUserService.getUserInfoByWechatId(wechatId, companyId)).thenReturn(inputWechatUserInfo);
  // session.setAttribute(Constraints.SESSION_KEY_VERIFICATION_CODE, "heihei");
  // session.setAttribute(Constraints.SESSION_KEY_WECHAT_COMPANY_ID, companyId);
  // byte[] item = "heheda".getBytes();
  // session.setAttribute(wechatId + "_logo", item);
  //
  // Photo photo = new Photo();
  // photo.setPhotoId(photoId);
  // photo.setContent(item);
  // photo.setCategory("wechat_portrait");
  // when(wechatUserService.saveImg(any(Photo.class))).thenReturn(photo);
  // returnWechatUserInfo = userInfoController.bindInternalEmail(session, anoInputWechatUserInfo, verifyCodeInput);
  // }

  @Test
  public void testbindInternalEmailFailWithVerifyCodeMatch() throws Exception {
    WechatUser inputWechatUserInfo = new WechatUser();
    WechatUser anoInputWechatUserInfo = new WechatUser();
    MockHttpSession session = new MockHttpSession();
    WechatUser returnWechatUserInfo = new WechatUser();

    String wechatId = "wechatabc";
    String companyId = "sap";
    String verifyCodeInput = "heheda";
    Long photoId = 123L;
    inputWechatUserInfo.setWechatId(wechatId);
    inputWechatUserInfo.setPhotoId(photoId);
    inputWechatUserInfo.setInternalEmail("abc");
    anoInputWechatUserInfo.setWechatId(wechatId);
    anoInputWechatUserInfo.setPhotoId(photoId);
    anoInputWechatUserInfo.setInternalEmail("efg");
    when(wechatUserService.getUserInfoByEmail(wechatId, companyId)).thenReturn(inputWechatUserInfo);
    session.setAttribute(Constraints.SESSION_KEY_VERIFICATION_CODE, verifyCodeInput);
    byte[] item = "heheda".getBytes();
    session.setAttribute(wechatId + "_logo", item);

    Photo photo = new Photo();
    photo.setPhotoId(photoId);
    photo.setContent(item);
    photo.setCategory("wechat_portrait");
    when(wechatUserService.saveImg(any(Photo.class))).thenReturn(photo);
    returnWechatUserInfo = userInfoController.bindInternalEmail(session, anoInputWechatUserInfo, verifyCodeInput);
  }

  @Test
  public void testApplyHistorySuccess() throws Exception {
    List<WechatApplyHistory> applyHistoryList = new ArrayList<WechatApplyHistory>();
    MockHttpServletRequest request = new MockHttpServletRequest();

    WechatApplyHistory wechatApplyHistory = new WechatApplyHistory();
    wechatApplyHistory.setJobTitle("manager");
    applyHistoryList.add(wechatApplyHistory);
    String userEmail = "abc@sap.com";
    String companyId = "sap";
    when(wechatJobService.findApplyHistory(userEmail, companyId, null)).thenReturn(applyHistoryList);

    assertEquals("manager", userInfoController.getApplyHistoryList(request).get(0).getJobTitle());
  }

  @Test
  public void testApplyHistoryFail() throws Exception {
    List<WechatApplyHistory> applyHistoryList = new ArrayList<WechatApplyHistory>();
    MockHttpServletRequest request = new MockHttpServletRequest();

    WechatApplyHistory wechatApplyHistory = new WechatApplyHistory();
    wechatApplyHistory.setJobTitle("manager");
    applyHistoryList.add(wechatApplyHistory);
    String wechatId = "wechat001";
    String companyId = "sap";
    when(wechatJobService.findApplyHistory(wechatId, companyId, null)).thenThrow(
        new ServiceApplicationException("error"));
    userInfoController.getApplyHistoryList(request);
  }

  @Test
  public void testVerifyInternalEmailSuccess() throws Exception {
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    MockHttpServletRequest request = new MockHttpServletRequest();

    String veryCode = "abcd";
    String email = "abc@sap.com";

    SecureRandom sr = Mockito.mock(SecureRandom.class);
    Double rnd = 1.0;
    when(sr.nextDouble()).thenReturn(rnd);
    int code = (int) ((rnd * 9 + 1) * 1000);
    String verifyCode = Integer.toString(code);
    Mockito.doNothing().when(wechatUserService).sendVerificationCode(email, verifyCode);
    userInfoController.verifyInternalEmail(request, email);
  }

  @Test
  public void testVerifyInternalEmailFailWithNullPointer() throws Exception {
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    MockHttpServletRequest request = new MockHttpServletRequest();

    String veryCode = "abcd";
    String email = "abc@sap.com";

    SecureRandom sr = Mockito.mock(SecureRandom.class);
    Double rnd = 1.0;
    Mockito.doNothing().when(sr).setSeed((new Date()).getTime());
    when(sr.nextDouble()).thenReturn(rnd);
    int code = (int) ((rnd * 9 + 1) * 1000);
    String verifyCode = Integer.toString(code);
    Mockito.doThrow(new ServiceApplicationException("error")).when(wechatUserService)
        .sendVerificationCode(any(String.class), any(String.class));

  }

  @Test
  public void testFetchUserInfoSuccess() throws Exception {
    MockHttpServletRequest request = new MockHttpServletRequest();

    String email = "abc@sap.com";
    String companyId = "sap";
    WechatUser wu = new WechatUser();
    wu.setInternalEmail("abc@sap.com");
    when(wechatUserService.getUserInfoByEmail(email, companyId)).thenReturn(wu);

    assertEquals(1, userInfoController.fetchUserInfo(request).getCode());
  }

  @Test
  public void testFetchUserInfoFail() throws Exception {
    MockHttpServletRequest request = new MockHttpServletRequest();

    String email = "abc@sap.com";
    String companyId = "sap";
    WechatUser wu = new WechatUser();
    when(wechatUserService.getUserInfoByEmail(email, companyId)).thenReturn(wu);

    assertEquals(-1, userInfoController.fetchUserInfo(request).getCode());
  }
}
