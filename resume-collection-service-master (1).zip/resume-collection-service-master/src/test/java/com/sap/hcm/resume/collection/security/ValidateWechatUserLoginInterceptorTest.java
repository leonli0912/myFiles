package com.sap.hcm.resume.collection.security;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.when;

import javax.annotation.Resource;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;

import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.context.TestContext;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatUserService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { TestContext.class })
public class ValidateWechatUserLoginInterceptorTest {

  @Resource(name = "wechatUserService")
  private WechatUserService wechatUserService;

  @Autowired
  private Params params;

  private ValidateWechatUserLoginInterceptor wechatUserLoginInterceptor;

  @Before
  public void setUp() {
    reset(wechatUserService);
    wechatUserLoginInterceptor = new ValidateWechatUserLoginInterceptor();

    params.setCompanyId("sap");
    params.setWechatOpenId("openid");
    params.setUserEmail("123@sap.com");

    ReflectionTestUtils.setField(wechatUserLoginInterceptor, "wechatUserService", wechatUserService);
    ReflectionTestUtils.setField(wechatUserLoginInterceptor, "params", params);
  }

  @Test
  public void testPreHandleSuccess() throws Exception {
    MockHttpServletRequest request = new MockHttpServletRequest();
    String candidateId = "123";
    request.setParameter("candidateId", candidateId);
    request.setMethod("POST");
    MockHttpServletResponse response = new MockHttpServletResponse();
    Object handler = new Object();
    when(wechatUserService.checkIsCurrentID(Long.parseLong(candidateId), "123@sap.com", "sap")).thenReturn(true);
    assertEquals(true, wechatUserLoginInterceptor.preHandle(request, response, handler));
  }

  @Test
  public void testPreHandleErrorWithEmptyOpenId() throws Exception {
    params.setWechatOpenId(null);
    ReflectionTestUtils.setField(wechatUserLoginInterceptor, "params", params);
    MockHttpServletRequest request = new MockHttpServletRequest();
    String candidateId = "123";
    request.setParameter("candidateId", candidateId);
    request.setMethod("POST");
    MockHttpServletResponse response = new MockHttpServletResponse();
    Object handler = new Object();
    when(wechatUserService.checkIsCurrentID(Long.parseLong(candidateId), "123@sap.com", "sap")).thenReturn(true);
    assertEquals(false, wechatUserLoginInterceptor.preHandle(request, response, handler));
  }

  @Test
  public void testPreHandleErrorWithInvalidWechatUser() throws Exception {
    params.setWechatOpenId("openid");
    ReflectionTestUtils.setField(wechatUserLoginInterceptor, "params", params);
    MockHttpServletRequest request = new MockHttpServletRequest();
    String candidateId = "123";
    request.setParameter("candidateId", candidateId);
    request.setMethod("POST");
    MockHttpServletResponse response = new MockHttpServletResponse();
    Object handler = new Object();
    when(wechatUserService.checkIsCurrentID(Long.parseLong(candidateId), "123@sap.com", "sap")).thenReturn(false);
    assertEquals(true, wechatUserLoginInterceptor.preHandle(request, response, handler));
  }

  @Test(expected = ServiceApplicationException.class)
  public void testPreHandleErrorWithHeader() throws Exception {
    params.setWechatOpenId("openid");
    ReflectionTestUtils.setField(wechatUserLoginInterceptor, "params", params);
    MockHttpServletRequest request = new MockHttpServletRequest();
    String candidateId = "123";
    request.setParameter("candidateId", candidateId);
    request.addHeader("x-requested-with", "XMLHttpRequest");
    request.setMethod("POST");
    MockHttpServletResponse response = new MockHttpServletResponse();
    Object handler = new Object();
    when(wechatUserService.checkIsCurrentID(Long.parseLong(candidateId), "123@sap.com", "sap")).thenReturn(false);
    wechatUserLoginInterceptor.preHandle(request, response, handler);
  }
}
