package com.sap.hcm.resume.collection.integration.wechat.entity;

public class OAuthAccessToken {
  
  private String accessToken;

  private Integer expiresIn;

  private String openId;

  /**
   * @return the accessToken
   */
  public String getAccessToken() {
    return accessToken;
  }

  /**
   * @param accessToken the accessToken to set
   */
  public void setAccessToken(String accessToken) {
    this.accessToken = accessToken;
  }

  /**
   * @return the expiresIn
   */
  public Integer getExpiresIn() {
    return expiresIn;
  }

  /**
   * @param expiresIn the expiresIn to set
   */
  public void setExpiresIn(Integer expiresIn) {
    this.expiresIn = expiresIn;
  }

  /**
   * @return the openId
   */
  public String getOpenId() {
    return openId;
  }

  /**
   * @param openId the openId to set
   */
  public void setOpenId(String openId) {
    this.openId = openId;
  }

  
}
