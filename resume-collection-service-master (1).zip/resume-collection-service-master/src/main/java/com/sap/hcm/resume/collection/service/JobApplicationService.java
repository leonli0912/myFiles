package com.sap.hcm.resume.collection.service;

import java.util.List;
import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.sap.hcm.resume.collection.bean.JobAppQuestionResponse;
import com.sap.hcm.resume.collection.entity.DataModelMapping;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;
import com.sap.hcm.resume.collection.entity.view.JobApplyMappingVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.bean.CandProfileDataModelMapping;
import com.sap.hcm.resume.collection.integration.service.JobApplicationIntegrationService;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJob;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJobApplicationVO;

@Component
public class JobApplicationService {
  
  
  @Autowired
  @Qualifier(value="jobApplicationIntegrationServiceProxy")
  private JobApplicationIntegrationService integrationService;
  
  @Autowired
  private DataModelMappingService mappingService;

  @Autowired
  private DataModelMappingService dmMappingService;
  
  public WechatJobApplicationVO insertJobApplication(CandidateProfileVO candidateProfileVO,
      DataModelMapping mapping, WechatJob wechatJob, List<JobAppQuestionResponse> questionResponses) throws ServiceApplicationException {
    
    JobApplyMappingVO jobApplyMappingVO = mappingService.getApplyDataModelMappingByCompanyId(wechatJob.getCompanyId());
    CandProfileDataModelMapping profileMapping = dmMappingService.getProfileMapping(mapping);
    
    return integrationService.insertJobApplication(candidateProfileVO, mapping, wechatJob, jobApplyMappingVO, profileMapping, questionResponses);
  }
  
  public String queryAppliationStatus(String applicationId, Locale locale) throws ServiceApplicationException{
    return integrationService.queryApplicationStatus(applicationId, locale);
  }
}
