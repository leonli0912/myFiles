package com.sap.hcm.resume.collection.parser;

import org.springframework.context.MessageSource;

import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;

public abstract class TextDocumentParser {

  protected MessageSource messageSource;
  
  public TextDocumentParser(MessageSource messageSource){
    this.messageSource = messageSource;
  }
  
  public CandidateProfileVO parseCandidateProfile(CandidateProfileVO candidateProfileVO, String content) 
      throws ServiceApplicationException{
    this.parseProfile(candidateProfileVO, content);
    this.parseBackgroundWorkExp(candidateProfileVO, content);
    this.parseBackgroundCertificate(candidateProfileVO, content);
    this.parseBackgroundEducation(candidateProfileVO, content);
    this.parseBackgroundLanguage(candidateProfileVO, content);
    return candidateProfileVO;
  }; 
  
  public abstract CandidateProfileVO parseProfile(CandidateProfileVO candidateProfileVO, String content)
      throws ServiceApplicationException;

  public abstract CandidateProfileVO parseBackgroundWorkExp(CandidateProfileVO candidateProfileVO, String content)
      throws ServiceApplicationException;

  public abstract CandidateProfileVO parseBackgroundEducation(CandidateProfileVO candidateProfileVO, String content)
      throws ServiceApplicationException;

  public abstract CandidateProfileVO parseBackgroundLanguage(CandidateProfileVO candidateProfileVO, String content)
      throws ServiceApplicationException;

  public abstract CandidateProfileVO parseBackgroundCertificate(CandidateProfileVO candidateProfileVO, String content)
      throws ServiceApplicationException;

}
