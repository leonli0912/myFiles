package com.sap.hcm.resume.collection.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sap.hcm.resume.collection.bean.DropdownBean;
import com.sap.hcm.resume.collection.registry.CandidateVendorRegistry;

@Controller
@RequestMapping("/jobboards")
public class CandidateVendorController {

	@RequestMapping(value = "country", method = RequestMethod.GET)
	public @ResponseBody DropdownBean getCountries() {
		DropdownBean dp = new DropdownBean();
		dp.setOptions(CandidateVendorRegistry.getAllCountries());
		return dp;
	}

	@RequestMapping(value = "{countryCode}/vendor", method = RequestMethod.GET)
	public @ResponseBody DropdownBean getVenderName(@PathVariable(value = "countryCode") String countryCode) {
		DropdownBean dp = new DropdownBean();
		dp.setOptions(CandidateVendorRegistry.getVendorByCountry(countryCode));
		return dp;
	}

	@RequestMapping(value = "{countryCode}/{vendorCode}/template", method = RequestMethod.GET)
	public @ResponseBody DropdownBean getTemplateName(@PathVariable(value = "countryCode") String countryCode,
	        @PathVariable(value = "vendorCode") String vendorCode) {
		DropdownBean dp = new DropdownBean();
		dp.setOptions(CandidateVendorRegistry.getTemplateByCountryAndName(countryCode, vendorCode));
		return dp;
	}
}
