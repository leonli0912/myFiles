package com.sap.hcm.resume.collection.entity.view;

import java.io.Serializable;

import com.sap.hcm.resume.collection.annotation.ProfileAttribute;
import com.sap.hcm.resume.collection.util.I18nMessages;
import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("certificate")
public class CandidateBgCertificateVO implements CandidateBgBase, Serializable{

	/**
	 * serialVersionUID
	 */
    private static final long serialVersionUID = 5053277078804298399L;
    
    @ProfileAttribute(name="name", type=String.class, label=I18nMessages.LABEL_NAME)
    private String name;
    
    @ProfileAttribute(name="description", type=String.class, label=I18nMessages.LABEL_DESCRIPTION)
    private String description;
    
    @ProfileAttribute(name="institution", type=String.class, label=I18nMessages.LABEL_INSTITUTION)
    private String institution;
    
    @ProfileAttribute(name="score", type=String.class, label=I18nMessages.LABEL_SCORE)
    private String score;
    
    @ProfileAttribute(name="startDate", type=String.class, label=I18nMessages.LABEL_START_DATE)
    private String startDate;
    
    @ProfileAttribute(name="endDate", type=String.class, label=I18nMessages.LABEL_END_DATE)
    private String endDate;

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the institution
	 */
	public String getInstitution() {
		return institution;
	}

	/**
	 * @param institution the institution to set
	 */
	public void setInstitution(String institution) {
		this.institution = institution;
	}

	/**
	 * @return the score
	 */
	public String getScore() {
		return score;
	}

	/**
	 * @param score the score to set
	 */
	public void setScore(String score) {
		this.score = score;
	}

	/**
	 * @return the startDate
	 */
	public String getStartDate() {
		return startDate;
	}

	/**
	 * @param startDate the startDate to set
	 */
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	/**
	 * @return the endDate
	 */
	public String getEndDate() {
		return endDate;
	}

	/**
	 * @param endDate the endDate to set
	 */
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

}
