package com.sap.hcm.resume.collection.hcp;

import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sap.security.auth.login.LoginContextFactory;
import com.sap.security.um.user.User;
import com.sap.security.um.user.UserProvider;

/**
 * HCP user Provider
 * 
 * @author i065831
 *
 */
@Component
public class HCPUserProvider {

  @Autowired
  private UserProvider userProvider;

  private static Logger logger = LoggerFactory.getLogger(HCPUserProvider.class);

  public static final String LOGIN_USER = "LOGIN_USER";

  /**
   * get login hcp user
   * 
   * @param request
   * @return
   */
  public User getLoginUser(HttpServletRequest request) {

    // check the user from session
    HttpSession session = request.getSession();
    User user = (User) session.getAttribute(LOGIN_USER);
    if (user == null) {

      if (request.getUserPrincipal() != null) {
        try {
          user = userProvider.getUser(request.getUserPrincipal().getName());
          session.setAttribute(LOGIN_USER, user);
        } catch (com.sap.security.um.user.PersistenceException e) {
          logger.error("failed to get login user from HCP with message: " + e.getMessage());
        }

      }
    }
    return user;
  }

  public static boolean logout(HttpServletRequest request) {
    LoginContext loginContext = null;
    if (request.getRemoteUser() != null) {
      try {
        loginContext = LoginContextFactory.createLoginContext();
        loginContext.logout();

        request.getSession().invalidate();
      } catch (LoginException e) {
        return false;
      }
    }
    return true;
  }

}
