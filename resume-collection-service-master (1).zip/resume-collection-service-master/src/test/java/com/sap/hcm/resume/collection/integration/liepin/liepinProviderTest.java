package com.sap.hcm.resume.collection.integration.liepin;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

import javax.ws.rs.core.Response.Status;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.ProtocolVersion;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.message.BasicStatusLine;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mock.web.MockHttpServletRequest;

import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.HttpRequestMatcher;
import com.sap.hcm.resume.collection.integration.MockHttpEntity;
import com.sap.hcm.resume.collection.integration.bean.ResumeDownloadBean;


@RunWith(PowerMockRunner.class)
public class liepinProviderTest {

  private LiepinProvider liepinProvider;

  private CloseableHttpClient httpClient = null;

  @Before
  public void setUp() throws Exception {
    liepinProvider = PowerMockito.spy(new LiepinProvider());
    httpClient = Mockito.mock(CloseableHttpClient.class);

    PowerMockito.doReturn(httpClient).when(liepinProvider, "createHttpClient");
  }

  @Test
  public void testPreLogin() throws ClientProtocolException, IOException, ServiceApplicationException {
    CloseableHttpResponse response = Mockito.mock(CloseableHttpResponse.class);
    Mockito.when(httpClient.execute(Mockito.any(HttpGet.class))).thenReturn(response);

    Header header = new BasicHeader("Set-Cookie",
        "JSESSIONID=EB91B59A77CBA5192E0468B8AB60FFBD40C1CA58CED9E7C31BEE6F40E33E0566");
    Header[] headers = new Header[1];
    headers[0] = header;
    Mockito.when(response.getHeaders("Set-Cookie")).thenReturn(headers);

    liepinProvider.preLogin();
  }

  @Test
  public void testPreLoginFailed() throws ClientProtocolException, IOException, ServiceApplicationException {
    Mockito.when(httpClient.execute(Mockito.any(HttpGet.class))).thenThrow(new IOException("failed"));
    liepinProvider.preLogin();
  }

  @Test
  public void testGetVerifyCodeSuccess() throws ClientProtocolException, IOException, ServiceApplicationException {
    CloseableHttpResponse response = Mockito.mock(CloseableHttpResponse.class);
    Mockito.when(httpClient.execute(Mockito.any(HttpGet.class))).thenReturn(response);

    MockHttpServletRequest mockRequest = new MockHttpServletRequest();
    ClassPathResource image = new ClassPathResource("/images/test.png");
    HttpEntity mockGetVerifyCodeEntity = new MockHttpEntity("image/png", image.getInputStream());
    Mockito.when(response.getEntity()).thenReturn(mockGetVerifyCodeEntity);

    liepinProvider.getVerifyCode(mockRequest);
  }

  @Test(expected = ServiceApplicationException.class)
  public void testGetVerifyCodeFailed() throws ClientProtocolException, IOException, ServiceApplicationException {

    Mockito.when(httpClient.execute(Mockito.any(HttpGet.class))).thenThrow(new RuntimeException("test"));
    MockHttpServletRequest mockRequest = new MockHttpServletRequest();
    liepinProvider.getVerifyCode(mockRequest);
  }

  @Test(expected = ServiceApplicationException.class)
  public void testGetResumeFailedWithNullResponse()
      throws ClientProtocolException, IOException, ServiceApplicationException {

    HttpRequestMatcher loginPost = new HttpRequestMatcher(LiepinProvider.LOGIN_URL);
    Mockito.when(httpClient.execute(Matchers.argThat(loginPost))).thenReturn(null);

    MockHttpServletRequest mockRequest = new MockHttpServletRequest();

    liepinProvider.getResume(mockRequest, "test", "test", "test");

  }

  @Test(expected = ServiceApplicationException.class)
  public void testGetResumeFailedWithWrongResponseStatus()
      throws ClientProtocolException, IOException, ServiceApplicationException {
    HttpRequestMatcher loginPost = new HttpRequestMatcher(LiepinProvider.LOGIN_URL);
    CloseableHttpResponse response = Mockito.mock(CloseableHttpResponse.class);
    ProtocolVersion protocolVer = new ProtocolVersion("http",1,2);
    Mockito.when(response.getStatusLine()).thenReturn(new BasicStatusLine(protocolVer, 500, Status.INTERNAL_SERVER_ERROR.getReasonPhrase()));
    
    Mockito.when(httpClient.execute(Matchers.argThat(loginPost))).thenReturn(response);
    MockHttpServletRequest mockRequest = new MockHttpServletRequest();

    liepinProvider.getResume(mockRequest, "test", "test", "test");
  }
  
  @Test(expected = ServiceApplicationException.class)
  public void testGetResumeFailedWithWrongCredential() throws ServiceApplicationException, ClientProtocolException, IOException{
    HttpRequestMatcher loginPost = new HttpRequestMatcher(LiepinProvider.LOGIN_URL);
    CloseableHttpResponse response = Mockito.mock(CloseableHttpResponse.class);
    
    ProtocolVersion protocolVer = new ProtocolVersion("http",1,2);
    Mockito.when(response.getStatusLine()).thenReturn(new BasicStatusLine(protocolVer, 200, Status.OK.getReasonPhrase()));
    
    HttpEntity loginRspEntity = new MockHttpEntity("plain/text", "aa");
    Mockito.when(response.getEntity()).thenReturn(loginRspEntity);
    
    Mockito.when(httpClient.execute(Matchers.argThat(loginPost))).thenReturn(response);
    MockHttpServletRequest mockRequest = new MockHttpServletRequest();
    liepinProvider.getResume(mockRequest, "test", "test", "test");
  }
  
  @Test(expected = ServiceApplicationException.class)
  public void testGetResumeFailedWithWrongVerifyCode() throws ClientProtocolException, IOException, ServiceApplicationException{
    HttpRequestMatcher loginPost = new HttpRequestMatcher(LiepinProvider.LOGIN_URL);
    CloseableHttpResponse response = Mockito.mock(CloseableHttpResponse.class);
    
    ProtocolVersion protocolVer = new ProtocolVersion("http",1,2);
    Mockito.when(response.getStatusLine()).thenReturn(new BasicStatusLine(protocolVer, 200, Status.OK.getReasonPhrase()));
    
    HttpEntity loginRspEntity = new MockHttpEntity("plain/text", "验证码不正确");
    Mockito.when(response.getEntity()).thenReturn(loginRspEntity);
    
    Mockito.when(httpClient.execute(Matchers.argThat(loginPost))).thenReturn(response);
    MockHttpServletRequest mockRequest = new MockHttpServletRequest();
    liepinProvider.getResume(mockRequest, "test", "test", "test");
  }
  
  @Test
  public void testGetResumeSucess() throws ClientProtocolException, IOException, ServiceApplicationException{
    HttpRequestMatcher loginPost = new HttpRequestMatcher(LiepinProvider.LOGIN_URL);
    CloseableHttpResponse response = Mockito.mock(CloseableHttpResponse.class);
    
    ProtocolVersion protocolVer = new ProtocolVersion("http",1,2);
    Mockito.when(response.getStatusLine()).thenReturn(new BasicStatusLine(protocolVer, 200, Status.OK.getReasonPhrase()));
    
    HttpEntity loginRspEntity = new MockHttpEntity("plain/text", "{user_id:1233}");
    Mockito.when(response.getEntity()).thenReturn(loginRspEntity);
    
    Header header = new BasicHeader("Set-Cookie",
        "JSESSIONID=EB91B59A77CBA5192E0468B8AB60FFBD40C1CA58CED9E7C31BEE6F40E33E0566");
    Header[] headers = new Header[1];
    headers[0] = header;
    Mockito.when(response.getHeaders("Set-Cookie")).thenReturn(headers);
    
    Mockito.when(httpClient.execute(Matchers.argThat(loginPost))).thenReturn(response);
    MockHttpServletRequest mockRequest = new MockHttpServletRequest();
    
    //login after
    HttpRequestMatcher loginAfterGet = new HttpRequestMatcher("http://c.liepin.com/?time=");
    CloseableHttpResponse loginAfterResponse = Mockito.mock(CloseableHttpResponse.class);
    
    String resumeLink = "<a target=\"_blank\" href=\"/resume/regresume/?res_id_encode=f8fb627fS2ad67a83\" class=\"icon-16 icon-redit\" title=\"修改简历\"></a>";
    HttpEntity loginAfterRspEntity = new MockHttpEntity("plain/text", resumeLink);
    Mockito.when(loginAfterResponse.getEntity()).thenReturn(loginAfterRspEntity);
    
    header = new BasicHeader("Set-Cookie",
        "JSESSIONID=EB91B59A77CBA5192E0468B8AB60FFBD40C1CA58CED9E7C31BEE6F40E33E0566");
    headers = new Header[1];
    headers[0] = header;
    Mockito.when(loginAfterResponse.getHeaders("Set-Cookie")).thenReturn(headers);
    Mockito.when(httpClient.execute(Matchers.argThat(loginAfterGet))).thenReturn(loginAfterResponse);
    
    //resume content simulation
    HttpRequestMatcher resumeContentGet = new HttpRequestMatcher("http://c.liepin.com/resume/download?res_id_encode=");
    CloseableHttpResponse resumeContentResponse = Mockito.mock(CloseableHttpResponse.class);
    
    HttpEntity resumeContentEntity = new MockHttpEntity("plain/text", "基本资料");
    Mockito.when(resumeContentResponse.getEntity()).thenReturn(resumeContentEntity);
    Mockito.when(httpClient.execute(Matchers.argThat(resumeContentGet))).thenReturn(resumeContentResponse);
    
    List<ResumeDownloadBean> dbList = liepinProvider.getResume(mockRequest, "test", "test", "test");
    Assert.assertEquals(dbList.size(), 1);
    Assert.assertEquals(dbList.get(0).getLocale(), Locale.CHINA);
  }
  
}
