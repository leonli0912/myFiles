package com.sap.hcm.resume.collection.integration.job51;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.ArrayUtils;
import org.springframework.context.MessageSource;
import org.springframework.util.StringUtils;

import com.sap.hcm.resume.collection.entity.view.CandidateBgCertificateVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgEducationVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgLanguageVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgWorkExprVO;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.parser.TextDocumentParser;
import com.sap.hcm.resume.collection.util.MappingUtil;

public class ResumeParser51 extends TextDocumentParser {

  public ResumeParser51(MessageSource messageSource) {
    super(messageSource);
  }
  
  @Override
  public CandidateProfileVO parseProfile(CandidateProfileVO candidateProfileVO, String text)
      throws ServiceApplicationException {

    try {
      String regex = null;

      // primaryEmail 电子邮件 主键
      regex = "(?<=E-mail：)\\s*\\S*"; // 获取邮箱的正则
      candidateProfileVO.setPrimaryEmail((MappingUtil.matchSingle(regex, text)).trim());

      // contactEmail 电子邮件
      candidateProfileVO.setContactEmail(candidateProfileVO.getPrimaryEmail());

      // country 国籍
      candidateProfileVO.setCountry("CN");
      // 获取姓名的正则
      String fullName = "";
      if (text.contains("简历关键字")) {
        regex = "(?<=(简历关键字：.{0,100}(\r\n|\n)))\\S+";
        fullName = MappingUtil.matchSingle(regex, text);
      } else if (text.contains("简历匹配度")) {
        regex = "(?<=(简历匹配度：(\r\n|\n)\\d{1,3}%(\r\n|\n)))\\S+";
        fullName = MappingUtil.matchSingle(regex, text);
      } else if (text.contains("更新时间")) {
        regex = "(?<=(更新时间：\\d{4}-\\d{2}-\\d{2}[\r\n]{1,2}))\\S+";
        fullName = MappingUtil.matchSingle(regex, text);
      } else {
        regex = "\n[\\s\\S]*(?=\n\\S+年工作经验)";
        String nameLine = MappingUtil.matchSingle(regex, text);
        String[] items = nameLine.split(" ");
        fullName = items[0].trim();
      }

      // firstName 名
      candidateProfileVO.setFirstName(fullName.substring(1, fullName.length()));

      // lastName 姓
      candidateProfileVO.setLastName(fullName.substring(0, 1));

      // marriage
      regex = "(?<=|)\\S+(?=婚)";
      String marriage = MappingUtil.matchSingle(regex, text);

      if (marriage.equals("已")) {
        candidateProfileVO.setMarriage("Y");
      } else {
        candidateProfileVO.setMarriage("N");
      }

      // cellPhone 移动电话
      regex = "(?<=电　话：)\\s*\\d*"; // 获取手机号码的正则
      candidateProfileVO.setCellPhone((MappingUtil.matchSingle(regex, text)).trim());

      // ENName 英文名
      candidateProfileVO.setEnglishName("");

      // gender 性别
      regex = "(?<=\\|\\s{0,2})\\S(?=\\s{0,2}\\|)"; // 获取性别的正则
      String gender = MappingUtil.matchSingle(regex, text);
      if ("男".equals(gender)) {
        candidateProfileVO.setGender("Male");
      } else if ("女".equals(gender)) {
        candidateProfileVO.setGender("Female");
      } else {
        candidateProfileVO.setGender("");
      }

      // identitycard 身份证码
      candidateProfileVO.setIdentityCard("");

      // dateOfBirth
      regex = "(?<=岁\\S)\\S*\\s*\\d+日"; // 获取出生日期的正则
      String dateOfBirth = MappingUtil.matchSingle(regex, text);
      String year = dateOfBirth.substring(0, 4);
      regex = "(?<=年)\\d+";
      String month = MappingUtil.matchSingle(regex, dateOfBirth);
      regex = "(?<=月)\\s*\\d+";
      String day = MappingUtil.matchSingle(regex, dateOfBirth).trim();
      if (month != null && month.length() == 1) {
        month = "0" + month;
      }
      candidateProfileVO.setDateOfBirth(year + "/" + month + "/" + day);

      // nationality 国籍
      candidateProfileVO.setNationality("");

      // ethnicity
      candidateProfileVO.setEthnicity("Asian");

      // residence 现居住城市
      regex = "(?<=居住地：)\\s*\\S*"; // 获取地址的正则
      candidateProfileVO.setResidence((MappingUtil.matchSingle(regex, text)).trim());

      // zip
      candidateProfileVO.setZipcode("");

      // address
      regex = "(?<=地　址：)\\s*\\S*";
      candidateProfileVO.setAddress((MappingUtil.matchSingle(regex, text)).trim());

      // houseHold 户口性质
      regex = "(?<=户　口：)\\s*\\S*";
      candidateProfileVO.setHousehold((MappingUtil.matchSingle(regex, text)).trim());

      // minAnnualSal
      regex = "(?<=期望月薪：\\s)\\d*(?=/月)"; // 获取期望收入的正则
      String minAnnualSal = MappingUtil.matchSingle(regex, text);
      if (!minAnnualSal.isEmpty()) {
        candidateProfileVO.setMinAnnualSal(Integer.parseInt(MappingUtil.matchSingle(regex, text)) * 12 + "");
      } else {
        candidateProfileVO.setMinAnnualSal("0");
      }

      // preferredLoc
      candidateProfileVO.setPreferredLoc("");

      // currency CNY is the default value for SF
      candidateProfileVO.setCurrency("CNY");

      // lastLogin
      candidateProfileVO.setLastModify(null);
    } catch (Exception e) {
      throw new ServiceApplicationException("Profile parse error" + e.getMessage());
    }

    return candidateProfileVO;
  }

  /**
   * get workExp
   * 
   * @return dataList
   */
  @Override
  public CandidateProfileVO parseBackgroundWorkExp(CandidateProfileVO candidateProfileVO, String text)
      throws ServiceApplicationException {

    try {
      String regex = null;
      List<CandidateBgWorkExprVO> candidateBgWorkExprVOList = new ArrayList<CandidateBgWorkExprVO>();

      String workExp = getWorkExpMatchGroup(text);

      regex = "\\d{4}\\s/\\d{1,2}[\\s\\S]*?(?=\\d{4}\\s/\\d{1,2}--\\d{4}\\s/\\d{1,2}|$)";
      Pattern pattern = Pattern.compile(regex);
      Matcher matcher = pattern.matcher(workExp);

      CandidateBgWorkExprVO candidateBgWorkExprVO = null;

      while (matcher.find()) {

        candidateBgWorkExprVO = new CandidateBgWorkExprVO();

        // presentEmployer
        regex = "(?<=\\d{4}\\s/\\d{1,2}(--|―)至今：).{0,100}(?=\\[)";
        String presentEmployer = MappingUtil.matchSingle(regex, matcher.group());
        if (!presentEmployer.isEmpty()) {
          candidateBgWorkExprVO.setIsPresent(true);
          candidateBgWorkExprVO.setPresentEmployer("Yes");
        } else {
          candidateBgWorkExprVO.setIsPresent(false);
          candidateBgWorkExprVO.setPresentEmployer("No");
        }

        // employer 公司名称
        regex = "(?<=\\d{4}\\s/\\d{1,2}(--|―)(\\d{4}\\s/\\d{1,2}|至今)：).{0,100}(?=\\()";
        String employer = MappingUtil.matchSingle(regex, matcher.group());
        if (!employer.isEmpty()) {
          candidateBgWorkExprVO.setEmployer(MappingUtil.matchSingle(regex, matcher.group()).trim());
        } else {
          regex = "(?<=\\d{4}\\s/\\d{1,2}(--|―)(\\d{4}\\s/\\d{1,2}|至今)：).{0,100}(?=\\s\\[)";
          candidateBgWorkExprVO.setEmployer(MappingUtil.matchSingle(regex, matcher.group()).trim());
        }

        // title 职位 department 部门
        regex = "(?<=\\d{4}\\s/\\d{1,2}.{0,300}(\r\n|\n))[\\s\\S]*(?=(\r\n|\n|$))";
        String titleRaw = MappingUtil.matchSingle(regex, matcher.group());

        if (!StringUtils.isEmpty(titleRaw)) {
          String[] lines = titleRaw.split("\\n");
          String line1 = "";
          String line2 = "";
          if (lines.length == 2) {
            line1 = lines[0];
            line2 = lines[1];
          } else if (lines.length >= 3) {
            line1 = lines[0];
            line2 = lines[1];

            String[] descriptionsArray = (String[]) ArrayUtils.subarray(lines, 2, lines.length);
            // build the description back
            StringBuilder descrBuilder = new StringBuilder();
            for (int i = 0; i < descriptionsArray.length; i++) {
              descrBuilder.append(descriptionsArray[i]);
              descrBuilder.append(System.lineSeparator());
            }
            candidateBgWorkExprVO.setDescription(descrBuilder.toString());
          }

          // handle industry and job title
          if (line1.contains("所属行业")) {
            String industry = line1.replaceAll("所属行业：", "").trim();
            candidateBgWorkExprVO.setBusinessType(industry);

            // then line2 would be department and job title
            String[] departmentJobTitle = line2.replaceAll("\\s+", " ").split(" ");
            if (departmentJobTitle.length == 1) {
              candidateBgWorkExprVO.setJobTitle(departmentJobTitle[0].trim());
            } else {
              candidateBgWorkExprVO.setDepartment(departmentJobTitle[0].trim());
              candidateBgWorkExprVO.setJobTitle(departmentJobTitle[1].trim());
            }
          }
          if (line1.contains("职位名称")) {
            regex = "(?<=职位名称：\\s{0,4})[\\s\\S]+(?=部门)";
            String jobTitle = MappingUtil.matchSingle(regex, line1);
            candidateBgWorkExprVO.setJobTitle(jobTitle.trim());

            regex = "(?<=部门：\\s{0,4})[\\s\\S]+$";
            String department = MappingUtil.matchSingle(regex, line1);
            candidateBgWorkExprVO.setDepartment(department.trim());

            // handle industry in line2
            regex = "(?<=行业：\\s{0,4})[\\s\\S]+$";
            String industry = MappingUtil.matchSingle(regex, line2);
            candidateBgWorkExprVO.setBusinessType(industry.trim());
          }
        }

        // startDate 开始时间
        regex = "^\\d{4}\\s/\\d{1,2}";
        String startDate = MappingUtil.matchSingle(regex, matcher.group());
        regex = "(\\d{4})(\\s/)(\\d{1,2})";
        Pattern patternStartDate = Pattern.compile(regex);
        Matcher matcherStartDate = patternStartDate.matcher(startDate);
        if (matcherStartDate.find()) {
          // startDate 开始时间
          String month = matcherStartDate.group(3);
          if (month != null && month.length() == 1) {
            month = "0" + month;
          }
          candidateBgWorkExprVO.setStartDate(matcherStartDate.group(1) + "/" + month + "/01");
        }

        // endDate 结束时间
        regex = "(?<=\\d{4}\\s/\\d{1,2}(--|―))\\d{4}\\s/\\d{1,2}";
        String endDate = MappingUtil.matchSingle(regex, matcher.group());
        regex = "(\\d{4})(\\s/)(\\d{1,2})";
        Pattern patternEndDate = Pattern.compile(regex);
        Matcher matcherEndDate = patternEndDate.matcher(endDate);
        if (matcherEndDate.find()) {
          // endDate 结束时间
          String month = matcherEndDate.group(3);
          if (month != null && month.length() == 1) {
            month = "0" + month;
          }
          candidateBgWorkExprVO.setEndDate(matcherEndDate.group(1) + "/" + month + "/01");
        } else {
          regex = "(?<=\\d{4}\\s/\\d{1,2}(--|―))至今";
          endDate = MappingUtil.matchSingle(regex, matcher.group());
          if ("至今".equals(endDate)) {
            candidateBgWorkExprVO.setEndDate("NOW");
          }
        }

        // // description
        // regex =
        // "(?<=所属行业：[\\s\\S]{0,100}(\r\n|\n)[\\s\\S]{0,100}(\r\n|\n))[\\s\\S]+";
        // candidateBgWorkExprVO.setDescription(MappingUtil.matchSingle(regex,
        // matcher.group()));

        // exitReason
        candidateBgWorkExprVO.setExitReason("unkown");

        // salary
        candidateBgWorkExprVO.setSalary("unkown");

        // salaryEnd
        candidateBgWorkExprVO.setSalaryEnd("unkown");

        candidateBgWorkExprVOList.add(candidateBgWorkExprVO);
      }

      candidateProfileVO.setWorkExprs(candidateBgWorkExprVOList);
    } catch (Exception e) {
      throw new ServiceApplicationException("Work experience parse error" + e.getMessage());
    }

    return candidateProfileVO;
  }

  /**
   * get education
   * 
   * @return dataList
   */
  @Override
  public CandidateProfileVO parseBackgroundEducation(CandidateProfileVO candidateProfileVO, String text)
      throws ServiceApplicationException {

    try {
      String regex = null;
      List<CandidateBgEducationVO> candidateBgEducationVOList = new ArrayList<CandidateBgEducationVO>();
      CandidateBgEducationVO candidateBgEducationVO = null;
      String education = getEducationMatchGroup(text);

      regex = "\\d{4}\\s/\\d{1,2}[\\s\\S]*?(?=\\d{4}\\s/\\d{1,2}(--|―)\\d{4}\\s/\\d{1,2}|$)";
      Pattern pattern = Pattern.compile(regex);
      Matcher matcher = pattern.matcher(education);

      while (matcher.find()) {

        candidateBgEducationVO = new CandidateBgEducationVO();
        String tempInfo = "";

        if (matcher.group().contains("\n")) {
          regex = "(?<=\\d{4}\\s/\\d{1,2}(--|―)(\\d{4}\\s/\\d{1,2}|(至今|今)))[\\s\\S]*(?=(\r\n|\n))";
          tempInfo = MappingUtil.matchSingle(regex, matcher.group());
        } else {
          regex = "(?<=\\d{4}\\s/\\d{1,2}(--|―)(\\d{4}\\s/\\d{1,2}|(至今|今)))[\\s\\S]*(?=$)";
          tempInfo = MappingUtil.matchSingle(regex, matcher.group());
        }

        regex = "(\\s*)(\\S*)(\\s*)(\\S*)(\\s*)(\\S*)";
        Pattern patternEducation = Pattern.compile(regex);
        Matcher matcherEducation = patternEducation.matcher(tempInfo);
        Map<String, String> degrees = new HashMap<String, String>();
        degrees.put("大专", "大专");
        degrees.put("本科", "学士");
        degrees.put("研究生", "硕士");
        degrees.put("博士生", "博士");
        if (matcherEducation.find()) {
          // major
          candidateBgEducationVO.setMajor(matcherEducation.group(4));
          // school
          candidateBgEducationVO.setSchool(matcherEducation.group(2));
          // degree
          String degree = matcherEducation.group(6);
          if(degrees.containsKey(degree)){
            candidateBgEducationVO.setDegree(degrees.get(degree));
          }else{
            candidateBgEducationVO.setDegree("其他");
          }
        }

        // startDate
        regex = "^\\d{4}\\s/\\d{1,2}";
        String startDate = MappingUtil.matchSingle(regex, matcher.group());
        regex = "(\\d{4})(\\s/)(\\d{1,2})";
        Pattern patternStartDate = Pattern.compile(regex);
        Matcher matcherStartDate = patternStartDate.matcher(startDate);
        if (matcherStartDate.find()) {
          // startDate 开始时间
          String month = matcherStartDate.group(3);
          if (!StringUtils.isEmpty(month) && month.length() == 1) {
            month = "0" + month;
          }
          candidateBgEducationVO.setStartDate(matcherStartDate.group(1) + "/" + month + "/01");
        }

        // endDate
        regex = "(?<=\\d{4}\\s/\\d{1,2}(--|―))(\\d{4}\\s/\\d{1,2}|(至今|今))";
        String endDate = MappingUtil.matchSingle(regex, matcher.group());
        regex = "(\\d{4})(\\s/)(\\d{1,2})";
        Pattern patternEndDate = Pattern.compile(regex);
        Matcher matcherEndDate = patternEndDate.matcher(endDate);
        if (matcherEndDate.find()) {
          // endDate 结束时间
          String month = matcherEndDate.group(3);
          if (!StringUtils.isEmpty(month) && month.length() == 1) {
            month = "0" + month;
          }
          candidateBgEducationVO.setEndDate(matcherEndDate.group(1) + "/" + month + "/01");
        } else {
          candidateBgEducationVO.setEndDate("NOW");
        }

        // schoolState
        candidateBgEducationVO.setSchoolState("no comment");

        // gpa
        candidateBgEducationVO.setGpa("no comment");

        candidateBgEducationVOList.add(candidateBgEducationVO);
      }

      candidateProfileVO.setEducation(candidateBgEducationVOList);
    } catch (Exception e) {
      throw new ServiceApplicationException("Education parse error");
    }

    return candidateProfileVO;
  }

  /**
   * get language
   * 
   * @return dataList
   */
  @Override
  public CandidateProfileVO parseBackgroundLanguage(CandidateProfileVO candidateProfileVO, String text)
      throws ServiceApplicationException {

    List<CandidateBgLanguageVO> candidateBgLanguageVOList = new ArrayList<CandidateBgLanguageVO>();
    try {
      String regex = null;

      String language = getLanguageMatchGroup(text).trim();
      String[] langArray = language.split("\\r\\n");

      CandidateBgLanguageVO candidateBgLanguageVO = null;
      Map<String, String> LangWithProf = new HashMap<String, String>();

      for (String piece : langArray) {
        if(StringUtils.isEmpty(piece)){
          continue;
        }
        candidateBgLanguageVO = new CandidateBgLanguageVO();
        if (piece.indexOf("等级") < 0) {
          if (piece.contains("：")) {
            regex = ".{0,10}(?=（.{0,10}）：)";
            candidateBgLanguageVO.setName(MappingUtil.matchSingle(regex, piece));

            // speakingProf
            regex = "(?<=听说（)\\S*(?=），)";
            String speakingProf = MappingUtil.matchSingle(regex, piece);
            candidateBgLanguageVO.setSpeakingProf(speakingProf);

            regex = "(?<=读写（)\\S*(?=）)";
            String readingAndWritingProf = MappingUtil.matchSingle(regex, piece);
            candidateBgLanguageVO.setReadingProf(readingAndWritingProf);
            candidateBgLanguageVO.setWritingProf(readingAndWritingProf);
          } else {
            String[] langItem = piece.split("（");
            candidateBgLanguageVO.setName(langItem[0]);
            String langLevel = langItem[1].replace("）", "");
            
            candidateBgLanguageVO.setSpeakingProf(langLevel);
            candidateBgLanguageVO.setReadingProf(langLevel);
            candidateBgLanguageVO.setWritingProf(langLevel);
           
          }
          
          candidateBgLanguageVOList.add(candidateBgLanguageVO);
          LangWithProf.put(candidateBgLanguageVO.getName(), candidateBgLanguageVO.getName());
        }
      }

      for (String piece : langArray) {
        if(StringUtils.isEmpty(piece)){
          continue;
        }
        candidateBgLanguageVO = new CandidateBgLanguageVO();
        if (piece.indexOf("等级") > 0) {
          regex = "\\S*(?=等级：)";

          String langName = MappingUtil.matchSingle(regex, piece);
          if (!LangWithProf.containsKey(langName)) {
            candidateBgLanguageVO.setName(langName);

            candidateBgLanguageVO.setReadingProf("一般");
            candidateBgLanguageVO.setWritingProf("一般");
            candidateBgLanguageVO.setSpeakingProf("一般");
            candidateBgLanguageVOList.add(candidateBgLanguageVO);
          }
        }
      }
    } catch (Exception e) {
      throw new ServiceApplicationException("Languages parse error");
    }
    candidateProfileVO.setLanguages(candidateBgLanguageVOList);
    return candidateProfileVO;
  }

  /**
   * get certificate
   * 
   * @return dataList
   */
  @Override
  public CandidateProfileVO parseBackgroundCertificate(CandidateProfileVO candidateProfileVO, String text)
      throws ServiceApplicationException {

    try {
      String regex = null;
      List<CandidateBgCertificateVO> candidateBgCertificateVOList = new ArrayList<CandidateBgCertificateVO>();

      String certificate = getCertificateMatchGroup(text);

      regex = "\\d{4}\\s/\\d{1,2}[\\s\\S]*?(?=\\d{4}\\s/\\d{1,2}|$)";
      Pattern pattern = Pattern.compile(regex);
      Matcher matcher = pattern.matcher(certificate);

      CandidateBgCertificateVO candidateBgCertificateVO = null;

      while (matcher.find()) {

        candidateBgCertificateVO = new CandidateBgCertificateVO();

        // name
        regex = "(?<=/\\d{1,2})\\s+\\S*";
        candidateBgCertificateVO.setName(MappingUtil.matchSingle(regex, matcher.group()));

        // description
        candidateBgCertificateVO.setDescription("");

        // institution
        candidateBgCertificateVO.setInstitution("");

        // startDate
        regex = "^\\d{4}\\s/\\d{1,2}";
        String startDate = MappingUtil.matchSingle(regex, matcher.group());
        regex = "(\\d{4})(\\s/)(\\d{1,2})";
        Pattern patternStartDate = Pattern.compile(regex);
        Matcher matcherStartDate = patternStartDate.matcher(startDate);
        if (matcherStartDate.find()) {
          // startDate 开始时间
          candidateBgCertificateVO.setStartDate(matcherStartDate.group(1) + "/" + matcherStartDate.group(3) + "/01");
        }

        // endDate
        candidateBgCertificateVO.setEndDate(null);

        candidateBgCertificateVOList.add(candidateBgCertificateVO);
      }

      candidateProfileVO.setCertificates(candidateBgCertificateVOList);
    } catch (Exception e) {
      throw new ServiceApplicationException("Certificates parse error");
    }

    return candidateProfileVO;
  }

  /**
   * profile match
   * 
   * @return profile
   */
  public String getProfileMatchGroup(String text) {

    String regex = "(?<=应聘职位.{0,100}[\r\n|\n])[\\S\\s]*(?=工作经验)"; // 获取个人资料的正则[结果为多条，需要进一步解析]
    String profile = MappingUtil.matchSingle(regex, text);

    if (profile.isEmpty()) {
      regex = "(?<=个人信息[\r\n|\n].{0,100})[\\S\\s]*(?=教育经历[\r\n|\n])";
      profile = MappingUtil.matchSingle(regex, text);
    }

    return profile;
  }

  /**
   * work Exp match
   * 
   * @return workExp
   */
  public String getWorkExpMatchGroup(String text) {

    String regex = "(?<=工作经验[\r\n|\n].{0,100})[\\S\\s]*(?=项目经验[\r\n|\n])"; // 获取工作经历的正则[结果为多条，需要进一步解析]
    String workExp = MappingUtil.matchSingle(regex, text);
    //locate the ending clause and ensure they do exist
    if (workExp.isEmpty()) {
      regex = "(?<=工作经验[\r\n|\n].{0,100})[\\S\\s]*(?=教育经历[\r\n|\n])";
      workExp = MappingUtil.matchSingle(regex, text);
    }
    if (workExp.isEmpty()) {
      regex = "(?<=工作经验[\r\n|\n].{0,100})[\\S\\s]*(?=培训经历[\r\n|\n])";
      workExp = MappingUtil.matchSingle(regex, text);
    }
    if (workExp.isEmpty()) {
      regex = "(?<=工作经验[\r\n|\n].{0,100})[\\S\\s]*(?=证书[\r\n|\n])";
      workExp = MappingUtil.matchSingle(regex, text);
    }
    if (workExp.isEmpty()) {
      regex = "(?<=工作经验[\r\n|\n].{0,100})[\\S\\s]*(?=语言能力[\r\n|\n])";
      workExp = MappingUtil.matchSingle(regex, text);
    }
    if (workExp.isEmpty()) {
      regex = "(?<=工作经验[\r\n|\n].{0,100})[\\S\\s]*(?=其他信息[\r\n|\n])";
      workExp = MappingUtil.matchSingle(regex, text);
    }

    return workExp;
  }

  /**
   * education match
   * 
   * @return education
   */
  public String getEducationMatchGroup(String text) {

    String regex = "(?<=教育经历[\r\n|\n].{0,100})[\\S\\s]*?(?=(\r\n|\n)所获奖项(\r\n|\n))"; // 获取教育经历的正则[结果为多条，需要进一步解析]
    String education = MappingUtil.matchSingle(regex, text);

    if (education.isEmpty()) {
      regex = "(?<=教育经历[\r\n|\n].{0,100})[\\S\\s]*?(?=(\r\n|\n)校内职务(\r\n|\n))";
      education = MappingUtil.matchSingle(regex, text);
    }
    if (education.isEmpty()) {
      regex = "(?<=教育经历[\r\n|\n].{0,100})[\\S\\s]*?(?=(\r\n|\n)培训经历(\r\n|\n))";
      education = MappingUtil.matchSingle(regex, text);
    }
    if (education.isEmpty()) {
      regex = "(?<=教育经历[\r\n|\n].{0,100})[\\S\\s]*?(?=(\r\n|\n)证书(\r\n|\n))";
      education = MappingUtil.matchSingle(regex, text);
    }
    if (education.isEmpty()) {
      regex = "(?<=教育经历[\r\n|\n].{0,100})[\\S\\s]*?(?=(\r\n|\n)语言能力(\r\n|\n))";
      education = MappingUtil.matchSingle(regex, text);
    }

    return education;
  }

  /**
   * language match
   * 
   * @return education
   */
  public String getLanguageMatchGroup(String text) {

    String regex = "(?<=语言能力[\r\n|\n].{0,100})[\\S\\s]*(?=IT 技能)"; // 获取语言的正则[结果为多条，需要进一步解析]
    String language = MappingUtil.matchSingle(regex, text);

    if (language.isEmpty()) {
      regex = "(?<=语言能力[\r\n|\n].{0,100})[\\S\\s]*(?=其他信息)";
    }
    if (language.isEmpty()) {
      regex = "(?<=语言能力[\r\n|\n].{0,100})[\\S\\s]*";
    }
    language = MappingUtil.matchSingle(regex, text);

    return language;
  }

  /**
   * certificate match
   * 
   * @return education
   */
  public String getCertificateMatchGroup(String text) {

    String regex = "(?<=[\r\n|\n]证\\s{0,100}书[\r\n|\n].{0,100})[\\S\\s]*(?=语言能力)"; // 获取证书的正则[结果为多条，需要进一步解析]
    String certificate = MappingUtil.matchSingle(regex, text);

    return certificate;
  }

}
