sap.ui.controller("static.js.layout.wechatUsageReport", {

	/**
	 * Called when a controller is instantiated and its View controls (if
	 * available) are already created. Can be used to modify the View before it
	 * is displayed, to bind event handlers and do other one-time
	 * initialization.
	 * 
	 * @memberOf resume-collection-service.wechatUsageReport
	 */
	_yearlyReportModel: null,
	_yearSelected: "2016",
	
	onInit : function() {
		
		this.getView().byId("exceptionLogLink").setHref(
				"import#/exceptionLog");
		var typeSelect = this.getView().byId("typeSelector");
		// -------- typeSelect ----------------
		var item0 = new sap.ui.core.Item({
			key : "0",
			text : "{i18n>BY_YEAR}"
		});
		var item1 = new sap.ui.core.Item({
			key : "1",
			text : "{i18n>BY_MONTH}"
		});

		typeSelect.addItem(item0);
		typeSelect.addItem(item1);

		var yearSelect = this.getView().byId("yearSelector");
		// -------- yearSelect ----------------

		for (var year = this._yearSelected; year < 2020; year++) {

			var item = new sap.ui.core.Item({
				key : year,
				text : year
			});
			yearSelect.addItem(item);
		}
		
		
		
		// vizFrame for line chart
		var oVizFrame = this.getView().byId("idoVizFrame");

		var reportInfoModel = new sap.ui.model.json.JSONModel();
		reportInfoModel.loadData("report/year", null, false);
		this._yearlyReportModel = reportInfoModel;
		
		var oDataset_bl = new sap.viz.ui5.data.FlattenedDataset({
			dimensions : [ {
				name : 'Time',
				value : "{label}"
			} ],
			measures : [ {
				group : 1,
				name : "Successfully Applied Job Nbr",
				value : "{key}"
			}, {
				group : 2,
				name : "Failed Applied Job Nbr",
				value : "{additionalText}"
			}],
			data : {
				path : "/"
			}
		});

		oVizFrame.setVizProperties({
			plotArea : {
				showGap : true,
				dataLabel: {
                    visible: true
                }
			}
		});
		oVizFrame.setDataset(oDataset_bl);

		var feedPrimaryValues_bl7 = new sap.viz.ui5.controls.common.feeds.FeedItem({
			'uid' : "primaryValues",
			'type' : "Measure",
			'values' : [ "Successfully Applied Job Nbr", "Failed Applied Job Nbr" ]
		}), feedAxisLabels_bl7 = new sap.viz.ui5.controls.common.feeds.FeedItem({
			'uid' : "axisLabels",
			'type' : "Dimension",
			'values' : [ "Time" ]
		});

		
		oVizFrame.addFeed(feedPrimaryValues_bl7);
		oVizFrame.addFeed(feedAxisLabels_bl7);
		oVizFrame.setVizType('line');

		oVizFrame.setModel(reportInfoModel);
		
		
		var that = this;
		var cfg = {
				type : 'GET',
				dataType : 'json',
				contentType : 'application/json;charset=UTF-8',
				url : "report/wechatusernbr"
			};
			
		    $.ajax(cfg).success(function(data) {
		    	var wechatUserNbrLabel = that.getView().byId("wechatUserNbr");
				wechatUserNbrLabel.setText(data);
		    });
	},

	handleTypeSelectionChange : function(oEvent) {
		var selectedItem = oEvent.getSource().getSelectedKey();
		var oVizFrame = this.getView().byId("idoVizFrame");
		var reportInfoModel = new sap.ui.model.json.JSONModel();
		var yearSelect = this.getView().byId("yearSelector");
		
		if (selectedItem === "1") {
			
			if(this._yearSelected){
				reportInfoModel.loadData("report/month/" + this._yearSelected, null, false);
				yearSelect.setEnabled(true);
			}
			
		}
		else{
			yearSelect.setEnabled(false);
			
			if(this._yearlyReportModel){
				reportInfoModel = this._yearlyReportModel;
			}
			else{
				reportInfoModel.loadData("report/year", null, false);
				this._yearlyReportModel = reportInfoModel;
			}
		}
		
		oVizFrame.setModel(reportInfoModel);

	},

	handleYearSelectionChange: function(oEvent){
		var selectedYear = oEvent.getSource().getSelectedKey();
		this._yearSelected = selectedYear;
		var oVizFrame = this.getView().byId("idoVizFrame");
		var reportInfoModel = new sap.ui.model.json.JSONModel();
		if(this._yearSelected){
			reportInfoModel.loadData("report/month/" + this._yearSelected, null, false);
			oVizFrame.setModel(reportInfoModel);
		}
	},
	
/**
 * Similar to onAfterRendering, but this hook is invoked before the controller's
 * View is re-rendered (NOT before the first rendering! onInit() is used for
 * that one!).
 * 
 * @memberOf resume-collection-service.wechatUsageReport
 */
// onBeforeRendering: function() {
//
// },
/**
 * Called when the View has been rendered (so its HTML is part of the document).
 * Post-rendering manipulations of the HTML could be done here. This hook is the
 * same one that SAPUI5 controls get after being rendered.
 * 
 * @memberOf resume-collection-service.wechatUsageReport
 */
// onAfterRendering: function() {
//
// },
/**
 * Called when the Controller is destroyed. Use this one to free resources and
 * finalize activities.
 * 
 * @memberOf resume-collection-service.wechatUsageReport
 */
// onExit: function() {
//
// }
});