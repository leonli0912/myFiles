package com.sap.hcm.resume.collection.integration.wechat.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jmx.export.annotation.ManagedOperation;
import org.springframework.jmx.export.annotation.ManagedOperationParameter;
import org.springframework.jmx.export.annotation.ManagedOperationParameters;
import org.springframework.jmx.export.annotation.ManagedResource;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.sap.hcm.resume.collection.bean.FilterListItem;
import com.sap.hcm.resume.collection.bean.FunctionTypeEnum;
import com.sap.hcm.resume.collection.bean.KeyLabelBean;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.bean.JobReqDataModelMappingItem;
import com.sap.hcm.resume.collection.integration.sf.bean.SFPicklistCacheEntityType;
import com.sap.hcm.resume.collection.integration.sf.bean.SFPicklistItem;
import com.sap.hcm.resume.collection.integration.sf.service.SFPicklistCacheService;
import com.sap.hcm.resume.collection.integration.wechat.bean.JobDynSearchBean;
import com.sap.hcm.resume.collection.integration.wechat.bean.JobDynSearchBeanItem;
import com.sap.hcm.resume.collection.integration.wechat.bean.MonthEnum;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatApplyHistory;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJob;
import com.sap.hcm.resume.collection.service.DataModelMappingService;
import com.sap.hcm.resume.collection.util.MappingUtil;

@Service
@ManagedResource(objectName = "com.sap.hcm.resume.collection.integration.wechat.service:type=WechatJobService", description = "Wechat Job Service")
public class WechatJobService {

  @PersistenceContext
  private EntityManager entityManager;

  @Autowired
  private SFPicklistCacheService pklCacheService;

  @Autowired
  private DataModelMappingService dmMappingService;

  /**
   * save the job
   * 
   * @param job
   * @throws ServiceApplicationException
   */
  @ManagedOperation(description = "Save Job")
  @ManagedOperationParameter(name = "job", description = "job")
  public WechatJob saveJob(WechatJob job) throws ServiceApplicationException {

    WechatJob existWechatJob = this.findJobByReqId(job.getExternalJobId(), job.getCompanyId());

    if (existWechatJob != null && !existWechatJob.getJobId().equals(job.getJobId())) {
      throw new ServiceApplicationException("Requisition ID is exist");
    }

    if (job.getJobId() == null) {
      job.setCreateAt(new Date());
    }
    job.setLastModify(new Date());
    job = entityManager.merge(job);
    return job;
  }

  /**
   * save loaded job
   * 
   * @param job
   * @throws ServiceApplicationException
   */
  @ManagedOperation(description = "Save Job from successfactors")
  @ManagedOperationParameter(name = "job", description = "job")
  public WechatJob saveSFJob(WechatJob job) throws ServiceApplicationException {

    WechatJob existWechatJob = this.findJobByReqId(job.getExternalJobId(), job.getCompanyId());

    if (existWechatJob != null) {
      job.setJobId(existWechatJob.getJobId());
    } else {
      job.setCreateAt(new Date());
    }
    job.setLastModify(new Date());
    job = entityManager.merge(job);
    return job;
  }

  /**
   * @param jobId
   * @return
   * @throws ServiceApplicationException
   */
  @ManagedOperation(description = "Find job by job Id")
  @ManagedOperationParameter(name = "jobId", description = "job Id")
  public WechatJob findJobById(Long jobId) throws ServiceApplicationException {
    try {
      return entityManager.find(WechatJob.class, jobId);
    } catch (Exception ex) {
      throw new ServiceApplicationException("unable to load given job detail");
    }
  }

  @ManagedOperation(description = "Find job by job requsition Id")
  @ManagedOperationParameters(value = {
      @ManagedOperationParameter(name = "externalJobId", description = "External Job Id"),
      @ManagedOperationParameter(name = "companyId", description = "company id") })
  public WechatJob findJobByReqId(String externalJobId, String companyId) {
    WechatJob job = null;
    List<WechatJob> jobList = new ArrayList<WechatJob>();

    String sel = "select h from WechatJob h where h.externalJobId = :externalJobId and h.companyId = :companyId";
    TypedQuery<WechatJob> queryJobInfo = entityManager.createQuery(sel, WechatJob.class);
    queryJobInfo.setParameter("externalJobId", externalJobId);
    queryJobInfo.setParameter("companyId", companyId);
    jobList = queryJobInfo.getResultList();
    if (!jobList.isEmpty()) {
      job = jobList.get(0);
    }

    return job;
  }

  /**
   * get apply history for browser
   * 
   * @param wechatId
   * @param companyId
   * @return
   * @throws ServiceApplicationException
   */
  @ManagedOperation(description = "Find apply history")
  @ManagedOperationParameters(value = { @ManagedOperationParameter(name = "wechatId", description = "Wechat Id"),
      @ManagedOperationParameter(name = "companyId", description = "company id") })
  public List<WechatApplyHistory> findApplyHistory(String wechatId, String companyId, String extJobId)
      throws ServiceApplicationException {

    List<WechatApplyHistory> applyHistoryList = new ArrayList<WechatApplyHistory>();

    try {

      String sel = "select h from WechatApplyHistory h where h.wechatId = :wechatId AND h.companyId = :companyId ";
      if (extJobId != null) {
        sel = sel.concat("AND h.externalJobId = :externalJobId ");
      }

      sel = sel.concat("order by h.applyHistoryId desc");
      TypedQuery<WechatApplyHistory> queryJobInfo = entityManager.createQuery(sel, WechatApplyHistory.class);
      queryJobInfo.setParameter("wechatId", wechatId);
      queryJobInfo.setParameter("companyId", companyId);
      if (extJobId != null) {
        queryJobInfo.setParameter("externalJobId", extJobId);
      }
      applyHistoryList = queryJobInfo.getResultList();

    } catch (Exception ex) {
      throw new ServiceApplicationException("unable to load apply history");
    }

    return applyHistoryList;
  }

  @ManagedOperation(description = "Get application Id")
  @ManagedOperationParameters(value = { @ManagedOperationParameter(name = "wechatId", description = "Wechat Id"),
      @ManagedOperationParameter(name = "companyId", description = "Company Id"),
      @ManagedOperationParameter(name = "jobId", description = "Job Id") })
  public String getAppId(String wechatId, String companyId, Long applyHistoryId) throws ServiceApplicationException {

    WechatApplyHistory applyHistory = new WechatApplyHistory();

    try {

      String sel = "select h from WechatApplyHistory h where h.wechatId = :wechatId AND h.companyId = :companyId AND h.applyHistoryId = :applyHistoryId order by h.applyHistoryId desc";
      Query queryJobInfo = entityManager.createQuery(sel);
      queryJobInfo.setParameter("wechatId", wechatId);
      queryJobInfo.setParameter("companyId", companyId);
      queryJobInfo.setParameter("applyHistoryId", applyHistoryId);
      applyHistory = (WechatApplyHistory) queryJobInfo.getSingleResult();

    } catch (Exception ex) {
      throw new ServiceApplicationException("unable to load apply history");
    }
    String status = applyHistory.getSfjobApplicationId();

    return status;
  }

  /**
   * check multi-apply
   * 
   * @param wechatId
   * @param companyId
   * @return
   * @throws ServiceApplicationException
   */
  @ManagedOperation(description = "Find apply history for check")
  @ManagedOperationParameters(value = {
      @ManagedOperationParameter(name = "applyEmail", description = "Application Email"),
      @ManagedOperationParameter(name = "extJobId", description = "External Job Id") })
  public List<WechatApplyHistory> findApplyHistoryForCheck(String applyEmail, String extJobId)
      throws ServiceApplicationException {

    List<WechatApplyHistory> applyHistoryList = new ArrayList<WechatApplyHistory>();

    try {

      String sel = "select h from WechatApplyHistory h where h.applyEmail = :applyEmail AND h.externalJobId = :externalJobId";
      TypedQuery<WechatApplyHistory> queryJobInfo = entityManager.createQuery(sel, WechatApplyHistory.class);
      queryJobInfo.setParameter("applyEmail", applyEmail);
      queryJobInfo.setParameter("externalJobId", extJobId);
      applyHistoryList = queryJobInfo.getResultList();

    } catch (Exception ex) {
      throw new ServiceApplicationException("unable to load apply history");
    }

    return applyHistoryList;
  }

  /**
   * insert apply into history
   * 
   * @param WechatApplyHistory
   */
  @ManagedOperation(description = "Save application history")
  @ManagedOperationParameters(value = { @ManagedOperationParameter(name = "wechatApplyHistory", description = "WeChat Application History"), })
  public void saveHistory(WechatApplyHistory wechatApplyHistory) {

    wechatApplyHistory.setLastModify(new Date());
    entityManager.persist(wechatApplyHistory);
  }

  @ManagedOperation(description = "Save application status")
  @ManagedOperationParameters(value = { @ManagedOperationParameter(name = "wechatId", description = "Wechat Id"),
      @ManagedOperationParameter(name = "applyHistoryId", description = "Application History Id"),
      @ManagedOperationParameter(name = "status", description = "Status") })
  public void saveStatus(String wechatId, String companyId, Long applyHistoryId, String status)
      throws ServiceApplicationException {
    try {
      String sel = "update WechatApplyHistory h set h.applyStatus=:status where h.wechatId = :wechatId AND h.companyId = :companyId AND h.applyHistoryId = :applyHistoryId";
      Query queryJobInfo = entityManager.createQuery(sel);
      queryJobInfo.setParameter("status", status);
      queryJobInfo.setParameter("wechatId", wechatId);
      queryJobInfo.setParameter("companyId", companyId);
      queryJobInfo.setParameter("applyHistoryId", applyHistoryId);
      queryJobInfo.executeUpdate();
    } catch (Exception ex) {
      throw new ServiceApplicationException("unable to update the sfjobApplicationId");
    }
  }

  /**
   * @param companyId
   * @return
   * @throws ServiceApplicationException
   */
  @ManagedOperation(description = "Find distinct value of one column in database")
  @ManagedOperationParameters(value = { @ManagedOperationParameter(name = "fieldName", description = "Field Name"),
      @ManagedOperationParameter(name = "companyId", description = "Company Id") })
  public List<String> findDistinctValuesOf(String fieldName, String companyId) {
    List<String> values = new ArrayList<String>();
    if (StringUtils.isEmpty(companyId)) {
      return values;
    }
    try {
      String sel = "select distinct j." + fieldName + " from WechatJob j where j.companyId = :companyId and j."
          + fieldName + " IS NOT NULL";
      TypedQuery<String> valueQuery = entityManager.createQuery(sel, String.class);
      valueQuery.setParameter("companyId", companyId);
      values = valueQuery.getResultList();
    } catch (Exception ex) {
      // no result found
      return values;
    }
    return values;
  }

  /**
   * @param jobId
   * @return
   * @throws ServiceApplicationException
   */
  @ManagedOperation(description = "Delete job by Id")
  @ManagedOperationParameters(value = { @ManagedOperationParameter(name = "jobId", description = "Job Id") })
  public int deleteJobById(Long jobId) throws ServiceApplicationException {
    int res = -1;
    String deleteJob = "delete from WechatJob j where j.jobId = :jobId";
    Query query = entityManager.createQuery(deleteJob);

    try {
      query.setParameter("jobId", jobId);
      query.executeUpdate();
      res = 1;
    } catch (PersistenceException e) {
      res = -1;
    }

    return res;
  }

  @ManagedOperation(description = "Get job list")
  @ManagedOperationParameters(value = { @ManagedOperationParameter(name = "searchBean", description = "Dynamic Search Bean") })
  public List<WechatJob> getJobInfoList(JobDynSearchBean searchBean) throws ServiceApplicationException {
    List<WechatJob> jobInfoList = new ArrayList<WechatJob>();
    try {
      TypedQuery<WechatJob> queryJobInfo = this.buildJobFilterQuery("j", searchBean, true);

      // add pagination
      queryJobInfo.setFirstResult(searchBean.getSkip());
      queryJobInfo.setMaxResults(searchBean.getTop());
      jobInfoList = queryJobInfo.getResultList();
    } catch (Exception ex) {
      throw new ServiceApplicationException("failed to read job list" + ex.getMessage());
    }

    return jobInfoList;
  }

  private TypedQuery<WechatJob> buildJobFilterQuery(String selectClause, JobDynSearchBean searchBean,
      boolean needOrderBy) {
    TypedQuery<WechatJob> queryJobInfo;
    String sql = "select " + selectClause + " from WechatJob j where j.companyId = :companyId";

    List<JobDynSearchBeanItem> items = searchBean.getItems();
    if (items != null && items.size() > 0) {
      for (JobDynSearchBeanItem item : items) {
        sql = sql.concat(" and j." + item.getType() + " in :" + item.getType() + "");
      }
    }

    if (!StringUtils.isEmpty(searchBean.getInputFilterValue())) {
      sql = sql.concat(" AND ( LOWER(j.jobTitle) like LOWER(:inputFilterValue) OR j.externalJobId like :externalId)");
    }

    sql = sql
        .concat(" AND ((j.postStartDate <= CURRENT_DATE AND j.postEndDate >= CURRENT_DATE) OR (j.postStartDate <= CURRENT_DATE AND j.postEndDate = null) OR (j.postStartDate = null AND j.postEndDate = null))");
    /* add logic to bypass the jobs which posting date range not valid */

    if (needOrderBy) {
      if (searchBean.getOrderBy().indexOf("externalJobId") >= 0) {
        if (searchBean.getOrderBy().toLowerCase().indexOf("desc") >= 0) {
          sql = sql.concat(" order by length(j.externalJobId) desc, j.externalJobId desc");
        } else {
          sql = sql.concat(" order by length(j.externalJobId) asc, j.externalJobId asc");
        }
      } else {
        sql = sql.concat(" order by j." + searchBean.getOrderBy());
      }
    }

    queryJobInfo = entityManager.createQuery(sql, WechatJob.class);

    queryJobInfo.setParameter("companyId", searchBean.getCompanyId());

    if (items != null && items.size() > 0) {
      for (JobDynSearchBeanItem item : items) {
        queryJobInfo.setParameter(item.getType(), item.getValues());
      }
    }

    if (!StringUtils.isEmpty(searchBean.getInputFilterValue())) {
      String inputFilterValuelike = "%" + searchBean.getInputFilterValue() + "%";
      queryJobInfo.setParameter("inputFilterValue", inputFilterValuelike);
      queryJobInfo.setParameter("externalId", inputFilterValuelike);
    }

    return queryJobInfo;

  }

  @ManagedOperation(description = "Get total count of jobs")
  @ManagedOperationParameters(value = { @ManagedOperationParameter(name = "searchBean", description = "Dynamic Search Bean") })
  public Long getTotalCount(JobDynSearchBean searchBean) throws ServiceApplicationException {
    Long totalCount = 0L;
    try {
      Query queryJobInfo = this.buildJobFilterQuery("count(j)", searchBean, false);
      totalCount = (Long) queryJobInfo.getSingleResult();
    } catch (Exception ex) {
      throw new ServiceApplicationException("failed to read job list " + ex.getMessage());
    }
    return totalCount;
  }

  /**
   * key for number of wechat user label for year
   * 
   * @param companyId
   * @return
   */
  @ManagedOperation(description = "Get apply history statics by year")
  @ManagedOperationParameters(value = { @ManagedOperationParameter(name = "companyId", description = "Company Id") })
  public List<KeyLabelBean> getApplyHistoryStaticsByYear(String companyId) {

    List<KeyLabelBean> result = new ArrayList<KeyLabelBean>();

    /* Retrieve Success Job Apply History Number */
    String sel = "select count(h.wechatId) as num , FUNCTION('YEAR',h.applyDate) as year from WechatApplyHistory h where h.companyId = :companyId group by FUNCTION('YEAR',h.applyDate)";
    Query query = this.entityManager.createQuery(sel);

    if (!StringUtils.isEmpty(companyId)) {
      query.setParameter("companyId", companyId);
    }

    @SuppressWarnings("rawtypes")
    List rows = query.getResultList();
    if (rows != null && rows.size() > 0) {
      for (Object row : rows) {
        Object[] rowData = (Object[]) row;
        KeyLabelBean kl = new KeyLabelBean();
        kl.setKey(rowData[0] == null ? "" : rowData[0].toString());
        kl.setLabel(rowData[1] == null ? "" : rowData[1].toString());
        // kl.setAdditionalText("10");
        result.add(kl);
      }
    }

    /* Retrieve Fail Job Apply History Number */
    sel = "select count(h.logId) as num , FUNCTION('YEAR',h.createAt) as year from ExceptionLog h where h.companyId = :companyId and h.functionType = :functionType group by FUNCTION('YEAR',h.createAt)";
    query = this.entityManager.createQuery(sel);

    if (!StringUtils.isEmpty(companyId)) {
      query.setParameter("companyId", companyId);
    }

    query.setParameter("functionType", FunctionTypeEnum.JOB_APPLY.getLabelKey());

    @SuppressWarnings("rawtypes")
    List rows1 = query.getResultList();
    if (rows1 != null && rows1.size() > 0) {
      for (Object row : rows1) {
        Object[] rowData = (Object[]) row;

        for (KeyLabelBean temp : result) {
          if (temp.getLabel().equals(rowData[1] == null ? "" : rowData[1].toString())) {
            temp.setAdditionalText(rowData[0] == null ? "" : rowData[0].toString());
            break;
          }
        }
      }
    }
    return result;
  }

  @ManagedOperation(description = "Get total wechat user")
  @ManagedOperationParameters(value = { @ManagedOperationParameter(name = "companyId", description = "Company Id") })
  public long getTotalWechatUserNumber(String companyId) {
    long result = 0;
    String sel = "select count(h.wechatId) as num from WechatUser h where h.companyId = :companyId";
    Query query = this.entityManager.createQuery(sel);

    if (!StringUtils.isEmpty(companyId)) {
      query.setParameter("companyId", companyId);
    }
    @SuppressWarnings("rawtypes")
    List rows = query.getResultList();
    if (rows != null && rows.size() > 0) {
      for (Object row : rows) {
        result = (long) row;
      }
    }
    return result;

  }

  /**
   * key for number of wechat user label for month SELECT count(wechat_id) as num , month(apply_date) as month FROM
   * hcp.WECHAT_APPLY_HISTORY where company_id = 'sap' and year(apply_date) = '2016' group by month(apply_date) order by
   * month;
   * 
   * @param companyId
   * @param year
   * @return
   */
  @ManagedOperation(description = "Get apply history statics by month")
  @ManagedOperationParameters(value = { @ManagedOperationParameter(name = "companyId", description = "Company Id") })
  public List<KeyLabelBean> getApplyHistoryStaticsByMonth(String companyId, String year) {
    List<KeyLabelBean> result = new ArrayList<KeyLabelBean>();

    String sel = "select count(h.wechatId) as num , FUNCTION('MONTH',h.applyDate) as month from WechatApplyHistory h where h.companyId = :companyId and FUNCTION('YEAR',h.applyDate) = :year group by FUNCTION('MONTH',h.applyDate) order by month";
    Query query = this.entityManager.createQuery(sel);

    if (!StringUtils.isEmpty(companyId)) {
      query.setParameter("companyId", companyId);
    }

    if (!StringUtils.isEmpty(year)) {
      query.setParameter("year", year);
    }

    @SuppressWarnings("rawtypes")
    List rows = query.getResultList();
    if (rows != null && rows.size() > 0) {
      for (Object row : rows) {
        Object[] rowData = (Object[]) row;
        KeyLabelBean kl = new KeyLabelBean();
        kl.setKey(rowData[0] == null ? "" : rowData[0].toString());
        String month = MonthEnum.getLabelByRange(rowData[1] == null ? 0 : Integer.parseInt(rowData[1].toString()));
        kl.setLabel(month);
        result.add(kl);
      }
    }

    sel = "select count(h.logId) as num , FUNCTION('MONTH',h.createAt) as month from ExceptionLog h where h.companyId = :companyId and h.functionType = :functionType and FUNCTION('YEAR',h.createAt) = :year group by FUNCTION('MONTH',h.createAt) order by month";
    query = this.entityManager.createQuery(sel);

    if (!StringUtils.isEmpty(companyId)) {
      query.setParameter("companyId", companyId);
    }

    if (!StringUtils.isEmpty(year)) {
      query.setParameter("year", year);
    }

    query.setParameter("functionType", FunctionTypeEnum.JOB_APPLY.getLabelKey());

    @SuppressWarnings("rawtypes")
    List rows1 = query.getResultList();
    if (rows1 != null && rows1.size() > 0) {
      for (Object row : rows1) {
        Object[] rowData = (Object[]) row;
        String month = MonthEnum.getLabelByRange(rowData[1] == null ? 0 : Integer.parseInt(rowData[1].toString()));
        for (KeyLabelBean temp : result) {

          if (temp.getLabel().equals(month)) {
            temp.setAdditionalText(rowData[0] == null ? "" : rowData[0].toString());
            break;
          }
        }

      }
    }

    return result;
  }

  @ManagedOperation(description = "Get filter list by config")
  @ManagedOperationParameters(value = { @ManagedOperationParameter(name = "companyId", description = "Company Id"),
      @ManagedOperationParameter(name = "locale", description = "locale") })
  public List<FilterListItem> getFilterListByConfig(String companyId, Locale locale) {
    List<FilterListItem> filterList = new ArrayList<FilterListItem>();

    Set<JobReqDataModelMappingItem> fieldSet = dmMappingService.getFilterableFieldsForJobRequisition(companyId);
    if (fieldSet != null && fieldSet.size() > 0) {
      for (JobReqDataModelMappingItem fd : fieldSet) {

        if (!StringUtils.isEmpty(fd.getPicklist())) {
          // handle pick list filter
          List<SFPicklistItem> itemList = pklCacheService.getPicklistOptionsByName(companyId, fd.getPicklist(),
              locale.toString(), SFPicklistCacheEntityType.JOB_REQUISITION.name());
          if (itemList != null && itemList.size() > 0) {
            FilterListItem filterItem = new FilterListItem();
            filterItem.setTitle(fd.getLabel());
            filterItem.setType(fd.getSourceField());

            List<KeyLabelBean> valueList = new ArrayList<KeyLabelBean>();
            for (SFPicklistItem pkItem : itemList) {
              KeyLabelBean kl = new KeyLabelBean();
              kl.setKey(pkItem.getOptionId() == null ? null : pkItem.getOptionId().toString());
              kl.setLabel(pkItem.getLabel());
              valueList.add(kl);
            }
            filterItem.setValues(valueList);
            filterList.add(filterItem);
          }
        } else {
          // handle input fields
          List<String> dbResults = this.findDistinctValuesOf(fd.getSourceField(), companyId);
          if (dbResults != null && dbResults.size() > 0) {
            FilterListItem filterItem = new FilterListItem();
            filterItem.setTitle(fd.getLabel());
            filterItem.setType(fd.getSourceField());

            dbResults = sortFilterItems(dbResults);
            List<KeyLabelBean> valueList = new ArrayList<KeyLabelBean>();
            for (String val : dbResults) {
              KeyLabelBean kl = new KeyLabelBean();
              kl.setKey(val);
              kl.setLabel(val);
              valueList.add(kl);
            }
            filterItem.setValues(valueList);
            filterList.add(filterItem);
          }
        }
      }
    }
    return filterList;
  }

  private List<String> sortFilterItems(List<String> itemList) {
    List<String> itemListWithInt = new ArrayList<String>();
    List<String> itemListWithoutInt = new ArrayList<String>();
    for (String item : itemList) {
      if (item.matches("[0-9]*?\\s\\S*")) {
        itemListWithInt.add(item);
      } else {
        itemListWithoutInt.add(item);
      }
    }

    for (int i = 0; i < itemListWithInt.size(); i++) {
      for (int j = i + 1; j < itemListWithInt.size(); j++) {
        if (getNum(itemListWithInt.get(i)) > getNum(itemListWithInt.get(j))) {
          String temp = itemListWithInt.get(i);
          itemListWithInt.set(i, itemListWithInt.get(j));
          itemListWithInt.set(j, temp);
        }
      }
    }
    Collections.sort(itemListWithoutInt);
    itemListWithInt.addAll(itemListWithoutInt);

    return itemListWithInt;

  }

  private int getNum(String item) {
    String regex = "[0-9]*";
    int number = Integer.parseInt(MappingUtil.matchSingle(regex, item));
    return number;
  }
}
