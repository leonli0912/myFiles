package com.sap.hcm.resume.collection.controller;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.sap.hcm.resume.collection.context.TestContext;
import com.sap.hcm.resume.collection.context.WebAppContext;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { TestContext.class, WebAppContext.class })
public class CandidateVendorControllerTest {

  @Autowired
  private WebApplicationContext webApplicationContext;
  
  private MockMvc mockMvc;
  
  @Before
  public void setUp() {
    mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
  }
  
  
  @Test
  public void testGetAllCountries() throws Exception{
    mockMvc.perform(MockMvcRequestBuilders.get("/jobboards/country")).andExpect(MockMvcResultMatchers.status().is(200));
  }
  
  @Test
  public void testGetVendorByCountry() throws Exception{
    mockMvc.perform(MockMvcRequestBuilders.get("/jobboards/CN/vendor")).andExpect(MockMvcResultMatchers.status().is(200));
  }
  
  @Test
  public void testGetTemplateByVendorAndCountry() throws Exception{
    mockMvc.perform(MockMvcRequestBuilders.get("/jobboards/CN/ZHILIAN/template")).andExpect(MockMvcResultMatchers.status().is(200));
  }
}
