package com.sap.hcm.resume.collection.bean;

import java.io.Serializable;

public class SimpleJsonResponse implements Serializable{

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = -6511701513603686611L;
    
    private int code;
    
    private String message;

    /**
     * @return the code
     */
    public int getCode() {
        return code;
    }

    /**
     * @param code the code to set
     */
    public void setCode(int code) {
        this.code = code;
    }

    /**
     * @return the message
     */
    public String getMessage() {
        return message;
    }

    /**
     * @param message the message to set
     */
    public void setMessage(String message) {
        this.message = message;
    }

}
