package com.sap.hcm.resume.collection.integration.sf.cdm;

import org.junit.Assert;
import org.junit.Test;

import com.sap.hcm.resume.collection.integration.sf.bean.cdm.SFCDMSimple;

public class SFCDMSimpleTest {

  @Test
  public void testGetterSetter(){
    SFCDMSimple sm = new SFCDMSimple();
    sm.setFieldDefinition(null);
    sm.setTemplateName("template");
    
    Assert.assertEquals(null, sm.getFieldDefinition());
    Assert.assertEquals("template", sm.getTemplateName());
  }
}
