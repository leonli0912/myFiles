package com.sap.hcm.resume.collection.integration.wechat.bean;

import java.io.Serializable;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("button")
public class WechatMenuItem implements Serializable{

  /**
   * 
   */
  private static final long serialVersionUID = 316633120659556810L;
  
  private String name;

  private List<WechatSubMenuItem> wechatSubMenuItem;
  
  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public List<WechatSubMenuItem> getWechatSubMenuItem() {
    return wechatSubMenuItem;
  }

  public void setWechatSubMenuItem(List<WechatSubMenuItem> wechatSubMenuItem) {
    this.wechatSubMenuItem = wechatSubMenuItem;
  }
}
