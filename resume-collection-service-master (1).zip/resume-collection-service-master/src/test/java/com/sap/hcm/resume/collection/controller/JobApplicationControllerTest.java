package com.sap.hcm.resume.collection.controller;

import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;

import com.sap.hcm.resume.collection.bean.JobReqScreeningQuestion;
import com.sap.hcm.resume.collection.context.TestContext;
import com.sap.hcm.resume.collection.context.WebAppContext;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJob;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJobScreeningQuestion;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJobScreeningQuestionAndChoice;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJobScreeningQuestionChoice;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatJobScreeningQuestionService;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatJobService;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { TestContext.class, WebAppContext.class })
public class JobApplicationControllerTest {
  private JobApplicationController jobApplicationController;

  @Resource(name = "wechatJobScreeningQuestionService")
  private WechatJobScreeningQuestionService questionService;

  @Resource(name = "wechatJobService")
  private WechatJobService wechatJobService;

  @Before
  public void setUp() {
    reset(questionService);
    reset(wechatJobService);
    MockitoAnnotations.initMocks(this);
    jobApplicationController = spy(new JobApplicationController());
    ReflectionTestUtils.setField(jobApplicationController, "wechatJobService", wechatJobService);
    ReflectionTestUtils.setField(jobApplicationController, "questionService", questionService);
  }

  @Test
  public void testGetQuestionsByJobReqIdFailWithJobNull() throws ServiceApplicationException {
    Long jobId = 123L;
    when(wechatJobService.findJobById(jobId)).thenReturn(null);
    List<JobReqScreeningQuestion> questionList = jobApplicationController.getQuestionsByJobReqId(jobId);
  }

  @Test
  public void testGetQuestionsByJobReqIdFailWithJobIdNull() throws ServiceApplicationException {
    List<JobReqScreeningQuestion> questionList = jobApplicationController.getQuestionsByJobReqId(null);
  }

  @Test
  public void testGetQuestionsByJobReqId() throws ServiceApplicationException {
    Long jobId = 123L;
    String jobReqId = "456";
    WechatJob job = new WechatJob();
    job.setExternalJobId(jobReqId);
    when(wechatJobService.findJobById(jobId)).thenReturn(job);
    WechatJobScreeningQuestionAndChoice wechatJobScreeningQuestionAndChoice = new WechatJobScreeningQuestionAndChoice();
    WechatJobScreeningQuestion wechatJobScreeningQuestion = new WechatJobScreeningQuestion();
    wechatJobScreeningQuestion.setQuestionOrder(12345L);
    wechatJobScreeningQuestionAndChoice.setWechatJobScreeningQuestion(wechatJobScreeningQuestion);
    List<WechatJobScreeningQuestionChoice> jobScreeningQuestionChoiceList = new ArrayList<WechatJobScreeningQuestionChoice>();
    WechatJobScreeningQuestionChoice choice = new WechatJobScreeningQuestionChoice();
    choice.setOptionId(567L);
    jobScreeningQuestionChoiceList.add(choice);
    wechatJobScreeningQuestionAndChoice.setJobScreeningQuestionChoiceList(jobScreeningQuestionChoiceList);
    List<WechatJobScreeningQuestionAndChoice> questionList = new ArrayList<WechatJobScreeningQuestionAndChoice>();
    questionList.add(wechatJobScreeningQuestionAndChoice);
    when(questionService.findJobScreeningQuestionAndChoice(jobReqId)).thenReturn(questionList);
    List<JobReqScreeningQuestion> resultQuestionList = jobApplicationController.getQuestionsByJobReqId(jobId);
  }
}
