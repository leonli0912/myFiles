package com.sap.hcm.resume.collection.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;

@Service
public class CompanyInfoService {

  @PersistenceContext
  private EntityManager entityManager;

  private static final Logger logger = LoggerFactory.getLogger(CompanyInfoService.class);

  public CompanyInfo saveCompanyInfo(CompanyInfo companyInfo) throws ServiceApplicationException {
    String companyId = companyInfo.getCompanyId();
    boolean newCompany = StringUtils.isEmpty(companyId);
    if (newCompany) {
      companyInfo.setCreateAt(new Date());
      companyInfo.setLastModify(new Date());
    } else {
      companyInfo.setLastModify(new Date());
    }

    CompanyInfo info = null;
    try {
      info = entityManager.merge(companyInfo);
    } catch (PersistenceException e) {
      logger.error("save company failed with error " + e.getMessage());
      throw new ServiceApplicationException("save company failed");
    }
    return info;
  }

  /**
   * @param companyId
   * @return
   * @throws ServiceApplicationException
   */
  public CompanyInfo getCompanyInfo(String companyId) throws ServiceApplicationException {
    CompanyInfo info = null;
    try {
      info = entityManager.find(CompanyInfo.class, companyId);
    } catch (IllegalArgumentException e) {
      logger.error("get company info failed due to: " + e.getMessage());
      throw new ServiceApplicationException("get company info failed, companyId = " + companyId);
    } catch (PersistenceException e) {
      logger.error("get company info failed due to: " + e.getMessage());
      throw new ServiceApplicationException("get company info failed, companyId = " + companyId);
    }
    return info;
  }

  public List<CompanyInfo> findAllCompany() throws ServiceApplicationException {

    List<CompanyInfo> CompanyInfoList = new ArrayList<CompanyInfo>();

    try {

      String sel = "select h from CompanyInfo h";

      TypedQuery<CompanyInfo> queryCompanyInfo = entityManager.createQuery(sel, CompanyInfo.class);
      CompanyInfoList = queryCompanyInfo.getResultList();

    } catch (Exception ex) {
      throw new ServiceApplicationException("unable to load company info");
    }

    return CompanyInfoList;
  }
}
