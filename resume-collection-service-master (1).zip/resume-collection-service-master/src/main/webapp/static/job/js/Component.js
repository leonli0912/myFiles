jQuery.sap.declare("com.sap.rcs.job.Component");

sap.ui.core.UIComponent.extend("com.sap.rcs.job.Component",{
	metadata:{
		routing:{
			config : {
				viewType:"XML",
				viewPath:"static.job.js.layout",
				targetControl:"navContainer",
				targetAggregation:"pages",
				clearTaget:false
			},
			routes:[
			        {
			        	pattern:"",
			        	name:"maintainJob",
			        	view:"maintainJob",
			        },
			        {
			        	pattern:"load",
			        	name:"loadJob",
			        	view:"loadJob",
			        },
			        {
	     	        	   pattern:"display/{jobId}",
	     	        	   name:"jobDisplay",
	     	        	   view:"jobDisplay"
	     	        },
			        {
     	        	   pattern:"publish",
     	        	   name:"jobPublish",
     	        	   view:"jobPublish"
     	            }
			      
			        ]
		}
	},
	
});

com.sap.rcs.job.Component.prototype.init = function(){
	jQuery.sap.require("sap.ui.core.routing.History");
	jQuery.sap.require("sap.m.routing.RouteMatchedHandler");
	
	sap.ui.core.UIComponent.prototype.init.apply(this);
	
	var router = this.getRouter();
	this.routeHandler = new sap.m.routing.RouteMatchedHandler(router);
	router.initialize();
	
	jQuery.sap.require("jquery.sap.resources");
	var sLocale = sap.ui.getCore().getConfiguration().getLanguage();
	var resModel = new sap.ui.model.resource.ResourceModel({bundleName:"static.i18n.i18n",bundleLocale:sLocale});
	var resWechatModel = new sap.ui.model.resource.ResourceModel({bundleName:"static.i18n.wechat.i18n",bundleLocale:sLocale});
	//update the page title
	window.document.title = resWechatModel.getResourceBundle().getText("ApplicationTitle");
	this.setModel(resModel, "i18n");
	this.setModel(resWechatModel, "wi18n");
	
	
}

com.sap.rcs.job.Component.prototype.destroy = function(){
	if(this.routeHandler){
		this.routeHandler.destroy();
	}
	sap.ui.core.UIComponent.destroy.apply(this,arguments);
};

com.sap.rcs.job.Component.prototype.createContent = function(){
	this.view = sap.ui.view({id:"rcsWechatApplicationJob",viewName:"static.job.js.layout.application",type:sap.ui.core.mvc.ViewType.JS});
	return this.view;
};
