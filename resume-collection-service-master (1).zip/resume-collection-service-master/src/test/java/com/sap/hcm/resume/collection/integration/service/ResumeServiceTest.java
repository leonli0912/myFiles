package com.sap.hcm.resume.collection.integration.service;

import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.io.IOUtils;
import org.junit.Test;
import org.junit.runner.RunWith;

import static org.mockito.Mockito.spy;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.core.io.ClassPathResource;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;

import com.sap.hcm.resume.collection.bean.ImportResultBean;
import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.context.TestContext;
import com.sap.hcm.resume.collection.context.WebAppContext;
import com.sap.hcm.resume.collection.entity.DataModelMapping;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJob;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJobApplicationVO;
import com.sap.hcm.resume.collection.service.CandidateService;
import com.sap.hcm.resume.collection.service.JobApplicationService;

import static org.junit.Assert.*;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { TestContext.class, WebAppContext.class })
public class ResumeServiceTest {
  
  private ResumeService resumeService;
  
  @Autowired
  private MessageSource messageSource; 
  
  @Autowired
  private CandidateService candidateService;

  @Autowired
  private JobApplicationService jobApplicationService;
  
  @Autowired
  private Params params;
 
  
  @SuppressWarnings({ "unchecked" })
  @Test
  public void testProcessFileWithJobId() throws IOException, ServiceApplicationException{
    resumeService =  spy(new ResumeService());
    
    ReflectionTestUtils.setField(resumeService, "params", params);
    ReflectionTestUtils.setField(resumeService, "messageSource", messageSource);
    ReflectionTestUtils.setField(resumeService, "candidateService", candidateService);
    ReflectionTestUtils.setField(resumeService, "jobApplicationService", jobApplicationService);
    
    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
    Mockito.when(request.getLocale()).thenReturn(Locale.ENGLISH);
    
    DataModelMapping mapping = Mockito.mock(DataModelMapping.class);
    WechatJobApplicationVO applicationData = new WechatJobApplicationVO();
    
    ClassPathResource resume = new ClassPathResource("resumes/parser/51_TEST_RC_CN_V16.doc");
    InputStream is = resume.getInputStream();
    byte[] resumeByteArray = IOUtils.toByteArray(is);
    FileItem item = Mockito.mock(FileItem.class);
    Mockito.when(item.getName()).thenReturn("TestFile");
    Mockito.when(item.getSize()).thenReturn(123L);
    Mockito.when(item.get()).thenReturn(resumeByteArray);
    
    Mockito.when(messageSource.getMessage(Mockito.anyString(), Mockito.any(Object[].class), Mockito.any(Locale.class))).thenReturn("test");
    Mockito.when(jobApplicationService.insertJobApplication(Mockito.any(CandidateProfileVO.class), Mockito.any(DataModelMapping.class), 
        Mockito.any(WechatJob.class), Mockito.anyList())).thenReturn(applicationData);
    
    Mockito.when(candidateService.getCandidateId("123@test.com")).thenReturn(777L);

    ImportResultBean result =  resumeService.processFile(item, request, "JOB51", "51Job_2016", mapping, "12", "123");
    
    assertEquals("success", result.getImportStatus());
  }
  
  @SuppressWarnings("unchecked")
  @Test
  public void testProcessFileWithoutJobId() throws IOException, ServiceApplicationException{
    resumeService =  spy(new ResumeService());
    
    ReflectionTestUtils.setField(resumeService, "params", params);
    ReflectionTestUtils.setField(resumeService, "messageSource", messageSource);
    ReflectionTestUtils.setField(resumeService, "candidateService", candidateService);
    ReflectionTestUtils.setField(resumeService, "jobApplicationService", jobApplicationService);
    
    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
    Mockito.when(request.getLocale()).thenReturn(Locale.ENGLISH);
    
    DataModelMapping mapping = Mockito.mock(DataModelMapping.class);
    WechatJobApplicationVO applicationData = new WechatJobApplicationVO();
    
    ClassPathResource resume = new ClassPathResource("resumes/parser/51_TEST_RC_CN_V16.doc");
    InputStream is = resume.getInputStream();
    byte[] resumeByteArray = IOUtils.toByteArray(is);
    FileItem item = Mockito.mock(FileItem.class);
    Mockito.when(item.getName()).thenReturn("TestFile");
    Mockito.when(item.getSize()).thenReturn(123L);
    Mockito.when(item.get()).thenReturn(resumeByteArray);
    
    Mockito.when(messageSource.getMessage(Mockito.anyString(), Mockito.any(Object[].class), Mockito.any(Locale.class))).thenReturn("test");
    Mockito.when(jobApplicationService.insertJobApplication(Mockito.any(CandidateProfileVO.class), Mockito.any(DataModelMapping.class), 
        Mockito.any(WechatJob.class), Mockito.anyList())).thenReturn(applicationData);
    
    Mockito.when(candidateService.getCandidateId("123@test.com")).thenReturn(777L);

    ImportResultBean result =  resumeService.processFile(item, request, "JOB51", "51Job_2016", mapping, null, "123");
    
    assertEquals("success", result.getImportStatus());
  }
}
