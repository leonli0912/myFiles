
package com.sap.hcm.resume.collection.integration.sf.bean;


import org.junit.Assert;
import org.junit.Test;

/**
 * @author I075908
 * SAP
 */
public class JobRequisitionBeanTest {

  @Test
  public void testJobRequisitionBean() {
    JobRequisitionBean underTest = new JobRequisitionBean();
    
    underTest.setJobReqId("jobReqId");
    underTest.setJobTitle("jobTitle");
    underTest.setLineManager("lineManager");
    underTest.setStatusSetId("statusSetId");
    
    Assert.assertEquals("jobReqId", underTest.getJobReqId());
    Assert.assertEquals("jobTitle", underTest.getJobTitle());
    Assert.assertEquals("lineManager", underTest.getLineManager());
    Assert.assertEquals("statusSetId", underTest.getStatusSetId());
  }
}
