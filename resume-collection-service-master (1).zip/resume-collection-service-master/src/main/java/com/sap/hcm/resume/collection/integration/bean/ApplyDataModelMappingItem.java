package com.sap.hcm.resume.collection.integration.bean;

import java.io.Serializable;
import java.util.List;

import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.annotations.XStreamImplicit;

@XStreamAlias("apply-mapping-item")
public class ApplyDataModelMappingItem implements Serializable {

    /**
   * serialVersionUID
   */
  private static final long serialVersionUID = 5726642642450747045L;

    private String sourceField;

    private String sfDmField;
    
    private String label;
    
    private String fieldLabel;
    
    private boolean required;
    
    @XStreamImplicit(itemFieldName="label-translation")
    private List<ApplyDMMappingItemLabelTranslation> labelTranslations;
    
    /**
     * picklist name for successfactors
     */
    private String picklist;
    
    /**
     * default value for the key that can not find in candidate profile or apply info
     */
    private String defaultValue;
    
    private String sourceNameType;
    
    private boolean displaySourceName;
    
    private boolean displayDefaultValue;
    
    private boolean displayFieldLabel = false;

    public String getSourceField() {
      return sourceField;
    }

    public void setSourceField(String sourceField) {
      this.sourceField = sourceField;
    }

    public String getSfDmField() {
      return sfDmField;
    }

    public void setSfDmField(String sfDmField) {
      this.sfDmField = sfDmField;
    }

    public String getLabel() {
      return label;
    }

    public void setLabel(String label) {
      this.label = label;
    }

    public String getFieldLabel() {
      return fieldLabel;
    }

    public void setFieldLabel(String filedLabel) {
      this.fieldLabel = filedLabel;
    }

    public boolean isRequired() {
      return required;
    }

    public void setRequired(boolean required) {
      this.required = required;
    }

    public String getPicklist() {
      return picklist;
    }

    public void setPicklist(String picklist) {
      this.picklist = picklist;
    }

    public String getDefaultValue() {
      return defaultValue;
    }

    public void setDefaultValue(String defaultValue) {
      this.defaultValue = defaultValue;
    }

    public String getSourceNameType() {
      return sourceNameType;
    }

    public void setSourceNameType(String sourceNameType) {
      this.sourceNameType = sourceNameType;
    }

    public boolean isDisplaySourceName() {
      return displaySourceName;
    }

    public void setDisplaySourceName(boolean displaySourceName) {
      this.displaySourceName = displaySourceName;
    }

    public boolean isDisplayDefaultValue() {
      return displayDefaultValue;
    }

    public void setDisplayDefaultValue(boolean displayDefaultValue) {
      this.displayDefaultValue = displayDefaultValue;
    }

    public boolean isDisplayFieldLabel() {
      return displayFieldLabel;
    }

    public void setDisplayFieldLabel(boolean displayFieldLabel) {
      this.displayFieldLabel = displayFieldLabel;
    }

    /**
     * @return the labelTranslations
     */
    public List<ApplyDMMappingItemLabelTranslation> getLabelTranslations() {
      return labelTranslations;
    }

    /**
     * @param labelTranslations the labelTranslations to set
     */
    public void setLabelTranslations(List<ApplyDMMappingItemLabelTranslation> labelTranslations) {
      this.labelTranslations = labelTranslations;
    }

    

}
