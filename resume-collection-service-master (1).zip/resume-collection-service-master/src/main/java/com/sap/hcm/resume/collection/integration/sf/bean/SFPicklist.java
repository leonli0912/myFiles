package com.sap.hcm.resume.collection.integration.sf.bean;

import java.io.Serializable;
import java.util.List;

/**
 * sf picklist
 * @author i065831
 *
 */
public class SFPicklist implements Serializable{
    
    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 3303825706986029216L;
    
    private String srcPropertyName;
    
    private String sfPropertyName;
    
    private String picklistName;
    
    private List<SFPicklistItem> valueList;
    
    private String category;

    /**
     * @return the propertyName
     */
    public String getSFPropertyName() {
        return sfPropertyName;
    }

    /**
     * @param propertyName the propertyName to set
     */
    public void setSFPropertyName(String propertyName) {
        this.sfPropertyName = propertyName;
    }

    /**
     * @return the srcPropertyName
     */
    public String getSrcPropertyName() {
      return srcPropertyName;
    }

    /**
     * @param srcPropertyName the srcPropertyName to set
     */
    public void setSrcPropertyName(String srcPropertyName) {
      this.srcPropertyName = srcPropertyName;
    }

    /**
     * @return the picklistName
     */
    public String getPicklistName() {
        return picklistName;
    }

    /**
     * @param picklistName the picklistName to set
     */
    public void setPicklistName(String picklistName) {
        this.picklistName = picklistName;
    }

    /**
     * @return the valueList
     */
    public List<SFPicklistItem> getValueList() {
        return valueList;
    }

    /**
     * @param valueList the valueList to set
     */
    public void setValueList(List<SFPicklistItem> valueList) {
        this.valueList = valueList;
    }

    /**
     * @return the category
     */
    public String getCategory() {
      return category;
    }

    /**
     * @param category the category to set
     */
    public void setCategory(String category) {
      this.category = category;
    }
    
}
