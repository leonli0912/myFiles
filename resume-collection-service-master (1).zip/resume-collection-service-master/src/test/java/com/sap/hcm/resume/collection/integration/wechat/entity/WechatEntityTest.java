package com.sap.hcm.resume.collection.integration.wechat.entity;

import static org.junit.Assert.assertEquals;

import java.io.UnsupportedEncodingException;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Date;
import java.util.GregorianCalendar;

import org.junit.Assert;
import org.junit.Test;
import org.powermock.api.mockito.PowerMockito;

import com.sap.hcm.resume.collection.integration.wechat.entity.AccessToken.AccessTokenHolder;

public class WechatEntityTest {

  @Test
  public void testWechatApplyHistory() {
    WechatApplyHistory wechatApplyHistory = new WechatApplyHistory();
    wechatApplyHistory.setApplyHistoryId(123L);
    assertEquals("123", Long.toString(wechatApplyHistory.getApplyHistoryId()));
    wechatApplyHistory.setJobId(123L);
    assertEquals("123", Long.toString(wechatApplyHistory.getJobId()));
    wechatApplyHistory.setWechatId("hehe");
    assertEquals("hehe", wechatApplyHistory.getWechatId());
    wechatApplyHistory.setCompanyId("hehe");
    assertEquals("hehe", wechatApplyHistory.getCompanyId());
    wechatApplyHistory.setApplyEmail("hehe");
    assertEquals("hehe", wechatApplyHistory.getApplyEmail());
    wechatApplyHistory.setApplyStatus("hehe");
    assertEquals("hehe", wechatApplyHistory.getApplyStatus());
    wechatApplyHistory.setApplyDate("hehe");
    assertEquals("hehe", wechatApplyHistory.getApplyDate());
    Date date = new GregorianCalendar(2016, 8, 10).getTime();
    wechatApplyHistory.setLastModify(date);
    assertEquals(date, wechatApplyHistory.getLastModify());
  }

  @Test
  public void testWechatUserResumeMapping() {
    WechatUserResumeMapping wechatUserResumeMapping = new WechatUserResumeMapping();
    wechatUserResumeMapping.setResumeName("haha");
    assertEquals("haha", wechatUserResumeMapping.getResumeName());
    wechatUserResumeMapping.setVendorName("haha");
    assertEquals("haha", wechatUserResumeMapping.getVendorName());
    wechatUserResumeMapping.setLanguage("haha");
    assertEquals("haha", wechatUserResumeMapping.getLanguage());
    wechatUserResumeMapping.setExternalResumeId("haha");
    assertEquals("haha", wechatUserResumeMapping.getExternalResumeId());

  }

  @Test
  public void testWechatUser() {
    WechatUser wechatUser = new WechatUser();
    Date date = new GregorianCalendar(2016, 8, 10).getTime();
    wechatUser.setLoginTime(date);
    assertEquals(date, wechatUser.getLoginTime());
    wechatUser.setActive(true);
    assertEquals(true, wechatUser.isActive());

    wechatUser.setPortrait("haha".getBytes());
    assertEquals(true, Arrays.equals(wechatUser.getPortrait(), "haha".getBytes()));
  }

  @Test
  public void testWechatJobVO() throws Exception {
    WechatJobVO wechatJobVO = new WechatJobVO();
    wechatJobVO.setStrJobDescription("haha");
    WechatJob job = new WechatJob();
    job.setJobDescription("haha".getBytes());
    PowerMockito.whenNew(String.class).withArguments(job.getJobDescription(), "UTF-8")
        .thenThrow(new UnsupportedEncodingException());
    
    String jobDesc = "TestDesc";
    job.setJobDescription(jobDesc.getBytes(StandardCharsets.UTF_8));
    String result = WechatJobVO.fromWechatJobEntity(job).getStrJobDescription();
    Assert.assertEquals(jobDesc, result);
    
    Assert.assertNotNull(wechatJobVO.toWechatJobEntity());
  }

  @Test
  public void testWechatJobApplicationVO() {
    WechatJobApplicationVO wechatJobApplicationVO = new WechatJobApplicationVO();
    wechatJobApplicationVO.setAgencyInfo("haha");
    assertEquals("haha", wechatJobApplicationVO.getAgencyInfo());
    wechatJobApplicationVO.setAddress("haha");
    assertEquals("haha", wechatJobApplicationVO.getAddress());
    wechatJobApplicationVO.setAnonymizedFlag("haha");
    assertEquals("haha", wechatJobApplicationVO.getAnonymizedFlag());
    Date date = new GregorianCalendar(2016, 8, 10).getTime();
    wechatJobApplicationVO.setAnonymizedDate(date);
    assertEquals(date, wechatJobApplicationVO.getAnonymizedDate());
    wechatJobApplicationVO.setAppLocale("haha");
    assertEquals("haha", wechatJobApplicationVO.getAppLocale());
    wechatJobApplicationVO.setAppStatusSetItemId("haha");
    assertEquals("haha", wechatJobApplicationVO.getAppStatusSetItemId());
    wechatJobApplicationVO.setApplicationTemplateId("haha");
    assertEquals("haha", wechatJobApplicationVO.getApplicationTemplateId());
    wechatJobApplicationVO.setCandConversionProcessed("haha");
    assertEquals("haha", wechatJobApplicationVO.getCandConversionProcessed());
    wechatJobApplicationVO.setCandTypeWhenHired("haha");
    assertEquals("haha", wechatJobApplicationVO.getCandTypeWhenHired());
    wechatJobApplicationVO.setCandidateId(123L);
    assertEquals("123", Long.toString(wechatJobApplicationVO.getCandidateId()));
    wechatJobApplicationVO.setCellPhone("haha");
    assertEquals("haha", wechatJobApplicationVO.getCellPhone());
    wechatJobApplicationVO.setCity("haha");
    assertEquals("haha", wechatJobApplicationVO.getCity());
    wechatJobApplicationVO.setContactEmail("haha");
    assertEquals("haha", wechatJobApplicationVO.getContactEmail());
    wechatJobApplicationVO.setCountryCode("haha");
    assertEquals("haha", wechatJobApplicationVO.getCountryCode());
    wechatJobApplicationVO.setDataSource("haha");
    assertEquals("haha", wechatJobApplicationVO.getDataSource());
    wechatJobApplicationVO.setDuplicateProfile("haha");
    assertEquals("haha", wechatJobApplicationVO.getDuplicateProfile());
    wechatJobApplicationVO.setFirstName("haha");
    assertEquals("haha", wechatJobApplicationVO.getFirstName());
    wechatJobApplicationVO.setExportedOn(date);
    assertEquals(date, wechatJobApplicationVO.getExportedOn());
    wechatJobApplicationVO.setFormerEmployee(true);
    assertEquals(true, wechatJobApplicationVO.isFormerEmployee());
    wechatJobApplicationVO.setHiredOn("haha");
    assertEquals("haha", wechatJobApplicationVO.getHiredOn());
    wechatJobApplicationVO.setHomePhone("haha");
    assertEquals("haha", wechatJobApplicationVO.getHomePhone());
    wechatJobApplicationVO.setJobAppGuid("haha");
    assertEquals("haha", wechatJobApplicationVO.getJobAppGuid());
    wechatJobApplicationVO.setJobReqId("haha");
    assertEquals("haha", wechatJobApplicationVO.getJobReqId());
    wechatJobApplicationVO.setLastModifiedBy("haha");
    assertEquals("haha", wechatJobApplicationVO.getLastModifiedBy());
    wechatJobApplicationVO.setLastModifiedByProxy("haha");
    assertEquals("haha", wechatJobApplicationVO.getLastModifiedByProxy());
    wechatJobApplicationVO.setLastModifiedDateTime(date);
    assertEquals(date, wechatJobApplicationVO.getLastModifiedDateTime());
    wechatJobApplicationVO.setLastName("haha");
    assertEquals("haha", wechatJobApplicationVO.getLastName());
    wechatJobApplicationVO.setMiddleName("haha");
    assertEquals("haha", wechatJobApplicationVO.getMiddleName());
    wechatJobApplicationVO.setNonApplicantStatus("haha");
    assertEquals("haha", wechatJobApplicationVO.getNonApplicantStatus());
    wechatJobApplicationVO.setOwner("haha");
    assertEquals("haha", wechatJobApplicationVO.getOwner());
    wechatJobApplicationVO.setOwnershpDate(date);
    assertEquals(date, wechatJobApplicationVO.getOwnershpDate());
    wechatJobApplicationVO.setProfileUpdated("haha");
    assertEquals("haha", wechatJobApplicationVO.getProfileUpdated());
    wechatJobApplicationVO.setQuestionResponse("haha");
    assertEquals("haha", wechatJobApplicationVO.getQuestionResponse());
    wechatJobApplicationVO.setRating("haha");
    assertEquals("haha", wechatJobApplicationVO.getRating());
    wechatJobApplicationVO.setReference("haha");
    assertEquals("haha", wechatJobApplicationVO.getReference());
    wechatJobApplicationVO.setReferralName("haha");
    assertEquals("haha", wechatJobApplicationVO.getReferralName());
    wechatJobApplicationVO.setReferredBy("haha");
    assertEquals("haha", wechatJobApplicationVO.getReferredBy());
    wechatJobApplicationVO.setResumeUploadDate(date);
    assertEquals(date, wechatJobApplicationVO.getResumeUploadDate());
    wechatJobApplicationVO.setSnapShotDate(date);
    assertEquals(date, wechatJobApplicationVO.getSnapShotDate());
    wechatJobApplicationVO.setSource("haha");
    assertEquals("haha", wechatJobApplicationVO.getSource());
    wechatJobApplicationVO.setStatus("haha");
    assertEquals("haha", wechatJobApplicationVO.getStatus());
    wechatJobApplicationVO.setStatusComments("haha");
    assertEquals("haha", wechatJobApplicationVO.getStatusComments());
    wechatJobApplicationVO.setTimeToHire("haha");
    assertEquals("haha", wechatJobApplicationVO.getTimeToHire());
    wechatJobApplicationVO.setUsersSysId("haha");
    assertEquals("haha", wechatJobApplicationVO.getUsersSysId());
    wechatJobApplicationVO.setZip("haha");
    assertEquals("haha", wechatJobApplicationVO.getZip());
    wechatJobApplicationVO.setReferenceComments("haha");
    assertEquals("haha", wechatJobApplicationVO.getReferenceComments());
  }
  
  @Test
  public void testOAuthAccessToken() {
    OAuthAccessToken oAuthAccessToken = new OAuthAccessToken();
    Integer expireIn = 123;
    oAuthAccessToken.setExpiresIn(expireIn);
    assertEquals(expireIn, oAuthAccessToken.getExpiresIn());
  }

  @Test
  public void testUserBasicInfo() {
    UserBascInfo userBasicInfo = new UserBascInfo();
    String openid = "abc";
    String nickname = "efg";
    String sex = "hij";
    String city = "klm";
    String unionid = "nop";
    String headimgurl = "rst";
    String province = "uvw";
    String country = "xyz";
    userBasicInfo.setOpenid(openid);
    userBasicInfo.setNickname(nickname);
    userBasicInfo.setSex(sex);
    userBasicInfo.setCity(city);
    userBasicInfo.setUnionid(unionid);
    userBasicInfo.setHeadimgurl(headimgurl);
    userBasicInfo.setProvince(province);
    userBasicInfo.setCountry(country);
    assertEquals(openid, userBasicInfo.getOpenid());
    assertEquals(nickname, userBasicInfo.getNickname());
    assertEquals(sex, userBasicInfo.getSex());
    assertEquals(city, userBasicInfo.getCity());
    assertEquals(unionid, userBasicInfo.getUnionid());
    assertEquals(headimgurl, userBasicInfo.getHeadimgurl());
    assertEquals(province, userBasicInfo.getProvince());
    assertEquals(country, userBasicInfo.getCountry());
  }

  @Test
  public void testAccessToken() {
    String companyId = "sap";
    String access_token = "token";
    Long createTime = 123L;
    int expires_in = 456;
    AccessTokenHolder.saveAccessToken(access_token, companyId);
    AccessTokenHolder.getInstance(companyId).setAccess_token(access_token);
    AccessTokenHolder.getInstance(companyId).setCompanyId(companyId);
    AccessTokenHolder.getInstance(companyId).setCreateTime(createTime);
    AccessTokenHolder.getInstance(companyId).setExpires_in(expires_in);
    assertEquals(true, AccessTokenHolder.getInstance(companyId).isExpired());
    assertEquals(companyId, AccessTokenHolder.getInstance(companyId).getCompanyId());
    assertEquals(access_token, AccessTokenHolder.getInstance(companyId).getAccess_token());
    assertEquals(Long.toString(createTime), Long.toString(AccessTokenHolder.getInstance(companyId).getCreateTime()));
    assertEquals(expires_in, AccessTokenHolder.getInstance(companyId).getExpires_in());
    AccessTokenHolder.getInstance(companyId).setCreateTime(14709861138356L);
    assertEquals(false, AccessTokenHolder.getInstance(companyId).isExpired());
    AccessTokenHolder.getInstance(companyId).setCreateTime(-14709861138356L);
    assertEquals(true, AccessTokenHolder.getInstance(companyId).isExpired());
    AccessTokenHolder.removeToken(companyId);
  }

  @Test
  public void testJsTicket() {
    String ticket = "abc";
    Long createTime = 123L;
    String js_ticket = "efg";
    JsTicket.getInstance().saveLocalJsTicket(ticket);
    JsTicket.getInstance().setCreateTime(createTime);
    JsTicket.getInstance().setJs_ticket(js_ticket);
    assertEquals(true, JsTicket.getInstance().isExpired());
    assertEquals(js_ticket, JsTicket.getInstance().getJs_ticket());
    assertEquals(Long.toString(createTime), Long.toString(JsTicket.getInstance().getCreateTime()));
    JsTicket.getInstance().setCreateTime(14709861138356L);
    assertEquals(false, JsTicket.getInstance().isExpired());
    JsTicket.getInstance().setCreateTime(-14709861138356L);
    assertEquals(true, JsTicket.getInstance().isExpired());
  }

}
