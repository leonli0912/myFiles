package com.sap.hcm.resume.collection.integration.sf.cdm;

import org.junit.Before;
import org.junit.Test;

import com.sap.hcm.resume.collection.integration.sf.bean.cdm.SFCDMFieldDefinition;
import com.sap.hcm.resume.collection.integration.sf.bean.cdm.SFCDMFieldEnum;
import com.sap.hcm.resume.collection.integration.sf.bean.cdm.SFCDMFieldEnumLabel;
import com.sap.hcm.resume.collection.integration.sf.bean.cdm.SFCDMFieldLabel;
import com.sap.hcm.resume.collection.integration.sf.bean.cdm.SFCDMSimple;
import com.sap.hcm.resume.collection.util.BeanTestUtil;

public class SFCDMBeanTest {
  
  @Before
  public void setup(){
    BeanTestUtil.registerBean4Test(SFCDMFieldDefinition.class);
    BeanTestUtil.registerBean4Test(SFCDMFieldEnum.class);
    BeanTestUtil.registerBean4Test(SFCDMFieldEnumLabel.class);
    BeanTestUtil.registerBean4Test(SFCDMFieldLabel.class);
    BeanTestUtil.registerBean4Test(SFCDMSimple.class);
  }
  
  @Test
  public void testGetterSetter(){
    BeanTestUtil.processBeanTest();
  }
}
