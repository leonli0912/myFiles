package com.sap.hcm.resume.collection.integration.bean;

/**
 * @author I075908 SAP
 */
public enum TargetSystem {
  SF("SuccessFactors"),
  NONE("None");

  private String name;

  private TargetSystem(String name) {
    this.name = name;
  }

  public String getName() {
    return name;
  }
}
