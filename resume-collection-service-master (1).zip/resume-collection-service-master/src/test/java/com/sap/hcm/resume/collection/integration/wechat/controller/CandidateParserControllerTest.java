package com.sap.hcm.resume.collection.integration.wechat.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.jsoup.nodes.Document;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.BDDMockito;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.context.WebApplicationContext;

import com.sap.hcm.resume.collection.bean.CandidateVendorEnum;
import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.bean.ResumeInfo;
import com.sap.hcm.resume.collection.context.TestContext;
import com.sap.hcm.resume.collection.context.WebAppContext;
import com.sap.hcm.resume.collection.entity.view.CandidateBgWorkExprVO;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;
import com.sap.hcm.resume.collection.factory.CandidateFactory;
import com.sap.hcm.resume.collection.integration.JobBoardBaseProvider;
import com.sap.hcm.resume.collection.integration.JobBoardProviderFactory;
import com.sap.hcm.resume.collection.integration.bean.ResumeDownloadBean;
import com.sap.hcm.resume.collection.integration.wechat.bean.WechatImportResultWrapper;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatUserResumeMapping;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatUserService;
import com.sap.hcm.resume.collection.integration.wechat.util.WechatResumeHelper;
import com.sap.hcm.resume.collection.parser.DocumentParserAdapter;
import com.sap.hcm.resume.collection.service.CandidateProfileService;
import com.sap.hcm.resume.collection.util.CandidateProfileHelper;

@RunWith(PowerMockRunner.class)
@PowerMockRunnerDelegate(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { TestContext.class, WebAppContext.class })
@PrepareForTest({ CandidateParserController.class, CandidateFactory.class })
public class CandidateParserControllerTest {

  @Resource(type = WebApplicationContext.class)
  private WebApplicationContext webApplicationContext;

  @Resource(name = "wechatUserService")
  private WechatUserService wechatUserService;

  @Resource(name = "wechatResumeHelper")
  private WechatResumeHelper wechatResumeHelper;

  @Resource(name = "jobBoardProviderFactory")
  private JobBoardProviderFactory jobBoardProviderFactory;

  @Resource(name = "messageSource")
  private MessageSource messageSource;

  private CandidateParserController candidateParserController;
  
  @Resource(name = "candidateProfileHelper")
  private CandidateProfileHelper candidateProfileHelper;

  private CandidateProfileService candidateProfileService;
  
  @Autowired
  private Params params;

  @Before
  public void setUp() {
    reset(wechatUserService);
    candidateParserController = spy(new CandidateParserController());
    candidateProfileHelper = Mockito.mock(CandidateProfileHelper.class);
    candidateProfileService = Mockito.mock(CandidateProfileService.class);
    
    params.setCompanyId("sap");
    params.setWechatOpenId("openid");
    params.setUserEmail("abc@sap.com");
    ReflectionTestUtils.setField(candidateParserController, "wechatUserService", wechatUserService);
    ReflectionTestUtils.setField(candidateParserController, "wechatResumeHelper", wechatResumeHelper);
    ReflectionTestUtils.setField(candidateParserController, "jobBoardProviderFactory", jobBoardProviderFactory);
    ReflectionTestUtils.setField(candidateParserController, "messageSource", messageSource);
    ReflectionTestUtils.setField(candidateParserController, "params", params);
    ReflectionTestUtils.setField(candidateParserController, "candidateProfileHelper", candidateProfileHelper);
    ReflectionTestUtils.setField(candidateParserController, "candidateProfileService", candidateProfileService);
  }

  @Test
  public void testGetPreloginInfo() throws Exception {
    Map<String, String> result = new HashMap<String, String>();
    MockHttpServletRequest request = new MockHttpServletRequest();
    String vendor = "sap";
    JobBoardBaseProvider jobBoardBaseProvider = Mockito.mock(JobBoardBaseProvider.class);
    when(jobBoardProviderFactory.getProvider(vendor)).thenReturn(jobBoardBaseProvider);
    Mockito.doNothing().when(jobBoardBaseProvider).preLogin();

    result = candidateParserController.getPreLoginInfo(request, vendor);
    assertEquals("success", result.get("result"));
  }

  @Test
  public void testGetVerifyCode() throws Exception {
    MockHttpServletRequest request = new MockHttpServletRequest();
    String vendor = "sap";
    JobBoardBaseProvider jobBoardBaseProvider = Mockito.mock(JobBoardBaseProvider.class);
    when(jobBoardProviderFactory.getProvider(vendor)).thenReturn(jobBoardBaseProvider);
    Mockito.doNothing().when(jobBoardBaseProvider).getVerifyCode(request);

    candidateParserController.getVerifyCode(request, vendor);
  }

  @Test
  public void testGetVerifyCodeImage() throws Exception {
    MockHttpServletRequest request = new MockHttpServletRequest();
    MockHttpServletResponse response = new MockHttpServletResponse();
    byte[] item = "heheda".getBytes();
    request.getSession().setAttribute("verifyCode", item);
    OutputStream ops = Mockito.mock(OutputStream.class);
    candidateParserController.getVerifyCodeImage(request, response);
  }

  @Test(expected = IOException.class)
  public void testGetVerifyCodeImageFail() throws Exception {
    MockHttpServletRequest request = new MockHttpServletRequest();
    byte[] item = "heheda".getBytes();
    request.getSession().setAttribute("verifyCode", item);
    OutputStream ops = Mockito.mock(OutputStream.class);
    HttpServletResponse response = Mockito.mock(HttpServletResponse.class);
    when(response.getOutputStream()).thenThrow(new IOException());
    candidateParserController.getVerifyCodeImage(request, response);
  }

  @Test
  public void testWechatImportResultWrapperFailWithResumeExist() throws Exception {
    MockHttpServletRequest request = new MockHttpServletRequest();
    WechatImportResultWrapper result = new WechatImportResultWrapper();
    String username = "abc";
    String pwd = "efg";
    String captcha = "hij";
    String vendor = "klm";
    String wechatId = "wechat001";
    String companyId = "sap";
    boolean dpcsAgreed = false;
    List<ResumeDownloadBean> fileNameList = new ArrayList<ResumeDownloadBean>();
    ResumeDownloadBean resumeDownloadBean = new ResumeDownloadBean();
    resumeDownloadBean.setFileName("heheda");
    resumeDownloadBean.setLocale(Locale.CHINA);
    fileNameList.add(resumeDownloadBean);
    when(
        wechatUserService.checkResumeAlreadyImported(wechatId, companyId, vendor,
            resumeDownloadBean.getExternalResumeId(), resumeDownloadBean.getLocale().getLanguage(),
            CandidateVendorEnum.LIEPIN.toString().equalsIgnoreCase(vendor) ? false : true)).thenReturn(true);
    JobBoardBaseProvider jobBoardBaseProvider = Mockito.mock(JobBoardBaseProvider.class);
    when(jobBoardProviderFactory.getProvider(vendor)).thenReturn(jobBoardBaseProvider);
    when(jobBoardBaseProvider.getResume(request, username, pwd, captcha)).thenReturn(fileNameList);
    result = candidateParserController.parseResume(request, username, pwd, captcha, vendor, dpcsAgreed);
    assertEquals(1, result.getFailureCount());
  }

  @Test
  public void testWechatImportResultWrapperSuccess() throws Exception {
    MockHttpServletRequest request = new MockHttpServletRequest();
    WechatImportResultWrapper result = new WechatImportResultWrapper();
    String username = "abc";
    String pwd = "efg";
    String captcha = "hij";
    String vendor = "klm";
    String wechatId = "wechat001";
    String companyId = "sap";
    Long candidateId = 12345L;
    String externalResumeId = "1234567";
    boolean dpcsAgreed = false;

    List<ResumeDownloadBean> fileNameList = new ArrayList<ResumeDownloadBean>();
    ResumeDownloadBean resumeDownloadBean = new ResumeDownloadBean();
    resumeDownloadBean.setFileName("heheda");
    resumeDownloadBean.setLocale(Locale.CHINA);
    resumeDownloadBean.setExternalResumeId(externalResumeId);
    fileNameList.add(resumeDownloadBean);
    when(
        wechatUserService.checkResumeAlreadyImported(wechatId, companyId, vendor,
            resumeDownloadBean.getExternalResumeId(), resumeDownloadBean.getLocale().getLanguage(),
            CandidateVendorEnum.LIEPIN.toString().equalsIgnoreCase(vendor) ? false : true)).thenReturn(false);
    JobBoardBaseProvider jobBoardBaseProvider = Mockito.mock(JobBoardBaseProvider.class);
    when(jobBoardProviderFactory.getProvider(vendor)).thenReturn(jobBoardBaseProvider);
    when(jobBoardBaseProvider.getResume(request, username, pwd, captcha)).thenReturn(fileNameList);
    ResumeInfo resumeInfo = new ResumeInfo();
    Document content = new Document("heheda");
    resumeInfo.setHtmlDocument(content);
    resumeInfo.setResumeExtension("html");
    when(jobBoardBaseProvider.getFileContent(resumeDownloadBean.getFileContent())).thenReturn(resumeInfo);
    DocumentParserAdapter parser = Mockito.mock(DocumentParserAdapter.class);
    PowerMockito.mockStatic(CandidateFactory.class);
    BDDMockito.given(CandidateFactory.getDocumentParserInstance(messageSource, vendor, resumeDownloadBean.getLocale()))
        .willReturn(parser);
    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    candidateProfileVO.setCandidateId(candidateId);
    candidateProfileVO.setExtProfile(null);
    when(parser.parseProfile(any(CandidateProfileVO.class), any(ResumeInfo.class))).thenReturn(candidateProfileVO);
    when(parser.parseBackgroundWorkExp(any(CandidateProfileVO.class), any(ResumeInfo.class))).thenReturn(
        candidateProfileVO);
    when(parser.parseBackgroundEducation(any(CandidateProfileVO.class), any(ResumeInfo.class))).thenReturn(
        candidateProfileVO);
    when(parser.parseBackgroundLanguage(any(CandidateProfileVO.class), any(ResumeInfo.class))).thenReturn(
        candidateProfileVO);
    when(parser.parseBackgroundCertificate(any(CandidateProfileVO.class), any(ResumeInfo.class))).thenReturn(
        candidateProfileVO);
    when(wechatResumeHelper.generateResumePDF(any(CandidateProfileVO.class))).thenReturn("resumeHtmlHaha".getBytes());
    
    Mockito.doNothing().when(wechatUserService).saveUserResumeMapping(any(WechatUserResumeMapping.class));
    Mockito.doNothing().when(candidateProfileHelper).fillPicklistOptions(any(CandidateProfileVO.class),Mockito.any(Locale.class));
    when(candidateProfileService.saveCandidateProfile(any(CandidateProfileVO.class))).thenReturn(candidateProfileVO);
    
    result = candidateParserController.parseResume(request, username, pwd, captcha, vendor, dpcsAgreed);
    assertEquals(1, result.getSuccessCount());
  }

  @Test
  public void testWechatImportResultFailWithParseError() throws Exception {
    MockHttpServletRequest request = new MockHttpServletRequest();
    WechatImportResultWrapper result = new WechatImportResultWrapper();
    String username = "abc";
    String pwd = "efg";
    String captcha = "hij";
    String vendor = "klm";
    String wechatId = "wechat001";
    String companyId = "sap";
    Long candidateId = 12345L;
    String externalResumeId = "1234567";
    boolean dpcsAgreed = false;

    List<ResumeDownloadBean> fileNameList = new ArrayList<ResumeDownloadBean>();
    ResumeDownloadBean resumeDownloadBean = new ResumeDownloadBean();
    resumeDownloadBean.setFileName("heheda");
    resumeDownloadBean.setLocale(Locale.CHINA);
    resumeDownloadBean.setExternalResumeId(externalResumeId);
    fileNameList.add(resumeDownloadBean);
    when(
        wechatUserService.checkResumeAlreadyImported(wechatId, companyId, vendor,
            resumeDownloadBean.getExternalResumeId(), resumeDownloadBean.getLocale().getLanguage(),
            CandidateVendorEnum.LIEPIN.toString().equalsIgnoreCase(vendor) ? false : true)).thenReturn(false);
    JobBoardBaseProvider jobBoardBaseProvider = Mockito.mock(JobBoardBaseProvider.class);
    when(jobBoardProviderFactory.getProvider(vendor)).thenReturn(jobBoardBaseProvider);
    when(jobBoardBaseProvider.getResume(request, username, pwd, captcha)).thenReturn(fileNameList);
    ResumeInfo resumeInfo = new ResumeInfo();
    Document content = new Document("heheda");
    resumeInfo.setHtmlDocument(content);
    resumeInfo.setResumeExtension("html");
    when(jobBoardBaseProvider.getFileContent(resumeDownloadBean.getFileContent())).thenReturn(resumeInfo);
    DocumentParserAdapter parser = Mockito.mock(DocumentParserAdapter.class);
    PowerMockito.mockStatic(CandidateFactory.class);
    BDDMockito.given(CandidateFactory.getDocumentParserInstance(messageSource, vendor, resumeDownloadBean.getLocale()))
        .willReturn(parser);
    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    candidateProfileVO.setCandidateId(candidateId);
    when(parser.parseProfile(candidateProfileVO, resumeInfo)).thenReturn(candidateProfileVO);
    when(parser.parseBackgroundWorkExp(any(CandidateProfileVO.class), any(ResumeInfo.class))).thenReturn(
        candidateProfileVO);
    when(parser.parseBackgroundEducation(any(CandidateProfileVO.class), any(ResumeInfo.class))).thenReturn(
        candidateProfileVO);
    when(parser.parseBackgroundLanguage(any(CandidateProfileVO.class), any(ResumeInfo.class))).thenReturn(
        candidateProfileVO);
    when(parser.parseBackgroundCertificate(any(CandidateProfileVO.class), any(ResumeInfo.class))).thenReturn(
        candidateProfileVO);
    when(wechatResumeHelper.generateResumePDF(any(CandidateProfileVO.class))).thenReturn("resumeHtmlHaha".getBytes());

    Mockito.doNothing().when(wechatUserService).saveUserResumeMapping(any(WechatUserResumeMapping.class));
    Mockito.doNothing().when(candidateProfileHelper).fillPicklistOptions(any(CandidateProfileVO.class),Mockito.any(Locale.class));
    when(candidateProfileService.saveCandidateProfile(any(CandidateProfileVO.class))).thenReturn(candidateProfileVO);
    
    result = candidateParserController.parseResume(request, username, pwd, captcha, vendor, dpcsAgreed);
    assertEquals(1, result.getFailureCount());
  }

  @Test
  public void testWechatImportResultWrapperSuccessWithCurrentWorkName() throws Exception {
    MockHttpServletRequest request = new MockHttpServletRequest();
    WechatImportResultWrapper result = new WechatImportResultWrapper();
    String username = "abc";
    String pwd = "efg";
    String captcha = "hij";
    String vendor = "klm";
    String wechatId = "wechat001";
    String companyId = "sap";
    Long candidateId = 12345L;
    String externalResumeId = "1234567";
    boolean dpcsAgreed = false;

    List<ResumeDownloadBean> fileNameList = new ArrayList<ResumeDownloadBean>();
    ResumeDownloadBean resumeDownloadBean = new ResumeDownloadBean();
    resumeDownloadBean.setFileName("heheda");
    resumeDownloadBean.setLocale(Locale.CHINA);
    resumeDownloadBean.setExternalResumeId(externalResumeId);
    fileNameList.add(resumeDownloadBean);
    when(
        wechatUserService.checkResumeAlreadyImported(wechatId, companyId, vendor,
            resumeDownloadBean.getExternalResumeId(), resumeDownloadBean.getLocale().getLanguage(),
            CandidateVendorEnum.LIEPIN.toString().equalsIgnoreCase(vendor) ? false : true)).thenReturn(false);
    JobBoardBaseProvider jobBoardBaseProvider = Mockito.mock(JobBoardBaseProvider.class);
    when(jobBoardProviderFactory.getProvider(vendor)).thenReturn(jobBoardBaseProvider);
    when(jobBoardBaseProvider.getResume(request, username, pwd, captcha)).thenReturn(fileNameList);
    ResumeInfo resumeInfo = new ResumeInfo();
    Document content = new Document("heheda");
    resumeInfo.setHtmlDocument(content);
    resumeInfo.setResumeExtension("html");
    when(jobBoardBaseProvider.getFileContent(resumeDownloadBean.getFileContent())).thenReturn(resumeInfo);
    DocumentParserAdapter parser = Mockito.mock(DocumentParserAdapter.class);
    PowerMockito.mockStatic(CandidateFactory.class);
    BDDMockito.given(CandidateFactory.getDocumentParserInstance(messageSource, vendor, resumeDownloadBean.getLocale()))
        .willReturn(parser);
    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    candidateProfileVO.setCandidateId(candidateId);
    candidateProfileVO.setExtProfile(null);

    List<CandidateBgWorkExprVO> workExprs = new ArrayList<CandidateBgWorkExprVO>();
    CandidateBgWorkExprVO candidateBgWorkExprVO = new CandidateBgWorkExprVO();
    candidateBgWorkExprVO.setIsPresent(true);
    candidateBgWorkExprVO.setEmployer("sap");
    candidateBgWorkExprVO.setJobTitle("Manager");
    workExprs.add(candidateBgWorkExprVO);
    candidateProfileVO.setWorkExprs(workExprs);

    when(parser.parseProfile(any(CandidateProfileVO.class), any(ResumeInfo.class))).thenReturn(candidateProfileVO);
    when(parser.parseBackgroundWorkExp(any(CandidateProfileVO.class), any(ResumeInfo.class))).thenReturn(
        candidateProfileVO);
    when(parser.parseBackgroundEducation(any(CandidateProfileVO.class), any(ResumeInfo.class))).thenReturn(
        candidateProfileVO);
    when(parser.parseBackgroundLanguage(any(CandidateProfileVO.class), any(ResumeInfo.class))).thenReturn(
        candidateProfileVO);
    when(parser.parseBackgroundCertificate(any(CandidateProfileVO.class), any(ResumeInfo.class))).thenReturn(
        candidateProfileVO);
    when(wechatResumeHelper.generateResumePDF(any(CandidateProfileVO.class))).thenReturn("resumeHtmlHaha".getBytes());

    Mockito.doNothing().when(wechatUserService).saveUserResumeMapping(any(WechatUserResumeMapping.class));
    Mockito.doNothing().when(candidateProfileHelper).fillPicklistOptions(any(CandidateProfileVO.class),Mockito.any(Locale.class));
    when(candidateProfileService.saveCandidateProfile(any(CandidateProfileVO.class))).thenReturn(candidateProfileVO);
    
    result = candidateParserController.parseResume(request, username, pwd, captcha, vendor, dpcsAgreed);
    assertEquals(1, result.getSuccessCount());
  }

  @Test
  public void testWechatImportResultWrapperSuccessWithCurrentWorkNameEmpty() throws Exception {
    MockHttpServletRequest request = new MockHttpServletRequest();
    WechatImportResultWrapper result = new WechatImportResultWrapper();
    String username = "abc";
    String pwd = "efg";
    String captcha = "hij";
    String vendor = "klm";
    String wechatId = "wechat001";
    String companyId = "sap";
    Long candidateId = 12345L;
    String externalResumeId = "1234567";
    boolean dpcsAgreed = false;

    List<ResumeDownloadBean> fileNameList = new ArrayList<ResumeDownloadBean>();
    ResumeDownloadBean resumeDownloadBean = new ResumeDownloadBean();
    resumeDownloadBean.setFileName("heheda");
    resumeDownloadBean.setLocale(Locale.CHINA);
    resumeDownloadBean.setExternalResumeId(externalResumeId);
    fileNameList.add(resumeDownloadBean);
    when(
        wechatUserService.checkResumeAlreadyImported(wechatId, companyId, vendor,
            resumeDownloadBean.getExternalResumeId(), resumeDownloadBean.getLocale().getLanguage(),
            CandidateVendorEnum.LIEPIN.toString().equalsIgnoreCase(vendor) ? false : true)).thenReturn(false);
    JobBoardBaseProvider jobBoardBaseProvider = Mockito.mock(JobBoardBaseProvider.class);
    when(jobBoardProviderFactory.getProvider(vendor)).thenReturn(jobBoardBaseProvider);
    when(jobBoardBaseProvider.getResume(request, username, pwd, captcha)).thenReturn(fileNameList);
    ResumeInfo resumeInfo = new ResumeInfo();
    Document content = new Document("heheda");
    resumeInfo.setHtmlDocument(content);
    resumeInfo.setResumeExtension("html");
    when(jobBoardBaseProvider.getFileContent(resumeDownloadBean.getFileContent())).thenReturn(resumeInfo);
    DocumentParserAdapter parser = Mockito.mock(DocumentParserAdapter.class);
    PowerMockito.mockStatic(CandidateFactory.class);
    BDDMockito.given(CandidateFactory.getDocumentParserInstance(messageSource, vendor, resumeDownloadBean.getLocale()))
        .willReturn(parser);
    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    candidateProfileVO.setCandidateId(candidateId);
    candidateProfileVO.setExtProfile(null);

    List<CandidateBgWorkExprVO> workExprs = new ArrayList<CandidateBgWorkExprVO>();
    CandidateBgWorkExprVO candidateBgWorkExprVO = new CandidateBgWorkExprVO();
    candidateBgWorkExprVO.setIsPresent(false);
    candidateBgWorkExprVO.setEmployer("");
    candidateBgWorkExprVO.setJobTitle("");
    workExprs.add(candidateBgWorkExprVO);
    candidateProfileVO.setWorkExprs(workExprs);

    when(parser.parseProfile(any(CandidateProfileVO.class), any(ResumeInfo.class))).thenReturn(candidateProfileVO);
    when(parser.parseBackgroundWorkExp(any(CandidateProfileVO.class), any(ResumeInfo.class))).thenReturn(
        candidateProfileVO);
    when(parser.parseBackgroundEducation(any(CandidateProfileVO.class), any(ResumeInfo.class))).thenReturn(
        candidateProfileVO);
    when(parser.parseBackgroundLanguage(any(CandidateProfileVO.class), any(ResumeInfo.class))).thenReturn(
        candidateProfileVO);
    when(parser.parseBackgroundCertificate(any(CandidateProfileVO.class), any(ResumeInfo.class))).thenReturn(
        candidateProfileVO);
    when(wechatResumeHelper.generateResumePDF(any(CandidateProfileVO.class))).thenReturn("resumeHtmlHaha".getBytes());
    Mockito.doNothing().when(candidateProfileHelper).fillPicklistOptions(any(CandidateProfileVO.class),Mockito.any(Locale.class));
    when(candidateProfileService.saveCandidateProfile(any(CandidateProfileVO.class))).thenReturn(candidateProfileVO);
    
    result = candidateParserController.parseResume(request, username, pwd, captcha, vendor, dpcsAgreed);
    assertEquals(1, result.getSuccessCount());
  }
}
