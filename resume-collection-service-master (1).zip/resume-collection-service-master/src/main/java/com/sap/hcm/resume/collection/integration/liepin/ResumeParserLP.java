package com.sap.hcm.resume.collection.integration.liepin;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.context.MessageSource;
import org.springframework.util.StringUtils;

import com.sap.hcm.resume.collection.entity.view.CandidateBgEducationVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgLanguageVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgWorkExprVO;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.parser.HTMLDocumentParser;
import com.sap.hcm.resume.collection.util.CandidateDateUtil;
import com.sap.hcm.resume.collection.util.MappingUtil;

public class ResumeParserLP extends HTMLDocumentParser {

  public ResumeParserLP(MessageSource messageSource) {
    super(messageSource);
  }

  private static Map<String, Integer> aliases = new HashMap<String, Integer>();

  private static Elements resumeElements;


  private void setAliasesToMap(Document content) {

    resumeElements = content.getElementsByClass("MsoTableGrid");

    for (int i = 1; i < resumeElements.size(); i++) {
      Element element = resumeElements.get(i);
      String data = element.text();

      /* Judge whether the resume to be parsed is English version or Chinese version */
      if (i == 1) {
        if (data.contains("基本资料")) {
          resumeLanguageType = Locale.CHINA.getLanguage();
        } else if (data.contains("Personal Information")) {
          resumeLanguageType = Locale.US.getLanguage();
        }
      }

      if (data.contains("基本资料") || (data.contains("Personal Information"))) {
        aliases.put("profile", i);
        continue;
      } else if (data.contains("职业意向") || (data.contains("Career Development"))) {
        aliases.put("career", i);
        continue;
      } else if (data.contains("工作经历") || (data.contains("Work Experience"))) {
        aliases.put("workExp", i);
        continue;
      } else if (data.contains("教育经历") || (data.contains("Educational Experience"))) {
        aliases.put("education", i);
        continue;
      } else if (data.contains("语言能力") || (data.contains("Language Ability"))) {
        aliases.put("language", i);
        continue;
      }
    }

  }

  @Override
  public CandidateProfileVO parseProfile(CandidateProfileVO candidateProfileVO, Document content)
      throws ServiceApplicationException {

    try {

      setAliasesToMap(content);

      String regex = null;

      Element element = resumeElements.get(0);
      String data = element.text();

      if (resumeLanguageType.equals(Locale.CHINA.getLanguage())) {
        /* Parse Chinese version Resume */
        regex = "(\\S+)\\s(\\S)\\s(?=目前公司：)";
      } else if (resumeLanguageType.equals(Locale.US.getLanguage())) {
        /* Parse English version Resume */
        regex = "(\\S+\\s?\\S*)\\s(\\S+)\\s(?=Current Company:)";
      }else{
        throw new ServiceApplicationException("Unsupported resume language type.");
      }

      Pattern pattern = Pattern.compile(regex);
      Matcher matcher = pattern.matcher(data);
      if (matcher.find()) {
        String name = matcher.group(1);

        if (resumeLanguageType.equals(Locale.CHINA.getLanguage())) {
          // lastName 姓
          candidateProfileVO.setLastName(name.substring(0, 1));
          // firstName 名
          candidateProfileVO.setFirstName(name.substring(1, name.length()));
        } else if (resumeLanguageType.equals(Locale.US.getLanguage())) {
          String[] nameList = name.split("\\s+");
          // lastName 姓
          if (nameList.length > 1) {
            candidateProfileVO.setLastName(nameList[1]);
          }
          // firstName 名
          candidateProfileVO.setFirstName(nameList[0]);
        }
        // gender 性别
        if (resumeLanguageType.equals(Locale.CHINA.getLanguage())) {
          if ("男".equals(matcher.group(2))) {
            candidateProfileVO.setGender("Male");
          } else {
            candidateProfileVO.setGender("Female");
          }
        } else if (resumeLanguageType.equals(Locale.US.getLanguage())) {
          if ("Male".equals(matcher.group(2))) {
            candidateProfileVO.setGender("Male");
          } else {
            candidateProfileVO.setGender("Female");
          }

        }

      }

      Integer profileIndex = aliases.get("profile");
      if (profileIndex == null) {
        return candidateProfileVO;
      }
      element = resumeElements.get(profileIndex);
      data = element.text();

      if (resumeLanguageType.equals(Locale.CHINA.getLanguage())) {
        regex = "(?<=婚姻状况：\\s)\\S+(?=\\s手　　机：)";
      } else if (resumeLanguageType.equals(Locale.US.getLanguage())) {
        regex = "(?<=Marital Status:\\s)\\S+(?=\\sMobile:)";
      }

      String marriage = MappingUtil.matchSingle(regex, data);
      // marriage 婚姻状况
      if (resumeLanguageType.equals(Locale.CHINA.getLanguage())) {
        if ("已婚".equals(marriage)) {
          candidateProfileVO.setMarriage("Y");
        } else if ("未婚".equals(marriage)) {
          candidateProfileVO.setMarriage("N");
        }
      } else if (resumeLanguageType.equals(Locale.US.getLanguage())) {
        if ("Married".equals(marriage)) {
          candidateProfileVO.setMarriage("Y");
        } else if ("Single".equals(marriage)) {
          candidateProfileVO.setMarriage("N");
        }
      }

      if (resumeLanguageType.equals(Locale.CHINA.getLanguage())) {
        regex = "(?<=手　　机：\\s)\\S+(?=\\s邮　　箱：)";
      } else if (resumeLanguageType.equals(Locale.US.getLanguage())) {
        regex = "(?<=Mobile:\\s)\\S+(?=\\sEmail:)";
      }

      // cellPhone 移动电话
      candidateProfileVO.setCellPhone(MappingUtil.matchSingle(regex, data));

      if (resumeLanguageType.equals(Locale.CHINA.getLanguage())) {
        regex = "(?<=邮　　箱：\\s)\\S+(?=\\s国　　籍：)";
      } else if (resumeLanguageType.equals(Locale.US.getLanguage())) {
        regex = "(?<=Email:\\s)\\S+(?=\\sNationality:)";
      }
      // primaryEmail 电子邮件 主键
      candidateProfileVO.setPrimaryEmail(MappingUtil.matchSingle(regex, data));

      // contactEmail 电子邮件
      candidateProfileVO.setContactEmail(MappingUtil.matchSingle(regex, data));

      if (resumeLanguageType.equals(Locale.CHINA.getLanguage())) {
        regex = "(?<=国　　籍：\\s)\\S+(?=\\s户　　籍：)";
      } else if (resumeLanguageType.equals(Locale.US.getLanguage())) {
        regex = "(?<=Nationality:\\s)\\S+(?=\\sHukou:)";
      }

      // country 国籍
      candidateProfileVO.setCountry(MappingUtil.matchSingle(regex, data));

      if (resumeLanguageType.equals(Locale.CHINA.getLanguage())) {
        regex = "(?<=户　　籍：\\s)\\S+(?=\\s目前状态：)";
      } else if (resumeLanguageType.equals(Locale.US.getLanguage())) {
        regex = "(?<=Nationality:\\s)\\S+(?=\\sCurrent Status:)";
      }

      // houseHold 户口性质
      candidateProfileVO.setHousehold(MappingUtil.matchSingle(regex, data));

      if (resumeLanguageType.equals(Locale.CHINA.getLanguage())) {
        regex = "(?<=所在地点：\\s)\\S+";
      } else if (resumeLanguageType.equals(Locale.US.getLanguage())) {
        regex = "(?<=Present Locus:\\s)\\S+";
      }

      // residence 现居住城市
      candidateProfileVO.setResidence(MappingUtil.matchSingle(regex, data));

      Integer careerIndex = aliases.get("career");
      if (careerIndex == null) {
        return candidateProfileVO;
      }
      element = resumeElements.get(careerIndex);
      data = element.text();

      if (resumeLanguageType.equals(Locale.CHINA.getLanguage())) {
        regex = "(?<=期望地点：\\s)\\S+(?=\\s期望年薪：)";
      } else if (resumeLanguageType.equals(Locale.US.getLanguage())) {
        regex = "(?<=Expected Location:\\s)\\S+(?=\\sExpect Salary:)";
      }

      // preferredLoc
      candidateProfileVO.setResidence(MappingUtil.matchSingle(regex, data));

      if (resumeLanguageType.equals(Locale.CHINA.getLanguage())) {
        regex = "(?<=期望年薪：\\s)\\S+(?=\\s万)";
      } else if (resumeLanguageType.equals(Locale.US.getLanguage())) {
        regex = "(?<=Expect Salary:\\s)\\S+(?=\\s万)";
      }

      String strMinAnnualSal = MappingUtil.matchSingle(regex, data);
      if (!StringUtils.isEmpty(strMinAnnualSal)) {
        Double doubleMinAnnualSal = Double.valueOf(strMinAnnualSal) * 10000;
        int intMinAnnualSal = (int) doubleMinAnnualSal.doubleValue();
        candidateProfileVO.setMinAnnualSal(String.valueOf(intMinAnnualSal));
      }

    } catch (Exception e) {
      throw new ServiceApplicationException("Profile parse error");
    }

    return candidateProfileVO;
  }

  @Override
  public CandidateProfileVO parseBackgroundWorkExp(CandidateProfileVO candidateProfileVO, Document content)
      throws ServiceApplicationException {

    try {

      List<CandidateBgWorkExprVO> candidateBgWorkExprVOList = new ArrayList<CandidateBgWorkExprVO>();

      CandidateBgWorkExprVO candidateBgWorkExprVO = null;
      String regex = null;

      Integer workExpIndex = aliases.get("workExp");
      if (workExpIndex == null) {
        return candidateProfileVO;
      }
      Element element = resumeElements.get(workExpIndex);
      String data = element.text();

      List<String> workExprList = getWorkExprList(data);

      for (String workExpr : workExprList) {
        candidateBgWorkExprVO = new CandidateBgWorkExprVO();

        // presentEmployer
        if (resumeLanguageType.equals(Locale.CHINA.getLanguage())) {
          regex = "\\d{4}\\.\\d{2}-至今";
        } else if (resumeLanguageType.equals(Locale.US.getLanguage())) {
          regex = "\\d{4}\\.\\d{2}-Now";
        }
        String presentEmployer = MappingUtil.matchSingle(regex, workExpr);
        if (!presentEmployer.isEmpty()) {
          candidateBgWorkExprVO.setIsPresent(true);
        } else {
          candidateBgWorkExprVO.setIsPresent(false);
        }

        if (resumeLanguageType.equals(Locale.CHINA.getLanguage())) {
          regex = "(?<=\\d{4}\\.\\d{2}-(\\d{4}\\.\\d{2}\\s|至今\\s))\\S*(?=   (公司描述：|公司行业：|公司性质：))";
        } else if (resumeLanguageType.equals(Locale.US.getLanguage())) {
          regex = "(?<=\\d{4}\\.\\d{2}-(\\d{4}\\.\\d{2}\\s|Now\\s))[\\S\\s]*(?=   Industry:)";
        }
        // employer 公司名称

        candidateBgWorkExprVO.setEmployer(MappingUtil.matchSingle(regex, workExpr));
        
        if (resumeLanguageType.equals(Locale.CHINA.getLanguage())) {
          regex = "(?<=公司行业：\\s)[\\S]{0,100}(?=[\\s\\S]*)";
        } else if (resumeLanguageType.equals(Locale.US.getLanguage())) {
          regex = "(?<=Industry:\\s)[\\s\\S]{0,100}(?=[\\s\\S]*)";
        }
        candidateBgWorkExprVO.setBusinessType(MappingUtil.matchSingle(regex, workExpr));
        
        if (resumeLanguageType.equals(Locale.CHINA.getLanguage())) {
          regex = "(?<=公司行业：\\s[\\S]{0,100}   )[\\s\\S]*";
        } else if (resumeLanguageType.equals(Locale.US.getLanguage())) {
          regex = "(?<=Industry:\\s[\\s\\S]{0,100}   )[\\s\\S]*";
        }
        String companyCareer = MappingUtil.matchSingle(regex, workExpr);

        regex = "\\S+\\s\\d{4}\\.\\d{2}-[\\S\\s]*?(?=(\\S+\\s\\d{4}\\.\\d{2}-|$))";
        Pattern careerPattern = Pattern.compile(regex);
        Matcher careerMatcher = careerPattern.matcher(companyCareer);
        CandidateBgWorkExprVO careerCandidateBgWorkExprVO = null;

        while (careerMatcher.find()) {

          careerCandidateBgWorkExprVO = new CandidateBgWorkExprVO();
          careerCandidateBgWorkExprVO = candidateBgWorkExprVO;

          // title
          regex = "\\S+(?=\\s)";
          careerCandidateBgWorkExprVO.setJobTitle(MappingUtil.matchSingle(regex, careerMatcher.group()));

          // startDate 开始时间
          regex = "\\d{4}\\.\\d{2}(?=-)";
          careerCandidateBgWorkExprVO.setStartDate(CandidateDateUtil.formatDate("yyyy.mm", "yyyy/mm/dd",
              MappingUtil.matchSingle(regex, careerMatcher.group())));

          if (!careerCandidateBgWorkExprVO.getIsPresent()) {
            // endDate 结束时间
            regex = "(?<=-)\\d{4}\\.\\d{2}";
            careerCandidateBgWorkExprVO.setEndDate(CandidateDateUtil.formatDate("yyyy.mm", "yyyy/mm/dd",
                MappingUtil.matchSingle(regex, careerMatcher.group())));
          }else{
            careerCandidateBgWorkExprVO.setEndDate("NOW");
          }

          // department
          if (resumeLanguageType.equals(Locale.CHINA.getLanguage())) {
            regex = "(?<=所在部门：\\s)[\\S]{0,100}(?=[\\s\\S]*)";
          } else if (resumeLanguageType.equals(Locale.US.getLanguage())) {
            regex = "(?<=Department：\\s)[\\S]{0,100}(?=[\\s\\S]*)";
          }
          careerCandidateBgWorkExprVO.setDepartment(MappingUtil.matchSingle(regex, careerMatcher.group()));
                    
          // description
          if (resumeLanguageType.equals(Locale.CHINA.getLanguage())) {
            regex = "(?<=工作职责：\\s)[\\s\\S]*(?=$)";
          } else if (resumeLanguageType.equals(Locale.US.getLanguage())) {
            regex = "(?<=Responsibilities:\\s)[\\s\\S]*(?=$)";
          }
          careerCandidateBgWorkExprVO.setDescription(MappingUtil.matchSingle(regex, careerMatcher.group()));

          // exitReason
          careerCandidateBgWorkExprVO.setExitReason("unkown");

          // salary
          careerCandidateBgWorkExprVO.setSalary("unkown");

          // salaryEnd
          careerCandidateBgWorkExprVO.setSalaryEnd("unkown");

          candidateBgWorkExprVOList.add(careerCandidateBgWorkExprVO);
        }
      }

      candidateProfileVO.setWorkExprs(candidateBgWorkExprVOList);

    } catch (Exception e) {
      throw new ServiceApplicationException("Profile parse error" + e.getMessage());
    }

    return candidateProfileVO;
  }

  @Override
  public CandidateProfileVO parseBackgroundEducation(CandidateProfileVO candidateProfileVO, Document content)
      throws ServiceApplicationException {

    try {

      List<CandidateBgEducationVO> candidateBgEducationVOList = new ArrayList<CandidateBgEducationVO>();

      CandidateBgEducationVO candidateBgEducationVO = null;
      String regex = null;

      Integer educationIndex = aliases.get("education");
      if (educationIndex == null) {
        return candidateProfileVO;
      }
      Element element = resumeElements.get(educationIndex);
      Elements educationElements = element.getElementsByTag("tr");

      for (int i = 1; i < educationElements.size() - 1; i += 2) {

        candidateBgEducationVO = new CandidateBgEducationVO();
        Element eduElement = educationElements.get(i);
        String data = eduElement.text();

        // school
        if (resumeLanguageType.equals(Locale.CHINA.getLanguage())) {
          regex = "[\\S\\s]*?(?=\\（)";
        } else {
          regex = "[\\S\\s]*?(?=\\()";
        }
        candidateBgEducationVO.setSchool(MappingUtil.matchSingle(regex, data));

        // startDate 开始时间
        regex = "\\d{4}\\.\\d{2}(?=\\s-)";
        candidateBgEducationVO.setStartDate(CandidateDateUtil.formatDate("yyyy.mm", "yyyy/mm/dd",
            MappingUtil.matchSingle(regex, data)));

        // endDate 结束时间
        regex = "(?<=-\\s)\\d{4}\\.\\d{2}";
        candidateBgEducationVO.setEndDate(CandidateDateUtil.formatDate("yyyy.mm", "yyyy/mm/dd",
            MappingUtil.matchSingle(regex, data)));

        eduElement = educationElements.get(i + 1);
        data = eduElement.text();

        if (resumeLanguageType.equals(Locale.CHINA.getLanguage())) {
          regex = "(?<=专业名称：\\s)\\S+(?=\\s学历：)";
        } else if (resumeLanguageType.equals(Locale.US.getLanguage())) {
          regex = "(?<=Major:\\s)\\S+(?=\\sDegree:)";
        }
        // major

        candidateBgEducationVO.setMajor(MappingUtil.matchSingle(regex, data));

        if (resumeLanguageType.equals(Locale.CHINA.getLanguage())) {
          regex = "(?<=学历：\\s)\\S+(?=\\s是否统招：)";
        } else if (resumeLanguageType.equals(Locale.US.getLanguage())) {
          regex = "(?<=Degree:\\s)\\S+(?=\\sFull-time school:)";
        }

        // degree or level
        candidateBgEducationVO.setDegree(MappingUtil.matchSingle(regex, data));

        // schoolState
        candidateBgEducationVO.setSchoolState("no comment");

        // gpa
        candidateBgEducationVO.setGpa("no comment");

        candidateBgEducationVOList.add(candidateBgEducationVO);
      }

      candidateProfileVO.setEducation(candidateBgEducationVOList);

    } catch (Exception e) {
      throw new ServiceApplicationException("Profile parse error");
    }

    return candidateProfileVO;
  }

  @Override
  public CandidateProfileVO parseBackgroundLanguage(CandidateProfileVO candidateProfileVO, Document content)
      throws ServiceApplicationException {

    try {

      List<CandidateBgLanguageVO> candidateBgLanguageVOList = new ArrayList<CandidateBgLanguageVO>();

      CandidateBgLanguageVO candidateBgLanguageVO = null;
      String regex = null;

      Integer languageIndex = aliases.get("language");
      if (languageIndex == null) {
        return candidateProfileVO;
      }
      Element element = resumeElements.get(languageIndex);
      String data = element.text();

      if (resumeLanguageType.equals(Locale.CHINA.getLanguage())) {
        regex = "(?<=语言能力\\s)[\\s\\S]*";
      } else if (resumeLanguageType.equals(Locale.US.getLanguage())) {
        regex = "(?<=Language\\s)[\\s\\S]*";
      } else {
        throw new ServiceApplicationException("Unsupported language type: " + resumeLanguageType);
      }

      String languages = MappingUtil.matchSingle(regex, data);

      String language[] = languages.split("、");

      String nameRegex;
      String levelRegex;
      for (String str : language) {

        candidateBgLanguageVO = new CandidateBgLanguageVO();

        nameRegex = "[\\S]*?(?=\\()";

        String name = MappingUtil.matchSingle(nameRegex, str);

        levelRegex = "(?<=\\()[\\S]*?(?=\\))";
        String level = MappingUtil.matchSingle(levelRegex, str);
        String levelResult = null;
        if (resumeLanguageType.equals(Locale.CHINA.getLanguage())) {

          if (!StringUtils.isEmpty(name)) {
            candidateBgLanguageVO.setName(name);
          } else {
            continue;
          }

          if (level.length() >= 4) {
            levelResult = level.substring(0, 4);
          } else {
            levelResult = "简单沟通";
          }
          candidateBgLanguageVO.setReadingProf(levelResult);
          candidateBgLanguageVO.setWritingProf(levelResult);
          candidateBgLanguageVO.setSpeakingProf(levelResult);
          
        } else if (resumeLanguageType.equals(Locale.US.getLanguage())) {
          if (name.equals("Mandarin") || name.isEmpty()) {
            continue;
          }
          candidateBgLanguageVO.setName(name.toUpperCase());

          /*
           * Get the level in case there is extra useless infomation such as English(ThresholdCET6)
           */
          if (level.startsWith("Th")) {
            level = level.substring(0, 9);
          } else if (level.startsWith("Ma")) {
            level = level.substring(0, 7);
          } else if (level.startsWith("Ne")) {
            level = level.substring(0, 11);
          } else if (level.startsWith("Tr")) {
            level = level.substring(0, 10);
          }
          candidateBgLanguageVO.setReadingProf(level);
          candidateBgLanguageVO.setWritingProf(level);
          candidateBgLanguageVO.setSpeakingProf(level);
          
        }
        candidateBgLanguageVOList.add(candidateBgLanguageVO);
      }

      candidateProfileVO.setLanguages(candidateBgLanguageVOList);

    } catch (Exception e) {
      throw new ServiceApplicationException("Profile parse error");
    }

    return candidateProfileVO;
  }

  @Override
  public CandidateProfileVO parseBackgroundCertificate(CandidateProfileVO candidateProfileVO, Document content)
      throws ServiceApplicationException {

    // no certificates in liepin resume
    return candidateProfileVO;
  }

  private static List<String> getWorkExprList(String content) {

    List<String> exprList = new ArrayList<String>();
    content = content.replace("工作经历", "").replace("Work Experience", "").trim();

    Pattern p = Pattern.compile("\\d{4}\\.\\d{2}-");
    Matcher m = p.matcher(content);

    // find all the start dates and add separator ############ in front
    Set<String> startDates = new HashSet<String>();
    while (m.find()) {
      startDates.add(m.group());
    }
    if (startDates != null) {
      for (String sdate : startDates) {
        content = content.replaceAll(sdate, "############" + sdate);
      }
    }
    String[] es = content.split("############");

    for (int i = 0; i < es.length; i++) {
      String expr = "";
      if (es[i].indexOf("公司行业：") >= 0 || es[i].indexOf("Industry:") > 0) {
        expr = es[i];
        if (i + 1 < es.length) {
          expr = expr.concat(es[i + 1]);
          exprList.add(expr);
        }
      }
    }
    return exprList;
  }

}
