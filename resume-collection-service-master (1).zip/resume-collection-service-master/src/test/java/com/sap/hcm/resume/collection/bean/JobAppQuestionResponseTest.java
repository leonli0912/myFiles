package com.sap.hcm.resume.collection.bean;

import org.junit.Assert;
import org.junit.Test;

public class JobAppQuestionResponseTest {
  
  @Test
  public void testGetterSetter(){
    JobAppQuestionResponse rsp = new JobAppQuestionResponse();
    rsp.setAnswer("anwser");
    rsp.setOrder(1L);
    
    Assert.assertEquals("anwser", rsp.getAnswer());
    Assert.assertEquals("1", rsp.getOrder().toString());
  }
}
