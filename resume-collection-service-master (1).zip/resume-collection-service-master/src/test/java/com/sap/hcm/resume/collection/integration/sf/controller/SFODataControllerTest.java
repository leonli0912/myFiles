package com.sap.hcm.resume.collection.integration.sf.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.olingo.odata2.api.edm.Edm;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.test.util.ReflectionTestUtils;

import com.sap.hcm.resume.collection.bean.SimpleJsonResponse;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.sf.bean.SFPicklistItem;
import com.sap.hcm.resume.collection.integration.sf.odata.SFODataService;
import com.sap.hcm.resume.collection.integration.sf.service.SFPicklistService;

@RunWith(PowerMockRunner.class)
public class SFODataControllerTest {

  private SFODataController sfODataController;

  private SFODataService sfODataService;

  private SFPicklistService sfPicklistService;

  @Before
  public void setUp() {
    sfODataController = new SFODataController();
    sfODataService = Mockito.mock(SFODataService.class);
    sfPicklistService = Mockito.mock(SFPicklistService.class);
    ReflectionTestUtils.setField(sfODataController, "sfODataService", sfODataService);
    ReflectionTestUtils.setField(sfODataController, "sfPicklistService", sfPicklistService);
  }

  @Test
  public void testRefreshMetadataSuccess() throws ServiceApplicationException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    Edm edm = Mockito.mock(Edm.class);
    Mockito.when(sfODataService.getEdm(true)).thenReturn(edm);

    SimpleJsonResponse response = sfODataController.refreshMetadata(request);
    Assert.assertEquals("success", response.getMessage());
  }

  @Test
  public void testRefreshMetadataWithEdmNull() throws ServiceApplicationException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    Mockito.when(sfODataService.getEdm(true)).thenReturn(null);

    SimpleJsonResponse response = sfODataController.refreshMetadata(request);
    Assert.assertEquals(-1, response.getCode());
    Assert.assertEquals("refresh metadata failed", response.getMessage());
  }

  @Test
  public void testRefreshMetadataWithException() throws ServiceApplicationException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    ServiceApplicationException ex = new ServiceApplicationException("Test Exception");
    Mockito.when(sfODataService.getEdm(true)).thenThrow(ex);

    SimpleJsonResponse response = sfODataController.refreshMetadata(request);
    Assert.assertEquals(-1, response.getCode());
    Assert.assertEquals(
        "refresh metadata failed, please check destination 'SF_ODATA' or contact application admin for help",
        response.getMessage());
  }

  @Test
  public void testLoadPicklistOptionsSuccess() throws ServiceApplicationException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    String testPicklistId = "testPicklistId";
    List<SFPicklistItem> optionList = mockPicklist();
    Mockito.when(sfPicklistService.loadPickListOption(testPicklistId)).thenReturn(optionList);
    List<SFPicklistItem> result = sfODataController.loadPicklistOptions(request, testPicklistId, "zh_CN");

    Assert.assertEquals(2, result.size());
  }

  @Test
  public void testGetPicklistNameSuccess() throws ServiceApplicationException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    String propName = "testPropName";
    String entityTypeName = "testEntityTypeName";
    String picklistName = "testPicklistName";
    Mockito.when(sfPicklistService.getPicklistName(propName, entityTypeName)).thenReturn(picklistName);
    SimpleJsonResponse response = sfODataController.getPicklistName(request, propName, entityTypeName);
    Assert.assertEquals("testPicklistName", response.getMessage());
    Assert.assertEquals(0, response.getCode());
  }

  @Test
  public void testGetPicklistNameFailed() throws ServiceApplicationException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    String propName = "testPropName";
    String entityTypeName = "testEntityTypeName";
    Mockito.when(sfPicklistService.getPicklistName(propName, entityTypeName)).thenThrow(
        new ServiceApplicationException("TestEx"));
    SimpleJsonResponse response = sfODataController.getPicklistName(request, propName, entityTypeName);
    Assert.assertEquals("", response.getMessage());
    Assert.assertEquals(-1, response.getCode());
  }

  private List<SFPicklistItem> mockPicklist() {
    List<SFPicklistItem> result = new ArrayList<SFPicklistItem>();
    SFPicklistItem item1 = new SFPicklistItem();
    item1.setLabel("item1_label");
    item1.setLocale("zh_CN");
    item1.setOptionId(1L);
    result.add(item1);
    SFPicklistItem item2 = new SFPicklistItem();
    item2.setLabel("item2_label");
    item2.setLocale("en_US");
    item2.setOptionId(2L);
    result.add(item2);
    SFPicklistItem item3 = new SFPicklistItem();
    item3.setLabel("item3_label");
    item3.setLocale("zh_CN");
    item3.setOptionId(3L);
    result.add(item3);
    return result;
  }
}
