package com.sap.hcm.resume.collection.integration.bean;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.junit.Assert;

@SuppressWarnings("rawtypes")
public class IntegrationBeanUtil {

	private static List<Class> beanList;
	
	static{
		beanList = new ArrayList<Class>();
	}
	
	public static void registerBean(Class beanClaz){
		beanList.add(beanClaz);
	}
	
	public static void executeBeanTest(){
		for (Class beanClaz : beanList){
			Map keyValueMap = new HashMap();
			Object beanInstance = setUpDummyData(beanClaz, keyValueMap);
			validateDummyData(beanClaz, beanInstance, keyValueMap);
			keyValueMap = null;
		}
		
		beanList.clear();
	}
	
	@SuppressWarnings({ "unchecked" })
	private static void validateDummyData(Class beanClaz, Object beanInstance, Map keyValueMap) {
		for(Object fieldN : keyValueMap.keySet()){
			String fieldName = (String) fieldN;
			try{
				Method getMethod = null;
				Class type = beanClaz.getDeclaredField(fieldName).getType();
				if(type.getSimpleName().equals("boolean")){
					getMethod = beanClaz.getMethod("is".concat(composeMethodPostFix(fieldName)));
				}else{
					getMethod = beanClaz.getMethod("get".concat(composeMethodPostFix(fieldName)));
				}
				Object getValue = getMethod.invoke(beanInstance);
				Assert.assertEquals(keyValueMap.get(fieldName), getValue);
			}catch(Exception e){
				continue;
			}
		}
		
	}

	@SuppressWarnings({ "unchecked" })
	private static Object setUpDummyData(Class beanClaz, Map keyValueMap){
		Object beanInstance = null;
		Field[] fields = beanClaz.getDeclaredFields();
		try{
			beanInstance = beanClaz.newInstance();
			for(int i = 0; i < fields.length; i++){
				Field field = fields[i];
				Class type = field.getType();
				Object value = generateDummyValue(type);
				if(value != null){
					String fieldName = field.getName();
					//The modifier of serialVersionUID is "private static final",
					//which accounts for 26 letter
					if(field.getModifiers() == 26){
						//skip the field serialVersionUID
						continue;
					}
					keyValueMap.put(fieldName, value);
					Method setMethod = beanClaz.getMethod("set".concat(composeMethodPostFix(fieldName)), type);
				    setMethod.invoke(beanInstance, value);
				}
			}
		}catch(Exception e){
			//Do nothing
		}
		
		return beanInstance;
	}

	private static Object generateDummyValue(Class type) {
		if (type.isArray()) {
		      Class compType = type.getComponentType();
		      return null;
		    }
		    if (type.isEnum()) {
		      return null;
		    }
		    if (type.getSimpleName().equals("int") || type.getSimpleName().equals("Integer")) {
		      return 1;
		    }
		    if (type.getSimpleName().equalsIgnoreCase("Boolean")) {
		      return true;
		    }
		    if (type.getSimpleName().equals("char") || type.getSimpleName().equals("Character")) {
		      return 'a';
		    }
		    if (type.getSimpleName().equalsIgnoreCase("long")) {
		      return 1L;
		    }
		    if (type.getSimpleName().equalsIgnoreCase("float")) {
		      return 1f;
		    }
		    if (type.getSimpleName().equals("Date")) {
		      return new Date();
		    }
		    if ("java.sql.Timestamp".equals(type.getName())) {
		      long time = new Date().getTime();
		      return new Timestamp(time);
		    }
		    if (type.getSimpleName().equalsIgnoreCase("Short")) {
		      return 1;
		    }
		    if (type.getSimpleName().equalsIgnoreCase("Byte")) {
		      return 1;
		    }
		    if (type.getSimpleName().equals("String")) {
		      return "test string";
		    }
		    if (type.getSimpleName().equals("List")) {
		      return Collections.EMPTY_LIST;
		    }
		    if (type.getSimpleName().equals("Map")) {
		      return Collections.EMPTY_MAP;
		    }
		    if (type.getSimpleName().equals("Set")) {
		      return Collections.EMPTY_SET;
		    }
		    if (type.getSimpleName().equals("Array")) {
		      return null;
		    }
		    if (type.getSimpleName().equals("Locale")) {
		    	return Locale.CANADA;
		    }
		    if (type.getSimpleName().equals("InputStream")){
		    	return null;
		    }
		    try {
		      return type.newInstance();
		    } catch (Exception e) {
		      e.printStackTrace();
		      return null;
		    }
	}

	private static String composeMethodPostFix(String fieldName) {
		if (fieldName.length() > 1) {
		    if (Character.isUpperCase(fieldName.charAt(1))) {
		      return fieldName;
		    } else {
		      return fieldName.substring(0, 1).toUpperCase().concat(fieldName.substring(1, fieldName.length()));
		    }
		 } else {
		    return "";
		 }
	}
}

