package com.sap.hcm.resume.collection.integration.wechat.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "WECHAT_USER")
@Embeddable
public class WechatUser {
  
  /**
   * Pls note: we will use user's email as 
   * wechat Id  
   */
  @Id
  @Column(name = "wechat_id")
  private String wechatId;

  @Id
  @Column(name = "company_id")
  private String companyId;

  @Temporal(TemporalType.DATE)
  @Column(name = "login_time")
  private Date loginTime;

  @Column(name = "active")
  private boolean active;

  @Column(name = "nickname", unique = false)
  private String nickname;

  @Column(name = "portrait")
  @Lob
  private byte[] portrait;

  @Column(name = "photo_id")
  private Long photoId;

  @Column(name = "internalEmail")
  private String internalEmail;

  @Column(name = "dpcs_agreed")
  private boolean dpcsAgreed;

  public String getInternalEmail() {
    return internalEmail;
  }

  public void setInternalEmail(String internalEmail) {
    this.internalEmail = internalEmail;
  }

  /**
   * @return the dpcsAgreed
   */
  public boolean isDpcsAgreed() {
    return dpcsAgreed;
  }

  /**
   * @param dpcsAgreed
   *          the dpcsAgreed to set
   */
  public void setDpcsAgreed(boolean dpcsAgreed) {
    this.dpcsAgreed = dpcsAgreed;
  }

  public Date getLoginTime() {
    return loginTime;
  }

  public void setLoginTime(Date loginTime) {
    this.loginTime = loginTime;
  }

  public String getWechatId() {
    return wechatId;
  }

  public void setWechatId(String wechatId) {
    this.wechatId = wechatId;
  }

  public String getCompanyId() {
    return companyId;
  }

  public void setCompanyId(String companyId) {
    this.companyId = companyId;
  }

  public boolean isActive() {
    return active;
  }

  public void setActive(boolean active) {
    this.active = active;
  }

  public String getNickname() {
    return nickname;
  }

  public void setNickname(String nickname) {
    this.nickname = nickname;
  }

  public byte[] getPortrait() {
    return portrait;
  }

  public void setPortrait(byte[] portrait) {
    this.portrait = portrait;
  }

  public Long getPhotoId() {
    return photoId;
  }

  public void setPhotoId(Long photoId) {
    this.photoId = photoId;
  }
}
