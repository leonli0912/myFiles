package com.sap.hcm.resume.collection.integration.sf.odata;

import com.sap.hcm.resume.collection.bean.BusinessEntityType;

/**
 * @author I075908 SAP
 */
public enum SFODataEntityType {
  CANDIDATE("Candidate", BusinessEntityType.CANDIDATE),
  JOBREQUISITION("JobRequisition", BusinessEntityType.JOBREQUISITION),
  JOBAPPLICATION("JobApplication", BusinessEntityType.JOBAPPLICATION);

  private String name;

  private BusinessEntityType mappedEntityType;

  private SFODataEntityType(String name, BusinessEntityType mappedEntityType) {
    this.name = name;
    this.mappedEntityType = mappedEntityType;
  }

  public String getName() {
    return name;
  }

  public BusinessEntityType getMappedEntityType() {
    return mappedEntityType;
  }
}
