package com.sap.hcm.resume.collection.bean;

import java.io.Serializable;
import java.util.List;

public class FilterListItem implements Serializable{

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 1L;
    
    public String type;
    
    public String title;
    
    public List<KeyLabelBean> values;

    /**
     * @return the type
     */
    public String getType() {
        return type;
    }

    /**
     * @param type the type to set
     */
    public void setType(String type) {
        this.type = type;
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.title = title;
    }

    /**
     * @return the values
     */
    public List<KeyLabelBean> getValues() {
        return values;
    }

    /**
     * @param values the values to set
     */
    public void setValues(List<KeyLabelBean> values) {
        this.values = values;
    }

}
