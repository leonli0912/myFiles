package com.sap.hcm.resume.collection.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

@Entity
@Table(name = "EXCEPTION_LOG")
public class ExceptionLog {
  @Id
  @GeneratedValue(strategy = GenerationType.TABLE, generator = "exception_log_seq")
  @TableGenerator(initialValue = 1, table = "SEQUENCE", name = "exception_log_seq", pkColumnName = "SEQ_NAME", valueColumnName = "SEQ_COUNT", pkColumnValue = "EXCEPTION_LOG_PK", allocationSize = 1)
  @Column(name = "log_id")
  private long logId;

  @Column(name = "company_id")
  private String companyId;

  @Column(name = "create_at", length = 30)
  private String createAt;

  @Column(name = "exception_type")
  private String exceptionType;

  @Column(name = "function_type")
  private String functionType;

  @Column(name = "exception_message", length = 4000)
  private String exceptionMessage;

  public long getLogId() {
    return logId;
  }

  public void setLogId(long logId) {
    this.logId = logId;
  }

  public String getCompanyId() {
    return companyId;
  }

  public void setCompanyId(String companyId) {
    this.companyId = companyId;
  }

  public String getCreateAt() {
    return createAt;
  }

  public void setCreateAt(String createAt) {
    this.createAt = createAt;
  }

  public String getExceptionType() {
    return exceptionType;
  }

  public void setExceptionType(String exceptionType) {
    this.exceptionType = exceptionType;
  }

  public String getFunctionType() {
    return functionType;
  }

  public void setFunctionType(String functionType) {
    this.functionType = functionType;
  }

  public String getExceptionMessage() {
    return exceptionMessage;
  }

  public void setExceptionMessage(String exceptionMessage) {
    this.exceptionMessage = exceptionMessage;
  }

}
