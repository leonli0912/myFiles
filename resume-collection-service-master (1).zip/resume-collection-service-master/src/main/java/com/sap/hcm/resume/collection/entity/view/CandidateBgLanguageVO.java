package com.sap.hcm.resume.collection.entity.view;

import java.io.Serializable;

import com.sap.hcm.resume.collection.annotation.ProfileAttribute;
import com.sap.hcm.resume.collection.util.I18nMessages;
import com.thoughtworks.xstream.annotations.XStreamAlias;

@XStreamAlias("language")
public class CandidateBgLanguageVO implements CandidateBgBase, Serializable{
	
	/**
	 * serialVersionUID
	 */
    private static final long serialVersionUID = 5566584389705607592L;
    
	@ProfileAttribute(name="name", type=String.class, label=I18nMessages.LABEL_NAME)
	private String name;
	
	@ProfileAttribute(name="speakingProf", type=String.class, label=I18nMessages.LABEL_SPEAKING_PROF)
	private String speakingProf;
	
	@ProfileAttribute(name="readingProf", type=String.class, label=I18nMessages.LABEL_READING_PROF)
	private String readingProf;
	
	@ProfileAttribute(name="writingProf", type=String.class, label=I18nMessages.LABEL_WRITING_PROF)
	private String writingProf;

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the speakingProf
	 */
	public String getSpeakingProf() {
		return speakingProf;
	}

	/**
	 * @param speakingProf the speakingProf to set
	 */
	public void setSpeakingProf(String speakingProf) {
		this.speakingProf = speakingProf;
	}

	/**
	 * @return the readingProf
	 */
	public String getReadingProf() {
		return readingProf;
	}

	/**
	 * @param readingProf the readingProf to set
	 */
	public void setReadingProf(String readingProf) {
		this.readingProf = readingProf;
	}

	/**
	 * @return the writingProf
	 */
	public String getWritingProf() {
		return writingProf;
	}

	/**
	 * @param writingProf the writingProf to set
	 */
	public void setWritingProf(String writingProf) {
		this.writingProf = writingProf;
	}
	
}
