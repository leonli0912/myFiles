package com.sap.hcm.resume.collection.controller;

import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sap.cloud.account.Account;
import com.sap.cloud.account.Tenant;
import com.sap.cloud.account.TenantContext;
import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.bean.SimpleJsonResponse;
import com.sap.hcm.resume.collection.context.TestContext;
import com.sap.hcm.resume.collection.context.WebAppContext;
import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.hcp.HCPUserProvider;
import com.sap.hcm.resume.collection.integration.wechat.bean.JobDynSearchBean;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatJobService;
import com.sap.hcm.resume.collection.service.CompanyInfoService;
import com.sap.hcm.resume.collection.util.MockHCPUser;
import com.sap.security.um.user.User;

@RunWith(PowerMockRunner.class)
@PowerMockRunnerDelegate(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { TestContext.class, WebAppContext.class })
public class HCPUserControllerTest {

  private MockMvc mockMvc;

  @Resource(type = WebApplicationContext.class)
  private WebApplicationContext webApplicationContext;

  @Autowired
  private CompanyInfoService compInfoService;

  @Autowired
  private HCPUserProvider hcpUserProvider;

  @Autowired
  private TenantContext tenantContext;

  @Autowired
  private Params param;
  
  @Autowired
  private WechatJobService wechatJobService;

  @Before
  public void setUp() {
    mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
  }

  @SuppressWarnings("rawtypes")
  @Test
  public void testGetValidUserInfoWithTanent() throws Exception {

    User loginUser = new MockHCPUser();
    Mockito.when(hcpUserProvider.getLoginUser(Mockito.any(HttpServletRequest.class))).thenReturn(loginUser);

    Tenant tenant = Mockito.mock(Tenant.class);
    Mockito.when(tenantContext.getTenant()).thenReturn(tenant);

    Account account = Mockito.mock(Account.class);
    Mockito.when(tenant.getAccount()).thenReturn(account);
    Mockito.when(account.getId()).thenReturn("account1");

    System.setProperty("HC_ACCOUNT", "account1");

    CompanyInfo compInfo = new CompanyInfo();
    compInfo.setCompanyId("sap");
    compInfo.setCompanyName("sap");
    
    Mockito.when(compInfoService.getCompanyInfo(param.getCompanyId())).thenReturn(compInfo);
    
    Mockito.when(wechatJobService.getTotalWechatUserNumber(param.getCompanyId())).thenReturn(10L);
    
    Mockito.when(wechatJobService.getTotalCount(Mockito.any(JobDynSearchBean.class))).thenReturn(10L);
    
    ResultActions result = mockMvc.perform(MockMvcRequestBuilders.get("/user/info").principal(loginUser)).andExpect(
        MockMvcResultMatchers.status().is(200));
    String content = result.andReturn().getResponse().getContentAsString();
    ObjectMapper mapper = new ObjectMapper();
    Map resultMap = mapper.readValue(content, Map.class);
    Map companyInfoMap = (Map) resultMap.get("company");
    Assert.assertEquals(companyInfoMap.get("id"), "sap");
  }


  @Test
  public void testGetValidUserInfoNoUser() throws Exception {
    Mockito.when(hcpUserProvider.getLoginUser(Mockito.any(HttpServletRequest.class))).thenReturn(null);
    ResultActions result = mockMvc.perform(MockMvcRequestBuilders.get("/user/info")).andExpect(
        MockMvcResultMatchers.status().is(200));
    String content = result.andReturn().getResponse().getContentAsString();
    ObjectMapper mapper = new ObjectMapper();
    SimpleJsonResponse rsp = mapper.readValue(content, SimpleJsonResponse.class);
    Assert.assertEquals(rsp.getCode(), -1005);
  }

  @Test
  @SuppressWarnings("rawtypes")
  public void testGetUserWithoutCompanyInfo() throws Exception {

    User loginUser = new MockHCPUser();
    MockHttpSession session = new MockHttpSession();
    session.putValue(HCPUserProvider.LOGIN_USER, loginUser);

    ResultActions result = mockMvc.perform(
        MockMvcRequestBuilders.get("/user/info").session(session).principal(loginUser)).andExpect(
        MockMvcResultMatchers.status().is(200));
    String content = result.andReturn().getResponse().getContentAsString();
    ObjectMapper om = new ObjectMapper();

    Map responseJson = om.readValue(content, Map.class);
    Assert.assertEquals(responseJson.get("code"), -1005);
  }

  @Test
  public void testLogout() throws Exception {

    User loginUser = new MockHCPUser();
    MockHttpSession session = new MockHttpSession();
    session.putValue(HCPUserProvider.LOGIN_USER, loginUser);

    mockMvc.perform(MockMvcRequestBuilders.get("/user/logout").session(session)).andExpect(
        MockMvcResultMatchers.status().is(200));
  }
}
