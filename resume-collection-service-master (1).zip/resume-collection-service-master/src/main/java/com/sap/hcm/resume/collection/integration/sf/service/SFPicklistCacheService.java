package com.sap.hcm.resume.collection.integration.sf.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.bean.ApplyDataModelMappingItem;
import com.sap.hcm.resume.collection.integration.bean.CandProfileDataModelMapping;
import com.sap.hcm.resume.collection.integration.bean.DataModelMappingItem;
import com.sap.hcm.resume.collection.integration.bean.JobReqDataModelMappingItem;
import com.sap.hcm.resume.collection.integration.sf.bean.SFPicklistItem;
import com.sap.hcm.resume.collection.integration.sf.entity.SFPicklistCache;
import com.sap.hcm.resume.collection.service.DataModelMappingService;

/**
 * serivce to cache picklist options to DB to improve overall performance.
 * 
 * @author i065831
 */
@Service
public class SFPicklistCacheService {

  @PersistenceContext
  private EntityManager entityManager;

  @Autowired
  private DataModelMappingService dmMappingService;

  /**
   * remove all picklist cache
   * 
   * @param companyId
   * @return
   */
  public int deletePicklistCache(String companyId, String entityType) {
    int rs = 1;
    String sql = "delete from SFPicklistCache pk where pk.companyId = :companyId";
    if (!StringUtils.isEmpty(entityType)) {
      sql = sql.concat(" and pk.entityType = :entityType");
    }
    Query query = entityManager.createQuery(sql);

    query.setParameter("companyId", companyId);
    if (!StringUtils.isEmpty(entityType)) {
      query.setParameter("entityType", entityType);
    }
    try {
      query.executeUpdate();
    } catch (PersistenceException e) {
      rs = -1;
    }
    return rs;
  }

  /**
   * remove all picklist cache
   * 
   * @param companyId
   * @return
   */
  public int deletePicklistCacheByName(String companyId, String picklistName, String entityType) {
    int rs = 1;
    Query query = entityManager
        .createQuery("delete from SFPicklistCache pk where pk.companyId = :companyId and pk.pklName = :pklName and pk.entityType = :entityType");
    query.setParameter("companyId", companyId);
    query.setParameter("pklName", picklistName);
    query.setParameter("entityType", entityType);

    try {
      query.executeUpdate();
    } catch (PersistenceException e) {
      rs = -1;
    }
    return rs;
  }

  /**
   * save picklist item into cache
   * 
   * @param pkItems
   * @param picklistName
   * @param companyId
   * @return
   */
  public int savePickListCache(List<SFPicklistItem> pkItems, String picklistName, String companyId, String entityType) {
    int rs = 1;
    if (pkItems != null) {
      int rcode = this.deletePicklistCacheByName(companyId, picklistName, entityType);
      if (rcode > 0) {
        try {
          for (SFPicklistItem item : pkItems) {
            SFPicklistCache cache = new SFPicklistCache();
            cache.setCompanyId(companyId);
            cache.setLocale(item.getLocale());
            cache.setPklLabel(item.getLabel());
            cache.setPklOptionId(item.getOptionId());
            cache.setPklName(picklistName);
            cache.setEntityType(entityType);
            entityManager.persist(cache);
          }
        } catch (Exception e) {
          rs = -1;
        }
      }
    }
    return rs;
  }

  /**
   * @param companyId
   * @param picklistName
   * @return
   */
  public List<SFPicklistItem> getPicklistOptionsByName(String companyId, String picklistName, String locale,
      String entityType) {
    List<SFPicklistItem> itemList = new ArrayList<SFPicklistItem>();

    String sql = "select pk from SFPicklistCache pk where pk.companyId = :companyId and pk.entityType = :entityType";
    if (!StringUtils.isEmpty(picklistName)) {
      sql = sql.concat(" and pk.pklName = :pklName");
    }
    if (!StringUtils.isEmpty(locale)) {
      sql = sql.concat(" and pk.locale = :locale");
    }
    TypedQuery<SFPicklistCache> query = entityManager.createQuery(sql, SFPicklistCache.class);
    query.setParameter("companyId", companyId);
    query.setParameter("entityType", entityType);

    if (!StringUtils.isEmpty(picklistName)) {
      query.setParameter("pklName", picklistName);
    }
    if (!StringUtils.isEmpty(locale)) {
      query.setParameter("locale", locale);
    }

    List<SFPicklistCache> cacheList = (List<SFPicklistCache>) query.getResultList();
    if (cacheList != null && cacheList.size() > 0) {
      for (SFPicklistCache cache : cacheList) {
        SFPicklistItem item = new SFPicklistItem();
        item.setOptionId(cache.getPklOptionId());
        item.setLabel(cache.getPklLabel());
        item.setLocale(cache.getLocale());
        itemList.add(item);
      }
    }

    return itemList;
  }

  @SuppressWarnings("unchecked")
  public List<String> getPicklistLocales(String companyId, String entityType) {
    List<String> localeList = new ArrayList<String>();
    String sql = "select distinct pk.locale from SFPicklistCache pk where pk.companyId = :companyId and pk.entityType = :entityType";
    Query query = entityManager.createQuery(sql);
    query.setParameter("companyId", companyId);
    query.setParameter("entityType", entityType);
    try {
      localeList = (List<String>) query.getResultList();
    } catch (Exception e) {
      return localeList;
    }
    return localeList;
  }

  /**
   * get picklist options from cache
   * 
   * @param companyId
   * @param locale
   * @return
   */
  public Map<String, List<SFPicklistItem>> getPicklistOptions(String companyId, String locale, String entityType) {

    Map<String, List<SFPicklistItem>> picklistMap = new HashMap<String, List<SFPicklistItem>>();
    Set<JobReqDataModelMappingItem> items = dmMappingService.getPicklistForJobRequisition(companyId, false);
    if (items != null && items.size() > 0) {
      for (JobReqDataModelMappingItem item : items) {
        List<SFPicklistItem> pkItemList = this.getPicklistOptionsByName(companyId, item.getPicklist(), locale,
            entityType);
        if (pkItemList != null) {
          picklistMap.put(item.getSourceField(), pkItemList);
        }
      }
    }
    return picklistMap;
  }

  /**
   * get job application picklist options from cache
   * 
   * @param companyId
   * @param locale
   * @return
   * @throws ServiceApplicationException
   */
  public Map<String, List<SFPicklistItem>> getJobApplPicklistOptions(String companyId, String locale, String entityType)
      throws ServiceApplicationException {

    Map<String, List<SFPicklistItem>> picklistMap = new HashMap<String, List<SFPicklistItem>>();
    Set<ApplyDataModelMappingItem> items = dmMappingService.getPicklistForJobApplication(companyId);
    if (items != null && items.size() > 0) {
      for (ApplyDataModelMappingItem item : items) {
        List<SFPicklistItem> pkItemList = this.getPicklistOptionsByName(companyId, item.getPicklist(), locale,
            entityType);
        if (pkItemList != null) {
          picklistMap.put(item.getPicklist(), pkItemList);
        }
      }
    }
    return picklistMap;
  }

  /**
   * get candidate picklist options from cache
   * 
   * @param companyId
   * @param locale
   * @return
   * @throws ServiceApplicationException
   */
  public Map<String, List<SFPicklistItem>> getCandidatePicklistOptions(String companyId, Long mappingId, String locale,
      String entityType) throws ServiceApplicationException {

    Map<String, List<SFPicklistItem>> picklistMap = new HashMap<String, List<SFPicklistItem>>();
    CandProfileDataModelMapping candMapping = dmMappingService.getCandidateProfileDataModelMappingById(mappingId);
    if (candMapping.getProfile() != null && candMapping.getProfile().size() > 0) {
      for (DataModelMappingItem item : candMapping.getProfile()) {
        if (StringUtils.isEmpty(item.getPicklist())) {
          continue;
        }
        List<SFPicklistItem> pkItemList = this.getPicklistOptionsByName(companyId, item.getPicklist(), locale,
            entityType);
        if (pkItemList != null) {
          picklistMap.put(item.getPicklist(), pkItemList);
        }
      }
    }
    if (candMapping.getWorkExprs() != null && candMapping.getWorkExprs().size() > 0) {
      for (DataModelMappingItem item : candMapping.getWorkExprs()) {
        if (StringUtils.isEmpty(item.getPicklist())) {
          continue;
        }
        List<SFPicklistItem> pkItemList = this.getPicklistOptionsByName(companyId, item.getPicklist(), locale,
            entityType);
        if (pkItemList != null) {
          picklistMap.put(item.getPicklist(), pkItemList);
        }
      }
    }
    if (candMapping.getEducation() != null && candMapping.getEducation().size() > 0) {
      for (DataModelMappingItem item : candMapping.getEducation()) {
        if (StringUtils.isEmpty(item.getPicklist())) {
          continue;
        }
        List<SFPicklistItem> pkItemList = this.getPicklistOptionsByName(companyId, item.getPicklist(), locale,
            entityType);
        if (pkItemList != null) {
          picklistMap.put(item.getPicklist(), pkItemList);
        }
      }
    }
    if (candMapping.getLanguages() != null && candMapping.getLanguages().size() > 0) {
      for (DataModelMappingItem item : candMapping.getLanguages()) {
        if (StringUtils.isEmpty(item.getPicklist())) {
          continue;
        }
        List<SFPicklistItem> pkItemList = this.getPicklistOptionsByName(companyId, item.getPicklist(), locale,
            entityType);
        if (pkItemList != null) {
          picklistMap.put(item.getPicklist(), pkItemList);
        }
      }
    }
    if (candMapping.getCertificates() != null && candMapping.getCertificates().size() > 0) {
      for (DataModelMappingItem item : candMapping.getCertificates()) {
        if (StringUtils.isEmpty(item.getPicklist())) {
          continue;
        }
        List<SFPicklistItem> pkItemList = this.getPicklistOptionsByName(companyId, item.getPicklist(), locale,
            entityType);
        if (pkItemList != null) {
          picklistMap.put(item.getPicklist(), pkItemList);
        }
      }
    }
    if (candMapping.getFamilies() != null && candMapping.getFamilies().size() > 0) {
      for (DataModelMappingItem item : candMapping.getFamilies()) {
        if (StringUtils.isEmpty(item.getPicklist())) {
          continue;
        }
        List<SFPicklistItem> pkItemList = this.getPicklistOptionsByName(companyId, item.getPicklist(), locale,
            entityType);
        if (pkItemList != null) {
          picklistMap.put(item.getPicklist(), pkItemList);
        }
      }
    }

    return picklistMap;
  }

  public String getPKLLabelByOptionId(String pklName, String companyId, Long optionId, String locale, String entityType) {
    String sql = "select pk from SFPicklistCache pk where pk.companyId = :companyId and pk.pklOptionId = :optionId "
        + "and pk.locale = :locale and pk.pklName = :pklName and pk.entityType = :entityType";
    Query query = entityManager.createQuery(sql);
    query.setParameter("companyId", companyId);
    query.setParameter("optionId", optionId);
    query.setParameter("locale", locale);
    query.setParameter("pklName", pklName);
    query.setParameter("entityType", entityType);
    SFPicklistCache plc = (SFPicklistCache) query.getSingleResult();
    String label = plc.getPklLabel();
    return label;

  }
}
