package com.sap.hcm.resume.collection.integration.zhilian;

import java.util.ArrayList;
import java.util.List;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.context.MessageSource;
import org.springframework.util.StringUtils;

import com.sap.hcm.resume.collection.entity.view.CandidateBgCertificateVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgEducationVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgLanguageVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgWorkExprVO;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.parser.HTMLDocumentParser;
import com.sap.hcm.resume.collection.util.CandidateDateUtil;
import com.sap.hcm.resume.collection.util.MappingUtil;

/**
 * a parser class to parse the English resume downloaded from zhilian
 * 
 * @author i065831
 */
public class EnglishDocumentParserZL extends HTMLDocumentParser {

  public EnglishDocumentParserZL(MessageSource messageSource) {
    super(messageSource);
  }

  public static String EMPTY_SPACE = " ";

  public static String FIELD_SEPARATOR = "\\|";

  public static String DASH = "-";

  public static String COLON = ":";

  public static String SEMI_COLON = ";";

  @Override
  public CandidateProfileVO parseProfile(CandidateProfileVO profile,
      Document content) throws ServiceApplicationException {
    Elements summaryElements = content.getElementsByClass("summary");
    if (summaryElements.size() > 0) {
      Element summary = summaryElements.get(0);

      // parse name
      String nameRaw = "";
      Elements nameELs = summary.getElementsByTag("h1");
      if (nameELs.size() > 0) {
        nameRaw = nameELs.get(0).text();
        String[] names = nameRaw.split(EMPTY_SPACE);
        profile.setEnglishName(nameRaw);
        if (names.length == 1) {
          profile.setFirstName(names[0]);
        } else if (names.length == 2) {
          profile.setFirstName(names[0]);
          profile.setLastName(names[1]);
        } else if (names.length >= 3) {
          profile.setFirstName(names[0]);
          profile.setLastName(names[names.length - 1]);
          profile.setMiddleName(names[1]);
        }
      }

      String summaryBodyWithoutName = summary.text().replace(nameRaw, "");
      String part1 = summaryBodyWithoutName.substring(0,
          summaryBodyWithoutName.indexOf("Location"));

      // parse gender
      String genderRaw = part1.split(FIELD_SEPARATOR)[0];
      if (genderRaw.equalsIgnoreCase("male")) {
        profile.setGender("Male");
      } else if (genderRaw.equalsIgnoreCase("female")) {
        profile.setGender("Female");
      } else {
        profile.setGender("Unkown");
      }
       int num = 1;
      // parser marriage
      if (part1.split(FIELD_SEPARATOR)[1].matches(".*Born in.*")) {
        num = 1;
      }else{
        num = 2;
      }
      String marriageRaw = part1.split(FIELD_SEPARATOR)[1];
      if (marriageRaw.equalsIgnoreCase("single")) {
        profile.setMarriage("N");
      } else {
        profile.setMarriage("Y");
      }

      // parse date of birth
      String dobRaw = part1.split(FIELD_SEPARATOR)[num];
      String dob = MappingUtil.matchSingle("[\\d\\/]+", dobRaw);
      profile.setDateOfBirth(CandidateDateUtil.formatDate("yyyy/MM","yyyy/MM/dd",dob));

      // parse the HUKOU
      String houseHoldRaw = part1.split(FIELD_SEPARATOR)[3];
      String houseHold = houseHoldRaw.trim().split("[ |：]")[houseHoldRaw.trim()
          .split("[ |：]").length - 1];
      if(houseHold.indexOf("-")>=0){
        profile.setHousehold(houseHold.split(DASH)[1]);
      }else{
        profile.setHousehold(houseHold);
      }
      String part2 = summaryBodyWithoutName.substring(summaryBodyWithoutName
          .indexOf("Location"));
      String[] tokens = part2.trim().replace(" ", EMPTY_SPACE)
          .replace("：", EMPTY_SPACE).replace(":", EMPTY_SPACE).replace("|",EMPTY_SPACE).split("\\s+");
      String phoneRegex = "^[0-9]{11}$";
      for (int i = 0; i < tokens.length; i++) {
        if (tokens[i].startsWith("Location")) {
          if (i + 1 < tokens.length) {
            String location = tokens[i + 1];
            profile.setResidence(location);
          }
        }
        if (tokens[i].startsWith("Card")||tokens[i].startsWith("Passport")) {
          if (i + 1 < tokens.length) {
            String idNum = tokens[i + 1];
            profile.setIdentityCard(idNum);
          }
        }
        if(tokens[i].matches(phoneRegex)){
            String mobile = tokens[i].trim();
            profile.setCellPhone(mobile);
        }
        if (tokens[i].startsWith("E-mail")) {
          if (i + 1 < tokens.length) {
            String email = tokens[i + 1];
            profile.setContactEmail(email);
            profile.setPrimaryEmail(email);
          }
        }
      }
    }

    // need to more code parse the peferedLocation
    Elements detailElements = content.getElementsByClass("details");
    if (detailElements.get(0).childNodeSize() > 0
        && detailElements.get(0).child(0).text().indexOf("Objective") > 0) {
      Element careerObj = detailElements.get(0).child(1);
      Elements objList = careerObj.getElementsByTag("li");
      for (Element obj : objList) {
        System.out.println(obj.text());
        // parse prefered location
        if (obj.text().indexOf("Location") > 0) {
          String preferedLocation = obj.text().split(COLON)[1].trim();
          profile.setPreferredLoc(preferedLocation);
        }

        if (obj.text().indexOf("Salary") > 0) {
          String montylySalaryMin = MappingUtil.matchSingle("\\d+", obj.text());
          if (!StringUtils.isEmpty(montylySalaryMin)) {
            Long annualSalaryMin = Long.parseLong(montylySalaryMin) * 12;
            profile.setMinAnnualSal(annualSalaryMin.toString());
          }
        }
      }
    }
    return profile;
  }

  @Override
  public CandidateProfileVO parseBackgroundWorkExp(
      CandidateProfileVO candidateProfileVO, Document content)
      throws ServiceApplicationException {
    Elements workExpELs = content.getElementsByClass("work-experience");
    if (workExpELs.size() > 0) {
      List<CandidateBgWorkExprVO> workExpList = new ArrayList<CandidateBgWorkExprVO>();
      for (Element workExp : workExpELs) {
        CandidateBgWorkExprVO expVO = new CandidateBgWorkExprVO();
        String periodRaw = workExp.children().get(0).text();
        String startDate = periodRaw.split("--")[0].trim();

        expVO.setStartDate(CandidateDateUtil.formatDate("yyyy/MM","yyyy/MM/dd",startDate));
        String endDate = periodRaw.split("--")[1].trim();
        if (endDate.equalsIgnoreCase("now")) {
          expVO.setEndDate("NOW");
          expVO.setIsPresent(true);
        } else {
          expVO.setEndDate(CandidateDateUtil.formatDate("yyyy/MM","yyyy/MM/dd",endDate));
          expVO.setIsPresent(false);
        }

        // parse employer and job title
        String[] titleRaws = workExp.children().get(1).text()
            .split(FIELD_SEPARATOR);
        expVO.setEmployer(titleRaws[0].replaceAll(" ", " "));
        expVO.setJobTitle(titleRaws[titleRaws.length - 1].replaceAll(" ", " "));

        Element line3EL = workExp.children().get(2);
        // parse salary range
        String salaryRaw = this.getLastElement(line3EL.children()).text();
        String salaryRange = MappingUtil.matchSingle("\\d+[-\\d]+", salaryRaw);
        expVO.setSalary(salaryRange.split(DASH)[0]);
        expVO.setSalaryEnd(salaryRange.split(DASH)[1]);

        // parse description
        expVO.setDescription(workExp.children().get(3).text()
            .replaceAll("Job Description:", "").trim());

        workExpList.add(expVO);
      }
      candidateProfileVO.setWorkExprs(workExpList);
    }
    return candidateProfileVO;
  }

  @Override
  public CandidateProfileVO parseBackgroundEducation(
      CandidateProfileVO candidateProfileVO, Document content)
      throws ServiceApplicationException {
    Elements eduBgELs = content.getElementsByClass("education-background");
    if (eduBgELs.size() > 0) {
      List<CandidateBgEducationVO> eduList = new ArrayList<CandidateBgEducationVO>();
      for (Element eduBg : eduBgELs) {

        CandidateBgEducationVO edu = new CandidateBgEducationVO();

        // parse the begin date and end date
        String periodRaw = eduBg.children().get(0).text();
        String beginRaw = periodRaw.split(DASH + DASH)[0].trim();
        String endRaw = periodRaw.split(DASH + DASH)[1].trim();
        if (beginRaw.matches("[\\d\\/]+")) {
          edu.setStartDate(CandidateDateUtil.formatDate("yyyy/MM","yyyy/MM/dd",beginRaw));
        }
        if (endRaw.matches("[\\d\\/]+")) {
          edu.setEndDate(CandidateDateUtil.formatDate("yyyy/MM","yyyy/MM/dd",endRaw));
        }else if(endRaw.equalsIgnoreCase("now")){
          edu.setEndDate("NOW");
        }

        // parse the university and major
        String universityRaw = eduBg.children().get(1).text();
        String school = universityRaw.split(FIELD_SEPARATOR)[0].trim();
        String major = universityRaw.split(FIELD_SEPARATOR)[1].trim();
        String degree = universityRaw.split(FIELD_SEPARATOR)[2].trim();
        edu.setSchool(school);
        edu.setMajor(major);
        edu.setDegree(degree);

        eduList.add(edu);
      }
      candidateProfileVO.setEducation(eduList);

    }
    return candidateProfileVO;
  }

  @Override
  public CandidateProfileVO parseBackgroundLanguage(
      CandidateProfileVO candidateProfileVO, Document content)
      throws ServiceApplicationException {

    Elements langBgELs = content.getElementsByClass("language-skill");
    if (langBgELs.size() > 0) {
      List<CandidateBgLanguageVO> langList = new ArrayList<CandidateBgLanguageVO>();
      for (Element langBg : langBgELs) {

        CandidateBgLanguageVO lang = new CandidateBgLanguageVO();
        String langBgText = langBg.text().replace("：", COLON);
        if (langBgText.indexOf(COLON) > 0) {
          String left = langBgText.split(COLON)[0];
          String right = langBgText.split(COLON)[1];

          lang.setName(left.trim());

          /**
           * basic average proficient expert
           */
          if (right.indexOf("|") > 0) {
            String readWriteProf = right.split(FIELD_SEPARATOR)[0];
            lang.setReadingProf(readWriteProf.split(EMPTY_SPACE)[1]);
            lang.setWritingProf(readWriteProf.split(EMPTY_SPACE)[1]);

            String speakingProf = right.split(FIELD_SEPARATOR)[1];
            lang.setSpeakingProf(speakingProf.split(EMPTY_SPACE)[1]);

            langList.add(lang);
          }
        }
      }
      candidateProfileVO.setLanguages(langList);
    }
    return candidateProfileVO;
  }

  @Override
  public CandidateProfileVO parseBackgroundCertificate(
      CandidateProfileVO candidateProfileVO, Document content)
      throws ServiceApplicationException {

    Elements certBgELs = content.getElementsByClass("certificates");
    if (certBgELs.size() > 0) {
      List<CandidateBgCertificateVO> certList = new ArrayList<CandidateBgCertificateVO>();
      for (Element certBg : certBgELs) {
        CandidateBgCertificateVO cert = new CandidateBgCertificateVO();

        /**
         * yyyy/MM
         */
        String startDateRaw = certBg.child(0).text();
        String name = certBg.child(1).text();
        cert.setStartDate(startDateRaw);
        cert.setName(name);

        certList.add(cert);
      }
      candidateProfileVO.setCertificates(certList);
    }
    return candidateProfileVO;
  }

  private Element getLastElement(Elements els) {
    if (els.size() > 0) {
      return els.get(els.size() - 1);
    }
    return null;
  }
  
}
