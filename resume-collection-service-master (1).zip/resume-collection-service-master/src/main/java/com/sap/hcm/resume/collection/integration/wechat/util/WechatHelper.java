package com.sap.hcm.resume.collection.integration.wechat.util;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Formatter;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import net.sf.json.JSONObject;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.utils.HttpClientUtils;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.sap.hcm.resume.collection.integration.wechat.entity.AccessToken;
import com.sap.hcm.resume.collection.integration.wechat.entity.JsTicket;
import com.sap.hcm.resume.collection.integration.wechat.entity.OAuthAccessToken;
import com.sap.hcm.resume.collection.integration.wechat.entity.UserBascInfo;
import com.sap.hcm.resume.collection.util.HTTPConnection;

@Component
public class WechatHelper {

  /**
   * oAuth URL
   */
  public static final String OAUTH_LOGIN_URL = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=%APPID%&redirect_uri=%REDIRECT_URI%&response_type=code&scope=snsapi_login#wechat_redirect";

  public static final String OAUTH_ACCESS_TOKEN_URL = "https://api.weixin.qq.com/sns/oauth2/access_token?appid=%APPID%&secret=%SECRET%&code=%CODE%&grant_type=authorization_code";

  public static final String OAUTH_USERINFO_URL = "https://api.weixin.qq.com/sns/userinfo?access_token=$ACCESS_TOKEN$&openid=$OPENID$&lang=zh_CN";

  public static final String ACCESS_TOKEN_URL = "https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid=APPID&secret=APPSECRET";

  public static final String JSAPI_TICKET_URL = "https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token=ACCESS_TOKEN&type=jsapi";

  public static final String WECHAT_APP_ID = "wxa370bd0541e24eaa";

  public static final String WECHAT_APP_SERECT = "a7c8c0c7be80f520c429baf5595d47c6";

  public static final String JS_TICKET_WECHAT_APP_ID = "wx0180d45c2d4f455d";

  public static final String JS_TICKET_WECHAT_APP_SECRET = "b889a3d1bd3695e98f2e0e0d70512eee";

  // Authorized user basic information page APIS
  public static final String GET_CODE_URL = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=APPID&redirect_uri=REDIRECT_URI&response_type=code&scope=SCOPE&state=STATE#wechat_redirect";

  public static final String WECHAT_MENU_PATH = "WEB-INF/classes/config/wechat/menu.json";

  public static final String CREATE_MENU_URL = "https://api.weixin.qq.com/cgi-bin/menu/create?access_token=ACCESS_TOKEN";

  public static final String WECHAT_ACCOUNT_PATH = "WEB-INF/classes/config/wechat/account.json";

  @Autowired
  private HTTPConnection httpConnection;

  private static Logger logger = LoggerFactory.getLogger(WechatHelper.class);

  public JSONObject doPostStr(String url, String outStr) throws IOException {

    JSONObject jsonObject = null;
    CloseableHttpClient httpClient = null;
    try {
      httpClient = httpConnection.createHttpClient();

      HttpResponse httpResponse = httpConnection.loadAsHttpResponse(httpClient, url, "POST", null, outStr, null);
      String result = EntityUtils.toString(httpResponse.getEntity(), "UTF-8");
      jsonObject = JSONObject.fromObject(result);
    } catch (Exception e) {
      logger.error(e.getMessage());
    } finally {
      HttpClientUtils.closeQuietly(httpClient);
    }
    return jsonObject;
  }

  /**
   * get url
   * 
   * @param url
   * @return
   * @throws Exception
   */
  @SuppressWarnings("unchecked")
  public Map<String, Object> doGetStr(String url) {

    Map<String, Object> jsonObject = null;
    CloseableHttpClient httpClient = null;
    try {
      httpClient = httpConnection.createHttpClient();

      HttpResponse httpResponse = httpConnection.loadAsHttpResponse(httpClient, url, "GET", null, null, null);
      HttpEntity httpEntity = httpResponse.getEntity();
      if (httpEntity != null) {
        logger.error("request success");
        String result = EntityUtils.toString(httpEntity);
        ObjectMapper om = new ObjectMapper();
        jsonObject = om.readValue(result, Map.class);
      }
    } catch (Exception e) {
      logger.error(e.getMessage());
      // do nothing
    } finally {
      httpConnection.closeHttpClient(httpClient);
    }

    return jsonObject;
  }

  /**
   * get access_token
   * 
   * @return
   * @throws ClientProtocolException
   * @throws IOException
   */
  public AccessToken getAccessToken(String companyId, String appId, String appSecret) throws ClientProtocolException,
      IOException {

    AccessToken accessToken = AccessToken.AccessTokenHolder.getInstance(companyId);
    if (accessToken == null || accessToken.isExpired()) {
      AccessToken.AccessTokenHolder.removeToken(companyId);
      String url = ACCESS_TOKEN_URL.replace("APPID", appId).replace("APPSECRET", appSecret);
      Map<String, Object> jsonObject = doGetStr(url);
      if (jsonObject != null) {
        AccessToken.AccessTokenHolder.saveAccessToken((String) jsonObject.get("access_token"), companyId);
        accessToken = AccessToken.AccessTokenHolder.getInstance(companyId);
      }
    }
    return accessToken;
  }

  public String getApiTicket(String accessToken) throws ClientProtocolException, IOException {

    boolean isExpired = JsTicket.getInstance().isExpired();
    if (isExpired) {
      String url = JSAPI_TICKET_URL.replace("ACCESS_TOKEN", accessToken);

      Map<String, Object> jsonObject = doGetStr(url);
      if (jsonObject != null) {

        JsTicket.getInstance().saveLocalJsTicket((String) jsonObject.get("ticket"));
      }
    }

    return JsTicket.getInstance().getJs_ticket();
  }

  public OAuthAccessToken getOAuthAccessToken(String code) {
    OAuthAccessToken token = null;
    String acessTokenUrl = OAUTH_ACCESS_TOKEN_URL.replace("%APPID%", WECHAT_APP_ID)
        .replace("%SECRET%", WECHAT_APP_SERECT).replace("%CODE%", code);
    Map<String, Object> jsonObject = doGetStr(acessTokenUrl);
    if (jsonObject != null) {
      token = new OAuthAccessToken();
      token.setAccessToken((String) jsonObject.get("access_token"));
      token.setExpiresIn((Integer) jsonObject.get("expires_in"));
      token.setOpenId((String) jsonObject.get("openid"));
    }
    return token;
  }

  /**
   * get userinfo
   * 
   * @param fromUserName
   * @return
   */
  public UserBascInfo getUserBascInfo(String accessToken, String openId) {

    UserBascInfo userBasicInfo = new UserBascInfo();
    try {
      String userInfoUri = OAUTH_USERINFO_URL.replace("%ACCESS_TOKEN%", accessToken).replace("%OPENID%", openId);
      logger.error("before do get str: " + OAUTH_USERINFO_URL);
      Map<String, Object> jsonObject = doGetStr(userInfoUri);
      if (jsonObject != null) {
        userBasicInfo.setOpenid((String) jsonObject.get("openid"));
        userBasicInfo.setNickname((String) jsonObject.get("nickname"));
        userBasicInfo.setSex((String) jsonObject.get("sex"));
        userBasicInfo.setHeadimgurl((String) jsonObject.get("headimgurl"));
        userBasicInfo.setCity((String) jsonObject.get("city"));
        userBasicInfo.setProvince((String) jsonObject.get("province"));
        userBasicInfo.setCountry((String) jsonObject.get("country"));
        logger.error("receive object success : " + userBasicInfo.toString());
      }
    } catch (Exception e) {
      logger.error(e.getMessage());
    }
    return userBasicInfo;
  }

  public Map<String, String> sign(String jsapi_ticket, String url) {
    Map<String, String> ret = new HashMap<String, String>();
    String nonce_str = create_nonce_str();
    String timestamp = create_timestamp();
    String signString;
    String signature = "";

    signString = "jsapi_ticket=" + jsapi_ticket + "&noncestr=" + nonce_str + "&timestamp=" + timestamp + "&url=" + url;
    try {
      MessageDigest crypt = MessageDigest.getInstance("SHA-1");
      crypt.reset();
      crypt.update(signString.getBytes("UTF-8"));
      signature = byteToHex(crypt.digest());
    } catch (NoSuchAlgorithmException | UnsupportedEncodingException e) {
      logger.error(e.getMessage());
    }

    ret.put("url", url);
    ret.put("jsapi_ticket", jsapi_ticket);
    ret.put("nonceStr", nonce_str);
    ret.put("timestamp", timestamp);
    ret.put("signature", signature);

    return ret;
  }

  private static String byteToHex(final byte[] hash) {
    Formatter formatter = new Formatter();
    for (byte b : hash) {
      formatter.format("%02x", b);
    }
    String result = formatter.toString();
    formatter.close();
    return result;
  }

  private static String create_nonce_str() {
    return UUID.randomUUID().toString();
  }

  private static String create_timestamp() {
    return Long.toString(System.currentTimeMillis() / 1000);
  }

  public String createMenu(String token, String menuString) {
    String rsp = "";
    int result = 0;
    try {
      String url = CREATE_MENU_URL.replace("ACCESS_TOKEN", token);
      JSONObject jsonObject = doPostStr(url, menuString);
      if (jsonObject != null) {
        result = jsonObject.getInt("errcode");
      }
      if (result == 0) {
        rsp = "success";
      } else {
        String errorMsg = jsonObject.getString("errmsg");
        rsp = "error with code : " + result + " message: " + errorMsg;
        logger.error(rsp);
      }

    } catch (ParseException | IOException e) {
      rsp = "error with exception: " + e.getMessage();
      logger.error(e.getMessage());
    }
    return rsp;
  }
}
