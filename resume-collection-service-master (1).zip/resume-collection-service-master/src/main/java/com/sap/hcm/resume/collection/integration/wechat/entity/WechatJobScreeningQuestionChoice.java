package com.sap.hcm.resume.collection.integration.wechat.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "WECHAT_JOB_SCREENING_QUESTION_CHOICE")
public class WechatJobScreeningQuestionChoice {

  @Id
  @Column(name = "company_id")
  private String companyId;

  @Id
  @Column(name = "choice_locale")
  private String choiceLocale;

  @Id
  @Column(name = "option_id")
  private Long optionId;

  @Id
  @Column(name = "option_value")
  private double optionValue;

  @Column(name = "option_label")
  private String optionLabel;

  @Id
  @Column(name = "job_req_question_choice_key")
  private String jobReqQuestionChoiceKey;

  public void setOptionLabel(String optionLabel) {
    this.optionLabel = optionLabel;
  }

  /**
   * @return the optionLabel
   */
  public String getOptionLabel() {
    return optionLabel;
  }

  public String getCompanyId() {
    return companyId;
  }

  public void setCompanyId(String companyId) {
    this.companyId = companyId;
  }

  public String getChoiceLocale() {
    return choiceLocale;
  }

  public void setChoiceLocale(String choiceLocale) {
    this.choiceLocale = choiceLocale;
  }

  public Long getOptionId() {
    return optionId;
  }

  public void setOptionId(Long optionId) {
    this.optionId = optionId;
  }

  public double getOptionValue() {
    return optionValue;
  }

  public void setOptionValue(double optionValue) {
    this.optionValue = optionValue;
  }

  public String getJobReqQuestionChoiceKey() {
    return jobReqQuestionChoiceKey;
  }

  public void setJobReqQuestionChoiceKey(String jobReqQuestionChoiceKey) {
    this.jobReqQuestionChoiceKey = jobReqQuestionChoiceKey;
  }
}
