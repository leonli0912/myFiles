package com.sap.hcm.resume.collection.service;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceException;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.BDDMockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;

import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.context.TestContext;
import com.sap.hcm.resume.collection.context.WebAppContext;
import com.sap.hcm.resume.collection.entity.CandidateBackground;
import com.sap.hcm.resume.collection.entity.CandidateProfile;
import com.sap.hcm.resume.collection.entity.CandidateProfileExt;
import com.sap.hcm.resume.collection.entity.view.CandidateBgWorkExprVO;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;
import com.sap.hcm.resume.collection.entity.view.JobApplicationRequiredFieldVO;
import com.sap.hcm.resume.collection.entity.view.JobApplyMappingVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.bean.ApplyDataModelMappingItem;
import com.sap.hcm.resume.collection.util.CandidateProfileHelper;
import com.sap.hcm.resume.collection.xml.RequiredFieldXMLConverter;

@RunWith(PowerMockRunner.class)
@PowerMockRunnerDelegate(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { TestContext.class, WebAppContext.class })
@PrepareForTest(RequiredFieldXMLConverter.class)
public class CandidateProfileServiceTest {
  @Autowired
  private EntityManager entityManager;

  @Autowired
  private CandidateProfileService candidateProfileService;

  @Autowired
  private CandidateProfileHelper candidateProfileHelper;

  @Autowired
  private Params params;
  
  @Autowired
  private DataModelMappingService dataModelMappingService;

  @Before
  public void setUp() {
    reset(entityManager);
    candidateProfileService = spy(new CandidateProfileService());
    params.setCompanyId("sap");
    params.setWechatOpenId("openid");
    ReflectionTestUtils.setField(candidateProfileService, "entityManager", entityManager);
    ReflectionTestUtils.setField(candidateProfileService, "candidateProfileHelper", candidateProfileHelper);
    ReflectionTestUtils.setField(candidateProfileService, "params", params);
    ReflectionTestUtils.setField(candidateProfileService, "dataModelMappingService", dataModelMappingService);
  }

  @Test
  public void testFindCandidateProfileByPrimaryEmail() throws ServiceApplicationException {
    String email = "sap";
    CandidateProfile profile = new CandidateProfile();
    profile.setCandidateId(1234L);
    TypedQuery<CandidateProfile> candidateProfileQuery = mock(TypedQuery.class);
    when(
        entityManager.createQuery("select pf from CandidateProfile pf where pf.primaryEmail = :primaryEmail",
            CandidateProfile.class)).thenReturn(candidateProfileQuery);
    when(candidateProfileQuery.setParameter("primaryEmail", email)).thenReturn(candidateProfileQuery);
    when(candidateProfileQuery.getSingleResult()).thenReturn(profile);
    assertEquals(profile, candidateProfileService.findCandidateProfileByPrimaryEmail(email));
  }

  @Test
  public void testmodifyCandidateProfile() throws ServiceApplicationException, ParseException {
    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    candidateProfileVO.setCandidateId(5678L);

    CandidateProfileVO candidateProfileVOAfter = new CandidateProfileVO();
    candidateProfileVOAfter.setCandidateId(1234L);
    CandidateProfile profile = new CandidateProfile();
    profile.setCandidateId(1234L);
    when(entityManager.merge(any(CandidateProfile.class))).thenReturn(profile);
    assertEquals(candidateProfileVOAfter.getCandidateId(),
        candidateProfileService.modifyCandidateProfile(candidateProfileVO, 1234L).getCandidateId());
  }

  @Test
  public void testsaveCandidateProfile() throws ServiceApplicationException {
    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    candidateProfileVO.setCandidateId(5678L);
    candidateProfileVO.setResidence("上海");

    // exprVO.setStartDate(startDate);

    CandidateProfile profile = new CandidateProfile();
    profile.setCandidateId(5678L);
    when(entityManager.merge(any(CandidateProfile.class))).thenReturn(profile);
    assertEquals(candidateProfileVO.getCandidateId(), candidateProfileService.saveCandidateProfile(candidateProfileVO)
        .getCandidateId());
  }

  @Test
  public void testSaveCandidateProfileWithParseDateException() throws ServiceApplicationException, ParseException {
    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    candidateProfileVO.setExtProfile(null);
    candidateProfileVO.setCandidateId(5678L);
    candidateProfileVO.setResidence("上海");
    List<CandidateBgWorkExprVO> workExprs = new ArrayList<CandidateBgWorkExprVO>();
    CandidateBgWorkExprVO exprVO = new CandidateBgWorkExprVO();
    exprVO.setStartDate("2010/08/09");
    SimpleDateFormat sdf = mock(SimpleDateFormat.class);
    when(sdf.parse(exprVO.getStartDate())).thenThrow(new ParseException(null, 0));
    workExprs.add(exprVO);
    candidateProfileVO.setWorkExprs(workExprs);
    CandidateProfile profile = new CandidateProfile();
    profile.setCandidateId(5678L);
    when(entityManager.merge(any(CandidateProfile.class))).thenReturn(profile);
    assertEquals(candidateProfileVO.getCandidateId(), candidateProfileService.saveCandidateProfile(candidateProfileVO)
        .getCandidateId());
  }

  @Test
  public void testSaveRequiredFieldsFromCandidateProfileExtVO() throws ServiceApplicationException {
    CandidateProfileExt ext = new CandidateProfileExt();
    List<JobApplicationRequiredFieldVO> fieldList = new ArrayList<JobApplicationRequiredFieldVO>();
    Long candidateId = 123L;
    when(entityManager.merge(any(CandidateProfileExt.class))).thenReturn(ext);
    candidateProfileService.saveRequiredFieldsFromCandidateProfileExtVO(candidateId, fieldList);
  }

  @Test(expected = ServiceApplicationException.class)
  public void testSaveRequiredFieldsFromCandidateProfileExtVOWithException() throws ServiceApplicationException {
    CandidateProfileExt ext = new CandidateProfileExt();
    List<JobApplicationRequiredFieldVO> fieldList = new ArrayList<JobApplicationRequiredFieldVO>();
    Long candidateId = 123L;
    when(entityManager.merge(any(CandidateProfileExt.class))).thenThrow(new RuntimeException());
    candidateProfileService.saveRequiredFieldsFromCandidateProfileExtVO(candidateId, fieldList);
  }

  @Test
  public void testGetJobApplicationReqFieldsById() {
    Long candidateId = 123L;
    byte[] byteResult = "123".getBytes();
    JobApplyMappingVO jobApplyMappingVO = new JobApplyMappingVO();
    ApplyDataModelMappingItem item = new ApplyDataModelMappingItem();
    List<ApplyDataModelMappingItem> itemList = new ArrayList<ApplyDataModelMappingItem>();
    item.setSourceNameType("candidateInput");
    item.setFieldLabel("qwe");
    item.setPicklist("asd");
    item.setSfDmField("zxc");
    itemList.add(item);
    jobApplyMappingVO.setItemList(itemList);
    when(dataModelMappingService.getApplyDataModelMappingByCompanyId(params
        .getCompanyId())).thenReturn(jobApplyMappingVO);
    TypedQuery<CandidateProfileExt> candidateProfileExtQuery = mock(TypedQuery.class);
    when(
        entityManager
            .createQuery(
                "select pfe from CandidateProfileExt pfe where pfe.candidateId = :candidateId and pfe.paramName = 'requiredFields'",
                CandidateProfileExt.class)).thenReturn(candidateProfileExtQuery);
    CandidateProfileExt candidateProfileExt = new CandidateProfileExt();
    when(candidateProfileExtQuery.setParameter("candidateId", candidateId)).thenReturn(candidateProfileExtQuery);
    when(candidateProfileExtQuery.getSingleResult()).thenReturn(candidateProfileExt);
    candidateProfileExt.setBlobValue(byteResult);
    List<JobApplicationRequiredFieldVO> fieldVOListFromXML = new ArrayList<JobApplicationRequiredFieldVO>();
    JobApplicationRequiredFieldVO field = new JobApplicationRequiredFieldVO();
    field.setFieldName("zxc");
    field.setFieldValue("wer");
    fieldVOListFromXML.add(field);
    PowerMockito.mockStatic(RequiredFieldXMLConverter.class);
    BDDMockito.given(RequiredFieldXMLConverter.convertFromXMLToBgElement(any(String.class))).willReturn(fieldVOListFromXML);
    assertEquals("wer",candidateProfileService.getJobApplicationReqFieldsById(candidateId).get(0).getFieldValue());
  }

  @Test
  public void testDeleteCandidateProfileByIdSuccess() throws ServiceApplicationException {
    Long candidateId = 123L;
    Query delProfileQuery = mock(Query.class);
    when(entityManager.createQuery("delete from CandidateProfile p where p.candidateId = :candidateId")).thenReturn(
        delProfileQuery);
    when(delProfileQuery.setParameter("candidateId", candidateId)).thenReturn(delProfileQuery);
    when(delProfileQuery.executeUpdate()).thenReturn(1);

    Query delExtProfile = mock(Query.class);
    when(entityManager.createQuery("delete from CandidateProfileExt ext where ext.candidateId = :candidateId"))
        .thenReturn(delExtProfile);
    when(delExtProfile.setParameter("candidateId", candidateId)).thenReturn(delExtProfile);
    when(delExtProfile.executeUpdate()).thenReturn(1);

    Query delBackground = mock(Query.class);
    when(entityManager.createQuery("delete from CandidateBackground bg where bg.candidateId = :candidateId"))
        .thenReturn(delBackground);
    when(delBackground.setParameter("candidateId", candidateId)).thenReturn(delBackground);
    when(delBackground.executeUpdate()).thenReturn(1);
    assertEquals(1, candidateProfileService.deleteCandidateProfileById(candidateId));
  }

  @Test
  public void testDeleteCandidateProfileByIdFailWithException() throws ServiceApplicationException {
    Long candidateId = 123L;
    Query delProfileQuery = mock(Query.class);
    when(entityManager.createQuery("delete from CandidateProfile p where p.candidateId = :candidateId")).thenReturn(
        delProfileQuery);
    when(delProfileQuery.setParameter("candidateId", candidateId)).thenReturn(delProfileQuery);
    when(delProfileQuery.executeUpdate()).thenThrow(new PersistenceException());

    Query delExtProfile = mock(Query.class);
    when(entityManager.createQuery("delete from CandidateProfileExt ext where ext.candidateId = :candidateId"))
        .thenReturn(delExtProfile);
    when(delExtProfile.setParameter("candidateId", candidateId)).thenReturn(delExtProfile);
    when(delExtProfile.executeUpdate()).thenReturn(1);

    Query delBackground = mock(Query.class);
    when(entityManager.createQuery("delete from CandidateBackground bg where bg.candidateId = :candidateId"))
        .thenReturn(delBackground);
    when(delBackground.setParameter("candidateId", candidateId)).thenReturn(delBackground);
    when(delBackground.executeUpdate()).thenReturn(1);
    assertEquals(-1, candidateProfileService.deleteCandidateProfileById(candidateId));
  }

  @Test
  public void testGetCandidateProfileById() throws ServiceApplicationException {
    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    Long candidateId = 123L;
    candidateProfileVO.setCandidateId(candidateId);
    CandidateProfile profile = new CandidateProfile();
    profile.setCandidateId(candidateId);
    when(entityManager.find(CandidateProfile.class, candidateId)).thenReturn(profile);

    TypedQuery<CandidateProfileExt> queryProfileExt = mock(TypedQuery.class);
    when(
        entityManager.createQuery("select ext from CandidateProfileExt ext where ext.candidateId = :candidateId",
            CandidateProfileExt.class)).thenReturn(queryProfileExt);
    queryProfileExt.setParameter("candidateId", candidateId);
    List<CandidateProfileExt> extList = new ArrayList<CandidateProfileExt>();
    when(queryProfileExt.getResultList()).thenReturn(extList);

    TypedQuery<CandidateBackground> queryBg = mock(TypedQuery.class);
    when(
        entityManager.createQuery("select bg from CandidateBackground bg where bg.candidateId = :candidateId",
            CandidateBackground.class)).thenReturn(queryBg);
    queryBg.setParameter("candidateId", candidateId);
    List<CandidateBackground> bgList = new ArrayList<CandidateBackground>();
    when(queryBg.getResultList()).thenReturn(bgList);
    when(
        candidateProfileHelper.convertFromProfileDB2UI(any(CandidateProfile.class), any(ArrayList.class),
            any(ArrayList.class))).thenReturn(candidateProfileVO);
    assertEquals(candidateId, candidateProfileService.getCandidateProfileById(candidateId).getCandidateId());
  }
  
  @Test
  public void testDeleteOverdueCandidate(){
    TypedQuery<CandidateProfile> query = mock(TypedQuery.class);
    List<CandidateProfile> list = new ArrayList<CandidateProfile>();
    CandidateProfile profile = new CandidateProfile();
    profile.setCandidateId(001L);
    list.add(profile);
    String sel = "select pf from CandidateProfile pf where pf.lastModify < :lastModify";
    when(entityManager.createQuery(sel,CandidateProfile.class)).thenReturn(query);
    when(query.getResultList()).thenReturn(list);
    Long candidateId = 123L;
    Query delProfileQuery = mock(Query.class);
    when(entityManager.createQuery("delete from CandidateProfile p where p.candidateId = :candidateId")).thenReturn(
        delProfileQuery);
    when(delProfileQuery.setParameter("candidateId", candidateId)).thenReturn(delProfileQuery);
    when(delProfileQuery.executeUpdate()).thenReturn(1);

    Query delExtProfile = mock(Query.class);
    when(entityManager.createQuery("delete from CandidateProfileExt ext where ext.candidateId = :candidateId"))
        .thenReturn(delExtProfile);
    when(delExtProfile.setParameter("candidateId", candidateId)).thenReturn(delExtProfile);
    when(delExtProfile.executeUpdate()).thenReturn(1);

    Query delBackground = mock(Query.class);
    when(entityManager.createQuery("delete from CandidateBackground bg where bg.candidateId = :candidateId"))
        .thenReturn(delBackground);
    when(delBackground.setParameter("candidateId", candidateId)).thenReturn(delBackground);
    when(delBackground.executeUpdate()).thenReturn(1);
    assertEquals(1,candidateProfileService.deleteOverdueCandidate());
  }
}
