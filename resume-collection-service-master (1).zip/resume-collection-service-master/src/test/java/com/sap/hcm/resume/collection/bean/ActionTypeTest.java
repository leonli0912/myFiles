package com.sap.hcm.resume.collection.bean;

import org.junit.Assert;
import org.junit.Test;

public class ActionTypeTest {
  
  @Test
  public void testFromActionTypeName(){
    ActionType type = ActionType.fromActionName("Add");
    Assert.assertEquals(type.getActionName(), "Add");
  }
  
  
  @Test
  public void testInvalidActionType(){
    ActionType type = ActionType.fromActionName("invalid");
    Assert.assertNull(type);
  }
}
