package com.sap.hcm.resume.collection.integration.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.PersistenceException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.olingo.odata2.api.ep.EntityProviderException;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.bean.SimpleJsonResponse;
import com.sap.hcm.resume.collection.context.TestContext;
import com.sap.hcm.resume.collection.context.WebAppContext;
import com.sap.hcm.resume.collection.entity.DataModelMapping;
import com.sap.hcm.resume.collection.entity.view.JobApplyMappingVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.hcp.HCPUserProvider;
import com.sap.hcm.resume.collection.integration.sf.bean.SFPicklistItem;
import com.sap.hcm.resume.collection.integration.sf.service.SFPicklistService;
import com.sap.hcm.resume.collection.service.DataModelMappingService;
import com.sap.hcm.resume.collection.util.CandidateFileUtil;
import com.sap.hcm.resume.collection.util.ChangeLogUtil;
import com.sap.hcm.resume.collection.util.MockHCPUser;
import com.sap.security.um.user.User;

@RunWith(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { TestContext.class, WebAppContext.class })
public class JobApplicationMappingControllerTest {

  private JobApplicationMappingController controller;

  private DataModelMapping mapping;

  private DataModelMappingService dataModelMappingService;

  @Autowired
  protected HCPUserProvider hcpUserProvider;
  
  @Autowired
  private SFPicklistService sfPicklistService;
  
  @Autowired
  private WebApplicationContext webApplicationContext;
  
  @Autowired
  private ChangeLogUtil changeLogUtil;
  
  @Autowired
  private Params params;

  @Before
  public void setUp() {
    controller = spy(new JobApplicationMappingController());
    dataModelMappingService = Mockito.mock(DataModelMappingService.class);
    ReflectionTestUtils.setField(controller, "dataModelMappingService", dataModelMappingService);
    ReflectionTestUtils.setField(controller, "sfPicklistService", sfPicklistService);
    ReflectionTestUtils.setField(controller, "hcpUserProvider", hcpUserProvider);
    ReflectionTestUtils.setField(controller, "changeLogUtil", changeLogUtil);
    ReflectionTestUtils.setField(controller, "params", params);
    buildDataModelMapping();
  }

  private void buildDataModelMapping() {
    mapping = new DataModelMapping();
    mapping.setCompanyId("sap");
    mapping.setCreateBy("Ryan");
    mapping.setMappingContent(null);
    mapping.setMappingId((long) 123);
    mapping.setMappingName("mapping");
    mapping.setMappingType("candidate_profile_mapping");
    mapping.setTargetSystem("SF");
    mapping
        .setMappingContent(new String(
            "<data-model-mapping><languages><mapping-item><from>readingProf</from><to>readingProf</to><label>LB_READING_PROF</label><required>true</required><picklist>fluency</picklist>"
                + "</mapping-item></languages><picklist-option-mapping><picklist id='fluency'><option source='1' target='一般'/></picklist></picklist-option-mapping>"
                + "<profile><mapping-item><from>firstName</from><to>firstName</to><label>LB_FIRST_NAME</label><required>true</required></mapping-item></profile>"
                + "<workExprs><mapping-item><from>startDate</from><to>startDate</to><label>LB_STARTDATE</label><required>false</required></mapping-item></workExprs>"
                + "<certificates><mapping-item><from>name</from><to>name</to><label>LB_NAME</label><required>false</required></mapping-item></certificates>"
                + "<families><mapping-item><from>name</from><to>name</to><label>LB_NAME</label><required>false</required></mapping-item></families>"
                + "<education><mapping-item><from>major</from><to>major</to><label>LB_MAJOR</label><required>false</required></mapping-item></education>"
                + "</data-model-mapping>").getBytes());
  }

  @Test
  public void testSaveJobApplicationDataModelMapping() throws ServiceApplicationException, JsonProcessingException {
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(0);
    rsp.setMessage("success");

    HttpServletRequest mockRequest = mock(HttpServletRequest.class);
    JobApplyMappingVO mappingResult = mock(JobApplyMappingVO.class);
    User loginUser = new MockHCPUser();
    Mockito.when(hcpUserProvider.getLoginUser(mockRequest)).thenReturn(loginUser);
    Mockito.when(mockRequest.getParameter("companyId")).thenReturn("sap");
    Mockito.doNothing().when(mappingResult).setCreateBy("test");
    
    DataModelMapping dmMapping = new DataModelMapping();
    dmMapping.setMappingId(1L);
    Mockito.when(dataModelMappingService.saveApplyDataModelMapping(mappingResult, "sap")).thenReturn(dmMapping);

    SimpleJsonResponse result = controller.saveJobApplicationDataModelMapping(mockRequest, mappingResult);
    assertEquals(new ObjectMapper().writeValueAsString(rsp), new ObjectMapper().writeValueAsString(result));
  }

  @SuppressWarnings("unchecked")
  @Test
  public void testSaveJobApplicationDataModelMapping_ThrowException() throws ServiceApplicationException,
      JsonProcessingException {
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(-1);
    rsp.setMessage("save data model failed");

    HttpServletRequest mockRequest = mock(HttpServletRequest.class);
    Mockito.when(hcpUserProvider.getLoginUser(mockRequest)).thenReturn(null);
    Mockito.when(mockRequest.getParameter("companyId")).thenReturn("sap");
    JobApplyMappingVO mappingResult = mock(JobApplyMappingVO.class);
    Mockito.when(dataModelMappingService.saveApplyDataModelMapping(mappingResult, "sap")).thenThrow(
        PersistenceException.class);

    SimpleJsonResponse result = controller.saveJobApplicationDataModelMapping(mockRequest, mappingResult);
    assertEquals(new ObjectMapper().writeValueAsString(rsp), new ObjectMapper().writeValueAsString(result));
  }

  @Test
  public void testLoadJobApplicationDataModelMapping() throws ServiceApplicationException {
    HttpServletRequest mockRequest = mock(HttpServletRequest.class);
    Mockito.when(mockRequest.getParameter("companyId")).thenReturn("sap");
    Mockito.when(dataModelMappingService.getApplyDataModelMappingByCompanyId("sap")).thenReturn(null);

    JobApplyMappingVO result = controller.loadJobApplicationDataModelMapping(mockRequest);
    assertEquals(null, result);
  }

  @Test
  public void testLoadPicklistOptions_Success() throws ServiceApplicationException, EntityProviderException,
      IOException {
    HttpServletRequest mockRequest = mock(HttpServletRequest.class);
    Mockito.when(sfPicklistService.loadPickListOption("position")).thenReturn(
        new ArrayList<SFPicklistItem>());

    List<SFPicklistItem> result = controller.loadPicklistOptions(mockRequest, "position", "en");
    assertEquals(0, result.size());
  }

  @Test
  public void testGetPicklistName_Success() throws EntityProviderException, MalformedURLException,
      ServiceApplicationException, IOException {
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(0);
    rsp.setMessage("position");
    
    Mockito.when(sfPicklistService.getPicklistName("prop", "entityTypeName")).thenReturn("position");

    HttpServletRequest mockRequest = mock(HttpServletRequest.class);
    SimpleJsonResponse result = controller.getPicklistName(mockRequest, "prop", "entityTypeName");
    assertEquals(new ObjectMapper().writeValueAsString(rsp), new ObjectMapper().writeValueAsString(result));
  }

  @Test
  public void testExportMappingById_Success() throws ServiceApplicationException {
    HttpServletResponse response = mock(HttpServletResponse.class);
    Mockito.when(dataModelMappingService.getApplyDataModelMappingByMappingId((long) 123)).thenReturn(mapping);

    ResponseEntity<byte[]> result = controller.exportMappingById((long) 123, response);
    assertEquals(HttpStatus.OK, result.getStatusCode());
  }

  @Test(expected = ServiceApplicationException.class)
  public void testExportMappingById_EmptyContent() throws ServiceApplicationException {
    HttpServletResponse response = mock(HttpServletResponse.class);
    mapping.setMappingContent(null);
    Mockito.when(dataModelMappingService.getApplyDataModelMappingByMappingId((long) 123)).thenReturn(mapping);

    controller.exportMappingById((long) 123, response);
  }

  @Test
  public void testImportMapping_Success() throws Exception {
    ClassPathResource resource = new ClassPathResource("/mapping/job_apply_model_mapping.xml");
    InputStream is = null;
    try {
      is = resource.getInputStream();
      String charsetName = CandidateFileUtil.getCharsetName(IOUtils.toByteArray(is));
      String fileContent = IOUtils.toString(is, charsetName);

      MockMvc mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
      ResultActions result = mockMvc.perform(MockMvcRequestBuilders.fileUpload("/appl/import")
          .content(this.createMultipartContent("mapping", "application/data", fileContent))
          .contentType("multipart/form-data; boundary=----WebKitFormBoundary8HC1OQgjqvtgc5tk"));
      result.andExpect(MockMvcResultMatchers.status().is(200));
      result.andReturn().getResponse().getContentAsString();
    } catch (IOException e) {
    } finally {
      IOUtils.closeQuietly(is);
    }
  }

  @Test
  public void testImportMapping_EmptyContent() throws Exception {
    MockMvc mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
    ResultActions result = mockMvc.perform(MockMvcRequestBuilders.fileUpload("/appl/import").contentType(
        "multipart/form-data; boundary=----WebKitFormBoundary8HC1OQgjqvtgc5tk"));
    result.andExpect(MockMvcResultMatchers.status().is(200));
    String content = result.andReturn().getResponse().getContentAsString();
    Assert.assertEquals("", content);
  }

  @Test
  public void testUploadSFDataModel_Success() throws Exception {
    ClassPathResource resource = new ClassPathResource("/mapping/job_apply_model_mapping.xml");
    InputStream is = null;
    try {
      is = resource.getInputStream();
      String charsetName = CandidateFileUtil.getCharsetName(IOUtils.toByteArray(is));
      String fileContent = IOUtils.toString(is, charsetName);

      MockMvc mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
      ResultActions result = mockMvc.perform(MockMvcRequestBuilders.fileUpload("/appl/uploadSFDataModel")
          .content(this.createMultipartContent("mapping", "application/data", fileContent))
          .contentType("multipart/form-data; boundary=----WebKitFormBoundary8HC1OQgjqvtgc5tk"));
      result.andExpect(MockMvcResultMatchers.status().is(200));
      result.andReturn().getResponse().getContentAsString();
    } catch (IOException e) {
    } finally {
      IOUtils.closeQuietly(is);
    }
  }

  @Test
  public void testUploadSFDataModel_EmptyContent() throws Exception {
    MockMvc mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext).build();
    ResultActions result = mockMvc.perform(MockMvcRequestBuilders.fileUpload("/appl/uploadSFDataModel").contentType(
        "multipart/form-data; boundary=----WebKitFormBoundary8HC1OQgjqvtgc5tk"));
    result.andExpect(MockMvcResultMatchers.status().is(200));
    String content = result.andReturn().getResponse().getContentAsString();
    Assert.assertEquals("[]", content);
  }

  private byte[] createMultipartContent(String fileName, String contentType, String fileContent) {
    String endline = "\r\n";
    String bondary = "----WebKitFormBoundary8HC1OQgjqvtgc5tk";
    String textFile = this.encodeTextFile(bondary, "\r\n", "file", fileName, contentType, fileContent);
    StringBuilder content = new StringBuilder(textFile.toString());
    content.append(endline);
    content.append(endline);
    content.append(endline);
    content.append("--");
    content.append(bondary);
    content.append("--");
    content.append(endline);
    return content.toString().getBytes();
  }

  private String encodeTextFile(String bondary, String endline, String name, String filename, String contentType,
      String content) {

    final StringBuilder sb = new StringBuilder();
    sb.append(endline);
    sb.append("--");
    sb.append(bondary);
    sb.append(endline);
    sb.append("Content-Disposition: form-data; name=\"");
    sb.append(name);
    sb.append("\"; filename=\"");
    sb.append(filename);
    sb.append("\"");
    sb.append(endline);
    sb.append("Content-Type: ");
    sb.append(contentType);
    sb.append(endline);
    sb.append(endline);
    sb.append(content);
    return sb.toString();
  }
}
