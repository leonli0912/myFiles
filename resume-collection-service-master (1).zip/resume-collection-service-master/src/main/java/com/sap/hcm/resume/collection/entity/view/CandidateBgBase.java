package com.sap.hcm.resume.collection.entity.view;

/**
 * candidate background base interface
 * @author i065831
 *
 */
public interface CandidateBgBase {

}
