package com.sap.hcm.resume.collection.hcp;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;

import javax.security.auth.login.LoginContext;
import javax.security.auth.login.LoginException;
import javax.servlet.http.HttpServletRequest;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.util.ReflectionTestUtils;

import com.sap.hcm.resume.collection.util.MockHCPUser;
import com.sap.security.auth.login.LoginContextFactory;
import com.sap.security.um.user.PersistenceException;
import com.sap.security.um.user.User;
import com.sap.security.um.user.UserProvider;

import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;

@RunWith(PowerMockRunner.class)
@PrepareForTest({HCPUserProvider.class ,LoginContextFactory.class})
public class HCPUserProviderTest {
	
	private HCPUserProvider provider;
	private UserProvider userProvider;
	
	@Before
	public void setUp(){
		provider = PowerMockito.spy(new HCPUserProvider());
		userProvider = Mockito.mock(UserProvider.class);
		ReflectionTestUtils.setField(provider, "userProvider", userProvider);
	}
	
	@Test
	public void testGetLoginUser_UserStoredInSession(){
		HttpServletRequest mockRequest = mock(HttpServletRequest.class);
		MockHttpSession mockSession = new MockHttpSession();
		User loginUser = new MockHCPUser();
		mockSession.putValue(HCPUserProvider.LOGIN_USER, loginUser);
		Mockito.when(mockRequest.getSession()).thenReturn(mockSession);
		
		User user = provider.getLoginUser(mockRequest);
		assertEquals(user.getName(), loginUser.getName());
	}
	
	@Test
	public void testGetLoginUser_NoUserStoredInSession() throws PersistenceException{
		HttpServletRequest mockRequest = mock(HttpServletRequest.class);
		User loginUser = new MockHCPUser();
		Mockito.when(mockRequest.getUserPrincipal()).thenReturn(loginUser);
		MockHttpSession mockSession = new MockHttpSession();
		mockSession.putValue(HCPUserProvider.LOGIN_USER, null);
		Mockito.when(mockRequest.getSession()).thenReturn(mockSession);
		Mockito.when(userProvider.getUser("test")).thenReturn(loginUser);
		
		User user = provider.getLoginUser(mockRequest);
		assertEquals(user.getName(), loginUser.getName());
	}
	
	@Test
	public void testGetLoginUser_ThrowException() throws PersistenceException{
		HttpServletRequest mockRequest = mock(HttpServletRequest.class);
		User loginUser = new MockHCPUser();
		MockHttpSession mockSession = new MockHttpSession();
		mockSession.putValue(HCPUserProvider.LOGIN_USER, null);
		Mockito.when(mockRequest.getSession()).thenReturn(mockSession);
		Mockito.when(mockRequest.getUserPrincipal()).thenReturn(loginUser);
		Mockito.when(userProvider.getUser("test")).thenThrow(new PersistenceException("failed to get login user from HCP"));
		
		User user = provider.getLoginUser(mockRequest);
		assertEquals(user, null);
	}
	
	@Test
	public void testGetLoginUser_UserPRrincipleNull() throws PersistenceException{
		HttpServletRequest mockRequest = mock(HttpServletRequest.class);
		MockHttpSession mockSession = new MockHttpSession();
		mockSession.putValue(HCPUserProvider.LOGIN_USER, null);
		Mockito.when(mockRequest.getSession()).thenReturn(mockSession);
		Mockito.when(mockRequest.getUserPrincipal()).thenReturn(null);
		
		User user = provider.getLoginUser(mockRequest);
		assertEquals(user, null);
	}
	
	@Test
	public void testLogout() throws LoginException{
		HttpServletRequest mockRequest = mock(HttpServletRequest.class);
		User loginUser = new MockHCPUser();
		MockHttpSession mockSession = new MockHttpSession();
		mockSession.putValue(HCPUserProvider.LOGIN_USER, loginUser);
		Mockito.when(mockRequest.getSession()).thenReturn(mockSession);
		Mockito.when(mockRequest.getRemoteUser()).thenReturn(loginUser.getName());
		PowerMockito.mockStatic(LoginContextFactory.class);
		LoginContext loginContext = mock(LoginContext.class);
		Mockito.when(LoginContextFactory.createLoginContext()).thenReturn(loginContext);
		Mockito.doNothing().when(loginContext).logout();
		
		boolean result = HCPUserProvider.logout(mockRequest);
		assertEquals(true, result);
	}
	
	@SuppressWarnings("unchecked")
	@Test
	public void testLogout_ThrowException() throws LoginException{
		HttpServletRequest mockRequest = mock(HttpServletRequest.class);
		User loginUser = new MockHCPUser();
		MockHttpSession mockSession = new MockHttpSession();
		mockSession.putValue(HCPUserProvider.LOGIN_USER, loginUser);
		Mockito.when(mockRequest.getSession()).thenReturn(mockSession);
		Mockito.when(mockRequest.getRemoteUser()).thenReturn(loginUser.getName());
		PowerMockito.mockStatic(LoginContextFactory.class);
		Mockito.when(LoginContextFactory.createLoginContext()).thenThrow(LoginException.class);
		
		boolean result = HCPUserProvider.logout(mockRequest);
		assertEquals(false, result);
	}
	
}
