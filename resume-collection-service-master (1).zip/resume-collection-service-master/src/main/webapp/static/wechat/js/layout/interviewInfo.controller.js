sap.ui.controller("static.wechat.js.layout.interviewInfo", {

	onButtonPress : function() {
		var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		oRouter.navTo("personalCenter");
	},

	onStartInterview : function() {
		
		
//		var ifr = document.createElement('iframe');
////		ifr.src = 'com.baidu.tieba://';
//		ifr.src = 'gruveo://';
//		ifr.style.display = 'none';
//		document.body.appendChild(ifr);
//		window.setTimeout(function(){  
//            document.body.removeChild(ifr);  
//            //window.location.href='https://itunes.apple.com/cn/app/id477927812';
//    		window.location.href='https://itunes.apple.com/cn/app/id911803832';
//        },3000) 
		
		window.location.href = 'gruveo://';
		window.setTimeout(function(){
			window.location.href='https://itunes.apple.com/cn/app/id911803832';
		 },3000)
        
	},
	/**
	 * Called when a controller is instantiated and its View controls (if
	 * available) are already created. Can be used to modify the View before it
	 * is displayed, to bind event handlers and do other one-time
	 * initialization.
	 * 
	 * @memberOf resume-collection-service.interviewInfo
	 */
	onInit : function() {
		
		if (this.isWechatBrowser()){
			var cssText = "#weixin-tip{position: fixed; left:0; top:0; background: rgba(0,0,0,0.8); filter:alpha(opacity=80); width: 100%; height:100%; z-index: 100;} #weixin-tip img{margin-top: 15%;}";
			this.loadHtml();
			this.loadStyleText(cssText);
		}
		
		var meta = document.createElement('meta');
		meta.name = "apple-itunes-app";
		meta.content = "app-id=911803832";
		document.head.appendChild(meta);
		
		var myDate = new Date();
		var formatDate = myDate.getFullYear() + "-" + (myDate.getMonth()+1) + "-" + myDate.getDate() + " " + myDate.getHours() + ":" + myDate.getMinutes();
		
		
		this._router = sap.ui.core.UIComponent.getRouterFor(this);
		var that = this;
		this._router.getRoute("interviewInfo").attachPatternMatched(function(oEvent){
			var query = oEvent.getParameter("arguments")['?query'];
			var oFilter =[] ;
			if(query && query.interviewId) {
				  oFilter.push(new sap.ui.model.Filter({ path: "id", operator: sap.ui.model.FilterOperator.EQ, value1: query.interviewId}));
			} 
			
			var listModel = new sap.ui.model.json.JSONModel(
			"static/wechat/js/json/interview_info.json");
			that.getView().setModel(listModel);
			var that1=that;
			listModel.attachRequestCompleted(function(oEvent) {
				var oData = listModel.getData();
				oData.interviewInfo[0].interview_time=formatDate;
				listModel.setData(oData);
				var oBinding = that1.getView().byId("interviewList").getBinding("items");
				oBinding.filter(oFilter);
			})
			
		});
		 
	},

	isWechatBrowser : function(){
		var ua = navigator.userAgent.toLowerCase();

	    if (ua.match(/MicroMessenger/i) == "micromessenger") {

	        return true;

	    } else {

	        return false;

	    }
	},
	
	loadHtml : function(){
		var div = document.createElement('div');
		div.id = 'weixin-tip';
		//div.innerHTML = '<p><img src="static/img/open_en.PNG" alt="请选择在safari中打开!"/></p>';
		var imgElement = document.createElement("img");
		imgElement.setAttribute("src", "static/img/open_en.PNG");
		imgElement.setAttribute("alt", "请选择在safari中打开!");
		div.appendChild(imgElement);
		document.body.appendChild(div);
	},
	
	loadStyleText : function(cssText){
		var style = document.createElement('style');
        style.rel = 'stylesheet';
        style.type = 'text/css';
        try {
            style.appendChild(document.createTextNode(cssText));
        } catch (e) {
            style.styleSheet.cssText = cssText; //ie9以下
        }
        var head=document.getElementsByTagName("head")[0]; //head标签之间加上style样式
        head.appendChild(style);
	},
	/**
	 * Similar to onAfterRendering, but this hook is invoked before the
	 * controller's View is re-rendered (NOT before the first rendering!
	 * onInit() is used for that one!).
	 * 
	 * @memberOf resume-collection-service.interviewInfo
	 */
	// onBeforeRendering: function() {
	//
	// },
	/**
	 * Called when the View has been rendered (so its HTML is part of the
	 * document). Post-rendering manipulations of the HTML could be done here.
	 * This hook is the same one that SAPUI5 controls get after being rendered.
	 * 
	 * @memberOf resume-collection-service.interviewInfo
	 */
	onAfterRendering : function() {
	},
/**
 * Called when the Controller is destroyed. Use this one to free resources and
 * finalize activities.
 * 
 * @memberOf resume-collection-service.interviewInfo
 */
// onExit: function() {
//
// }
});