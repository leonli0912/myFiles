package com.sap.hcm.resume.collection.integration.wechat.bean;

import java.io.Serializable;
import java.util.List;

public class JobDynSearchBean implements Serializable{
    
    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 1817946202528328152L;

    private String companyId;
    
    /**
     * filter value in the search input
     */
    private String inputFilterValue;
    
    private int skip = 0;
    
    private int top = 5;
    
    /**
     * order by
     */
    private String orderBy = "";
    
    public List<JobDynSearchBeanItem> items;

    /**
     * @return the companyId
     */
    public String getCompanyId() {
        return companyId;
    }

    /**
     * @param companyId the companyId to set
     */
    public void setCompanyId(String companyId) {
        this.companyId = companyId;
    }

    /**
     * @return the inputFilterValue
     */
    public String getInputFilterValue() {
        return inputFilterValue;
    }

    /**
     * @param inputFilterValue the inputFilterValue to set
     */
    public void setInputFilterValue(String inputFilterValue) {
        this.inputFilterValue = inputFilterValue;
    }

    /**
     * @return the skip
     */
    public int getSkip() {
        return skip;
    }

    /**
     * @param skip the skip to set
     */
    public void setSkip(int skip) {
        this.skip = skip;
    }

    /**
     * @return the top
     */
    public int getTop() {
        return top;
    }

    /**
     * @param top the top to set
     */
    public void setTop(int top) {
        this.top = top;
    }

    /**
     * @return the orderBy
     */
    public String getOrderBy() {
        return orderBy;
    }

    /**
     * @param orderBy the orderBy to set
     */
    public void setOrderBy(String orderBy) {
        this.orderBy = orderBy;
    }

    /**
     * @return the items
     */
    public List<JobDynSearchBeanItem> getItems() {
        return items;
    }

    /**
     * @param items the items to set
     */
    public void setItems(List<JobDynSearchBeanItem> items) {
        this.items = items;
    }
    
    
}
