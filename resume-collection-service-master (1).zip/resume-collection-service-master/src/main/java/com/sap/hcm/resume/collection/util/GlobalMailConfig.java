package com.sap.hcm.resume.collection.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.Environment;

/**
 * Global Mail Configuration
 * @author I073999
 *
 */
@Configuration
@PropertySource("classpath:properties/mail.properties")
public class GlobalMailConfig {
	public GlobalMailConfig(){
		
	}
	
	@Autowired
	private Environment env;
	
	@Bean
	public static PropertySourcesPlaceholderConfigurer propertyConfigInDev() {
        return new PropertySourcesPlaceholderConfigurer();
    }
	
	/**
	 * @return the host
	 */
	public String getSMTPHost(){
		return env.getProperty("mail.smtp.host");
	}
	
	/**
	 * @return the port
	 */
	public String getSMTPPort(){
		return env.getProperty("mail.smtp.port");
	}
	
	
	/**
	 * @return the sender's username
	 */
	public String getSMTPUser(){
		return env.getProperty("mail.smtp.user");
	}
	
	/**
	 * @return the sender's password
	 */
	public String getSMTPPwd(){
		return env.getProperty("mail.smtp.pwd");
	}
	
	/**
	 * @return the subject
	 */
	public String getSubject(){
		return env.getProperty("mail.subject");
	}
}
