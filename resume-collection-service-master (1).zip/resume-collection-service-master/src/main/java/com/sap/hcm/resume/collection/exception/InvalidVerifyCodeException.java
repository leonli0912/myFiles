package com.sap.hcm.resume.collection.exception;

/**
 * 
 * @author i065831
 *
 */
public class InvalidVerifyCodeException extends ServiceApplicationException {
  
  public static String ERROR_MESSAGE_KEY = "ERROR_MSG_VERIFYCODE_NOT_CORRECT";
  
  /**
   * serial version 
   */
  private static final long serialVersionUID = 1L;

  public InvalidVerifyCodeException() {
    super(-1002, ERROR_MESSAGE_KEY);
  }
  
}
