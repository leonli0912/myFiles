package com.sap.hcm.resume.collection.integration.sf.cdm;

import org.junit.Assert;
import org.junit.Test;

import com.sap.hcm.resume.collection.integration.sf.bean.cdm.SFCDMFieldDefinition;

public class SFCDMFieldDefinitionTest {
  
  @Test
  public void testGetterSetter(){
    SFCDMFieldDefinition def = new SFCDMFieldDefinition();
    def.setAnonymize(true);
    def.setCustom(true);
    def.setDefaultValue("default");
    def.setEnumValue(null);
    def.setForwardIntact(true);
    def.setId("id");
    def.setPicklistId("picklist");
    def.setReadOnly(true);
    def.setRequired(true);
    def.setType("type");
    
    Assert.assertEquals(true, def.isAnonymize());
    Assert.assertEquals(true, def.isCustom());
    Assert.assertEquals("default", def.getDefaultValue());
    Assert.assertEquals(null, def.getEnumValue());
    Assert.assertEquals(true, def.isForwardIntact());
    Assert.assertEquals("id", def.getId());
    Assert.assertEquals("picklist", def.getPicklistId());
    Assert.assertEquals(true, def.isReadOnly());
    Assert.assertEquals(true, def.isRequired());
    Assert.assertEquals("type", def.getType());
  }
}
