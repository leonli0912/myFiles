package com.sap.hcm.resume.collection.entity.view;

public class DummyClass {

}
