package com.sap.hcm.resume.collection.util;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

import org.springframework.util.StringUtils;

import com.sap.hcm.resume.collection.annotation.RequisitionAttribute;
import com.sap.hcm.resume.collection.bean.JobRequisitionAttribute;
import com.sap.hcm.resume.collection.bean.JobRequisitionModel;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJob;

/**
 * data model builder to build job requisition
 * @author i065831
 *
 */
public class JobRequisitionModelBuilder {
    
    private static JobRequisitionModelBuilder instance = new JobRequisitionModelBuilder();
    
    public static JobRequisitionModelBuilder getInstance(){
        return instance;
    }
    
    public JobRequisitionModel build(){
        JobRequisitionModel model = new JobRequisitionModel();
        List<JobRequisitionAttribute> attrs = new ArrayList<JobRequisitionAttribute>();
        Class<WechatJob> sourceClazz = WechatJob.class;
        this.parseComplexType(attrs, sourceClazz);
        model.setAttributes(attrs);
        return model;
    }
    
    private void parseComplexType(List<JobRequisitionAttribute> attrList, Class<?> profileClass) {
        Field[] fields = profileClass.getDeclaredFields();
        for (Field field : fields) {
            RequisitionAttribute profileAttr = field.getAnnotation(RequisitionAttribute.class);
            if (profileAttr != null) {
                String attrName = profileAttr.name();
                if (StringUtils.isEmpty(profileAttr.name())) {
                    attrName = field.getName();
                }
                JobRequisitionAttribute attr = new JobRequisitionAttribute();
                attr.setName(attrName);
                attr.setType(profileAttr.type().getSimpleName().toLowerCase());
                attr.setLabel(profileAttr.label());
                attr.setFilterable(profileAttr.filterable());
                attrList.add(attr);
            }

        }
    }
    
}
