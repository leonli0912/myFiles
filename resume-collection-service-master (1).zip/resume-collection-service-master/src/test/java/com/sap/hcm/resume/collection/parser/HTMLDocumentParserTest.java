
package com.sap.hcm.resume.collection.parser;

/**
 * @author I324117
 * SAP
 */
public class HTMLDocumentParserTest {

}
