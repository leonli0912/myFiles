package com.sap.hcm.resume.collection.integration.bean;

import java.util.Set;
import java.util.TreeSet;

import org.junit.Assert;
import org.junit.Test;


public class DataModelMappingItemTest {
  
  @Test
  public void testComparable(){
    DataModelMappingItem item1 = new DataModelMappingItem();
    item1.setSeq(10);
    
    DataModelMappingItem item2 = new DataModelMappingItem();
    item2.setSeq(1);
    
    DataModelMappingItem item3 = new DataModelMappingItem();
    item3.setSeq(30);
    
    DataModelMappingItem item4 = new DataModelMappingItem();
    item4.setSeq(30);
    
    Set<DataModelMappingItem> cc = new TreeSet<DataModelMappingItem>();
    cc.add(item1);
    cc.add(item2);
    cc.add(item3);
    cc.add(item4);
    
    Assert.assertEquals(cc.size(), 3);
  }
}
