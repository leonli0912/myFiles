package com.sap.hcm.resume.collection.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sap.hcm.resume.collection.bean.ImportResultBean;
import com.sap.hcm.resume.collection.bean.ImportResultWrapper;
import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.entity.DataModelMapping;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.service.ResumeService;
import com.sap.hcm.resume.collection.service.DataModelMappingService;
import com.sap.hcm.resume.collection.util.CandidateFileUtil;

/**
 * for candidate resume upload
 * 
 * @author i065831
 */
@Controller
public class CandidateResumeController extends ControllerBase {

  @Autowired
  private DataModelMappingService mappingService;

  @Autowired
  private ResumeService resumeService;
  
  @Autowired
  private Params params;

  private static final Logger logger = LoggerFactory.getLogger(CandidateResumeController.class);

  /**
   * @param request
   * @param response
   * @param vendor
   * @param mappingId
   * @param overwrite
   *          0 - does not overwrite the candidate profile when already exist, 1 - overwrite the candidate profile when
   *          already exist
   * @return
   * @throws Exception
   */
  @RequestMapping(value = "upload", method = RequestMethod.POST, produces = "application/json")
  public @ResponseBody ImportResultWrapper upload(HttpServletRequest request, HttpServletResponse response,
      @RequestParam(value = "vendor") String vendor,
      @RequestParam(value="template") String template,
      @RequestParam(value = "jobId", required = false) String jobId,
      @RequestParam(value = "statusSetId", required = false) String statusSetId) throws ServiceApplicationException {

    List<ImportResultBean> importResultList = new ArrayList<ImportResultBean>();

    DataModelMapping mapping = null;
    CompanyInfo info = compInfoService.getCompanyInfo(params.getCompanyId());
    Long mappingId = info.getDmMappingId();
    if (mappingId != null) {
      mapping = mappingService.getMappingById(mappingId);
      logger.debug("Mapping ID is : " + mappingId);
    } else {
      throw new ServiceApplicationException("Mapping ID is null");
    }

    List<FileItem> fileItemList = CandidateFileUtil.handleFileUploadRequest(request);
    for (FileItem item : fileItemList) {
      ImportResultBean importResultBean = resumeService.processFile(item, request, vendor,template, mapping, jobId, statusSetId);
      importResultList.add(importResultBean);

    }

    ImportResultWrapper resultWrapper = new ImportResultWrapper();
    resultWrapper.setResults(importResultList);

    return resultWrapper;
  }
}
