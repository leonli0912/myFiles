package com.sap.hcm.resume.collection.bean;

import java.util.Locale;

import org.junit.Assert;
import org.junit.Test;

public class ParamsTest {
  
  @Test
  public void testGetterSetter(){
    Params params = new Params();
    params.setLocale(Locale.CHINA);
    params.setCompanyId("sap");
    params.setUserEmail("user@user.com");
    params.setWechatOpenId("openId");
    
    Assert.assertEquals(Locale.CHINA, params.getLocale());
    Assert.assertEquals("sap", params.getCompanyId());
    Assert.assertEquals("user@user.com", params.getUserEmail());
    Assert.assertEquals("openId", params.getWechatOpenId());
  }
}
