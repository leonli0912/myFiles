package com.sap.hcm.resume.collection.bean;

import org.junit.Assert;
import org.junit.Test;

public class ExceptionTypeEnumTest {
  
  @Test
  public void testHasEnumError(){
    ExceptionTypeEnum exEnum = ExceptionTypeEnum.ERROR;
    exEnum.setLabelKey("error");
    Assert.assertEquals(exEnum.getLabelKey(), "error");
  }
  
  @Test
  public void testHasEnumWarning(){
    Assert.assertEquals(ExceptionTypeEnum.WARNING.getLabelKey(), "warning");
  }
}
