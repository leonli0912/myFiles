jQuery.sap.require("sap.m.MessageBox");
jQuery.sap.require("sap.m.MessageStrip");
sap.ui.controller("static.wechat.js.layout.candidateList", {

	_jobId : null,
	_editMode : true,
	_candidateId : null,
	_questionData : null,
	_check_job_applied: "wechatuser/checkApplied",
	_dpcsAccepted : false,

	/**
	 * Called when a controller is instantiated and its View controls (if
	 * available) are already created. Can be used to modify the View before it
	 * is displayed, to bind event handlers and do other one-time
	 * initialization.
	 *
	 * @memberOf resume-collection-service.candidateList
	 */
	onInit : function() {

		this._router = sap.ui.core.UIComponent.getRouterFor(this);
		var that = this;
		this._router.getRoute("candidateList").attachPatternMatched(function(oEvent) {
			var query = oEvent.getParameter("arguments")['?query'];
			if (query && query.jobId) {
				that._jobId = query.jobId;
				that.getView().byId("applyBtn").setVisible(true);
				that.getView().byId("aggreementBox").setVisible(true);
			} else {
				that._jobId = null;
				that.getView().byId("applyBtn").setVisible(false);
				that.getView().byId("aggreementBox").setVisible(false);
			}
			that.loadResumeList();
			that.loadDpcs();
			that.checkJobApplied();
		});
	},

	checkJobApplied: function(){
		if(sap.ui.getCore().byId("msgStrip") != null){
			sap.ui.getCore().byId("msgStrip").destroy();
		}
		var that = this;
		$.get(this._check_job_applied, function(data){
			if(data && data.code == 0){
				var message = that.translateText("LB_CANDIDATE_EXIST_TIP");
				var oMsgStrip = new sap.m.MessageStrip("msgStrip", {
    				text: message,
    				showCloseButton: true,
    				showIcon: true,
    				type: "Warning"
  			});
        that.getView().byId("resumeListPanel").addContent(oMsgStrip);
				that.getView().byId("resumeListPanel").setVisible(true);
			}else{
				that.getView().byId("resumeListPanel").setVisible(false);
			}
		});
	},
	calculateCompletionRatio : function(val) {
		if (!val)
			return;
		var resumeData = this.getView().getModel().getData();
		var rawRate = resumeData.completion[val].ratio;
		return parseInt(rawRate * 100) + "%";
	},

	loadResumeList : function() {
		var listModel = new sap.ui.model.json.JSONModel("cv/candidateList");
		this.getView().setModel(listModel);
		var that = this;
		this.getView().byId("candidateList").setBusy(true);
		listModel.attachRequestCompleted(function() {
			that.getView().byId("candidateList").setBusy(false);
			if (listModel.getData().candidateList.length > 0) {
				that.getView().byId("applyBtn").setEnabled(true);
			} else {
				that.getView().byId("applyBtn").setEnabled(false);
			}
			that._editMode = true;
			that.switchMode();
		})
	},

	useOtherResume : function() {
		var jobId = this._jobId;
		if (jobId) {
			this._router.navTo("jobApply", {
				query : {
					jobId : this._jobId
				}
			});
		} else {
			this._router.navTo("jobApply");
		}
	},

	preview : function(oEvent) {

		var rowId = oEvent.getSource().getBindingContext().getPath();
		var rows = rowId.match(/\d+/g);
		var rowNo = rows[rows.length - 1];

		var oModel = this.getView().getModel();
		var oData = oModel.getData();
		var candidateId = oData.candidateList[rowNo].candidateId;
		var profileLanguage = oData.candidateList[rowNo].language;

		var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		var jobId = this._jobId;
		if (jobId) {
			this._router.navTo("candidatePreview", {
				candidateId : candidateId,
				query : {
					jobId : this._jobId,
					profileLan : profileLanguage
				}
			});
		} else {
			this._router.navTo("candidatePreview", {
				candidateId : candidateId,
				query : {
					profileLan : profileLanguage
				}
			});
		}
	},

	onButtonPress : function() {

		var jobId = this._jobId;

		// var oHistory = sap.ui.core.routing.History.getInstance();
		// var sPreviousHash = oHistory.getPreviousHash();
		if (jobId) {
			this._router.navTo("jobDetail", {
				jobId : jobId
			});
		} else {
			this._router.navTo("personalCenter");
		}

	},

	checkDpcsAndApply : function() {
		var candidateList = this.getView().byId("candidateList");
		var selItem = candidateList.getSelectedItem();
		if (!selItem) {
			var selectMsg = this.translateText("CANDIDATE_LIST_SELECT_RESUME");
			sap.m.MessageBox.information(selectMsg, {
				styleClass : "sapUiSizeCompact"
			});
			return;
		}
		var sPath = selItem.getBindingContext().sPath;
		var rowNo = sPath.match("\\d+$")[0];
		var candidateId = selItem.getModel().getData().candidateList[rowNo].candidateId;

		var rate = this.getView().getModel().getData().completion[candidateId].ratio;
		if (parseInt(rate * 100) < 100) {
			sap.m.MessageBox.information(this.translateText("CANDIDATE_LIST_CV_COMPLETION_ERROR_MESSAGE"), {
				styleClass : "sapUiSizeCompact"
			});
			return;
		}
		this._candidateId = candidateId;

		if(!this._dpcsAccepted){
			var aggreementCheck = this.getView().byId("aggreementCheck").getSelected();
			if(!aggreementCheck){
				var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
				sap.m.MessageBox.alert(
				    	this.translatWechatLabel("WEB_AUTH_AGGREMENT_ERROR"),
				    	{
				    		styleClass: bCompact? "sapUiSizeCompact" : ""
				    	}
				    );
				return;
			}
		}
		this.checkScreenQuestionsAndApply();
	},

	loadDpcs: function(){
		var that = this;
		var cfg = {
			type : 'GET',
			dataType : 'json',
			url : 'wechatuser/user'
		};
		$.ajax(cfg).success(function(data) {
			if (data && data.userInfo && data.userInfo.dpcsAgreed) {
				that.getView().byId("aggreementBox").setVisible(false);
				that._dpcsAccepted = true;
			} else {
				that.getView().byId("aggreementBox").setVisible(true);
				that._dpcsAccepted = false;
			}
		});
	},
	checkScreenQuestionsAndApply: function(){
		var screenQuestionUrl = "question/list?jobId=" + this._jobId;
		var oJsonModel = new sap.ui.model.json.JSONModel();
		oJsonModel.loadData(screenQuestionUrl);
		var that = this;
		oJsonModel.attachRequestCompleted(function(){
				var oData = oJsonModel.getData();
				that._questionData = oData;
				if(!oData || oData.length == 0){
					that.jobApply();
					return;
				}
				var oDialog = that.getView().byId("screenQuestionsDiag");
				oDialog.destroyContent();

				var index = 0;
				for(var i in oData){
					var question = oData[i];

					var oHbox = new sap.m.HBox({
					});
					oHbox.addStyleClass("sapUiSmallMarginTop");
					var orderLabel = new sap.m.Label({text:question.questionOrder});
					var questionLabel;
					if(question.required){
						questionLabel = new sap.m.Label({text: "* " + question.questionName});
					}else{
						questionLabel = new sap.m.Label({text: question.questionName});
					}
					questionLabel.addStyleClass("sapUiSmallMarginBegin");
					oHbox.addItem(orderLabel);
					oHbox.addItem(questionLabel);
					oDialog.addContent(oHbox);

					switch(question.questionType){
						case "QUESTION_MULTI_CHOICE":
						case "QUESTION_RATING":
							var sel = new sap.m.Select({id:"_question_anwser_"+(index++)});
							sel.addStyleClass("sapUiSmallMarginBegin");
							var choices = question.choices;
							for(var i in choices){
								var selItem = new sap.ui.core.Item({key:choices[i].optionLabel,text:choices[i].optionLabel});
								sel.addItem(selItem);
							}
							oDialog.addContent(sel);
						break;
						case "QUESTION_NUMERIC":
							var oInput = new sap.m.Input({
								id:"_question_anwser_"+(index++),
								width:"95%"
							});
							oInput.addStyleClass("sapUiSmallMarginBegin");
							oDialog.addContent(oInput);
							break;
						case "QUESTION_TEXT":
							var oInput = new sap.m.TextArea({
								id:"_question_anwser_"+(index++),
								width:"95%",
								rows:5
							});
							oInput.addStyleClass("sapUiSmallMarginBegin");
							oDialog.addContent(oInput);
							var labelTxt = that.translatWechatLabel("LB_MAXIMUM_TEXT_LENGTH")+": " + question.maxLength;
							var oLabel = new sap.m.Label({
								text:labelTxt
							});
							oLabel.addStyleClass("sapUiSmallMarginBegin");
							oDialog.addContent(oLabel);
						break;
						default:
						break;
					}
				}

				that.getView().byId("screenQuestionsDiag").open();
		});
	},
	showAggreement: function(){
		var that = this;
		var cfg = {
			type : 'GET',
			dataType : 'json',
			url : 'company/dpcs'
		};
		$.ajax(cfg).success(function(data) {
			if (data) {
				that.getView().getModel().setData(data);
			}
		});
		this.getView().byId("dpcsConfirmDialog").open();
	},

	dpcsConfirmDialogAccept: function(){
		this.getView().byId("dpcsConfirmDialog").close();
	},

	dpcsConfirmDialogClose: function(){
		this.getView().byId("dpcsConfirmDialog").close();
	},

	translatWechatLabel : function(val) {
		if(!val) return "";
		return this.getView().getModel("wi18n")
				.getResourceBundle().getText(val);
	},

	submitScreenQuesAndApply: function(){

			var oDialog = this.getView().byId("screenQuestionsDiag");
			var questionAnwsers = [];
			var hasError = false;
			for(var i = 0; i < this._questionData.length; i++){
				var question = this._questionData[i];
				var answerId = "_question_anwser_" + i;
				var answerControl = sap.ui.getCore().byId(answerId);

				if(hasError){
					break;
				}
				var anwser = "";
				switch(question.questionType){
					case "QUESTION_MULTI_CHOICE":
					case "QUESTION_RATING":
						var selItem = answerControl.getSelectedItem();
						anwser = selItem.getKey();
					break;
					case "QUESTION_NUMERIC":
						anwser = answerControl.getValue();
						if(anwser && !anwser.match(/^\d+$/)){
							answerControl.setValueState("Error");
							hasError = true;
							break;
						}else{
							answerControl.setValueState("None");
						}
					break;
					case "QUESTION_TEXT":
						anwser = answerControl.getValue();
						if(anwser && anwser.length > question.maxLength - 1){
							answerControl.setValueState("Error");
							hasError = true;
							break;
						}else{
							answerControl.setValueState("None");
						}
					break;
					default:
					break;
				}

				if(!hasError && question.required){
					if(!anwser){
						answerControl.setValueState("Error");
						hasError =true;
						break;
					}else{
						answerControl.setValueState("None");
					}
				}
				questionAnwsers.push({
					order:question.questionOrder,
					answer:anwser
				});

			}

			if(!hasError){
				this.screenQuestionDialogClose();
				this.jobApply(questionAnwsers)
			}
	},

	screenQuestionDialogClose: function(){
		this.getView().byId("screenQuestionsDiag").close();
	},
	jobApply : function(questionAnwsers) {

		var candidateId = this._candidateId;

		var that = this;
		var oApplyButton = this.getView().byId("applyButton");
		var oUserOtherButton = this.getView().byId("userOtherButton");

		var oDialog = this.getView().byId("BusyDialog");
		oDialog.open();

		var successMsg = this.translateText("CANDIDATE_LIST_SUCCESS_MESSAGE");
		var errorMsg = this.translateText("CANDIDATE_LIST_ERROR_MESSAGE");


		jQuery.ajax({
			method : "POST",
			dataType : 'json',
			data:questionAnwsers ? JSON.stringify(questionAnwsers): null,
			contentType : 'application/json;charset=UTF-8',
			url : "wechatJobApp/jobApp?candidateId=" + candidateId + "&jobId=" + that._jobId,
			success : function(data) {
				jQuery.sap.require("sap.m.MessageToast");
				var oApplyButton = that.getView().byId("applyButton");
				var oUserOtherButton = that.getView().byId("userOtherButton");
				oDialog.close();
				if (data && data.code === 1) {
					sap.m.MessageBox.success(successMsg, {
						styleClass : "sapUiSizeCompact",
						onClose : function(oAction) {
							if (oAction === "OK") {
								that._router.navTo("jobList", true);
							}
						}
					});
				} else {
					sap.m.MessageBox.information(that.translateText(data.message), {
						styleClass : "sapUiSizeCompact"
					}

					);
				}
			},
			error : function(data) {
				oDialog.close();
				sap.m.MessageBox.information(errorMsg, {
					styleClass : "sapUiSizeCompact"
				}

				);
			}
		});
	},

	deleteCandidate : function(oEvent) {
		var rowId = oEvent.getSource().getBindingContext().getPath();
		var rows = rowId.match(/\d+/g);
		var rowNo = rows[rows.length - 1];

		var oModel = this.getView().getModel();
		var oData = oModel.getData();
		var candidateId = oData.candidateList[rowNo].candidateId;
		var that = this;
		sap.m.MessageBox.confirm(this.getView().getModel("wi18n").getResourceBundle().getText("DELETEMSG"), {
			onClose : function(command) {

				if (command == "OK") {
					var cfg = {
						type : 'DELETE',
						dataType : 'json',
						contentType : 'application/json;charset=UTF-8'
					};
					cfg.url = "cv/deleteCandidate?candidateId=" + candidateId;
					$.ajax(cfg).success(function() {
						that.loadResumeList();
					});
				}
			}
		})
	},

	formatLanguage : function(val) {
		if (!val)
			return "";
		if (val === "zh") {
			return this.translateText("LB_LANGUAGE_CHINESE");
		} else if (val === "en") {
			return this.translateText("LB_LANGUAGE_ENGLISH");
		}
	},

	formatVendorName : function(val) {
		if (!val)
			return "";
		if (val.toLowerCase() === "zhilian") {
			return this.translateText("LB_RECRUITMENT_VENDOR_ZHILIAN");
		} else if (val.toLowerCase() === "liepin") {
			return this.translateText("LB_RECRUITMENT_VENDOR_LIEPIN");
		} else if (val.toLowerCase() === "dajie") {
			return this.translateText("LB_RECRUITMENT_VENDOR_DAJIE");
		} else if (val.toLowerCase() === "wechat") {
			return this.translateText("LB_RECRUITMENT_VENDOR_WEIXIN");
		} else if (val.toLowerCase() === "job51") {
			return this.translateText("LB_RECRUITMENT_VENDOR_51JOB");
		} else {
			return "";
		}

	},
	translateText : function(val) {
		return this.getView().getModel("wi18n").getResourceBundle().getText(val);
	},

	switchMode : function() {

		var candidateList = this.getView().byId("candidateList");
		var items = candidateList.getItems();

		var listActions = {
			enableDelete : false
		};

		if (this._editMode) {
			this._editMode = false;

			if (items) {
				for (var i = 0; i < items.length; i++) {
					items[i].setType(sap.m.ListType.Navigation);
				}
			}

			listActions.enableDelete = false;
		} else {
			this._editMode = true;

			if (items) {
				for (var i = 0; i < items.length; i++) {
					items[i].setType(sap.m.ListType.Inactive);
				}
			}

			listActions.enableDelete = true;
		}

		var actionModel = candidateList.getModel("listAction");
		if (!actionModel) {
			actionModel = new sap.ui.model.json.JSONModel();
			actionModel.setData(listActions);
			candidateList.setModel(actionModel, "listAction");
		} else {
			actionModel.setData(listActions);
		}

	}

/**
 * Similar to onAfterRendering, but this hook is invoked before the controller's
 * View is re-rendered (NOT before the first rendering! onInit() is used for
 * that one!).
 *
 * @memberOf resume-collection-service.candidateList
 */
// onBeforeRendering: function() {
//
// },
/**
 * Called when the View has been rendered (so its HTML is part of the document).
 * Post-rendering manipulations of the HTML could be done here. This hook is the
 * same one that SAPUI5 controls get after being rendered.
 *
 * @memberOf resume-collection-service.candidateList
 */
// onAfterRendering: function() {
//
// },
/**
 * Called when the Controller is destroyed. Use this one to free resources and
 * finalize activities.
 *
 * @memberOf resume-collection-service.candidateList
 */
// onExit: function() {
//
// }
});
