package com.sap.hcm.resume.collection.integration.wechat.entity;

public class UserBascInfo {
	
	private String openid;
	private String nickname;
	private String  sex;
	private String city;
	private String unionid;
	private String headimgurl;
	private String province;
	private String country;
	
	public String getOpenid() {
		return openid;
	}
	public void setOpenid(String openid) {
		this.openid = openid;
	}
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getUnionid() {
		return unionid;
	}
	public void setUnionid(String unionid) {
		this.unionid = unionid;
	}
  /**
   * @return the headimgurl
   */
  public String getHeadimgurl() {
    return headimgurl;
  }
  /**
   * @param headimgurl the headimgurl to set
   */
  public void setHeadimgurl(String headimgurl) {
    this.headimgurl = headimgurl;
  }
  /**
   * @return the province
   */
  public String getProvince() {
    return province;
  }
  /**
   * @param province the province to set
   */
  public void setProvince(String province) {
    this.province = province;
  }
  /**
   * @return the country
   */
  public String getCountry() {
    return country;
  }
  /**
   * @param country the country to set
   */
  public void setCountry(String country) {
    this.country = country;
  }
  /* (non-Javadoc)
   * @see java.lang.Object#toString()
   */
  @Override
  public String toString() {
    return "UserBascInfo [openid=" + openid + ", nickname=" + nickname + ", sex=" + sex + ", city=" + city
        + ", unionid=" + unionid + ", headimgurl=" + headimgurl + ", province=" + province + ", country=" + country
        + "]";
  }

  
}
