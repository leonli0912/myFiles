package com.sap.hcm.resume.collection.bean;

import org.junit.Assert;
import org.junit.Test;

public class ImportResultBeanTest {
  
  @Test
  public void testGetterSetter(){
    ImportResultBean bean = new ImportResultBean();
    
    bean.setCandidateId(1L);
    Assert.assertEquals(bean.getCandidateId().toString(), "1");
    
    bean.setFileName("test");
    Assert.assertEquals("test", bean.getFileName());
    
    bean.setFilePath("path");
    Assert.assertEquals("path", bean.getFilePath());
    
    bean.setReason("reason");
    Assert.assertEquals("reason", bean.getReason());
    
    bean.setFileSize("0");
    Assert.assertEquals("0", bean.getFileSize());
  }
}
