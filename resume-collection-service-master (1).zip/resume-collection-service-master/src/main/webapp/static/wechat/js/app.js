sap.ui.localResources("static.wechat.js.layout");
sap.ui.localResources("static.wechat.js");
sap.ui.localResources("static.i18n");
sap.ui.localResources("static.js");

jQuery.sap.registerModulePath('com.sap.rcs.wechat', 'static/wechat/js/');

if (g_company_info.isLogin || window.location.href.indexOf("jobdetail")>=0 || window.location.href.indexOf("interviewInfo")>=0) {
	$(document).ready(function() {
		startPageLoading();
	});

	sap.ui.getCore().attachInit(
			function() {

				var component = sap.ui.component({
						name: "com.sap.rcs.wechat"
					});

				var componentContainer = new sap.ui.core.ComponentContainer({
				});
				componentContainer.setComponent(component);

				var personalCenterButton = new sap.ui.unified.ShellHeadItem({
					icon: "sap-icon://person-placeholder",
					press:function(){
						var oRouter = component.getRouter();
						oRouter.navTo("personalCenter", true);
					}
				});

				var oShell = new sap.ui.unified.Shell("mainShell",{
					icon : g_company_info.logo ? "wphoto/" + g_company_info.logo
							: "static/img/SAPLogo.png",
					headEndItems:[personalCenterButton],
					content : componentContainer
				}).placeAt("content");

				oShell.addStyleClass("mainShell");
			});
}

var startPageLoading = function() {
	$("#pageLoading").show();
	$("#content").css("visibility","hidden");
};

var hidePageLoading = function() {
	$("#pageLoading").hide();
	$("#content").css("visibility","visible");
}

function loadHtml() {
	var div = document.createElement('div');
	div.id = 'noWechatIdImg';
	var textElement = document.createElement('div');
	textElement.id = 'text';
	textElement.innerHTML = "若您未关注公众号，长按二维码识别，并关注公众号；若您已关注，长按二维码识别，并从公众号页面进入";
	textElement.style.fontSize = "1.2rem";
	div.appendChild(textElement);
	var imgDiv = document.createElement('div');
	imgDiv.id = 'imgdiv';
	var imgElement = document.createElement("img");
	imgElement.id = "img";
	imgElement.setAttribute("src",
			"/" + window.location.pathname.split('/')[1] + "/wphoto/"+g_company_info.qrcode);
	imgElement.setAttribute("alt", '二维码');
	imgDiv.appendChild(imgElement);
	div.appendChild(imgDiv);
	document.body.appendChild(div);
}

function loadStyleText(cssText) {
	var style = document.createElement('style');
	style.rel = 'stylesheet';
	style.type = 'text/css';
	try {
		style.appendChild(document.createTextNode(cssText));
	} catch (e) {
		style.styleSheet.cssText = cssText; //ie9以下
	}
	var head = document.getElementsByTagName("head")[0]; //head标签之间加上style样式
	head.appendChild(style);
}

var typeEMail = sap.ui.model.SimpleType.extend("email", {
	parseValue: function (oValue) {
		//parsing step takes place before validating step, value can be altered
		return oValue;
	},
	validateValue: function (oValue) {
		// The following Regex is NOT a completely correct one and only used for demonstration purposes.
		// RFC 5322 cannot even checked by a Regex and the Regex for RFC 822 is very long and complex.
		var mailregex = /^\w+[\w-+\.]*\@\w+([-\.]\w+)*\.[a-zA-Z]{2,}$/;
		if (!oValue.match(mailregex)) {
			throw new sap.ui.model.ValidateException("'" + oValue + "' is not a valid email address");
		}
	},
	formatValue: function (oValue) {
		return oValue;
	}
})
