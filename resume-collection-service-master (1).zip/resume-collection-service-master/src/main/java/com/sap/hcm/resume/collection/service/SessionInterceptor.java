package com.sap.hcm.resume.collection.service;

import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.sap.cloud.account.TenantContext;
import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.hcp.HCPUserProvider;
import com.sap.hcm.resume.collection.util.MappingUtil;
import com.sap.security.um.user.User;

/**
 * @author I073999 SAP
 */
public class SessionInterceptor implements HandlerInterceptor {
  @Autowired
  private TenantContext tenantContext;

  @Autowired
  private HCPUserProvider hcpUserProvider;

  @Autowired
  private Params params;

  @Autowired
  private CompanyInfoService companyInfoService;

  private static final String LOCAL = "dev_default";

  @Override
  public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
    String currentTenantId = tenantContext.getTenant().getAccount().getId();
    String providerAccount = System.getenv("HC_ACCOUNT");

    if (providerAccount == null && LOCAL.equals(currentTenantId)) {
      User loginUser = hcpUserProvider.getLoginUser(request);
      currentTenantId = currentTenantId.concat("_").concat(loginUser.getName());
      this.params.setCompanyId(currentTenantId);
      this.createCompanyIfNotExist(currentTenantId);
    } else if (providerAccount != null && providerAccount.equals(currentTenantId)) {
      // Handle Wechat callback URL, get the tenant ID from the URL
      String requestUrl = request.getRequestURI().toString();
      if(requestUrl.indexOf("callback") >= 0){
        String regex = "(?<=callback\\/)\\S+";
        String tenantId = MappingUtil.matchSingle(regex, requestUrl);
        this.params.setCompanyId(tenantId);
      }
    } else {
      this.params.setCompanyId(currentTenantId);
      this.createCompanyIfNotExist(currentTenantId);
    }
    // change locale to SF type
    if (Locale.ENGLISH.equals(request.getLocale())) {
      this.params.setLocale(Locale.US);
    } else if (Locale.CHINESE.equals(request.getLocale())) {
      this.params.setLocale(Locale.SIMPLIFIED_CHINESE);
    } else {
      this.params.setLocale(request.getLocale());
    }
    return true;
  }

  private void createCompanyIfNotExist(String tenantId) throws ServiceApplicationException {
    CompanyInfo companyInfo = companyInfoService.getCompanyInfo(tenantId);
    if (companyInfo == null) {
      companyInfo = new CompanyInfo();
      companyInfo.setCompanyId(tenantId);
      companyInfo.setCompanyName(tenantId);
      companyInfoService.saveCompanyInfo(companyInfo);
    }
  }

  @Override
  public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
      ModelAndView modelAndView) throws Exception {
    // TODO Auto-generated method stub

  }

  @Override
  public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
      throws Exception {
    // TODO Auto-generated method stub

  }
}
