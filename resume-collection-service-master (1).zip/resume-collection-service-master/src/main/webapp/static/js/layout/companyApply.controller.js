sap.ui.controller("static.js.layout.companyApply", {
	
	_companyInfo : {
		companyId:"",
		companyName:"",
		shortDescription:"",
		uiusers:"",
		phone:"",
		contactEmail:"",
		country:""
	},
/**
* Called when a controller is instantiated and its View controls (if available) are already created.
* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
* @memberOf static.js.layout.templateConfig
*/
	onInit : function() {
		
		
		// attach handlers for validation errors
		sap.ui.getCore().attachValidationError(function (evt) {
			var control = evt.getParameter("element");
			if (control && control.setValueState) {
				control.setValueState("Error");
			}
		});
		sap.ui.getCore().attachValidationSuccess(function (evt) {
			var control = evt.getParameter("element");
			if (control && control.setValueState) {
				control.setValueState("None");
			}
		});
		
		var jsonModel = new sap.ui.model.json.JSONModel();
		jsonModel.setData(this._companyInfo);
		this.getView().byId("companyApplyForm").setModel(jsonModel);
		
	},

	handleFormSubmit: function(){
		jQuery.sap.require("sap.m.MessageBox");
		if(!this.validate()){
			return;
		}
		
		var formData = this.getView().byId("companyApplyForm").getModel().getData();
		var users = formData.uiusers;
		var userArr = users.split(",");
		formData.users = [];
		for(var i in userArr){
			formData.users.push({
				hcpUser: userArr[i]
			})
		};
		var that = this;
		$.ajax({
			url:"company/apply",
			type : 'POST',
			data: JSON.stringify(formData),
			contentType : 'application/json;charset=UTF-8'
		}).success(function(data){
			if(data && data.companyId){
				
				var bCompact = !!that.getView().$().closest(".sapUiSizeCompact").length;
				sap.m.MessageBox.success(
					"Company with id '" + data.companyId+ "' was created and assigned to user "+data.users[0].hcpUser+".",
					{
						styleClass: bCompact? "sapUiSizeCompact" : ""
					}
				);
				
				that.getView().byId("submitBtn").setEnabled(false);
			}
			if(data && data.code < 0){
				var bCompact = !!that.getView().$().closest(".sapUiSizeCompact").length;
				sap.m.MessageBox.error(
					data.message,
					{
						styleClass: bCompact? "sapUiSizeCompact" : ""
					}
				);
			}
		});
	},
	
	validate: function(){
		var view = this.getView();
		
		var inputs = [
		              view.byId("companyId"),
		              view.byId("companyName"),
		              view.byId("hcpusers")
		              ];
		
		// check that inputs are not empty
		// this does not happen during data binding as this is only triggered by changes
		jQuery.each(inputs, function (i, input) {
			if (!input.getValue()) {
				input.setValueState("Error");
			}
		});

		// check states of inputs
		var canContinue = true;
		jQuery.each(inputs, function (i, input) {
			if ("Error" === input.getValueState()) {
				canContinue = false;
				return false;
			}
		});
		return canContinue;
	},
/**
* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
* (NOT before the first rendering! onInit() is used for that one!).
* @memberOf resume-collection-service.templateConfig
*/
	onBeforeRendering: function() {
	},

/**
* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
* This hook is the same one that SAPUI5 controls get after being rendered.
* @memberOf resume-collection-service.templateConfig
*/
//	onAfterRendering: function() {
//
//	},

/**
* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
* @memberOf resume-collection-service.templateConfig
*/
	onExit: function() {
		
	}

});