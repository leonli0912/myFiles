package com.sap.hcm.resume.collection.bean;

public enum LogObjectType {

  CANDIDATE_PROFILE("candidateProfile"), COMPANY_SETTING("companySetting"), JOB_SYNC("jobSync");

  private String objectName;

  public String getObjectName() {
    return objectName;
  }

  LogObjectType(String objectName) {
    this.objectName = objectName;
  }

  public static LogObjectType fromObjectName(String objectName) {
    for (LogObjectType ot : LogObjectType.values()) {
      if (ot.getObjectName().equals(objectName)) {
        return ot;
      }
    }
    return null;
  }
}
