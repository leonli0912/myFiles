package com.sap.hcm.resume.collection.integration.liepin;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpEntity;
import org.apache.http.NameValuePair;
import org.apache.http.ParseException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.HttpClientUtils;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.cookie.BasicClientCookie;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.stereotype.Component;

import com.sap.hcm.resume.collection.bean.KeyLabelBean;
import com.sap.hcm.resume.collection.bean.ResumeInfo;
import com.sap.hcm.resume.collection.exception.AuthenticationFailedException;
import com.sap.hcm.resume.collection.exception.InvalidVerifyCodeException;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.JobBoardBaseProvider;
import com.sap.hcm.resume.collection.integration.bean.ResumeDownloadBean;
import com.sap.hcm.resume.collection.util.CandidateFileUtil;

@Component(value = "liepinProvider")
@Scope(value = "session", proxyMode = ScopedProxyMode.TARGET_CLASS)
public class LiepinProvider extends JobBoardBaseProvider {

  private static final Logger logger = LoggerFactory.getLogger(LiepinProvider.class);
  
  public static final String PRE_LOGIN_URL="https://www.liepin.com/user/login/";
  
  public static final String LOGIN_URL="https://passport.liepin.com/c/login.json?__mn__=user_login";
  
  @Override
  public void preLogin() throws ServiceApplicationException {
    cookieStore.clear();

    CloseableHttpClient client = this.createHttpClient();
    HttpGet get = new HttpGet(PRE_LOGIN_URL);
    try {
      CloseableHttpResponse response = client.execute(get);
      if (response != null) {
        this.setCookieStore(response);
        response.close();
      }
      HttpClientUtils.closeQuietly(client);
    } catch (IOException e) {
      // Eat this exception by intention
    } finally {
      HttpClientUtils.closeQuietly(client);
    }

  }

  @Override
  public void getVerifyCode(HttpServletRequest request) throws ServiceApplicationException {
    CloseableHttpClient client = this.createHttpClient();
    SecureRandom sr = new SecureRandom();
    sr.setSeed((new Date()).getTime());
    Double rnd = sr.nextDouble();
    HttpEntity entity = null;
    try {
      HttpGet get = new HttpGet("https://passport.liepin.com/captcha/randomcodenoise?" + rnd);
      get.addHeader("Accept", "image/webp,image/*,*/*;q=0.8");
      get.addHeader("User-Agent",
          "Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/48.0.2564.109 Safari/537.36");
      
      CloseableHttpResponse response = client.execute(get);
      setCookieStore(response);
      entity = response.getEntity();
      byte[] image = CandidateFileUtil.cropImage(entity.getContent(), 120, 60);
      request.getSession().setAttribute("verifyCode", image);

    }catch(Exception e){ 
      throw new ServiceApplicationException("failed to retrieve the verify code: " + e.getMessage());
    }finally {
      EntityUtils.consumeQuietly(entity);
      HttpClientUtils.closeQuietly(client);
    }
  }

  @Override
  public List<ResumeDownloadBean> getResume(HttpServletRequest request, String username, String password,
      String captcha) throws ServiceApplicationException {
    List<ResumeDownloadBean> fileNameList = new ArrayList<ResumeDownloadBean>();

    String md5 = encryptPwd(password);

    KeyLabelBean keyLabelBean = this.encriptMobile("user_login", username);
    BasicClientCookie cookie = new BasicClientCookie(keyLabelBean.getKey(), keyLabelBean.getLabel());
    cookie.setDomain(".liepin.com");
    cookie.setPath("/");
    this.cookieStore.addCookie(cookie);

    CloseableHttpClient client = this.createHttpClient();
    CloseableHttpResponse resumeResponse = null;
    HttpEntity resumeEntity = null;
    InputStream resumeContent = null;
    ByteArrayOutputStream baos = null;
    InputStream bais = null;

    try {
      HttpPost post = new HttpPost(LOGIN_URL);
      List<NameValuePair> list = new ArrayList<NameValuePair>();
      list.add(new BasicNameValuePair("user_login", username));
      list.add(new BasicNameValuePair("user_pwd", md5));
      list.add(new BasicNameValuePair("layer_from", "wwwindex_rightbox_new"));
      list.add(new BasicNameValuePair("verifycode", captcha));
      UrlEncodedFormEntity encodedFormEntity = new UrlEncodedFormEntity(list);
      post.setEntity(encodedFormEntity);

      post.addHeader("Upgrade-Insecure-Requests", "1");
      post.addHeader("X-Requested-With", "XMLHttpRequest");
      post.addHeader("Content-Type", "application/x-www-form-urlencoded");
      post.addHeader("Origin", "https://passport.liepin.com");
      post.addHeader("Referer", "https://passport.liepin.com/ajaxproxy.html");
      post.addHeader("Host", "passport.liepin.com");
      post.addHeader(
          "User-Agent",
          "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.103 Safari/537.36");
      CloseableHttpResponse response = client.execute(post);
      if (response == null) {
        logger.error("connect to Liepin failed");
        throw new ServiceApplicationException("network error, unable to connect to Liepin");
      } else {
        if (response.getStatusLine() != null && response.getStatusLine().getStatusCode() != 200) {
          logger.error("status code returned from liepin is " + response.getStatusLine().getStatusCode());
          throw new ServiceApplicationException("server error, please try again later");
        }
        String loginResp = EntityUtils.toString(response.getEntity());
        if(loginResp.indexOf("验证码不正确") >= 0){
          throw new InvalidVerifyCodeException();
        }else if (loginResp.indexOf("user_id") < 0) {
          throw new AuthenticationFailedException();
        }
      }

      setCookieStore(response);
      String loginAfterPage = "http://c.liepin.com/?time=" + Calendar.getInstance().getTimeInMillis();
      HttpGet get = new HttpGet(loginAfterPage);
      CloseableHttpResponse response2 = client.execute(get);
      setCookieStore(response2);
      HttpEntity entity = response2.getEntity();
      String input = EntityUtils.toString(entity);
      String regex = "\" href=\"/resume/regresume/\\?res_id_encode=(.+)\" class";
      Pattern pattern = Pattern.compile(regex);
      Matcher matcher = pattern.matcher(input);
      while (matcher.find()) {
        String res_id_encode = matcher.group(1);
        ResumeDownloadBean rdb = new ResumeDownloadBean();
        rdb.setExternalResumeId(res_id_encode);
        rdb.setFileName(null);

        HttpGet get2 = new HttpGet("http://c.liepin.com/resume/download?res_id_encode=" + res_id_encode);
        resumeResponse = client.execute(get2);

        if (resumeResponse.getEntity() != null && resumeResponse.getEntity().getContent() != null) {

          resumeEntity = resumeResponse.getEntity();
          resumeContent = resumeEntity.getContent();

          // clone the input stream
          baos = new ByteArrayOutputStream();
          IOUtils.copy(resumeContent, baos);
          bais = new ByteArrayInputStream(baos.toByteArray());
          rdb.setFileContent(baos.toByteArray());

          String theString = IOUtils.toString(bais, "utf-8");
          if (theString.contains("基本资料")) {
            rdb.setLocale(Locale.CHINA);
          } else {
            rdb.setLocale(Locale.ENGLISH);
          }
          fileNameList.add(rdb);
          
          resumeContent.close();
        }
      }

      this.logout(loginAfterPage);
    } catch (ParseException | IOException e) {
      throw new ServiceApplicationException(e.getMessage());
    } finally {
      IOUtils.closeQuietly(bais);
      IOUtils.closeQuietly(baos);
      IOUtils.closeQuietly(resumeContent);
      EntityUtils.consumeQuietly(resumeEntity);
      HttpClientUtils.closeQuietly(resumeResponse);
      HttpClientUtils.closeQuietly(client);
    }

    return fileNameList;
  }

  /**
   * try logout after download
   * 
   * @param loginAfterPage
   */
  private void logout(String loginAfterPage) {
    CloseableHttpClient client = this.createHttpClient();
    HttpGet get = new HttpGet("https://www.liepin.com/user/logout/");
    get.addHeader("Referer", loginAfterPage);
    get.addHeader("Host", "www.liepin.com");
    get.addHeader("Upgrade-Insecure-Requests", "1");
    try {
      client.execute(get);
    } catch (IOException e) {
      logger.error("log out liepin failed with error : " + e.getMessage());
    } finally {
      HttpClientUtils.closeQuietly(client);
    }
    this.cookieStore.clear();
  }


  private String sortAndJoin(String str) {
    String result = "";
    String[] ss = str.split("");
    List<String> list = Arrays.asList(ss);
    Collections.sort(list);
    for (int i = 0; i < list.size(); i++) {
      result += list.get(i);
    }
    return result;
  }

  public KeyLabelBean encriptMobile(String fieldName, String fieldValue) {
    String rawValue = this.sortAndJoin(fieldValue) + fieldName;
    String md5Key = this.encryptPwd(rawValue).substring(4, 12);
    rawValue = this.sortAndJoin(rawValue);
    String md5Value = this.encryptPwd(rawValue);

    KeyLabelBean keyLabelBean = new KeyLabelBean();
    keyLabelBean.setKey(md5Key);
    keyLabelBean.setLabel(md5Value);
    return keyLabelBean;
  }

  @Override
  public ResumeInfo getFileContent(byte[] resource) throws ServiceApplicationException {
    ResumeInfo resumeInfo = new ResumeInfo();
    resumeInfo.setResumeExtension("html");
    resumeInfo.setHtmlDocument(CandidateFileUtil.getFileContentFromHtml(resource));
    return resumeInfo;
  }
}
