package com.sap.hcm.resume.collection.bean;

import java.io.Serializable;
import java.util.List;

public class JobRequisitionModel implements Serializable{

    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = -7514669010376176934L;

    public List<JobRequisitionAttribute> attributes;

    public List<JobRequisitionAttribute> getAttributes() {
        return attributes;
    }

    public void setAttributes(List<JobRequisitionAttribute> attributes) {
        this.attributes = attributes;
    }
}
