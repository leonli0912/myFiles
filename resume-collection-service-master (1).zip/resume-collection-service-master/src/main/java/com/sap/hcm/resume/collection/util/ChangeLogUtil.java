package com.sap.hcm.resume.collection.util;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.sap.hcm.resume.collection.bean.ActionType;
import com.sap.hcm.resume.collection.bean.LogObjectType;
import com.sap.hcm.resume.collection.entity.ChangeLog;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.service.ChangeLogService;

/**
 * @author I324117 SAP
 */
@Component
public class ChangeLogUtil {

  @Autowired
  private ChangeLogService changeLogService;

  public ChangeLog saveCandidateProfileChangeHistory(String resumeId, String resumeName, ActionType actionType,
      String wechatId, String content, String companyId) throws ServiceApplicationException {
    ChangeLog changeLog = new ChangeLog();
    changeLog.setActionType(actionType.getActionName());
    changeLog.setChangedBy(wechatId);
    changeLog.setObjectType(LogObjectType.CANDIDATE_PROFILE.getObjectName());
    changeLog.setChangeContent(content);
    changeLog.setObjectName(resumeName);
    changeLog.setObjectId(resumeId);
    changeLog.setCompanyId(companyId);
    changeLogService.saveChangeLog(changeLog);
    return changeLog;

  }

  public ChangeLog saveCompanyChangeHistory(ActionType actionType, String hcpUser, String content, String companyId,
      String mappingName, String mappingId) throws ServiceApplicationException {
    ChangeLog changeLog = new ChangeLog();
    changeLog.setActionType(actionType.getActionName());
    changeLog.setChangedBy(hcpUser);
    changeLog.setObjectType(LogObjectType.COMPANY_SETTING.getObjectName());
    changeLog.setChangeContent(content);
    changeLog.setObjectName(mappingName);
    changeLog.setObjectId(mappingId);
    changeLog.setCompanyId(companyId);
    changeLogService.saveChangeLog(changeLog);
    return changeLog;

  }

  public ChangeLog savejobSyncHistory(String content, String companyId) throws ServiceApplicationException {
    ChangeLog changeLog = new ChangeLog();
    changeLog.setObjectType(LogObjectType.JOB_SYNC.getObjectName());
    changeLog.setChangeAt(CandidateDateUtil.formatDate2String(new Date(), "yyyy-MM-dd HH:mm:ss"));
    changeLog.setChangeContent(content);
    changeLog.setCompanyId(companyId);
    changeLogService.saveChangeLog(changeLog);
    return changeLog;

  }
}
