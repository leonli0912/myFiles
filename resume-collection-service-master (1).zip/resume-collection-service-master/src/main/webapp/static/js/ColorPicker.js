sap.ui.define(['jquery.sap.global','sap/ui/core/Control', "sap/m/Button",
	"sap/ui/core/Icon","sap/m/Popover","static/js/Color"],
	function(jQuery, Control, Button, Icon, Popover, Color) {
	var colorPicker = Control.extend("static.js.ColorPicker",{
		metadata:{
			properties:{
				hex: {type:"string"}
			}
		},

		_icon:null,

		_defaultColors:["#F7055A","#F705C7","#5605F7","#0576F7","#05F7F7","#05F776","#8AF705","#F7DB05","#45443E","#F5F4F0"],

		_popup:null,

		_colorInput: null,

		init: function(){
			this._icon = new Icon({
				src:"sap-icon://palette",
				press: jQuery.proxy(this, "openPopover")
			});
			this._icon.addStyleClass("sapMInputValHelpInner");

			this._popup = new Popover({
				placement:"Left",
				showHeader:false,
				modal:false,
				width:"240px",
				height:"320px"
			});
			this._popup.addStyleClass("color-popup");

			var oHtml = this.buildColorGrid();

			var oColorGird = new sap.ui.core.HTML({
				content:oHtml
			});

			var oLabel = new sap.m.Label({
				text:"Color"
			});
			oLabel.addStyleClass("color-popup-label");
			this._colorInput = new sap.m.Input({
				value:""
			});
			this._colorInput.addStyleClass("sapUiTinyMarginBegin color-popup-input");

			var oHBox = new sap.m.HBox({
				items:[oLabel, this._colorInput],
				width:"80%",
				justifyContent:"Center",
				alignItems:"Center"
			});
			oHBox.addStyleClass("color-popup-hbox");

			this._popup.addContent(oColorGird);
			this._popup.addContent(oHBox);
		},
		renderer:function(rm, oControl){

			
			oControl._colorInput.setValue(oControl.getHex());

			rm.write("<div class='ui-color-picker'");
			rm.writeControlData(oControl);
			rm.addStyle("width", "100%");
			rm.addStyle("height", "3rem");
			rm.writeStyles();
			rm.write(">")

			rm.write("<div class='color-input-wrapper sapMInputVH'>");
				rm.write("<input type='text' class='color-input sapMInputBaseInner' value='"+oControl.getHex()+"'/>");
				rm.write("<div class='sapMInputValHelp' style='top:0px !important'>");
					rm.renderControl(oControl._icon);
				rm.write("</div>");
			rm.write("</div>");

			rm.write("</div>");
		},

		buildColorGrid: function(){

			var rm = null;
			var oHtml = [];
			oHtml.push("<div class='sapUiPopupWithPadding'>");
			oHtml.push("<table class='color-popup-grid'>");
			var that = this;

			var cellNum = 5;
			var rows = Math.floor(this._defaultColors.length / cellNum);

			var color = null;
			for(var i = 0; i < rows; i++){
				oHtml.push("<tr>");

				for(var j = 0; j < cellNum; j++){
					var idx = i * cellNum + j;
					color = new Color({
						hex: this._defaultColors[idx],
						width:"1.25rem",
						press:function(oEvent){
							var hex = oEvent.getParameter("hex");
							that.setHex(hex);
							that.rerender();
						}
					});
					oHtml.push("<td>");
					rm = new sap.ui.core.RenderManager()
					rm.renderControl(color);
					oHtml.push(rm.aBuffer.join(""));
					rm.destroy();
					oHtml.push("</td>");

				}
				oHtml.push("</tr>");
			}

			oHtml.push("</table>");
			oHtml.push("</div>");
			return oHtml.join("");
		},
		openPopover: function(){
			this._popup.openBy(this._icon);
		}
	});

	return colorPicker;

}, true);
