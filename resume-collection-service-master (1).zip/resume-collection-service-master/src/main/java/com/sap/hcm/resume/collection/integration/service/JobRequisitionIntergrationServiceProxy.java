package com.sap.hcm.resume.collection.integration.service;

import java.io.UnsupportedEncodingException;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.sap.hcm.resume.collection.bean.BusinessEntityType;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;

@Service(value = "jobRequisitionIntergrationServiceProxy")
public class JobRequisitionIntergrationServiceProxy implements JobRequisitionIntegrationService {

  @Autowired
  IntegrationServiceFactoryManager factoryManager;

  @Autowired
  @Qualifier(value = "sfJobRequisitionService")
  private JobRequisitionIntegrationService integrationService;

  @PostConstruct
  private void init() {
    IntegrationServiceFactory factory = factoryManager.getFactory();
    integrationService = (JobRequisitionIntegrationService) factory.create(BusinessEntityType.JOBREQUISITION);
  }

  @Override
  public Map<String, String> getJobRequisition(String jobReqMappingId, String lowDate, String highDate,
      String jobReqIdStr) throws ServiceApplicationException {
    return integrationService.getJobRequisition(jobReqMappingId, lowDate, highDate, jobReqIdStr);
  }

  @Override
  public void syncJobRequisition(String companyId) throws ServiceApplicationException {
    // TODO Auto-generated method stub
    integrationService.syncJobRequisition(companyId);
  }

  @Override
  public Map<String, Object> getJobRequisitionForSearch(String condition) throws UnsupportedEncodingException {
    // TODO Auto-generated method stub
    return integrationService.getJobRequisitionForSearch(condition);
  }
}
