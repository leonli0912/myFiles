package com.sap.hcm.resume.collection.integration.job51;

import java.util.Calendar;

import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.context.MessageSource;

import com.sap.hcm.resume.collection.parser.HTMLDocumentParser;
import com.sap.hcm.resume.collection.util.CandidateDateUtil;
import com.sap.hcm.resume.collection.util.MappingUtil;

public abstract class AbstractDocumentParser51 extends HTMLDocumentParser{

  public AbstractDocumentParser51(MessageSource messageSource) {
    super(messageSource);
  }
  
  protected String calculateDob(String ageRaw){
    int age = Integer.parseInt(MappingUtil.matchSingle("\\d+", ageRaw));
    Calendar cal = Calendar.getInstance();
    int dob = cal.get(Calendar.YEAR) - age;
    cal.set(Calendar.YEAR, dob);
    cal.set(Calendar.MONTH,0);
    cal.set(Calendar.DAY_OF_MONTH, 1);
    return CandidateDateUtil.formatDate2String(cal.getTime(), "yyyy/MM/dd");
  }
  
  protected Element getBlock(String title, Document doc){
    Elements classElements = doc.getElementsByClass("box");
    for(int i = 0;i < classElements.size();i++){
      if(classElements.get(i).text().toString().contains(title)){
        return classElements.get(i);
      }else{
        continue;
      }
    }
    return null;
  }
  
  protected String getColonRightValue(String text){
    return text.replace(text.split(":|：")[0],"").replaceFirst(":|：","").trim();
  }
  
}
