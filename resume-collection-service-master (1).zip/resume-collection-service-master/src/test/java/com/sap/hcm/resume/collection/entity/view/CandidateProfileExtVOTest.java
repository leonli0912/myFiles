package com.sap.hcm.resume.collection.entity.view;

import org.junit.Assert;
import org.junit.Test;


public class CandidateProfileExtVOTest {
  
  @Test
  public void test(){
    CandidateProfileExtVO vo = new CandidateProfileExtVO();
    vo.setCustom01(null);
    vo.setCustom02(null);
    vo.setCustom03(null);
    vo.setCustom04(null);
    vo.setCustom05(null);
    
    Assert.assertEquals(vo.getCustom01(), null);
    Assert.assertEquals(vo.getCustom02(), null);
    Assert.assertEquals(vo.getCustom03(), null);
    Assert.assertEquals(vo.getCustom04(), null);
    Assert.assertEquals(vo.getCustom05(), null);
  }
}
