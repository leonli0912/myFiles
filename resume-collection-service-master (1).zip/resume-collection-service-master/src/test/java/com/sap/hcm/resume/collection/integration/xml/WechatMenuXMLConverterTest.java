package com.sap.hcm.resume.collection.integration.xml;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.IOUtils;
import org.eclipse.persistence.jpa.jpql.Assert.AssertException;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.core.io.ClassPathResource;

import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.bean.CandProfileDataModelMapping;
import com.sap.hcm.resume.collection.integration.bean.DataMappingOverwrite;
import com.sap.hcm.resume.collection.integration.bean.DataMappingPicklist;
import com.sap.hcm.resume.collection.integration.bean.DataMappingPicklistOption;
import com.sap.hcm.resume.collection.integration.bean.DataMappingPkOptionMapping;
import com.sap.hcm.resume.collection.integration.bean.DataModelMappingItem;
import com.sap.hcm.resume.collection.integration.bean.JobReqDataModelMapping;
import com.sap.hcm.resume.collection.integration.bean.JobReqDataModelMappingItem;
import com.sap.hcm.resume.collection.integration.wechat.bean.WechatMenuContent;
import com.sap.hcm.resume.collection.integration.wechat.bean.WechatMenuItem;
import com.sap.hcm.resume.collection.integration.wechat.bean.WechatSubMenuItem;
import com.sap.hcm.resume.collection.integration.xml.DataModelMappingXMLConverter;
import com.sap.hcm.resume.collection.util.CandidateFileUtil;

public class WechatMenuXMLConverterTest {

  private static WechatMenuContent wechatMenuContent = new WechatMenuContent();

  @BeforeClass
  public static void Init() throws IOException {
    WechatSubMenuItem wechatSubMenuItem = new WechatSubMenuItem();
    wechatSubMenuItem.setKey("qwe");
    wechatSubMenuItem.setName("asd");
    wechatSubMenuItem.setType("zxc");
    wechatSubMenuItem.setUrl("qaz");
    List<WechatSubMenuItem> wechatSubMenuItemList = new ArrayList<WechatSubMenuItem>();
    wechatSubMenuItemList.add(wechatSubMenuItem);
    WechatMenuItem wechatMenuItem = new WechatMenuItem();
    wechatMenuItem.setName("wsx");
    wechatMenuItem.setWechatSubMenuItem(wechatSubMenuItemList);
    List<WechatMenuItem> wechatMenuItemList = new ArrayList<WechatMenuItem>();
    wechatMenuItemList.add(wechatMenuItem);
    wechatMenuContent = new WechatMenuContent();
    wechatMenuContent.setWechatMenuItem(wechatMenuItemList);
  }

  @Test
  public void testMappingToXML() {
    String xml = WechatMenuXMLConverter.toXML(wechatMenuContent);
    Assert.assertNotNull(xml);
  }

  @Test
  public void testMappingFromXML() {
    String xml = WechatMenuXMLConverter.toXML(wechatMenuContent);
    Assert.assertEquals("qwe", WechatMenuXMLConverter.fromXML(xml).getWechatMenuItem().get(0).getWechatSubMenuItem()
        .get(0).getKey());
  }

  @Test
  public void testMappingFromByte() {
    byte[] content = WechatMenuXMLConverter.toXML(wechatMenuContent).getBytes(StandardCharsets.UTF_8);
    Assert.assertEquals("qwe", WechatMenuXMLConverter.fromByte(content).getWechatMenuItem().get(0)
        .getWechatSubMenuItem().get(0).getKey());
  }

}
