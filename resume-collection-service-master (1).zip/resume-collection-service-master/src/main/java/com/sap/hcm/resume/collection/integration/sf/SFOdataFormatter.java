package com.sap.hcm.resume.collection.integration.sf;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import net.sf.json.JSONArray;

import org.apache.olingo.odata2.api.edm.Edm;
import org.apache.olingo.odata2.api.edm.EdmSimpleTypeKind;
import org.apache.olingo.odata2.api.edm.provider.NavigationProperty;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MarkerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.sap.hcm.resume.collection.bean.JobAppQuestionResponse;
import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.entity.view.CandidateBgCertificateVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgEducationVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgLanguageVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgWorkExprVO;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileConstants;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;
import com.sap.hcm.resume.collection.entity.view.JobApplicationRequiredFieldVO;
import com.sap.hcm.resume.collection.entity.view.JobApplyMappingVO;
import com.sap.hcm.resume.collection.entity.view.JobRequisitionMappingVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.bean.ApplyDataModelMappingItem;
import com.sap.hcm.resume.collection.integration.bean.CandProfileDataModelMapping;
import com.sap.hcm.resume.collection.integration.bean.DataMappingApplyStatus;
import com.sap.hcm.resume.collection.integration.bean.DataMappingApplyStatusList;
import com.sap.hcm.resume.collection.integration.bean.DataMappingOverwrite;
import com.sap.hcm.resume.collection.integration.bean.DataMappingPkOptionMapping;
import com.sap.hcm.resume.collection.integration.bean.DataModelMappingItem;
import com.sap.hcm.resume.collection.integration.bean.JobReqDataModelMapping;
import com.sap.hcm.resume.collection.integration.bean.JobReqDataModelMappingItem;
import com.sap.hcm.resume.collection.integration.sf.bean.SFPicklist;
import com.sap.hcm.resume.collection.integration.sf.bean.SFPicklistCacheEntityType;
import com.sap.hcm.resume.collection.integration.sf.bean.SFPicklistItem;
import com.sap.hcm.resume.collection.integration.sf.odata.SFODataEntityType;
import com.sap.hcm.resume.collection.integration.sf.odata.SFODataService;
import com.sap.hcm.resume.collection.integration.sf.service.SFPicklistCacheService;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJob;
import com.sap.hcm.resume.collection.integration.xml.DataModelMappingXMLConverter;
import com.sap.hcm.resume.collection.service.CandidateProfileService;
import com.sap.hcm.resume.collection.util.CandidateDateUtil;
import com.sap.hcm.resume.collection.util.CandidateFileUtil;
import com.sap.hcm.resume.collection.util.CandidateProfileHelper;
import com.sap.hcm.resume.collection.util.MappingUtil;

@Component
public class SFOdataFormatter {

  @Autowired
  private SFODataService sfODataService;

  @Autowired
  private SFPicklistCacheService sfPicklistCacheService;

  @Autowired
  private CandidateProfileHelper candidateProfileHelper;

  @Autowired
  private CandidateProfileService candidateProfileService;

  @Autowired
  private Params params;

  private static final Logger logger = LoggerFactory.getLogger(SFOdataFormatter.class);

  /**
   * check the field is pickList or not
   * 
   * @throws ServiceApplicationException
   */
  private void populateFieldValue(Map<String, Object> dataMap, String fieldName, Object fieldValue,
      Map<String, SFPicklist> pickListMap, boolean required, String pickListName,
      DataMappingPkOptionMapping dataMappingPkOptionMapping, String defaultValue, String entityName)
      throws ServiceApplicationException {

    String optionTargetValue = null;
    String pickListValue = null;

    if (pickListMap.containsKey(pickListName)) {

      if (!StringUtils.isEmpty(pickListName)) {
        // match value from pickListOption
        optionTargetValue = candidateProfileHelper.matchPickListOption(fieldValue, pickListName, dataMappingPkOptionMapping, pickListMap);
      }

      // can not find value in the picklist option mapping
      if (StringUtils.isEmpty(optionTargetValue)) {
        optionTargetValue = (String) fieldValue;
      }

      // read data from pick-list
      pickListValue = readPickListValue(pickListMap, pickListName, optionTargetValue);
      if (StringUtils.isEmpty(pickListValue)) {
        pickListValue = readPickListValue(pickListMap, pickListName, defaultValue);
      }

      List<String> naviPropertyNameList = sfODataService.getNaviPropertyNames(entityName);

      if (pickListValue == null && required) {
        // throw exception
        throw new ServiceApplicationException(" The value of [" + fieldName + "] is not in the pickList");
      } else if (!StringUtils.isEmpty(pickListValue)) {
        if (naviPropertyNameList.contains(fieldName)) {
          Map<String, Object> metadataMap = new HashMap<String, Object>();
          metadataMap.put("type", "SFOData.PicklistOption");
          Map<String, Object> naviPicklistMap = new HashMap<String, Object>();
          naviPicklistMap.put("__metadata", metadataMap);
          naviPicklistMap.put("id", pickListValue);
          dataMap.put(fieldName, naviPicklistMap);
        } else {
          dataMap.put(fieldName, pickListValue);
        }
      }
    } else {
      // put the data into map
      if (!StringUtils.isEmpty(fieldValue)) {
        dataMap.put(fieldName, fieldValue);
      }
    }

    EdmSimpleTypeKind propType = sfODataService.getPropertyType(fieldName, entityName);
    if (!StringUtils.isEmpty(fieldValue) && propType != null) {
      if ("DateTimeOffset".equals(propType.name())) {
        String dateTimeOffset = CandidateDateUtil.formatStringDateToOdata((String) fieldValue, false);
        dataMap.put(fieldName, "/Date(" + dateTimeOffset + "+0000)/");
      } else if ("DateTime".equals(propType.name())) {
        if ("NOW".equals(fieldValue)) {
          SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
          String today = CandidateDateUtil.formatStringDateToOdata(sdf.format(new Date()), true);
          dataMap.put(fieldName, "/Date(" + today + ")/");
        } else {
          String dataTime = CandidateDateUtil.formatStringDateToOdata((String) fieldValue, true);
          dataMap.put(fieldName, "/Date(" + dataTime + ")/");
        }
      }
    }
  }

  /**
   * @param pickListMap
   * @param fieldName
   * @param optionTargetValue
   * @return
   */
  private String readPickListValue(Map<String, SFPicklist> pickListMap, String pickListName, String optionTargetValue) {

    String pickListValue = "";
    // read data from pick-list
    SFPicklist sfPickListBean = pickListMap.get(pickListName);
    List<SFPicklistItem> sfPickList = sfPickListBean.getValueList();
    for (SFPicklistItem sfPicklistItem : sfPickList) {
      if (sfPicklistItem.getLabel().equals(optionTargetValue)) {
        pickListValue = sfPicklistItem.getOptionId().toString();
        break;
      }
    }

    return pickListValue;
  }



  /**
   * format profile info
   * 
   * @param dataModelMapping
   * @param candidateProfileVO
   * @param pickListMap
   * @return
   * @throws ServiceApplicationException
   */
  private Map<String, Object> getSFOdataProfileFormat(CandProfileDataModelMapping dataModelMapping,
      CandidateProfileVO candidateProfileVO, Map<String, SFPicklist> pickListMap) throws ServiceApplicationException {

    Map<String, Object> data = new HashMap<String, Object>();

    Set<DataModelMappingItem> profileMapping = dataModelMapping.getProfile();
    for (DataModelMappingItem mappingItem : profileMapping) {

      if (mappingItem.getTo() == null || mappingItem.getTo().isEmpty()) {
        continue;
      }

      Object reflectValue = candidateProfileHelper.getValueFromCandidateProfile(candidateProfileVO,
          mappingItem.getFrom());

      try {
        if (StringUtils.isEmpty(reflectValue) && !StringUtils.isEmpty(mappingItem.getDefaultValue())) {
          reflectValue = mappingItem.getDefaultValue();
        }
        if (mappingItem.isRequired() && StringUtils.isEmpty(reflectValue)) {
          throw new ServiceApplicationException(mappingItem.getFrom() + " is required");
        }
        if ("attachment".equals(mappingItem.getFrom())) {
          Map<String, Object> attachmentMap = new HashMap<String, Object>();
          byte[] content = (byte[]) reflectValue;
          attachmentMap.put("module", "RECRUITING");
          attachmentMap.put("fileContent", CandidateFileUtil.convertByteToBase64Str(content));
          attachmentMap.put("moduleCategory", "RESUME");
          attachmentMap.put("fileName", candidateProfileVO.getLastName() + "_" + candidateProfileVO.getFirstName()
              + "." + candidateProfileVO.getExtProfile().getResumeExtension());
          data.put(mappingItem.getTo(), attachmentMap);
        } else {
          populateFieldValue(data, mappingItem.getTo(), reflectValue, pickListMap, mappingItem.isRequired(),
              mappingItem.getPicklist(), dataModelMapping.getPicklistOptionMapping(), mappingItem.getDefaultValue(),
              "Candidate");
        }

      } catch (Exception ex) {
        if (ex instanceof ServiceApplicationException) {
          throw new ServiceApplicationException(ex.getMessage());
        } else {
          continue;
        }
      }

    }

    // handle overwrite
    this.handleDataMappingOverwrite(candidateProfileVO, data, dataModelMapping);
    return data;
  }

  /**
   * @param candidateProfileVO
   * @param data
   * @param dataModelMapping
   */
  private void handleDataMappingOverwrite(CandidateProfileVO candidateProfileVO, Map<String, Object> data,
      CandProfileDataModelMapping dataModelMapping) {
    DataMappingOverwrite overwrites = dataModelMapping.getDataMappingOverwrites();
    if (overwrites == null || overwrites.getRules() == null) {
      return;
    }
    for (String rule : overwrites.getRules()) {
      // parse rule
      if (!rule.contains("=")) {
        continue;
      }
      String target = rule.split("=")[0].trim();
      String source = rule.split("=")[1].trim();
      // get new value of target item
      StringBuilder targetValue = new StringBuilder();
      String[] parts = source.split("\\+");
      for (int i = 0; i < parts.length; i++) {
        String part = parts[i].trim();
        if (part.startsWith("\"") && part.endsWith("\"")) {
          // fix value
          targetValue.append(part.substring(1, part.length() - 1));
        } else {
          // from candidate profile
          Object reflectValue = candidateProfileHelper.getValueFromCandidateProfile(candidateProfileVO, part);
          if (reflectValue != null) {
            targetValue.append(reflectValue);
          }
        }
      }
      for (DataModelMappingItem item : dataModelMapping.getProfile()) {
        if (target.equals(item.getFrom()) && item.getTo() != null) {
          data.put(item.getTo(), targetValue.toString());
          break;
        }
      }
    }
  }

  /**
   * format workExp info
   * 
   * @param dataModelMapping
   * @param candidateProfileVO
   * @param pickListMap
   * @return
   * @throws ServiceApplicationException
   */
  private List<Map<String, Object>> getSFOdataWorkExpFormat(CandProfileDataModelMapping dataModelMapping,
      CandidateProfileVO candidateProfileVO, Map<String, SFPicklist> pickListMap, String entityName)
      throws ServiceApplicationException {

    // format workExp info
    List<Map<String, Object>> workExpList = new ArrayList<Map<String, Object>>();
    Set<DataModelMappingItem> workExpMapping = dataModelMapping.getWorkExprs();
    List<CandidateBgWorkExprVO> workExprs = candidateProfileVO.getWorkExprs();

    for (CandidateBgWorkExprVO candidateBgWorkExprVO : workExprs) {
      Map<String, Object> workExpData = new HashMap<String, Object>();
      for (DataModelMappingItem mappingItem : workExpMapping) {

        if (mappingItem.getTo() == null || mappingItem.getTo().isEmpty()) {
          continue;
        }
        Object reflectValue = candidateProfileHelper.getPropertyValueFromObject(candidateBgWorkExprVO,
            mappingItem.getFrom());

        if (reflectValue == null && !StringUtils.isEmpty(mappingItem.getDefaultValue())) {
          reflectValue = mappingItem.getDefaultValue();
        }
        if (mappingItem.isRequired() && StringUtils.isEmpty(reflectValue)) {
          throw new ServiceApplicationException(mappingItem.getFrom() + " is required");
        }

        populateFieldValue(workExpData, mappingItem.getTo(), reflectValue, pickListMap, mappingItem.isRequired(),
            mappingItem.getPicklist(), dataModelMapping.getPicklistOptionMapping(), mappingItem.getDefaultValue(),
            entityName);
      }
      if (!workExpData.isEmpty()) {
        workExpList.add(workExpData);
      }
    }

    return workExpList;
  }

  /**
   * format education info
   * 
   * @param dataModelMapping
   * @param candidateProfileVO
   * @param pickListMap
   * @return
   * @throws ServiceApplicationException
   */
  private List<Map<String, Object>> getSFOdataEducationFormat(CandProfileDataModelMapping dataModelMapping,
      CandidateProfileVO candidateProfileVO, Map<String, SFPicklist> pickListMap, String entityName)
      throws ServiceApplicationException {

    // format education info
    List<Map<String, Object>> educationList = new ArrayList<Map<String, Object>>();
    Set<DataModelMappingItem> educationMapping = dataModelMapping.getEducation();
    List<CandidateBgEducationVO> education = candidateProfileVO.getEducation();

    for (CandidateBgEducationVO candidateBgEducationVO : education) {

      Map<String, Object> educationData = new HashMap<String, Object>();
      for (DataModelMappingItem mappingItem : educationMapping) {

        if (mappingItem.getTo() == null || mappingItem.getTo().isEmpty()) {
          continue;
        }

        Object reflectValue = candidateProfileHelper.getPropertyValueFromObject(candidateBgEducationVO,
            mappingItem.getFrom());

        if (StringUtils.isEmpty(reflectValue) && !StringUtils.isEmpty(mappingItem.getDefaultValue())) {
          reflectValue = mappingItem.getDefaultValue();
        }
        if (mappingItem.isRequired() && StringUtils.isEmpty(reflectValue)) {
          throw new ServiceApplicationException(mappingItem.getFrom() + " is required");
        }

        populateFieldValue(educationData, mappingItem.getTo(), reflectValue, pickListMap, mappingItem.isRequired(),
            mappingItem.getPicklist(), dataModelMapping.getPicklistOptionMapping(), mappingItem.getDefaultValue(),
            entityName);

      }
      if (!educationData.isEmpty()) {
        educationList.add(educationData);
      }
    }

    return educationList;
  }

  /**
   * format languages info
   * 
   * @param dataModelMapping
   * @param candidateProfileVO
   * @param pickListMap
   * @return
   * @throws ServiceApplicationException
   */
  private List<Map<String, Object>> getSFOdataLanguageFormat(CandProfileDataModelMapping dataModelMapping,
      CandidateProfileVO candidateProfileVO, Map<String, SFPicklist> pickListMap, String entityName)
      throws ServiceApplicationException {
    // format languages info
    List<Map<String, Object>> languagesList = new ArrayList<Map<String, Object>>();
    Set<DataModelMappingItem> languagesMapping = dataModelMapping.getLanguages();
    List<CandidateBgLanguageVO> languages = candidateProfileVO.getLanguages();

    for (CandidateBgLanguageVO candidateBgLanguageVO : languages) {

      Map<String, Object> languagesData = new HashMap<String, Object>();
      boolean isExistLanguage = false;
      for (DataModelMappingItem mappingItem : languagesMapping) {

        if (mappingItem.getTo() == null || mappingItem.getTo().isEmpty()) {
          continue;
        }
        Object reflectValue = candidateProfileHelper.getPropertyValueFromObject(candidateBgLanguageVO,
            mappingItem.getFrom());

        if (StringUtils.isEmpty(reflectValue) && !StringUtils.isEmpty(mappingItem.getDefaultValue())) {
          reflectValue = mappingItem.getDefaultValue();
        }
        if (mappingItem.isRequired() && StringUtils.isEmpty(reflectValue)) {
          throw new ServiceApplicationException(mappingItem.getFrom() + " is required");
        }

        // check language is exist in picklistMap or not, if not exist then
        // ignore this language
        if ("name".equals(mappingItem.getFrom()) && !StringUtils.isEmpty(mappingItem.getPicklist())) {
          // match value from pickListOption
          String optionTargetValue = candidateProfileHelper.matchPickListOption(reflectValue, mappingItem.getPicklist(),
              dataModelMapping.getPicklistOptionMapping(), pickListMap);

          if (!StringUtils.isEmpty(optionTargetValue)) {
            isExistLanguage = true;
          } else {
            isExistLanguage = false;
            break;
          }
        }

        populateFieldValue(languagesData, mappingItem.getTo(), reflectValue, pickListMap, mappingItem.isRequired(),
            mappingItem.getPicklist(), dataModelMapping.getPicklistOptionMapping(), mappingItem.getDefaultValue(),
            entityName);

      }
      if (isExistLanguage && !languagesData.isEmpty()) {
        languagesList.add(languagesData);
      }
    }

    return languagesList;
  }

  /**
   * format certificates info
   * 
   * @param dataModelMapping
   * @param candidateProfileVO
   * @param pickListMap
   * @return
   * @throws ServiceApplicationException
   */
  private List<Map<String, Object>> getSFOdataCertificateFormat(CandProfileDataModelMapping dataModelMapping,
      CandidateProfileVO candidateProfileVO, Map<String, SFPicklist> pickListMap, String entityName)
      throws ServiceApplicationException {
    // format certificates info
    List<Map<String, Object>> certificatesList = new ArrayList<Map<String, Object>>();
    Set<DataModelMappingItem> certificatesMapping = dataModelMapping.getCertificates();
    List<CandidateBgCertificateVO> certificates = candidateProfileVO.getCertificates();

    for (CandidateBgCertificateVO candidateBgCertificateVO : certificates) {

      Map<String, Object> certificatesData = new HashMap<String, Object>();
      for (DataModelMappingItem mappingItem : certificatesMapping) {

        if (mappingItem.getTo() == null || mappingItem.getTo().isEmpty()) {
          continue;
        }
        Object reflectValue = candidateProfileHelper.getPropertyValueFromObject(candidateBgCertificateVO,
            mappingItem.getFrom());

        if (StringUtils.isEmpty(reflectValue) && !StringUtils.isEmpty(mappingItem.getDefaultValue())) {
          reflectValue = mappingItem.getDefaultValue();
        }
        if (mappingItem.isRequired() && StringUtils.isEmpty(reflectValue)) {
          throw new ServiceApplicationException(mappingItem.getFrom() + " is required");
        }
        if ("EndDate".equalsIgnoreCase(mappingItem.getFrom()) && StringUtils.isEmpty(reflectValue)) {
          continue;
        }
        populateFieldValue(certificatesData, mappingItem.getTo(), reflectValue, pickListMap, mappingItem.isRequired(),
            mappingItem.getPicklist(), dataModelMapping.getPicklistOptionMapping(), mappingItem.getDefaultValue(),
            entityName);

      }
      if (!certificatesData.isEmpty()) {
        certificatesList.add(certificatesData);
      }
    }

    return certificatesList;
  }

  /**
   * Candidate Info transfer to Odata
   * 
   * @throws Exception
   */
  public Map<String, Object> getSFOdataFormat(CandProfileDataModelMapping dataModelMapping,
      CandidateProfileVO candidateProfileVO) throws ServiceApplicationException {

    // format profile info
    String naviNameLanguage = null;
    String naviNameEducation = null;
    String naviNameWork = null;
    String naviNameCertificate = null;

    // read picklist cache from picklistcache service
    List<SFPicklist> picklist = dataModelMapping.picklists();

    Map<String, SFPicklist> pickListMap = candidateProfileHelper.readPicklistFromDB(picklist, SFPicklistCacheEntityType.CANDIDATE.name(), null);

    List<NavigationProperty> navigationProperties = sfODataService.getNaviProperties(SFODataEntityType.CANDIDATE
        .getName());
    if (navigationProperties != null && navigationProperties.size() > 0) {
      for (NavigationProperty prop : navigationProperties) {
        if (prop.getName().equals(dataModelMapping.getAliases().get(CandidateProfileConstants.BG_LANGU_NAME))) {
          naviNameLanguage = prop.getToRole();
          continue;
        } else if (prop.getName().equals(dataModelMapping.getAliases().get(CandidateProfileConstants.BG_EDUC_NAME))) {
          naviNameEducation = prop.getToRole();
          continue;
        } else if (prop.getName().equals(dataModelMapping.getAliases().get(CandidateProfileConstants.BG_WORKEXPR_NAME))) {
          naviNameWork = prop.getToRole();
          continue;
        } else if (prop.getName().equals(dataModelMapping.getAliases().get(CandidateProfileConstants.BG_CERT_NAME))) {
          naviNameCertificate = prop.getToRole();
        }
      }
    }
    Map<String, Object> data = getSFOdataProfileFormat(dataModelMapping, candidateProfileVO, pickListMap);
    if (data == null) {
      throw new ServiceApplicationException("Failed to format the candidate profile");
    }

    // format workExp info
    if (naviNameWork != null && candidateProfileVO.getWorkExprs() != null) {
      List<Map<String, Object>> workExpList = this.getSFOdataWorkExpFormat(dataModelMapping, candidateProfileVO,
          pickListMap, naviNameWork);
      if (!workExpList.isEmpty()
          && !StringUtils.isEmpty(dataModelMapping.getAliases().get(CandidateProfileConstants.BG_WORKEXPR_NAME))) {
        data.put(dataModelMapping.getAliases().get(CandidateProfileConstants.BG_WORKEXPR_NAME), workExpList);
      }
    }

    // format education info
    if (naviNameEducation != null && candidateProfileVO.getEducation() != null) {
      List<Map<String, Object>> educationList = this.getSFOdataEducationFormat(dataModelMapping, candidateProfileVO,
          pickListMap, naviNameEducation);
      if (!educationList.isEmpty()
          && !StringUtils.isEmpty(dataModelMapping.getAliases().get(CandidateProfileConstants.BG_EDUC_NAME))) {
        data.put(dataModelMapping.getAliases().get(CandidateProfileConstants.BG_EDUC_NAME), educationList);
      }
    }

    // format languages info
    if (naviNameLanguage != null && candidateProfileVO.getLanguages() != null) {
      List<Map<String, Object>> languagesList = this.getSFOdataLanguageFormat(dataModelMapping, candidateProfileVO,
          pickListMap, naviNameLanguage);
      if (!languagesList.isEmpty()
          && !StringUtils.isEmpty(dataModelMapping.getAliases().get(CandidateProfileConstants.BG_LANGU_NAME))) {
        data.put(dataModelMapping.getAliases().get(CandidateProfileConstants.BG_LANGU_NAME), languagesList);
      }
    }

    // format certificates info
    if (naviNameCertificate != null && candidateProfileVO.getCertificates() != null) {
      List<Map<String, Object>> certificatesList = this.getSFOdataCertificateFormat(dataModelMapping,
          candidateProfileVO, pickListMap, naviNameCertificate);
      if (!certificatesList.isEmpty()
          && !StringUtils.isEmpty(dataModelMapping.getAliases().get(CandidateProfileConstants.BG_CERT_NAME))) {
        data.put(dataModelMapping.getAliases().get(CandidateProfileConstants.BG_CERT_NAME), certificatesList);
      }
    }

    return data;
  }



  /**
   * JobApplication Info transfer to Odata
   * 
   * @throws Exception
   */
  public Map<String, Object> getSFJobApplicationOdataFormat(CandProfileDataModelMapping dataModelMapping,
      CandidateProfileVO candidateProfileVO, JobApplyMappingVO jobApplyMappingVO, CompanyInfo info,
      WechatJob wechatJob, List<JobAppQuestionResponse> questionResponses) throws ServiceApplicationException {

    // read and fill the picklist value
    List<SFPicklist> picklists = new ArrayList<SFPicklist>();
    for (ApplyDataModelMappingItem item : jobApplyMappingVO.getItemList()) {
      SFPicklist sfPicklist = new SFPicklist();
      if (!StringUtils.isEmpty(item.getPicklist())) {
        sfPicklist.setSrcPropertyName(item.getSourceField());
        sfPicklist.setPicklistName(item.getPicklist());
        sfPicklist.setSFPropertyName(item.getSfDmField());
        picklists.add(sfPicklist);
      }
    }
    Map<String, SFPicklist> pickListMap = new HashMap<String, SFPicklist>();
    if (picklists != null && picklists.size() > 0) {
      // prefill the pick list data
      pickListMap = candidateProfileHelper.readPicklistFromDB(picklists, SFPicklistCacheEntityType.JOB_APPLICATION.name(), null);
    }

    Map<String, Object> data = new HashMap<String, Object>();
    List<ApplyDataModelMappingItem> mappingItemList = jobApplyMappingVO.getItemList();

    // set default required field
    data.put("candidateId", candidateProfileVO.getExtProfile().getExternalCandidateId());
    data.put("jobReqId", wechatJob.getExternalJobId());
    data.put("status", "0");

    // Get additional required fields
    List<JobApplicationRequiredFieldVO> extraRequiredFields = new ArrayList<JobApplicationRequiredFieldVO>();
    Map<String, Object> requiredData = new HashMap<String, Object>();
    extraRequiredFields = candidateProfileService.getJobApplicationReqFieldsById(candidateProfileVO.getCandidateId());
    if (extraRequiredFields.size() > 0) {
      for (JobApplicationRequiredFieldVO item : extraRequiredFields) {
        requiredData.put(item.getFieldName(), item);
      }
    }

    DataMappingApplyStatusList applyStatusMappingList = DataModelMappingXMLConverter.fromApplyStatusReqXML(info
        .getApplyStatusMapping());
    boolean itemIdExist = false;
    for (DataMappingApplyStatus mapping : applyStatusMappingList.getStatusSetItem()) {
      if (mapping.getStatusSetId().equals(wechatJob.getSfStatusSetId())) {
        data.put("appStatusSetItemId", mapping.getStatusSetItemId());
        itemIdExist = true;
        break;
      }
    }
    if (!itemIdExist) {
      logger.error(MarkerFactory.getMarker("Critical"), "Application status item id" + wechatJob.getSfStatusSetId()
          + " can not be found in the status status mapping");
      throw new ServiceApplicationException("Apply Status Item ID can not be find in the mapping");
    }
    List<String> naviPropertyNameList = sfODataService.getNaviPropertyNames(SFODataEntityType.JOBAPPLICATION.getName());

    for (ApplyDataModelMappingItem mappingItem : mappingItemList) {

      if ("selectFromCandidateProfile".equals(mappingItem.getSourceNameType())) {

        Object reflectValue = candidateProfileHelper.getValueFromCandidateProfile(candidateProfileVO,
            mappingItem.getSourceField());

        if (StringUtils.isEmpty(reflectValue) && !StringUtils.isEmpty(mappingItem.getDefaultValue())) {
          reflectValue = mappingItem.getDefaultValue();
        }

        if ("attachment".equals(mappingItem.getSourceField())) {
          if (!StringUtils.isEmpty(candidateProfileVO.getExtProfile().getResumeExtension())) {
            Map<String, Object> attachmentMap = new HashMap<String, Object>();
            byte[] content = (byte[]) reflectValue;
            attachmentMap.put("module", "RECRUITING");
            attachmentMap.put("fileContent", CandidateFileUtil.convertByteToBase64Str(content));
            attachmentMap.put("moduleCategory", "RESUME");
            attachmentMap.put("fileName", candidateProfileVO.getLastName() + "_" + candidateProfileVO.getFirstName()
                + "." + candidateProfileVO.getExtProfile().getResumeExtension());
            data.put(mappingItem.getSfDmField(), attachmentMap);
          }
        } else {
          populateFieldValue(data, mappingItem.getSfDmField(), reflectValue, pickListMap, mappingItem.isRequired(),
              mappingItem.getPicklist(), dataModelMapping.getPicklistOptionMapping(), mappingItem.getDefaultValue(),
              SFODataEntityType.JOBAPPLICATION.getName());
        }

      } else if ("inputExtraField".equals(mappingItem.getSourceNameType())) {

        String targetValue = "";
        targetValue = mappingItem.getDefaultValue();

        if (naviPropertyNameList.contains(mappingItem.getSfDmField())) {
          Map<String, Object> metadataMap = new HashMap<String, Object>();
          metadataMap.put("type", "SFOData.PicklistOption");
          Map<String, Object> naviPicklistMap = new HashMap<String, Object>();
          naviPicklistMap.put("__metadata", metadataMap);
          naviPicklistMap.put("id", readPickListValue(pickListMap, mappingItem.getPicklist(), targetValue));
          data.put(mappingItem.getSfDmField(), naviPicklistMap);
        } else {
          data.put(mappingItem.getSfDmField(), targetValue);
        }
      } else {
        String targetValue = "";

        if (requiredData.size() > 0 && requiredData.get(mappingItem.getSfDmField()) != null) {
          JobApplicationRequiredFieldVO targetObject = (JobApplicationRequiredFieldVO) requiredData.get(mappingItem
              .getSfDmField());
          targetValue = targetObject.getFieldValue();
        }
        if (naviPropertyNameList.contains(mappingItem.getSfDmField())) {
          Map<String, Object> metadataMap = new HashMap<String, Object>();
          metadataMap.put("type", "SFOData.PicklistOption");
          Map<String, Object> naviPicklistMap = new HashMap<String, Object>();
          naviPicklistMap.put("__metadata", metadataMap);
          naviPicklistMap.put("id", readPickListValue(pickListMap, mappingItem.getPicklist(), targetValue));
          data.put(mappingItem.getSfDmField(), naviPicklistMap);
        } else {
          data.put(mappingItem.getSfDmField(), targetValue);
        }
      }

    }
    if (questionResponses != null && questionResponses.size() != 0) {

      JSONArray responseList = JSONArray.fromObject(questionResponses);

      data.put("jobApplicationQuestionResponse", responseList);
    }

    return data;
  }

  /**
   * format JobRequisition from SF to local
   * 
   * @throws ServiceApplicationException
   */
  @SuppressWarnings("unchecked")
  // TODO - code refactory is required
  public WechatJob formatJobReqFromSF2Local(WechatJob wechatJob, HashMap<String, Object> resultMap,
      JobRequisitionMappingVO mapping) throws ServiceApplicationException {
    JobReqDataModelMapping jobReqMapping = mapping.getMapping();
    List<JobReqDataModelMappingItem> itemList = jobReqMapping.getItems();
    for (JobReqDataModelMappingItem mappingItem : itemList) {

      String sfDmField = mappingItem.getSfDmField();
      if (!StringUtils.isEmpty(sfDmField)) {

        Object sfValueObj;
        if (sfDmField.contains("/")) {
          String arrField[] = sfDmField.split("/");
          HashMap<String, Object> jobReqMap = (HashMap<String, Object>) resultMap.get(arrField[0]);
          List<HashMap<String, Object>> jobReqMapResults = (List<HashMap<String, Object>>) jobReqMap.get("results");
          if (!jobReqMapResults.isEmpty()) {
            HashMap<String, Object> jobReqMapResultsData = jobReqMapResults.get(0);
            sfValueObj = jobReqMapResultsData.get(arrField[1]);
          } else {
            sfValueObj = "";
          }
        } else if (!StringUtils.isEmpty(mappingItem.getPicklist())) {
          HashMap<String, Object> jobReqMap = (HashMap<String, Object>) resultMap.get(sfDmField);
          List<HashMap<String, Object>> jobReqMapResults = (List<HashMap<String, Object>>) jobReqMap.get("results");
          if (!jobReqMapResults.isEmpty()) {
            HashMap<String, Object> jobReqMapResultsData = jobReqMapResults.get(0);
            sfValueObj = jobReqMapResultsData.get("id");
          } else {
            sfValueObj = "";
          }
        } else {
          sfValueObj = resultMap.get(sfDmField);
        }
        String mappedName = MappingUtil.methodNameCapitalized(mappingItem.getSourceField());
        try {

          Field field = wechatJob.getClass().getDeclaredField(mappingItem.getSourceField());
          if (field.getGenericType().toString().equals("class java.lang.String")) {
            Method method = wechatJob.getClass().getMethod("set" + mappedName, String.class);
            method.invoke(wechatJob, (String) sfValueObj);
          } else if (field.getGenericType().toString().equals("class [B")) {
            Method method = wechatJob.getClass().getMethod("set" + mappedName, byte[].class);
            String sfValue = (String) sfValueObj;
            if (sfValue != null) {
              sfValue = CandidateFileUtil.formatHtmlText(sfValue, false, true);
              // replace the return character
              sfValue = sfValue.replaceAll("&#13;", "");
              method.invoke(wechatJob, sfValue.getBytes("utf-8"));
            }

          } else if (field.getGenericType().toString().equals("class java.util.Date")) {
            Method method = wechatJob.getClass().getMethod("set" + mappedName, Date.class);
            method.invoke(wechatJob, (Date) sfValueObj);
          } else if (field.getGenericType().toString().equals("class java.lang.Integer")) {
            Method method = wechatJob.getClass().getMethod("set" + mappedName, Integer.class);
            method.invoke(wechatJob, (Integer) sfValueObj);
          }
        } catch (Exception e) {
          e.printStackTrace();
        }
      }
    }

    return wechatJob;
  }

  /**
   * check the field whether is a navigation or not
   * 
   * @throws ServiceApplicationException
   */
  public void checkJobReqPicklistNavi(Edm edm, JobRequisitionMappingVO mapping) throws ServiceApplicationException {

    List<String> naviPropertyNameList = sfODataService.getNaviPropertyNames(SFODataEntityType.JOBREQUISITION.getName());
    JobReqDataModelMapping jobReqMapping = mapping.getMapping();
    List<JobReqDataModelMappingItem> itemList = jobReqMapping.getItems();

    for (JobReqDataModelMappingItem mappingItem : itemList) {

      String sfDmField = mappingItem.getSfDmField();
      if (!StringUtils.isEmpty(sfDmField) && sfDmField.contains("/")) {
        String arrField[] = sfDmField.split("/");
        if (!naviPropertyNameList.contains(arrField[0])) {
          throw new ServiceApplicationException("Cann't find navigation : " + arrField[0]);
        }
      } else if (!StringUtils.isEmpty(sfDmField) && !StringUtils.isEmpty(mappingItem.getPicklist())) {
        if (!naviPropertyNameList.contains(sfDmField)) {
          throw new ServiceApplicationException("Cann't find navigation : " + mappingItem.getSfDmField());
        }
      }
    }
  }

}
