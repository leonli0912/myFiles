package com.sap.hcm.resume.collection.controller;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.hcp.HCPUserProvider;
import com.sap.hcm.resume.collection.integration.wechat.bean.JobDynSearchBean;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatJobService;
import com.sap.hcm.resume.collection.util.CandidateFileUtil;
import com.sap.hcm.resume.collection.util.MappingUtil;
import com.sap.security.um.user.User;

@Controller
@RequestMapping(value = "user")
public class HCPUserController extends ControllerBase {
  
  @Autowired
  private WechatJobService wechatJobService;
  
  @Autowired
  private Params params;
  
  private static final Logger logger = LoggerFactory.getLogger(HCPUserController.class);

  @RequestMapping(value = "/info", method = RequestMethod.GET)
  public @ResponseBody Map<String, Object> getUserInfo(HttpSession session, HttpServletRequest request)
      throws ServiceApplicationException {
    
    User loginUser = hcpUserProvider.getLoginUser(request);
    if (loginUser == null) {
      logger.error("failed to get login user from HCP");
      throw new ServiceApplicationException("failed to get login user from HCP");
    }
    Map<String, Object> userInfoMap = new HashMap<String, Object>();
    CompanyInfo compInfo = compInfoService.getCompanyInfo(params.getCompanyId());
    
    Map<String, Object> compSimpleInfo = new HashMap<String, Object>();
    if (compInfo != null) {
      compSimpleInfo.put("id", compInfo.getCompanyId());
      compSimpleInfo.put("logoId", compInfo.getLogoId());
      compSimpleInfo.put("name", compInfo.getCompanyName() == null ? compInfo.getCompanyId() : compInfo.getCompanyName());
      userInfoMap.put("company", compSimpleInfo);
    } else {
      logger.error("company info not found for " + params.getCompanyId());
      throw new ServiceApplicationException("company info not found for " + params.getCompanyId());
    }

    boolean isUserInRole = request.isUserInRole("SYSTEMADMIN");
    userInfoMap.put("isUserInRole", isUserInRole);
    
    //get total job count
    JobDynSearchBean searchBean = new JobDynSearchBean();
    searchBean.setCompanyId(compInfo.getCompanyId());
    Long totalJobCount = wechatJobService.getTotalCount(searchBean);
    if(totalJobCount != null){
      userInfoMap.put("jobCount", totalJobCount);
    }
    
    //get apply success count
    long userCount = wechatJobService.getTotalWechatUserNumber(compInfo.getCompanyId());
    userInfoMap.put("userCount", userCount);
    
    userInfoMap.put("name", loginUser.getName());
    return userInfoMap;
  }

  @RequestMapping(value = "/logout", method = RequestMethod.GET)
  public void logout(HttpServletRequest request, HttpServletResponse response,
      @RequestParam(value="saml2logoutresult", required=false) String saml2logoutresult) throws IOException, ServletException {
    
    if(saml2logoutresult != null && saml2logoutresult.indexOf("Success") >= 0){
      response.sendRedirect(request.getContextPath() + "/index");
    }else{
      HCPUserProvider.logout(request);
      response.setContentType("text/html");
      response.getWriter().write("<html>You have logged out successfully, click to <a href='"+ request.getContextPath() + "/index'>login</a> again</html>");
    }
  }
  
  @RequestMapping(value = "importDpcs", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
  public @ResponseBody Map<String, String> uploadDpcs(HttpServletRequest request, HttpServletResponse response) throws ServiceApplicationException {
    String dpcs = "";

    List<FileItem> items = CandidateFileUtil.handleFileUploadRequest(request);
    if (items != null && items.size() > 0) {
      for (FileItem item : items) {
        String filename = item.getName();
        String regex = ".*\\.txt";
        // check the file is txt file
        if (filename != null && MappingUtil.matchSingle(regex, filename) != null) {
          try {
            dpcs = new String(item.get(), StandardCharsets.UTF_8.name());
          } catch (Exception e) {
            logger.error("process upload file failed: " + e.getMessage());
            throw new ServiceApplicationException("process upload file failed");
          }
        }
      }
    }
    Map<String, String> data = new HashMap<String, String>();
    data.put("dpcs", dpcs);
    return data;
  }
}
