package com.sap.hcm.resume.collection.integration.wechat.controller;

import static org.junit.Assert.assertEquals;
import static org.mockito.Matchers.any;
import static org.mockito.Matchers.anyString;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

import java.io.ByteArrayInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.BDDMockito;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.core.JsonFactory;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.bean.SimpleJsonResponse;
import com.sap.hcm.resume.collection.context.TestContext;
import com.sap.hcm.resume.collection.context.WebAppContext;
import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.entity.Photo;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.wechat.entity.OAuthAccessToken;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatAuth;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatUser;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatAuthService;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatLoginService;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatUserService;
import com.sap.hcm.resume.collection.service.CompanyInfoService;
import com.sap.hcm.resume.collection.service.PhotoService;
import com.sap.hcm.resume.collection.util.CandidateFileUtil;
import com.sap.hcm.resume.collection.util.HTTPConnection;

@RunWith(PowerMockRunner.class)
@PowerMockRunnerDelegate(SpringJUnit4ClassRunner.class)
@WebAppConfiguration
@ContextConfiguration(classes = { TestContext.class, WebAppContext.class })
@PrepareForTest({ WechatNaviController.class, URL.class, CandidateFileUtil.class })
public class WechatNaviControllerTest {
  @Resource(type = WebApplicationContext.class)
  private WebApplicationContext webApplicationContext;

  private WechatNaviController wechatNaviController;

  @Resource(name = "wechatUserService")
  private WechatUserService wechatUserService;

  @Resource(name = "photoService")
  private PhotoService photoService;

  @Resource(name = "httpConnection")
  private HTTPConnection httpConnection;

  @Resource(name = "companyInfoService")
  private CompanyInfoService companyInfoService;

  @Resource(name = "wechatAuthService")
  private WechatAuthService wechatAuthService;

  private WechatLoginService wechatLoginService;

  @Autowired
  private Params params;

  @Before
  public void setUp() {
    reset(wechatUserService);
    reset(companyInfoService);
    MockitoAnnotations.initMocks(this);
    wechatNaviController = spy(new WechatNaviController());
    wechatLoginService = Mockito.mock(WechatLoginService.class);
    params.setCompanyId("sap");
    params.setWechatOpenId("abcdefg");
    // ReflectionTestUtils.setField(wechatNaviController, "userService", wechatUserService);
    ReflectionTestUtils.setField(wechatNaviController, "photoService", photoService);
    ReflectionTestUtils.setField(wechatNaviController, "httpConnection", httpConnection);
    ReflectionTestUtils.setField(wechatNaviController, "compInfoService", companyInfoService);
    ReflectionTestUtils.setField(wechatNaviController, "wechatLoginService", wechatLoginService);
    ReflectionTestUtils.setField(wechatNaviController, "wechatAuthService", wechatAuthService);
    ReflectionTestUtils.setField(wechatNaviController, "params", params);
  }

  @Test
  public void testLocalTestURL() throws Exception {
    MockHttpSession session = new MockHttpSession();
    MockHttpServletRequest request = new MockHttpServletRequest();
    MockHttpServletResponse response = new MockHttpServletResponse();
    String wechatId = "wechat001";
    String companyId = "sap";
    WechatAuth wechatAuth = null;
    when(wechatAuthService.getWechatAuthByOpenId(wechatId, companyId)).thenReturn(wechatAuth);
    wechatNaviController.localTest(session, request, response, wechatId);
  }

  @Test
  public void testVisitWechatPageSuccess() throws Exception {
    MockHttpSession session = new MockHttpSession();
    MockHttpServletRequest request = new MockHttpServletRequest();
    MockHttpServletResponse response = new MockHttpServletResponse();
    String wechatId = "wechat001";
    String companyId = "sap";

    ModelAndView mav = new ModelAndView();
    WechatUser info = null;
    when(wechatUserService.getUserInfoByEmail(wechatId, companyId)).thenReturn(info);
    when(wechatLoginService.getLoginURL(anyString(), anyString())).thenReturn("test");
    wechatNaviController.visitWechatPage(session, request, response, companyId, null);
  }

  @Test
  public void testVisitWechatPageFailWithValidateException() throws Exception {
    MockHttpSession session = new MockHttpSession();
    MockHttpServletRequest request = new MockHttpServletRequest();
    MockHttpServletResponse response = new MockHttpServletResponse();
    String wechatId = "wechat001";
    String companyId = "sap";

    ModelAndView mav = new ModelAndView();
    WechatUser info = null;
    when(wechatUserService.getUserInfoByEmail(wechatId, companyId)).thenReturn(info);
    when(wechatUserService.saveWechatUser(any(WechatUser.class))).thenThrow(new ServiceApplicationException("error"));
    when(wechatLoginService.getLoginURL(anyString(), anyString())).thenReturn("test");
    wechatNaviController.visitWechatPage(session, request, response, companyId, null);
  }

  @Test
  public void testChangeWechatPageFailWithInvalidCompany() throws Exception {
    MockHttpSession session = new MockHttpSession();
    MockHttpServletRequest request = new MockHttpServletRequest();
    MockHttpServletResponse response = new MockHttpServletResponse();
    String companyId = "sap";
    when(companyInfoService.getCompanyInfo(companyId)).thenReturn(null);
    ModelAndView mav = new ModelAndView();
    mav = wechatNaviController.changeWechatPage(session, request, response);
    assertEquals("invalid_company", mav.getViewName());
  }

  @Test
  public void testChangeWechatPageFailWithGetCompanyException() throws Exception {
    MockHttpSession session = new MockHttpSession();
    MockHttpServletRequest request = new MockHttpServletRequest();
    MockHttpServletResponse response = new MockHttpServletResponse();
    String companyId = "sap";
    when(companyInfoService.getCompanyInfo(companyId)).thenThrow(new ServiceApplicationException("error"));
    ModelAndView mav = new ModelAndView();
    mav = wechatNaviController.changeWechatPage(session, request, response);
    assertEquals("invalid_company", mav.getViewName());
  }

  @Test
  public void testChangeWechatPageSuccess() throws Exception {
    MockHttpSession session = new MockHttpSession();
    MockHttpServletRequest request = new MockHttpServletRequest();
    MockHttpServletResponse response = new MockHttpServletResponse();
    String companyId = "sap";
    CompanyInfo companyInfo = new CompanyInfo();
    when(companyInfoService.getCompanyInfo(companyId)).thenReturn(companyInfo);
    ModelAndView mav = new ModelAndView();
    mav = wechatNaviController.changeWechatPage(session, request, response);
    Map<String, Object> resultMap = mav.getModel();
    String CompanyInfoMapString = (String) resultMap.get("companyInfo");

    JsonFactory factory = new JsonFactory();
    ObjectMapper mapper = new ObjectMapper(factory);
    TypeReference<HashMap<String, Object>> typeRef = new TypeReference<HashMap<String, Object>>() {
    };

    HashMap<String, Object> result = mapper.readValue(new ByteArrayInputStream(CompanyInfoMapString.getBytes("UTF-8")),
        typeRef);
    assertEquals(true, result.get("isLogin"));
  }

  @Test(expected = ServiceApplicationException.class)
  public void testGotoWechatPageFailWithEmptyAppIdAndSecret() throws Exception {
    MockHttpSession session = new MockHttpSession();
    MockHttpServletRequest request = new MockHttpServletRequest();
    MockHttpServletResponse response = new MockHttpServletResponse();
    String companyId = "sap";
    String code = "abcd";

    ModelAndView mav = new ModelAndView();
    CompanyInfo companyInfo = new CompanyInfo();
    when(companyInfoService.getCompanyInfo(companyId)).thenReturn(companyInfo);

    mav = wechatNaviController.gotoWechatPage(session, request, response, code);
  }

  @Test
  public void testGotoWechatPageSuccess() throws Exception {
    MockHttpSession session = new MockHttpSession();
    MockHttpServletRequest request = new MockHttpServletRequest();
    MockHttpServletResponse response = new MockHttpServletResponse();
    String companyId = "sap";
    String code = "abcd";
    String access_token = "access_token123";
    String openid = "123";

    OAuthAccessToken accessToken = new OAuthAccessToken();
    accessToken.setAccessToken(access_token);
    accessToken.setOpenId(openid);

    when(wechatLoginService.getOAuthAccessToken(code)).thenReturn(accessToken);

    ModelAndView mav = new ModelAndView();
    CompanyInfo companyInfo = new CompanyInfo();
    companyInfo.setAppId("1234");
    companyInfo.setAppSecret("pwd");
    when(companyInfoService.getCompanyInfo(companyId)).thenReturn(companyInfo);

    WechatUser user = new WechatUser();
    when(wechatUserService.getUserInfoByEmail(accessToken.getOpenId(), companyId)).thenReturn(user);

    mav = wechatNaviController.gotoWechatPage(session, request, response, code);
    assertEquals("redirect:/wechat/index/", mav.getViewName());
  }

  @Test(expected = ServiceApplicationException.class)
  public void testGotoWechatPageFailWithException() throws Exception {
    MockHttpSession session = new MockHttpSession();
    MockHttpServletRequest request = new MockHttpServletRequest();
    MockHttpServletResponse response = new MockHttpServletResponse();
    String companyId = "sap";
    String code = "abcd";
    String access_token = "access_token123";
    String openid = "";
    String nickname = "jeremy";
    String headimgurl = "https://abc.com";
    Map<String, String> accessTokenMap = new HashMap<String, String>();
    accessTokenMap.put("access_token", access_token);
    accessTokenMap.put("openid", openid);
    ObjectMapper mapper = new ObjectMapper();
    String accessTokenJsonString = mapper.writeValueAsString(accessTokenMap);
    Map<String, String> userInfoMap = new HashMap<String, String>();
    userInfoMap.put("nickname", nickname);
    userInfoMap.put("headimgurl", headimgurl);
    ObjectMapper mapper1 = new ObjectMapper();
    String UserInfoJsonString = mapper1.writeValueAsString(userInfoMap);
    WechatUser info = new WechatUser();
    info.setWechatId(openid);
    info.setCompanyId(companyId);
    when(wechatUserService.getUserInfoByEmail(openid, companyId)).thenReturn(info);
    String accessTokenURL =

    "https://api.weixin.qq.com/sns/oauth2/access_token?appid=1234&secret=pwd&code=abcd&grant_type=authorization_code";
    String userTokenURL = "https://api.weixin.qq.com/sns/userinfo?access_token=access_token123&openid=&lang=zh_CN";
    ModelAndView mav = new ModelAndView();
    CompanyInfo companyInfo = new CompanyInfo();
    companyInfo.setAppId("1234");
    companyInfo.setAppSecret("pwd");
    when(companyInfoService.getCompanyInfo(companyId)).thenReturn(companyInfo);
    when(httpConnection.load(accessTokenURL, "GET", null, null, null)).thenReturn(accessTokenJsonString);
    when(httpConnection.load(userTokenURL, "GET", null, null, null)).thenReturn(UserInfoJsonString);

    HttpURLConnection conn = PowerMockito.mock(HttpURLConnection.class);
    URL portraitUrl = PowerMockito.mock(URL.class);
    PowerMockito.whenNew(URL.class).withArguments(headimgurl).thenReturn(portraitUrl);
    PowerMockito.doReturn(conn).when(portraitUrl).openConnection();
    Mockito.doNothing().when(conn).setDoInput(true);
    Mockito.doNothing().when(conn).connect();
    when(photoService.saveImg(any(Photo.class))).thenReturn(new Photo());
    when(wechatUserService.saveWechatUser(any(WechatUser.class))).thenThrow(new ServiceApplicationException("error"));
    InputStream is = null;
    Mockito.doReturn(is).when(conn).getInputStream();
    PowerMockito.mockStatic(CandidateFileUtil.class);
    byte[] item = "heheda".getBytes();
    BDDMockito.given(CandidateFileUtil.cropImage(is, 200, 200)).willReturn(item);
    mav = wechatNaviController.gotoWechatPage(session, request, response, code);
  }

  @Test
  public void testGetWechatJsSignature() throws ServiceApplicationException, IOException {
    String companyId = "sap";
    String url = "http://www.baidu.com";
    MockHttpServletRequest request = new MockHttpServletRequest();
    wechatLoginService.getWechatJsAPIConfiguration(companyId, url, request);
    wechatNaviController.getWechatJsSignature(url, request);
  }

  @Test
  public void testCreateMenuSuccess() throws FileNotFoundException, ServiceApplicationException, IOException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    String appId = "abc";
    String appSecret = "efg";
    String accessToken = "hij";
    String result = "success";

    when(wechatLoginService.getAccessToken("sap", appId, appSecret)).thenReturn(accessToken);
    when(wechatLoginService.createMenu(accessToken, "")).thenReturn(result);
    SimpleJsonResponse rsp = wechatNaviController.createMenu(request, appId, appSecret);
    assertEquals(0, rsp.getCode());
  }

  @Test
  public void testCreateMenuFail() throws FileNotFoundException, ServiceApplicationException, IOException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    String appId = "abc";
    String appSecret = "efg";
    String accessToken = "hij";
    String result = "fail";
    when(wechatLoginService.getAccessToken("sap", appId, appSecret)).thenReturn(accessToken);
    when(wechatLoginService.createMenu(accessToken, null)).thenReturn(result);
    SimpleJsonResponse rsp = wechatNaviController.createMenu(request, appId, appSecret);
    assertEquals(-1, rsp.getCode());
  }

  @Test(expected = ServiceApplicationException.class)
  public void testCreateMenuWithException() throws FileNotFoundException, ServiceApplicationException, IOException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    String appId = "";
    String appSecret = "efg";
    String accessToken = "hij";
    String result = "fail";
    when(wechatLoginService.getAccessToken("sap", appId, appSecret)).thenReturn(accessToken);
    when(wechatLoginService.createMenu(accessToken, null)).thenReturn(result);
    SimpleJsonResponse rsp = wechatNaviController.createMenu(request, appId, appSecret);
  }
}
