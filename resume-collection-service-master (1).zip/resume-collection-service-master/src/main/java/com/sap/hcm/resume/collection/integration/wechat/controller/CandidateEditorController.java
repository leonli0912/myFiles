package com.sap.hcm.resume.collection.integration.wechat.controller;

import java.io.IOException;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

import javax.persistence.PersistenceException;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sap.hcm.resume.collection.bean.ActionType;
import com.sap.hcm.resume.collection.bean.LogObjectType;
import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.bean.SimpleJsonResponse;
import com.sap.hcm.resume.collection.controller.ControllerBase;
import com.sap.hcm.resume.collection.entity.ChangeLog;
import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.entity.view.CandidateBgCertificateVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgEducationVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgFamilyVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgLanguageVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgWorkExprVO;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileConstants;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileExtVO;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileWrapperVO;
import com.sap.hcm.resume.collection.entity.view.JobApplicationRequiredFieldVO;
import com.sap.hcm.resume.collection.entity.view.JobApplyMappingVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.bean.ApplyDataModelMappingItem;
import com.sap.hcm.resume.collection.integration.bean.CandProfileDataModelMapping;
import com.sap.hcm.resume.collection.integration.bean.DataModelMappingItem;
import com.sap.hcm.resume.collection.integration.sf.bean.SFPicklistCacheEntityType;
import com.sap.hcm.resume.collection.integration.sf.bean.SFPicklistItem;
import com.sap.hcm.resume.collection.integration.sf.service.SFPicklistCacheService;
import com.sap.hcm.resume.collection.integration.sf.service.SFPicklistService;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatUserResumeMapping;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatUserService;
import com.sap.hcm.resume.collection.integration.wechat.util.WechatResumeHelper;
import com.sap.hcm.resume.collection.service.CandidateProfileService;
import com.sap.hcm.resume.collection.service.ChangeLogService;
import com.sap.hcm.resume.collection.service.DataModelMappingService;
import com.sap.hcm.resume.collection.util.CandidateDateUtil;
import com.sap.hcm.resume.collection.util.CandidateProfileHelper;
import com.sap.hcm.resume.collection.util.ChangeLogUtil;

@Controller
@RequestMapping(value = "/cv")
public class CandidateEditorController extends ControllerBase {

  private static final Logger logger = LoggerFactory.getLogger(CandidateEditorController.class);

  @Autowired
  private WechatUserService wechatUserService;

  @Autowired
  private CandidateProfileService candidateProfileService;

  @Autowired
  private WechatResumeHelper wechatResumeHelper;

  @Autowired
  private DataModelMappingService dataModelMappingService;

  @Autowired
  private ChangeLogUtil changeLogUtil;

  @Autowired
  private ChangeLogService changeLogService;

  @Autowired
  private SFPicklistCacheService pklCacheService;

  @Autowired
  private CandidateProfileHelper candidateProfileHelper;
  
  @Autowired
  private SFPicklistService sFPicklistService;

  @Autowired
  private Params params;

  @RequestMapping(value = "/candidateList", method = RequestMethod.GET)
  public @ResponseBody Map<String, Object> getCandidateList(HttpServletRequest request)
      throws ServiceApplicationException {

    String userEmail = params.getUserEmail();
    String companyId = params.getCompanyId();

    List<WechatUserResumeMapping> candidateList = wechatUserService.getCandidateListByWechatId(userEmail, companyId);
    Map<String, Object> map = new HashMap<String, Object>();
    map.put("candidateList", candidateList);

    if (candidateList != null && !candidateList.isEmpty()) {
      Map<Long, Object> ratioMap = new HashMap<Long, Object>();
      for (WechatUserResumeMapping wechatUserResumeMapping : candidateList) {
        Long candidateId = wechatUserResumeMapping.getCandidateId();
        Map<String, Object> ratioDetail = this.calculateResumeCompletionRatio(candidateId, companyId, request.getLocale());
        ratioMap.put(candidateId, ratioDetail);
      }
      map.put("completion", ratioMap);
    }
    return map;
  }

  public Map<String, Object> calculateResumeCompletionRatio(Long candidateId, String companyId, Locale locale)
      throws ServiceApplicationException {
    float ratio = 0;
    float totalRequiredFieldNum = 0;
    float totalRequiredFieldWithValue = 0;
    Set<String> missingFields = new HashSet<String>();
    Map<String, Object> ratioDetail = new HashMap<String, Object>();
    CandidateProfileVO profileVO = candidateProfileService.getCandidateProfileById(candidateId);
    if (profileVO == null) {
      return ratioDetail;
    }

    CompanyInfo compInfo = this.compInfoService.getCompanyInfo(companyId);
    CandProfileDataModelMapping profileDMMapping = dataModelMappingService
        .getCandidateProfileDataModelMappingById(compInfo.getDmMappingId());

    if (profileDMMapping == null) {
      return ratioDetail;
    }

    // check basic profile
    if (profileDMMapping.getProfile() != null) {
      for (DataModelMappingItem item : profileDMMapping.getProfile()) {
        if (item.isRequired() && !StringUtils.isEmpty(item.getTo())) {
          totalRequiredFieldNum++;

          // check whether value is exist
          Object value = candidateProfileHelper.getValueFromCandidateProfile(profileVO, item.getFrom());
          if (!StringUtils.isEmpty(value)) {
            totalRequiredFieldWithValue++;
          } else {
            missingFields.add(item.getLabel());
          }
        }
      }
    }

    float bgRequiredNum = 0;
    // check bg Elements work experience
    if (profileDMMapping.getAliases().get(CandidateProfileConstants.BG_WORKEXPR_NAME) != null) {
      bgRequiredNum = 0;
      for (DataModelMappingItem item : profileDMMapping.getWorkExprs()) {
        if (item.isRequired() && !StringUtils.isEmpty(item.getTo())) {
          bgRequiredNum++;

          if (profileVO.getWorkExprs() != null && profileVO.getWorkExprs().size() > 0) {
            for (CandidateBgWorkExprVO exprVO : profileVO.getWorkExprs()) {
              Object value = candidateProfileHelper.getPropertyValueFromObject(exprVO, item.getFrom());
              if (!StringUtils.isEmpty(value)) {
                totalRequiredFieldWithValue++;
              } else {
                missingFields.add(item.getLabel());
              }
            }
          } else {
            missingFields.add("LB_TITLE_WORKEXPR");
          }
        }
      }
      if (profileVO.getWorkExprs() != null && profileVO.getWorkExprs().size() > 0) {
        bgRequiredNum = bgRequiredNum * profileVO.getWorkExprs().size();
      }
      totalRequiredFieldNum = totalRequiredFieldNum + bgRequiredNum;
    }

    // check bg Elements education
    if (profileDMMapping.getAliases().get(CandidateProfileConstants.BG_EDUC_NAME) != null) {
      bgRequiredNum = 0;
      for (DataModelMappingItem item : profileDMMapping.getEducation()) {
        if (item.isRequired() && !StringUtils.isEmpty(item.getTo())) {
          bgRequiredNum++;

          if (profileVO.getEducation() != null && profileVO.getEducation().size() > 0) {
            for (CandidateBgEducationVO educVO : profileVO.getEducation()) {
              Object value = candidateProfileHelper.getPropertyValueFromObject(educVO, item.getFrom());
              if (!StringUtils.isEmpty(value)) {
                totalRequiredFieldWithValue++;
              } else {
                missingFields.add(item.getLabel());
              }
            }
          } else {
            missingFields.add("LB_TITLE_EDUCATION");
          }
        }
      }
      if (profileVO.getEducation() != null && profileVO.getEducation().size() > 0) {
        bgRequiredNum = bgRequiredNum * profileVO.getEducation().size();
      }
      totalRequiredFieldNum = totalRequiredFieldNum + bgRequiredNum;
    }

    // check bg Elements languages
    if (profileDMMapping.getAliases().get(CandidateProfileConstants.BG_LANGU_NAME) != null) {
      bgRequiredNum = 0;
      for (DataModelMappingItem item : profileDMMapping.getLanguages()) {
        if (item.isRequired() && !StringUtils.isEmpty(item.getTo())) {
          bgRequiredNum++;

          if (profileVO.getLanguages() != null && profileVO.getLanguages().size() > 0) {
            for (CandidateBgLanguageVO langVO : profileVO.getLanguages()) {
              Object value = candidateProfileHelper.getPropertyValueFromObject(langVO, item.getFrom());
              if (!StringUtils.isEmpty(value)) {
                totalRequiredFieldWithValue++;
              } else {
                missingFields.add(item.getLabel());
              }
            }
          } else {
            missingFields.add("LB_TITLE_LANGUAGE");
          }
        }
      }
      if (profileVO.getLanguages() != null && profileVO.getLanguages().size() > 0) {
        bgRequiredNum = bgRequiredNum * profileVO.getLanguages().size();
      }
      totalRequiredFieldNum = totalRequiredFieldNum + bgRequiredNum;
    }

    // check bg Elements cert
    if (profileDMMapping.getAliases().get(CandidateProfileConstants.BG_CERT_NAME) != null) {
      bgRequiredNum = 0;
      for (DataModelMappingItem item : profileDMMapping.getCertificates()) {
        if (item.isRequired() && !StringUtils.isEmpty(item.getTo())) {
          bgRequiredNum++;

          if (profileVO.getCertificates() != null && profileVO.getCertificates().size() > 0) {
            for (CandidateBgCertificateVO langVO : profileVO.getCertificates()) {
              Object value = candidateProfileHelper.getPropertyValueFromObject(langVO, item.getFrom());
              if (!StringUtils.isEmpty(value)) {
                totalRequiredFieldWithValue++;
              } else {
                missingFields.add(item.getLabel());
              }
            }
          } else {
            missingFields.add("LB_TITLE_CERTIFICATE");
          }
        }
      }
      if (profileVO.getCertificates() != null && profileVO.getCertificates().size() > 0) {
        bgRequiredNum = bgRequiredNum * profileVO.getCertificates().size();
      }
      totalRequiredFieldNum = totalRequiredFieldNum + bgRequiredNum;
    }

    // check bg Elements family
    if (profileDMMapping.getAliases().get(CandidateProfileConstants.BG_FAMI_NAME) != null) {
      bgRequiredNum = 0;
      for (DataModelMappingItem item : profileDMMapping.getFamilies()) {
        if (item.isRequired() && !StringUtils.isEmpty(item.getTo())) {
          bgRequiredNum++;

          if (profileVO.getFamilies() != null && profileVO.getFamilies().size() > 0) {
            for (CandidateBgFamilyVO langVO : profileVO.getFamilies()) {
              Object value = candidateProfileHelper.getPropertyValueFromObject(langVO, item.getFrom());
              if (!StringUtils.isEmpty(value)) {
                totalRequiredFieldWithValue++;
              } else {
                missingFields.add(item.getLabel());
              }
            }
          } else {
            missingFields.add("LB_TITLE_FAMILY");
          }
        }
      }
      if (profileVO.getFamilies() != null && profileVO.getFamilies().size() > 0) {
        bgRequiredNum = bgRequiredNum * profileVO.getFamilies().size();
      }
      totalRequiredFieldNum = totalRequiredFieldNum + bgRequiredNum;
    }

    JobApplyMappingVO jobApplyMappingVO = dataModelMappingService.getApplyDataModelMappingByCompanyId(companyId);
    List<JobApplicationRequiredFieldVO> jobApplicationReqFieldList = candidateProfileService
        .getJobApplicationReqFieldsById(candidateId);
    if (jobApplyMappingVO != null && jobApplyMappingVO.getItemList() != null
        && jobApplyMappingVO.getItemList().size() != 0) {
      for (ApplyDataModelMappingItem applyItem : jobApplyMappingVO.getItemList()) {
        if ("candidateInput".equals(applyItem.getSourceNameType()) && applyItem.isRequired()) {
          totalRequiredFieldNum++;
          if (jobApplicationReqFieldList != null && jobApplicationReqFieldList.size() != 0) {
            for (JobApplicationRequiredFieldVO appReqValue : jobApplicationReqFieldList) {
              if (applyItem.getSfDmField().equals(appReqValue.getFieldName())
                  && !StringUtils.isEmpty(appReqValue.getFieldValue())) {
                totalRequiredFieldWithValue++;
              } else if (applyItem.getSfDmField().equals(appReqValue.getFieldName())
                  && StringUtils.isEmpty(appReqValue.getFieldValue())) {
                String label = candidateProfileHelper.getTranslatedLabel(applyItem, locale);
                if(label != null){
                  missingFields.add(label);
                }
              }
            }
          }
        }
      }
    }

    if (totalRequiredFieldNum > 0) {
      ratio = (totalRequiredFieldWithValue / totalRequiredFieldNum);
    }
    ratioDetail.put("ratio", ratio);
    ratioDetail.put("missing", missingFields);
    return ratioDetail;
  }
  
  
  @RequestMapping(value = "/candidatePreview", method = RequestMethod.GET)
  public @ResponseBody CandidateProfileWrapperVO getCandidateList(@RequestParam("candidateId") Long candidateId)
      throws ServiceApplicationException {

    CandidateProfileWrapperVO candidateProfileWrapperVO = new CandidateProfileWrapperVO();
    CandidateProfileVO candidateProfileVO = candidateProfileService.getCandidateProfileById(candidateId);
    List<JobApplicationRequiredFieldVO> fieldVOList = candidateProfileService
        .getJobApplicationReqFieldsById(candidateId);
    candidateProfileWrapperVO.setCandidateProfileVO(candidateProfileVO);
    candidateProfileWrapperVO.setFieldVOList(fieldVOList);
    return candidateProfileWrapperVO;
  }

  @RequestMapping(value = "/candidatePreviewEmpty", method = RequestMethod.GET)
  public @ResponseBody CandidateProfileWrapperVO getEmptyCandidateList() throws ServiceApplicationException {

    CandidateProfileWrapperVO candidateProfileWrapperVO = new CandidateProfileWrapperVO();
    CandidateProfileVO candidateProfileVO = new CandidateProfileVO();
    List<JobApplicationRequiredFieldVO> fieldVOList = candidateProfileService.getJobApplicationReqFieldsById(null);
    candidateProfileWrapperVO.setCandidateProfileVO(candidateProfileVO);
    candidateProfileWrapperVO.setFieldVOList(fieldVOList);
    return candidateProfileWrapperVO;
  }

  @RequestMapping(value = "/missingFields", method = RequestMethod.GET)
  public @ResponseBody Map<String, Object> getMissingRequiredField(HttpServletRequest request,
      @RequestParam("candidateId") Long candidateId) throws ServiceApplicationException {
    String companyId = params.getCompanyId();
    Locale locale = request.getLocale();
    if (!StringUtils.isEmpty(companyId)) {
      return this.calculateResumeCompletionRatio(candidateId, companyId, locale);
    }
    return Collections.emptyMap();
  }

  @RequestMapping(value = "/saveCandidate", method = RequestMethod.POST)
  public @ResponseBody CandidateProfileWrapperVO saveCandidate(HttpServletRequest request,
      @RequestBody CandidateProfileWrapperVO candidateProfileWrapperVO) throws ServiceApplicationException {

    String userEmail = params.getUserEmail();
    String companyId = params.getCompanyId();

    String type = null;
    try {
      if (candidateProfileWrapperVO.getCandidateProfileVO().getCandidateId() == null) {
        type = "add Candidate Profile";
        candidateProfileWrapperVO.getCandidateProfileVO().setCompanyId(companyId);
      } else {
        type = "edit Candidate Profile";
      }
      CandidateProfileVO profileVO = this.saveCandidateToDB(candidateProfileWrapperVO.getCandidateProfileVO(), type);
      candidateProfileService.saveRequiredFieldsFromCandidateProfileExtVO(profileVO.getCandidateId(),
          candidateProfileWrapperVO.getFieldVOList());

      WechatUserResumeMapping userResumeMapping = new WechatUserResumeMapping();
      if (candidateProfileWrapperVO.getCandidateProfileVO().getCandidateId() != null) {
        userResumeMapping.setCandidateId(candidateProfileWrapperVO.getCandidateProfileVO().getCandidateId());
      }
      userResumeMapping.setWechatId(userEmail);
      userResumeMapping.setCompanyId(companyId);
      userResumeMapping.setLanguage(Locale.CHINA.getLanguage());
      userResumeMapping.setResumeName("My Resume "
          + CandidateDateUtil.formatDate2String(new Date(), "yyyy-MM-dd HH:mm:ss"));
      userResumeMapping.setVendorName("wechat");

      wechatUserService.saveUserResumeMapping(userResumeMapping);
      if ("add Candidate Profile".equals(type)) {
        changeLogUtil.saveCandidateProfileChangeHistory(candidateProfileWrapperVO.getCandidateProfileVO()
            .getCandidateId().toString(), userResumeMapping.getResumeName(), ActionType.ADD, params.getUserEmail(),
            type, params.getCompanyId());
      }
    } catch (Exception e) {
      logger.error("save candidate failed with exception: " + e.getMessage());
      throw new ServiceApplicationException("save candidate failed");
    }

    return candidateProfileWrapperVO;
  }

  @RequestMapping(value = "/editWorkExp", method = RequestMethod.GET)
  public @ResponseBody CandidateBgWorkExprVO editWorkExp(@RequestParam("candidateId") Long candidateId,
      @RequestParam("workExpId") int workExpId) throws ServiceApplicationException {

    CandidateProfileVO candidateProfileVO = candidateProfileService.getCandidateProfileById(candidateId);
    List<CandidateBgWorkExprVO> candidateBgWorkExprVOList = candidateProfileVO.getWorkExprs();
    CandidateBgWorkExprVO candidateBgWorkExprVO = candidateBgWorkExprVOList.get(workExpId);

    return candidateBgWorkExprVO;
  }

  @RequestMapping(value = "/saveWorkExp", method = RequestMethod.POST)
  public @ResponseBody SimpleJsonResponse saveWorkExp(HttpServletRequest request,
      @RequestBody CandidateBgWorkExprVO candidateBgWorkExprVO) throws ServiceApplicationException {

    SimpleJsonResponse rsp = new SimpleJsonResponse();
    String type = null;

    try {
      if ("NOW".equalsIgnoreCase(candidateBgWorkExprVO.getEndDate())) {
        candidateBgWorkExprVO.setIsPresent(true);
        candidateBgWorkExprVO.setPresentEmployer("Y");
      } else {
        candidateBgWorkExprVO.setIsPresent(false);
        candidateBgWorkExprVO.setPresentEmployer("N");
      }
      CandidateProfileVO candidateProfileVO = candidateProfileService.getCandidateProfileById(Long.valueOf(request
          .getParameter("candidateId")));
      List<CandidateBgWorkExprVO> candidateBgWorkExprVOList = candidateProfileVO.getWorkExprs();
      String count = request.getParameter("workExpId");
      if (!StringUtils.isEmpty(count)) {
        int row = Integer.valueOf(count);
        candidateBgWorkExprVOList.remove(row);
        candidateBgWorkExprVOList.add(row, candidateBgWorkExprVO);
        type = "edit Work Experience";
      } else {
        candidateBgWorkExprVOList.add(candidateBgWorkExprVO);
        type = "add Work Experience";
      }

      this.saveCandidateToDB(candidateProfileVO, type);

      rsp.setCode(0);
      rsp.setMessage("success");
    } catch (PersistenceException e) {
      rsp.setCode(-1);
      rsp.setMessage("failed");
    }

    return rsp;
  }

  @RequestMapping(value = "/deleteBgElement", method = RequestMethod.GET)
  public @ResponseBody SimpleJsonResponse deleteBgElement(HttpServletRequest request,
      @RequestParam(value = "candidateId") Long candidateId, @RequestParam(value = "elementType") String elementType,
      @RequestParam(value = "rowNo") int rowNo) throws ServiceApplicationException {

    SimpleJsonResponse rsp = new SimpleJsonResponse();
    String type = null;
    try {
      CandidateProfileVO candidateProfileVO = candidateProfileService.getCandidateProfileById(candidateId);
      if (CandidateProfileConstants.BG_WORKEXPR_NAME.equals(elementType)) {
        candidateProfileVO.getWorkExprs().remove(rowNo);
        type = "delete WorkExperience";
      }
      if (CandidateProfileConstants.BG_LANGU_NAME.equals(elementType)) {
        candidateProfileVO.getLanguages().remove(rowNo);
        type = "delete Language";
      }
      if (CandidateProfileConstants.BG_EDUC_NAME.equals(elementType)) {
        candidateProfileVO.getEducation().remove(rowNo);
        type = "delete Education";
      }
      if (CandidateProfileConstants.BG_CERT_NAME.equals(elementType)) {
        candidateProfileVO.getCertificates().remove(rowNo);
        type = "delete Certificate";
      }
      if (CandidateProfileConstants.BG_FAMI_NAME.equals(elementType)) {
        candidateProfileVO.getFamilies().remove(rowNo);
        type = "delete Family";
      }

      this.saveCandidateToDB(candidateProfileVO, type);

      rsp.setCode(0);
      rsp.setMessage("success");
    } catch (PersistenceException e) {
      rsp.setCode(-1);
      rsp.setMessage("failed");
    }

    return rsp;
  }

  @RequestMapping(value = "/editEducation", method = RequestMethod.GET)
  public @ResponseBody CandidateBgEducationVO editEducation(@RequestParam("candidateId") Long candidateId,
      @RequestParam("educId") int educId) throws ServiceApplicationException {

    CandidateProfileVO candidateProfileVO = candidateProfileService.getCandidateProfileById(candidateId);
    List<CandidateBgEducationVO> candidateBgEducationVOList = candidateProfileVO.getEducation();
    CandidateBgEducationVO candidateBgEducationVO = candidateBgEducationVOList.get(educId);

    return candidateBgEducationVO;
  }

  @RequestMapping(value = "/saveEducation", method = RequestMethod.POST)
  public @ResponseBody SimpleJsonResponse saveEducation(HttpServletRequest request,
      @RequestBody CandidateBgEducationVO candidateBgEducationVO) throws ServiceApplicationException {

    SimpleJsonResponse rsp = new SimpleJsonResponse();
    String type = null;

    try {
      CandidateProfileVO candidateProfileVO = candidateProfileService.getCandidateProfileById(Long.valueOf(request
          .getParameter("candidateId")));
      List<CandidateBgEducationVO> candidateBgEducationVOList = candidateProfileVO.getEducation();
      String count = request.getParameter("educId");
      if (!StringUtils.isEmpty(count)) {
        int row = Integer.valueOf(count);
        candidateBgEducationVOList.remove(row);
        candidateBgEducationVOList.add(row, candidateBgEducationVO);
        type = "edit Education";
      } else {
        candidateBgEducationVOList.add(candidateBgEducationVO);
        type = "add Education";
      }

      this.saveCandidateToDB(candidateProfileVO, type);
      rsp.setCode(0);
      rsp.setMessage("success");
    } catch (PersistenceException e) {
      rsp.setCode(-1);
      rsp.setMessage("failed");
    }

    return rsp;
  }

  @RequestMapping(value = "/editLanguage", method = RequestMethod.GET)
  public @ResponseBody CandidateBgLanguageVO editLanguage(@RequestParam("candidateId") Long candidateId,
      @RequestParam("langId") int langId) throws ServiceApplicationException {

    CandidateProfileVO candidateProfileVO = candidateProfileService.getCandidateProfileById(candidateId);
    List<CandidateBgLanguageVO> candidateBgLanguageVOList = candidateProfileVO.getLanguages();
    CandidateBgLanguageVO candidateBgLanguageVO = candidateBgLanguageVOList.get(langId);

    return candidateBgLanguageVO;
  }

  @RequestMapping(value = "/saveLanguage", method = RequestMethod.POST)
  public @ResponseBody SimpleJsonResponse saveLanguage(HttpServletRequest request,
      @RequestBody CandidateBgLanguageVO candidateBgLanguageVO) throws ServiceApplicationException {

    SimpleJsonResponse rsp = new SimpleJsonResponse();
    String type = null;

    try {
      CandidateProfileVO candidateProfileVO = candidateProfileService.getCandidateProfileById(Long.valueOf(request
          .getParameter("candidateId")));
      List<CandidateBgLanguageVO> candidateBgLanguageVOList = candidateProfileVO.getLanguages();
      String count = request.getParameter("langId");
      if (!StringUtils.isEmpty(count)) {
        int row = Integer.valueOf(count);
        candidateBgLanguageVOList.remove(row);
        candidateBgLanguageVOList.add(row, candidateBgLanguageVO);
        type = "edit Language";
      } else {
        candidateBgLanguageVOList.add(candidateBgLanguageVO);
        type = "add Language";
      }

      this.saveCandidateToDB(candidateProfileVO, type);
      rsp.setCode(0);
      rsp.setMessage("success");
    } catch (PersistenceException e) {
      rsp.setCode(-1);
      rsp.setMessage("failed");
    }

    return rsp;
  }

  @RequestMapping(value = "/editCertificate", method = RequestMethod.GET)
  public @ResponseBody CandidateBgCertificateVO editCertificate(@RequestParam("candidateId") Long candidateId,
      @RequestParam("certId") int certId) throws ServiceApplicationException {

    CandidateProfileVO candidateProfileVO = candidateProfileService.getCandidateProfileById(candidateId);
    List<CandidateBgCertificateVO> candidateBgCertificateVOList = candidateProfileVO.getCertificates();
    CandidateBgCertificateVO candidateBgCertificateVO = candidateBgCertificateVOList.get(certId);

    return candidateBgCertificateVO;
  }

  @RequestMapping(value = "/saveCertificate", method = RequestMethod.POST)
  public @ResponseBody SimpleJsonResponse saveCertificate(HttpServletRequest request,
      @RequestBody CandidateBgCertificateVO candidateBgCertificateVO) throws ServiceApplicationException {

    SimpleJsonResponse rsp = new SimpleJsonResponse();
    String type = null;

    try {
      CandidateProfileVO candidateProfileVO = candidateProfileService.getCandidateProfileById(Long.valueOf(request
          .getParameter("candidateId")));
      List<CandidateBgCertificateVO> candidateBgCertificateVOList = candidateProfileVO.getCertificates();
      String count = request.getParameter("certId");
      if (!StringUtils.isEmpty(count)) {
        int row = Integer.valueOf(count);
        candidateBgCertificateVOList.remove(row);
        candidateBgCertificateVOList.add(row, candidateBgCertificateVO);
        type = "edit Certificate";
      } else {
        candidateBgCertificateVOList.add(candidateBgCertificateVO);
        type = "add Certificate";
      }

      this.saveCandidateToDB(candidateProfileVO, type);
      rsp.setCode(0);
      rsp.setMessage("success");
    } catch (PersistenceException e) {
      rsp.setCode(-1);
      rsp.setMessage("failed");
    }

    return rsp;
  }

  @RequestMapping(value = "/editFamily", method = RequestMethod.GET)
  public @ResponseBody CandidateBgFamilyVO editFamily(@RequestParam("candidateId") Long candidateId,
      @RequestParam("famId") int famId) throws ServiceApplicationException {

    CandidateProfileVO candidateProfileVO = candidateProfileService.getCandidateProfileById(candidateId);
    List<CandidateBgFamilyVO> candidateBgFamilyVOList = candidateProfileVO.getFamilies();
    CandidateBgFamilyVO candidateBgFamilyVO = candidateBgFamilyVOList.get(famId);

    return candidateBgFamilyVO;
  }

  @RequestMapping(value = "/saveFamily", method = RequestMethod.POST)
  public @ResponseBody SimpleJsonResponse saveFamily(HttpServletRequest request,
      @RequestBody CandidateBgFamilyVO candidateBgFamilyVO) throws ServiceApplicationException {

    SimpleJsonResponse rsp = new SimpleJsonResponse();
    String type = null;

    try {
      CandidateProfileVO candidateProfileVO = candidateProfileService.getCandidateProfileById(Long.valueOf(request
          .getParameter("candidateId")));
      List<CandidateBgFamilyVO> candidateBgFamilyVOList = candidateProfileVO.getFamilies();
      String count = request.getParameter("famId");
      if (!StringUtils.isEmpty(count)) {
        int row = Integer.valueOf(count);
        candidateBgFamilyVOList.remove(row);
        candidateBgFamilyVOList.add(row, candidateBgFamilyVO);
        type = "edit Family";
      } else {
        candidateBgFamilyVOList.add(candidateBgFamilyVO);
        type = "add Family";
      }

      this.saveCandidateToDB(candidateProfileVO, type);
      rsp.setCode(0);
      rsp.setMessage("success");
    } catch (PersistenceException e) {
      rsp.setCode(-1);
      rsp.setMessage("failed");
    }

    return rsp;
  }

  private CandidateProfileVO saveCandidateToDB(CandidateProfileVO profileVO, String type)
      throws ServiceApplicationException {
    if (profileVO != null) {
      CandidateProfileExtVO extProfile = profileVO.getExtProfile();
      if (extProfile == null) {
        extProfile = new CandidateProfileExtVO();
      }

      try {
        extProfile.setAttachment(wechatResumeHelper.generateResumePDF(profileVO));
      } catch (IOException e) {
        extProfile.setAttachment(null);
      }
      profileVO.setExtProfile(extProfile);

      candidateProfileService.saveCandidateProfile(profileVO);
      ActionType actionType = null;
      if (type.startsWith("add")) {
        actionType = ActionType.ADD;
      } else if (type.startsWith("edit")) {
        actionType = ActionType.EDT;
      } else if (type.startsWith("delete")) {
        actionType = ActionType.DEL;
      }
      try {
        if (!"add Candidate Profile".equals(type)) {
          WechatUserResumeMapping wechatUserResumeMapping = wechatUserService.getCandidateByCandidateId(profileVO
              .getCandidateId());
          changeLogUtil.saveCandidateProfileChangeHistory(profileVO.getCandidateId().toString(),
              wechatUserResumeMapping.getResumeName(), actionType, params.getUserEmail(), type, params.getCompanyId());
        }
      } catch (ServiceApplicationException e) {
        logger.error("save candidate profile edit/add history " + e.getMessage());
      }
    }
    return profileVO;
  }

  @RequestMapping(value = "/deleteCandidate", method = RequestMethod.DELETE)
  public @ResponseBody SimpleJsonResponse deleteCandidate(HttpServletRequest request,
      @RequestParam("candidateId") Long candidateId) throws ServiceApplicationException {
    int res = -1;
    WechatUserResumeMapping wechatUserResumeMapping = wechatUserService.getCandidateByCandidateId(candidateId);
    String resumeName = wechatUserResumeMapping.getResumeName();
    int res1 = candidateProfileService.deleteCandidateProfileById(candidateId);
    int res2 = wechatUserService.deleteUserResumeMappingById(candidateId);
    if (res1 == 1 && res2 == 1) {
      res = 1;
    } else {
      res = -1;
    }
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    if (res < 0) {
      rsp.setCode(-1);
      rsp.setMessage("failed");
    } else {
      rsp.setCode(0);
      rsp.setMessage("success");
      try {
        changeLogUtil.saveCandidateProfileChangeHistory(candidateId.toString(), resumeName, ActionType.DEL,
            params.getUserEmail(), "delete resume", params.getCompanyId());
      } catch (ServiceApplicationException e) {
        logger.error("save candidate profile delete history " + e.getMessage());
      }
    }
    return rsp;
  }

  @RequestMapping(value = "/changeresumehistory", method = RequestMethod.GET)
  public @ResponseBody List<ChangeLog> showChangeCandidateProfileHistory(HttpServletRequest request)
      throws ServiceApplicationException {
    String userEmail = params.getUserEmail();
    String companyId = params.getCompanyId();
    try {
      return changeLogService.getChangeLogList(companyId, userEmail, LogObjectType.CANDIDATE_PROFILE.getObjectName());
    } catch (ServiceApplicationException e) {
      throw new ServiceApplicationException("get change log failed");
    }

  }

  @RequestMapping(value = "/picklists", method = RequestMethod.GET)
  public @ResponseBody Map<String, List<SFPicklistItem>> getPicklistsFromCache(@RequestParam("locale") String locale)
      throws ServiceApplicationException {
    Map<String, List<SFPicklistItem>> pkMap = new HashMap<String, List<SFPicklistItem>>();
    CompanyInfo info = compInfoService.getCompanyInfo(params.getCompanyId());
    locale = sFPicklistService.validateLocale(locale);
      pkMap = pklCacheService.getCandidatePicklistOptions(params.getCompanyId(), info.getDmMappingId(), locale,
          SFPicklistCacheEntityType.CANDIDATE.name());

    return pkMap;
  }

  @RequestMapping(value = "/jobApplPicklists", method = RequestMethod.GET)
  public @ResponseBody Map<String, List<SFPicklistItem>> getJobApplicationPicklistsFromCache(
      @RequestParam("locale") String locale) throws ServiceApplicationException {
    if ("zh".equals(locale)) {
      locale = "zh_CN";
    } else if ("en".equals(locale)) {
      locale = "en_US";
    }
    Map<String, List<SFPicklistItem>> pkMap = pklCacheService.getJobApplPicklistOptions(params.getCompanyId(), locale,
        SFPicklistCacheEntityType.JOB_APPLICATION.name());
    return pkMap;
  }

}
