package com.sap.hcm.resume.collection.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

@Entity
@Table(name="USER_INFO")
public class UserInfo implements Serializable{
    
    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = -3570504884122407725L;

    @Id
    @GeneratedValue(strategy = GenerationType.TABLE, generator = "user_info_seq")
    @TableGenerator(initialValue = 1, table = "SEQUENCE", name = "user_info_seq", pkColumnName = "SEQ_NAME", valueColumnName = "SEQ_COUNT", pkColumnValue = "USER_INFO_PK", allocationSize = 1)
    @Column(name="USER_ID")
    private Long userId;
    
    /**
     * link to hcp user name
     */
    @Column(name="HCP_USER", length=50)
    private String hcpUser;
    
    @Column(name="FIRST_NAME", length=50)
    private String fristName;
    
    @Column(name="LAST_NAME", length=50)
    private String lastName;
    

    /**
     * @return the userId
     */
    public Long getUserId() {
        return userId;
    }

    /**
     * @param userId the userId to set
     */
    public void setUserId(Long userId) {
        this.userId = userId;
    }

    /**
     * @return the hcpUser
     */
    public String getHcpUser() {
        return hcpUser;
    }

    /**
     * @param hcpUser the hcpUser to set
     */
    public void setHcpUser(String hcpUser) {
        this.hcpUser = hcpUser;
    }

    /**
     * @return the fristName
     */
    public String getFristName() {
        return fristName;
    }

    /**
     * @param fristName the fristName to set
     */
    public void setFristName(String fristName) {
        this.fristName = fristName;
    }

    /**
     * @return the lastName
     */
    public String getLastName() {
        return lastName;
    }

    /**
     * @param lastName the lastName to set
     */
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

}
