package com.sap.hcm.resume.collection.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sap.hcm.resume.collection.entity.ExceptionLog;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.util.CandidateDateUtil;

@Service
public class ExceptionLogService {

  @PersistenceContext
  private EntityManager entityManager;

  /**
   * logger instance
   */
  private static final Logger logger = LoggerFactory.getLogger(ExceptionLogService.class);

  public ExceptionLog saveExceptionLog(String companyId, String exceptionType, String functionType,
      String exceptionMessage) {

    ExceptionLog exceptionLog = new ExceptionLog();
    exceptionLog.setCompanyId(companyId);
    exceptionLog.setExceptionType(exceptionType);
    exceptionLog.setFunctionType(functionType);
    exceptionLog.setExceptionMessage(exceptionMessage);
    exceptionLog.setCreateAt(CandidateDateUtil.formatDate2String(new Date(), "yyyy-MM-dd HH:mm:ss"));
    ExceptionLog log = entityManager.merge(exceptionLog);

    return log;

  }

  public List<ExceptionLog> findExceptionLog(String companyId) throws ServiceApplicationException {
    List<ExceptionLog> exceptionLogList = new ArrayList<ExceptionLog>();

    try {

      String sel = "select h from ExceptionLog h where h.companyId = :companyId order by h.logId desc";
      TypedQuery<ExceptionLog> queryJobInfo = entityManager.createQuery(sel, ExceptionLog.class);
      queryJobInfo.setParameter("companyId", companyId);
      exceptionLogList = queryJobInfo.getResultList();

    } catch (Exception ex) {
      throw new ServiceApplicationException("unable to load exception log");
    }

    return exceptionLogList;

  }

  public int deleteOverdueExceptionLog() throws ServiceApplicationException {
    int res = -1;
    try {
      String deleteCl = "delete from ExceptionLog el where el.createAt < :createAt";
      Query query = entityManager.createQuery(deleteCl);
      query.setParameter("createAt", CandidateDateUtil.formatDate2StringMinus6Months("yyyy-MM-dd HH:mm:ss"));
      res = query.executeUpdate();
    } catch (Exception ex) {
      logger.error(ex.getMessage());
      res = -1;
    }
    return res;
  }
}
