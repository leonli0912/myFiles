jQuery.sap.require("sap.m.MessageBox");
sap.ui.controller("static.js.layout.mappingList", {

	_fromPage : null,
/**
 * Called when a controller is instantiated and its View controls (if available)
 * are already created. Can be used to modify the View before it is displayed,
 * to bind event handlers and do other one-time initialization.
 *
 * @memberOf resume-collection-service.mappingList
 */
	onInit: function() {
		var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		var that = this;
		oRouter.attachRouteMatched(function(oEvent){
			if(jQuery.sap.getUriParameters().mParams["from"] && jQuery.sap.getUriParameters().mParams["from"].length > 0){
				that._fromPage = jQuery.sap.getUriParameters().mParams["from"][0];
				var oMappingList = that.getView().byId("candidateModelMappingTab");
			 	if (that._fromPage === "cmpinfojob"){
			 		that.getView().byId("candProfileTabFilter").setVisible(false);
			 	}else{
			 		that.getView().byId("jobReqTabFilter").setVisible(false);
			 	}
			}
			that.loadDataList();
			that.loadReqDataList();
		});
	},

	loadDataList : function() {
	    var profileMappingListModel = new sap.ui.model.json.JSONModel("dm/list");
	    var oMappingList = this.getView().byId("mappingResultList");
	    oMappingList.setModel(profileMappingListModel);

			profileMappingListModel.attachRequestCompleted(function(){
				var oData = profileMappingListModel.getData();
				if(oData && oData.entries){
					for(var i in oData.entries){
						if(oData.entries[i].mappingId == oData.active){
							oData.entries[i]["selected"] = true;
						}else{
							oData.entries[i]["selected"] = false;
						}
					}
					profileMappingListModel.setData(oData);
				}
			})
	},

	loadReqDataList: function(){
		var jobReqMappingListModel = new sap.ui.model.json.JSONModel("jobreq/listMapping");
	    var oReqMappingList = this.getView().byId("reqMappingList");
	    oReqMappingList.setModel(jobReqMappingListModel);

			jobReqMappingListModel.attachRequestCompleted(function(){
				var oData = jobReqMappingListModel.getData();
				if(oData && oData.entries){
					for(var i in oData.entries){
						if(oData.entries[i].mappingId == oData.active){
							oData.entries[i]["selected"] = true;
						}else{
							oData.entries[i]["selected"] = false;
						}
					}
					jobReqMappingListModel.setData(oData);
				}
			});
	},

	addMapping : function() {
		var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		oRouter.navTo("newMapping",{data:{}});
	},

	addJobReqMapping: function(){
		var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		oRouter.navTo("newRequisitionMapping",{data:{}});
	},

	editMapping : function(oEvent) {

		var rowId = oEvent.getParameters().id;
		var rows = rowId.match(/\d+/g);
		var rowNo = rows[rows.length - 1];

		var oModel = oEvent.getSource().getModel();
		var oData = oModel.getData();
		var reqData = oData.entries[rowNo];

		var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		oRouter.navTo("mappingDetail", {id:reqData.mappingId});
	},

	editJobReqMapping: function(oEvent){
		var rowId = oEvent.getParameters().id;
		var rows = rowId.match(/\d+/g);
		var rowNo = rows[rows.length - 1];

		var oModel = oEvent.getSource().getModel();
		var oData = oModel.getData();
		var reqData = oData.entries[rowNo];

		var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		oRouter.navTo("jobReqMappingDetail", {id:reqData.mappingId});
	},
	deleteMapping : function(oEvent) {
		var deleteDialog = sap.ui.getCore().byId("deleteDialog");
		var rowId = oEvent.getParameters().id;
		var rows = rowId.match(/\d+/g);
		var rowNo = rows[rows.length - 1];

		var oModel = oEvent.getSource().getModel();
		var oData = oModel.getData();
		var reqData = oData.entries[rowNo];
		var that = this;
		if(!deleteDialog){
			deleteDialog = sap.ui.xmlfragment("static.js.layout.deleteDialog");
			var btnOk = sap.ui.getCore().byId("btnOk");
			var btnClose = sap.ui.getCore().byId("btnClose");
			btnOk.attachPress(function(){

				var cfg = {
					type : 'DELETE',
					dataType : 'json',
					contentType : 'application/json;charset=UTF-8'
				};
				cfg.url = "dm/delete/" + reqData.mappingId;
			    $.ajax(cfg).success(function() {

			    	that.loadDataList();
			    });
			    deleteDialog.destroy();
			    var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
				oRouter.navTo("mappingList",{data:{}});
			});
			btnClose.attachPress(function(){
				deleteDialog.destroy();
			});
		}
		this.getView().addDependent(deleteDialog);
		deleteDialog.open();
	},

	deleteJobReqMapping: function(oEvent){
		var deleteDialog = sap.ui.getCore().byId("deleteDialog");
		var rowId = oEvent.getParameters().id;
		var rows = rowId.match(/\d+/g);
		var rowNo = rows[rows.length - 1];

		var oModel = oEvent.getSource().getModel();
		var oData = oModel.getData();
		var reqData = oData.entries[rowNo];
		var that = this;
		if(!deleteDialog){
			deleteDialog = sap.ui.xmlfragment("static.js.layout.deleteDialog");
			var btnOk = sap.ui.getCore().byId("btnOk");
			var btnClose = sap.ui.getCore().byId("btnClose");
			btnOk.attachPress(function(){

				var cfg = {
					type : 'DELETE',
					dataType : 'json',
					contentType : 'application/json;charset=UTF-8'
				};
				cfg.url = "jobreq/" + reqData.mappingId + "/delete";
			    $.ajax(cfg).success(function() {

				    that.loadReqDataList();
			    });
			    deleteDialog.destroy();
			    var oRouter = sap.ui.core.UIComponent.getRouterFor(that);
				oRouter.navTo("mappingList",{data:{}});
			});
			btnClose.attachPress(function(){
				deleteDialog.destroy();
			});
		}
		this.getView().addDependent(deleteDialog);
		deleteDialog.open();
	},
	formateDate : function(val) {
		var date = new Date(val);
		return date.toLocaleDateString();
	},

	showImportPage: function(){
		var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		oRouter.navTo("templateConfig",{});
	},

	backTo: function(){
		if(this._fromPage === "cmpinfocan" || this._fromPage === "cmpinfojob"){
			window.close();
		}else{
			this.showImportPage();
		}
	},
	refreshPicklistCache: function(oEvent){
		var cfg = {
			type : 'GET',
			dataType : 'json',
			contentType : 'application/json;charset=UTF-8'
		};
		cfg.url = "jobreq/renewPicklistCache";
		that = this;
		var oDialog = this.getView().byId("BusyDialog");
		oDialog.open();
	    $.ajax(cfg).success(function(data) {
	    	oDialog.close();
	    	if(data && data.code < 0){
	    		that.alertMsg(data.message);
	    	}else{
	    		that.alertMsg(that.translateText("REFRESH_PICKLIST_SUCCESS"));
	    	}

	    }).error(function(data){
	    	oDialog.close();
	    });
	},
	alertMsg : function(requiredMsg) {
		var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
	    sap.m.MessageBox.information(
	    	requiredMsg,
	    	{
	    		styleClass: bCompact? "sapUiSizeCompact" : ""
	    	}
	    );
	},
	activeCandidateProfileSelection: function(){
		var oList = this.getView().byId("mappingResultList");
		var oItem = oList.getSelectedItem();
		if(oItem == null){
			return;
		}
		var sPath = oItem.getBindingContext().sPath;
		var entry = oItem.getBindingContext().getModel().getObject(sPath);
		var mappingId = entry.mappingId;

		var that = this;
		oList.setBusy(true);
		$.get("dm/active/"+mappingId, function(data){
			if(data && data.code == 0){
				oList.setBusy(false);
				that.loadDataList();
			}
		});
	},

	activeJobRequisitionSelection: function(){
		var oList = this.getView().byId("reqMappingList");
		var oItem = oList.getSelectedItem();
		if(oItem == null){
			return;
		}
		var sPath = oItem.getBindingContext().sPath;
		var entry = oItem.getBindingContext().getModel().getObject(sPath);
		var mappingId = entry.mappingId;

		var that = this;
		$.get("jobreq/active/" + mappingId, function(data){
			if(data && data.code == 0){
				that.loadReqDataList();
			}
		});
	},

	refreshCandidateProfilePicklistCache: function(){
		var cfg = {
			type : 'GET',
			dataType : 'json',
			contentType : 'application/json;charset=UTF-8'
		};
		cfg.url = "dm/renewPicklistCache";
		that = this;
		var oDialog = this.getView().byId("BusyDialog");
		oDialog.open();
	    $.ajax(cfg).success(function(data) {
	    	oDialog.close();
	    	if(data && data.code < 0){
	    		that.alertMsg(data.message);
	    	}else{
	    		that.alertMsg(that.translateText("REFRESH_PICKLIST_SUCCESS"));
	    	}

	    }).error(function(data){
	    	oDialog.close();
	    });
	},
	translateText: function(val){
		return this.getView().getModel("i18n").getResourceBundle().getText(val);
	}
/**
 * Similar to onAfterRendering, but this hook is invoked before the controller's
 * View is re-rendered (NOT before the first rendering! onInit() is used for
 * that one!).
 *
 * @memberOf resume-collection-service.mappingList
 */
// onBeforeRendering: function() {
//
// },

/**
 * Called when the View has been rendered (so its HTML is part of the document).
 * Post-rendering manipulations of the HTML could be done here. This hook is the
 * same one that SAPUI5 controls get after being rendered.
 *
 * @memberOf resume-collection-service.mappingList
 */
 // onAfterRendering: function() {
 //  var oMappingList = this.getView().byId("candidateModelMappingTab");
 //  var key = oMappingList.getSelectedKey();
 //  if (this._fromPage === "cmpinfojob"){
 //  oMappingList.setSelectedKey("__filter1");
 //  }
 // },
/**
 * Called when the Controller is destroyed. Use this one to free resources and
 * finalize activities.
 *
 * @memberOf resume-collection-service.mappingList
 */
// onExit: function() {
//
// }

});
