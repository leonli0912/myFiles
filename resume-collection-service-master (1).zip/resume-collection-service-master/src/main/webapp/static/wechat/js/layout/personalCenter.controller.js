sap.ui.controller("static.wechat.js.layout.personalCenter", {


	onButtonPress : function() {
		var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		oRouter.navTo("jobList");
	},

	onInit : function() {
		
		this._router = sap.ui.core.UIComponent.getRouterFor(this);
		var that = this;
		this._router.getRoute("personalCenter").attachPatternMatched(function(oEvent){
			var oModel = new sap.ui.model.json.JSONModel("wechatuser/user");
			that.getView().setModel(oModel);
			var that1 = that;
			oModel.attachRequestCompleted(function(oEvent) {
				var photoId = oModel.getData().userInfo.photoId;
				if (!photoId) {
					that1.getView().byId("portrait").setVisible(false);
					that1.getView().byId("noPortrait").setVisible(true);
					var uData = {
							iconUrl : "static/wechat/img/1.jpg",
							postfix : "@" + oModel.getData().companyInfo.emailPostfix
					};
				} else {
					that1.getView().byId("portrait").setVisible(true);
					that1.getView().byId("noPortrait").setVisible(false);
					var uData = {
							iconUrl : "wphoto/" + photoId + "?random=" + that1.generateRandomValue(),
							postfix : "@" + oModel.getData().companyInfo.emailPostfix
					}
				}
				var nickName = oModel.getData().userInfo.nickname;
				if(!nickName) {
					uData.wechatUserName=that.translateText("LB_WECHAT_USER");
				}else{
					uData.wechatUserName=nickName;
				}
				oModel.setData(uData, true);
			})
		});
	},
	
	generateRandomValue : function(){
		var array = new Uint32Array(1);
		window.crypto.getRandomValues(array);
		return array[0];
	},
	translateText : function(val) {
		return this.getView().getModel("wi18n").getResourceBundle().getText(val);
	},

	candidateListPress : function() {
		var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		oRouter.navTo("candidateList");
	},

	internalEmailPress : function() {
		var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		oRouter.navTo("internalEmailBinding");
	},

	applyHistory : function() {
		var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		oRouter.navTo("jobApplyHistory");
	},
	
	resumeChangeHistory : function() {
		var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		oRouter.navTo("resumeChangeHistory");
	},
	
	viewInterviewInfo : function() {
		var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		oRouter.navTo("interviewInfo");
	}
});
