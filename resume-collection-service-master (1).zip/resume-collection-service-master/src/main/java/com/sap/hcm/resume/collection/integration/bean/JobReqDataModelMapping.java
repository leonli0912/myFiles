package com.sap.hcm.resume.collection.integration.bean;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.annotations.XStreamAlias;
import com.thoughtworks.xstream.security.NullPermission;
import com.thoughtworks.xstream.security.PrimitiveTypePermission;

@XStreamAlias("jobreq-model-mapping")
public class JobReqDataModelMapping implements Serializable {

  /**
   * serialVersionUID
   */
  private static final long serialVersionUID = 3314549619619620013L;

  public List<JobReqDataModelMappingItem> items;

  public List<JobReqDataModelMappingItem> getItems() {
    return items;
  }

  public void setItems(List<JobReqDataModelMappingItem> items) {
    this.items = items;
  }

  public String toXML() {
    XStream xs = new XStream();
    xs.processAnnotations(JobReqDataModelMapping.class);
    xs.processAnnotations(JobReqDataModelMappingItem.class);
    xs.autodetectAnnotations(true);

    // add permissions, allow some basics
    xs.addPermission(NullPermission.NULL);
    xs.addPermission(PrimitiveTypePermission.PRIMITIVES);
    xs.allowTypeHierarchy(Collection.class);
    // allow any type from the same package
    xs.allowTypesByWildcard(new String[] { JobReqDataModelMapping.class.getPackage().getName() + ".*" });

    return xs.toXML(this);
  }

  public static JobReqDataModelMapping fromXML(String content) {
    if (content == null) {
      return null;
    }

    XStream xs = new XStream();
    xs.processAnnotations(JobReqDataModelMapping.class);
    xs.processAnnotations(JobReqDataModelMappingItem.class);
    xs.autodetectAnnotations(true);

    // add permissions, allow some basics
    xs.addPermission(NullPermission.NULL);
    xs.addPermission(PrimitiveTypePermission.PRIMITIVES);
    xs.allowTypeHierarchy(Collection.class);
    // allow any type from the same package
    xs.allowTypesByWildcard(new String[] { JobReqDataModelMapping.class.getPackage().getName() + ".*" });

    return (JobReqDataModelMapping) xs.fromXML(content);
  }
}
