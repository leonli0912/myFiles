package com.sap.hcm.resume.collection.util;

import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;

import net.sf.json.JSONObject;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.IOUtils;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.poi.POIXMLTextExtractor;
import org.apache.poi.hwpf.HWPFDocument;
import org.apache.poi.hwpf.extractor.WordExtractor;
import org.apache.poi.xwpf.extractor.XWPFWordExtractor;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.mozilla.universalchardet.UniversalDetector;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import com.github.stuxuhai.jpinyin.PinyinFormat;
import com.github.stuxuhai.jpinyin.PinyinHelper;
import com.sap.hcm.resume.collection.bean.ResumeInfo;
import com.sap.hcm.resume.collection.entity.view.CandidateBgWorkExprVO;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileExtVO;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.wechat.util.PDFPageWriter;
import com.thoughtworks.xstream.core.util.Base64Encoder;

public class CandidateFileUtil {

  private static final Logger logger = LoggerFactory.getLogger(CandidateFileUtil.class);

  public static enum ResumeType {
    HTML("pdf"), DOC("doc"), DOCX("docx"), MHT("pdf"), DOCHTML("html"), UNKNOWN("unknown");

    private String extension;

    private ResumeType(String extension) {
      this.extension = extension;
    }

    public String getExtension() {
      return extension;
    }
  };

  /**
   * @param fileContent
   * @return
   */
  public static String convertByteToBase64Str(byte[] fileContent) {

    if (fileContent == null) {
      return null;
    }
    Base64Encoder encoder = new Base64Encoder();
    return encoder.encode(fileContent);
  }

  /**
   * get resume content by different vendor
   * 
   * @param vendor
   * @param content
   * @return resume info
   * @throws ServiceApplicationException
   */
  public static ResumeInfo getFileContent(byte[] content) throws ServiceApplicationException {
    ResumeInfo resumeInfo = new ResumeInfo();
    String textContent = null;
    byte[] attachment = null;
    Document htmlDoc = null;

    String charsetName = getCharsetName(content);
    ResumeType resumeType = getResumeType(content, charsetName);

    switch (resumeType) {
    case MHT:
      InlineHtml inlineFile = MHTUtil.extractHtmlFromMht(content);
      textContent = formatHtmlText(inlineFile.getContent(), false, false);
      attachment = createPDFAttachment(textContent);
      htmlDoc = Jsoup.parse(inlineFile.getContent());
      break;
    case HTML:
      textContent = getContentFromHtml(content, charsetName);
      attachment = createPDFAttachment(textContent);
      textContent = getContentFromHtml(content, charsetName);
      try {
        htmlDoc = Jsoup.parse(new String(content, charsetName));
      } catch (IOException e) {
        logger.error("failed to parse the html document using jsoup");
      }
      attachment = createPDFAttachment(textContent);
      break;
    case DOCHTML:
      textContent = getContentFromWord2HTML(content, charsetName);
      attachment = createAttachment(content, charsetName);
      break;
    case DOC:
      textContent = getContentFrom2003(content);
      attachment = createAttachment(content, charsetName);
      break;
    case DOCX:
      textContent = getContentFrom2007(content);
      attachment = createAttachment(content, charsetName);
      break;
    case UNKNOWN:
    default:
      logger.error("the resume type can not be identified");
      throw new ServiceApplicationException("the resume type can not be identified");
    }

    if (textContent == null) {
      logger.error("file content not found");
      throw new ServiceApplicationException("file content not found");
    }
    resumeInfo.setTextContent(textContent);
    resumeInfo.setAttachment(attachment);
    resumeInfo.setHtmlDocument(htmlDoc);
    resumeInfo.setResumeExtension(resumeType.getExtension());
    resumeInfo.setCharset(charsetName);

    return resumeInfo;
  }

  /**
   * @param inlineFile
   * @return
   * @throws ServiceApplicationException
   */
  private static byte[] createPDFAttachment(String fileContent) throws ServiceApplicationException {
    byte[] result = null;
    try {

      fileContent = fileContent.replaceAll("[\u0020\u3000\u00a0\u0009\uFFFD\u30FB\\u000D]", " ").replaceAll(" {2,}",
          " ");
      PDDocument doc = new PDDocument();
      PDFPageWriter pdfWriter = new PDFPageWriter(doc);
      ByteArrayOutputStream byteOutputStream = new ByteArrayOutputStream();
      pdfWriter.write(50, 15, 10, null, fileContent);
      pdfWriter.close();
      doc.save(byteOutputStream);
      result = byteOutputStream.toByteArray();
    } catch (IOException e) {
      throw new ServiceApplicationException(e.getMessage());
    }
    return result;
  }

  /**
   * @param resume
   * @return attachment
   * @throws ServiceApplicationException
   */
  private static byte[] createAttachment(byte[] content, String charsetName) throws ServiceApplicationException {
    byte[] result = null;
    InputStream is = null;
    try {
      is = new ByteArrayInputStream(content);
      String src = IOUtils.toString(is, charsetName);
      String regex = "<!\\[if[\\S\\s]*?<!\\[endif\\]>";
      src = src.replaceAll(regex, "");
      result = src.getBytes(charsetName);
    } catch (IOException e) {
      logger.error("get attachment from resume failed: " + e.getMessage());
      throw new ServiceApplicationException("get attachment from resume failed: " + e.getMessage());
    } finally {
      IOUtils.closeQuietly(is);
    }
    return result;
  }

  /**
   * get resume file type by probing the top 10 lines
   * 
   * @param is
   *          the resume file
   * @param charsetName
   *          charset encoding
   * @return resume type
   * @throws ServiceApplicationException
   */
  public static ResumeType getResumeType(byte[] content, String charsetName) throws ServiceApplicationException {

    InputStream is = new ByteArrayInputStream(content);
    StringBuilder sb = new StringBuilder();
    InputStreamReader isr = null;
    BufferedReader br = null;
    try {
      isr = new InputStreamReader(is, charsetName);
      br = new BufferedReader(isr);
      String line = br.readLine();
      // TODO normally, top 10 lines contain the info for probing the file type
      for (int i = 0; i < 10 && line != null; i++) {
        sb.append(line);
        line = br.readLine();
      }
    } catch (IOException e) {
      logger.error("read file failed: " + e.getMessage());
      throw new ServiceApplicationException("read file failed: " + e.getMessage());
    } finally {
      IOUtils.closeQuietly(br);
      IOUtils.closeQuietly(isr);
    }

    String top10Lines = sb.toString().toLowerCase();
    if (top10Lines.isEmpty()) {
      String msg = "the file contains nothing";
      logger.error(msg);
      throw new ServiceApplicationException(msg);
    }

    // process mht condition first since mht file may also contain html tag
    ResumeType result = ResumeType.UNKNOWN;
    if (top10Lines.contains("multipart/related")) {
      result = ResumeType.MHT;
    } else if (top10Lines.contains("<html")) {
      // resume can be a html file, or html file wrapped by MS Word doc
      result = top10Lines.contains("schemas-microsoft-com:office:word") ? ResumeType.DOCHTML : ResumeType.HTML;
    } else {
      // verify content type by using signature aka magic number
      // D0CF11E0 -> MS Word doc
      // 504B0304 -> MS Word docx
      InputStream isNew = new ByteArrayInputStream(content);
      String signature = getFileSignature(isNew);
      if ("D0CF11E0".equalsIgnoreCase(signature)) {
        result = ResumeType.DOC;
      }
      if ("504B0304".equalsIgnoreCase(signature)) {
        result = ResumeType.DOCX;
      }
    }

    return result;
  }

  /**
   * signatures, aka magic numbers, is used to identify or verify the content of a binary file
   * 
   * @param is
   * @return signature the magic number
   * @throws ServiceApplicationException
   */
  private static String getFileSignature(InputStream is) throws ServiceApplicationException {
    StringBuilder sb = new StringBuilder();
    try {
      byte[] buf = new byte[4];
      if (is != null) {
        is.read(buf, 0, buf.length);
      }
      // convert to hex string
      if (buf == null || buf.length <= 0) {
        return null;
      }
      for (int i = 0; i < buf.length; i++) {
        int v = buf[i] & 0xFF;
        String hv = Integer.toHexString(v);
        if (hv.length() < 2) {
          sb.append(0);
        }
        sb.append(hv);
      }
    } catch (IOException e) {
      logger.error("get file signature / magic number failed:" + e.getMessage());
      throw new ServiceApplicationException("get file signature / magic number failed:" + e.getMessage());
    } finally {
      IOUtils.closeQuietly(is);
    }
    return sb.toString();
  }

  /**
   * @param resume
   * @return
   * @throws ServiceApplicationException
   */
  public static Document getFileContentFromHtml(byte[] resumeContent) throws ServiceApplicationException {

    Document doc = null;
    InputStream is = new ByteArrayInputStream(resumeContent);
    try {
      doc = Jsoup.parse(is, "UTF-8", "http://example.com/");
    } catch (IOException e) {
      throw new ServiceApplicationException("File content can not be read");
    } finally {
      IOUtils.closeQuietly(is);
    }

    return doc;
  }

  /**
   * @param resource
   * @return
   * @throws ServiceApplicationException
   */
  public static String getContentFromHtml(byte[] resource, String encoding) throws ServiceApplicationException {
    InputStream is = new ByteArrayInputStream(resource);
    String content = null;
    Document doc = null;
    try {
      doc = Jsoup.parse(is, encoding, "http://example.com/");
      content = formatHtmlText(doc.html(), true, false);
    } catch (IOException e) {
      throw new ServiceApplicationException("File content can not be read");
    } finally {
      IOUtils.closeQuietly(is);
    }

    return content;
  }

  // get Word2003 fileContent
  public static String getContentFrom2003(byte[] content) throws ServiceApplicationException {

    // word 2003
    InputStream is = null;
    String fileContent;
    WordExtractor ex = null;
    try {
      is = new ByteArrayInputStream(content);
      HWPFDocument document = new HWPFDocument(is);
      ex = new WordExtractor(document);
      fileContent = ex.getText();
    } catch (Exception e) {
      throw new ServiceApplicationException("File content can not be read");
    } finally {
      IOUtils.closeQuietly(ex);
      IOUtils.closeQuietly(is);
    }

    return fileContent;
  }

  // get Word2007 fileContent
  public static String getContentFrom2007(byte[] content) throws ServiceApplicationException {

    String text2007 = null;
    // word 2007
    InputStream in = null;
    POIXMLTextExtractor extractor = null;
    try {
      in = new ByteArrayInputStream(content);
      XWPFDocument document = new XWPFDocument(in);
      extractor = new XWPFWordExtractor(document);
      text2007 = extractor.getText();
    } catch (IOException e) {
      throw new ServiceApplicationException("File content can not be read");
    } finally {
      IOUtils.closeQuietly(extractor);
      IOUtils.closeQuietly(in);
    }
    return text2007;
  }

  // get MHT fileContent
  public static Document getContentFromMhtFile(byte[] resource) throws ServiceApplicationException {

    Document doc;
    try {
      // try parse with MHTReader
      String fileContent = MHTUtil.extractHtmlFromMht(resource).getContent();
      doc = Jsoup.parse(fileContent);
    } catch (Exception e) {
      throw new ServiceApplicationException("File content can not be read");
    }

    return doc;
  }

  // resize the uploaded IMG according to the parameter of width and height
  public static byte[] cropImage(InputStream oldImgByByte, int widthParam, int heightParam) throws IOException {
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    Image img;
    float modulus = (float) widthParam / heightParam;
    int width;
    int height;
    float xs1, xs2, ys1, ys2;
    img = ImageIO.read(oldImgByByte);
    width = img.getWidth(null);
    height = img.getHeight(null);
    if (height * modulus > width) {
      xs1 = 0;
      ys1 = (height - (width / modulus)) / 2;
      xs2 = width;
      ys2 = height - ys1;
    } else {
      xs1 = (width - (height * modulus)) / 2;
      ys1 = 0;
      xs2 = width - xs1;
      ys2 = height;
    }
    BufferedImage image = new BufferedImage(widthParam, heightParam, BufferedImage.TYPE_INT_ARGB);
    Graphics2D g2d = image.createGraphics();
    g2d.drawImage(img, 0, 0, widthParam, heightParam, Math.round(xs1), Math.round(ys1), Math.round(xs2),
        Math.round(ys2), null);
    g2d.dispose();
    ImageIO.write(image, "png", out);
    byte[] newImgByte = out.toByteArray();
    return newImgByte;
  }

  public static byte[] extendImage(byte[] oldImgByte, int widthParam, int heightParam) throws IOException {
    InputStream oldByteIs = new ByteArrayInputStream(oldImgByte);
    ByteArrayOutputStream out = new ByteArrayOutputStream();
    Image img;
    int width, height;
    float xs1, xs2, ys1, ys2;
    img = ImageIO.read(oldByteIs);
    width = img.getWidth(null);
    height = img.getHeight(null);
    float modulus = (float) width / height;
    if (modulus > widthParam / heightParam) {
      xs1 = 0;
      ys1 = -(heightParam - widthParam / modulus) / 2;
      xs2 = width;
      ys2 = height - ys1;
    } else {
      xs1 = -(widthParam - heightParam * modulus) / 2;
      ys1 = 0;
      xs2 = width - xs1;
      ys2 = height;

    }
    BufferedImage image = new BufferedImage(widthParam, heightParam, BufferedImage.TYPE_INT_ARGB);
    Graphics2D g2d = image.createGraphics();
    g2d.drawImage(img, 0, 0, widthParam, heightParam, Math.round(xs1), Math.round(ys1), Math.round(xs2),
        Math.round(ys2), null);
    g2d.dispose();
    ImageIO.write(image, "png", out);
    byte[] newImgByte = out.toByteArray();
    return newImgByte;
  }

  /**
   * read content from the html by saving from MS Word 2003 directly
   * 
   * @param content
   * @return
   * @throws ServiceApplicationException
   * @throws IOException
   */
  public static String getContentFromWord2HTML(byte[] content, String encode) throws ServiceApplicationException {
    // read out the charset

    StringBuffer buf = new StringBuffer();
    String output = "";
    InputStream is = null;
    InputStreamReader reader = null;
    BufferedReader bufferedReader = null;
    try {
      is = new ByteArrayInputStream(content);
      reader = new InputStreamReader(is, encode);
      bufferedReader = new BufferedReader(reader);
      String line = "";
      while ((line = bufferedReader.readLine()) != null) {
        if (!StringUtils.isEmpty(line.trim())) {
          buf.append(line);
          buf.append(System.lineSeparator());
        }
      }
      output = buf.toString();
      output = formatHtmlText(output, true, false);
    } catch (Exception e) {
      throw new ServiceApplicationException("can not read file content");
    } finally {
      IOUtils.closeQuietly(bufferedReader);
      IOUtils.closeQuietly(reader);
      IOUtils.closeQuietly(is);
    }

    return output;
  }

  /**
   * get the charset name of given file
   * 
   * @param fis
   * @return charset name
   * @throws ServiceApplicationException
   */
  public static String getCharsetName(byte[] content) throws ServiceApplicationException {
    String result = null;
    InputStream fis = new ByteArrayInputStream(content);
    try {
      byte[] buf = new byte[4096];
      UniversalDetector detector = new UniversalDetector(null);
      int nread;
      while ((nread = fis.read(buf)) > 0 && !detector.isDone()) {
        detector.handleData(buf, 0, nread);
      }
      detector.dataEnd();
      result = detector.getDetectedCharset();
      if (result == null) {
        // return system default encoding if detection failed
        logger.error("the detector couldn't determine what encoding was used");
        result = Charset.defaultCharset().name();
      }
      return result;
    } catch (IOException e) {
      logger.error(e.getMessage());
      throw new ServiceApplicationException(e.getMessage());
    } finally {
      IOUtils.closeQuietly(fis);
    }
  }
  
  /**
   * get the charset name of given file
   * 
   * @param file
   * @return charset name
   * @throws ServiceApplicationException
   */
  public static String getCharsetNameFromByte(byte[] content) throws ServiceApplicationException {
    String result = null;
    InputStream fis = null;
    try {
      byte[] buf = new byte[4096];
      fis = new ByteArrayInputStream(content);
      UniversalDetector detector = new UniversalDetector(null);
      int nread;
      while ((nread = fis.read(buf)) > 0 && !detector.isDone()) {
        detector.handleData(buf, 0, nread);
      }
      detector.dataEnd();
      result = detector.getDetectedCharset();
      if (result == null) {
        // return system default encoding if detection failed
        logger.error("the detector couldn't determine what encoding was used");
        result = Charset.defaultCharset().name();
      }
      return result;
    } catch (IOException e) {
      logger.error(e.getMessage());
      throw new ServiceApplicationException(e.getMessage());
    } finally {
      IOUtils.closeQuietly(fis);
    }
  }
  

  /**
   * format html text
   * 
   * @param html
   * @return
   */
  public static String formatHtmlText(String html, boolean keepSpace, boolean keepEnter) {

    html = MappingUtil.removeScriptTag(html);
    html = MappingUtil.removeStyleTag(html);
    html = MappingUtil.removeTdTag(html, keepEnter);
    html = MappingUtil.removeTrTag(html);
    html = MappingUtil.removePTag(html);
    html = MappingUtil.removeBrTag(html);
    html = MappingUtil.removeBracketTag(html);

    if (!keepSpace) {
      html = MappingUtil.removeSpaceTag(html);
    } else {
      html = MappingUtil.replaceSpaceTag(html);
    }
    String[] lines = html.split("[\r\n]");
    StringBuilder builder = new StringBuilder();
    for (String line : lines) {
      String nl = line.trim();
      if (!"".equals(nl)) {
        builder.append(nl);
        builder.append(System.getProperty("line.separator"));
      }
    }
    html = builder.toString();
    return html;
  }

  public static boolean deleteFile(String fileName) {
    File file = new File(fileName);
    if (file.isFile() && file.exists()) {
      file.delete();
      return true;
    } else {
      return false;
    }
  }

  public static String getPinyinFromChinese(String lastName, String firstName) {
    String last = "";
    String first = "";
    if (lastName != null) {
      last = PinyinHelper.convertToPinyinString(lastName, "", PinyinFormat.WITHOUT_TONE);
    }
    if (firstName != null) {
      first = PinyinHelper.convertToPinyinString(firstName, "", PinyinFormat.WITHOUT_TONE);
    }
    if (!StringUtils.isEmpty(last)) {
      last = last.substring(0, 1).toUpperCase() + last.substring(1);
    } else {
      last = "";
    }
    if (!StringUtils.isEmpty(first)) {
      first = first.substring(0, 1).toUpperCase() + first.substring(1);
    } else {
      first = "";
    }
    return (last + " " + first).trim();
  }

  public static String getState(String city) {

    InputStream in = null;
    BufferedReader br = null;
    StringBuffer buffer = new StringBuffer();

    try {
      in = CandidateFileUtil.class.getClassLoader().getResourceAsStream("model/state.json");
      br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8));
      String line = "";
      while ((line = br.readLine()) != null) {
        buffer.append(line);
      }

      JSONObject jsonObject = JSONObject.fromObject(buffer.toString()).getJSONObject("state");
      Map<String, Object> stateMap = new HashMap<String, Object>();
      Iterator<?> it = jsonObject.keys();
      while (it.hasNext()) {
        String key = String.valueOf(it.next());
        Object value = (Object) jsonObject.get(key);
        stateMap.put(key, value);
      }

      for (Map.Entry<String, Object> entry : stateMap.entrySet()) {
        if (city.equals(entry.getKey())) {
          return city;
        }

        @SuppressWarnings("unchecked")
        List<Map<String, String>> cityList = (List<Map<String, String>>) entry.getValue();
        for (Map<String, String> cityMap : cityList) {
          if (city.equals(cityMap.get("text"))) {
            return entry.getKey();
          }
        }
      }
    } catch (Exception ex) {
      ex.printStackTrace();
    } finally {
      IOUtils.closeQuietly(br);
      IOUtils.closeQuietly(in);
    }

    return "";
  }

  public static String getCity(String val) {
    String[] arr = val.split("-|\\s");
    return arr[0].replace("省", "");
  }

  public static List<FileItem> handleFileUploadRequest(HttpServletRequest request) throws ServiceApplicationException {
    List<FileItem> resultList = new ArrayList<FileItem>();
    boolean isMultipart = ServletFileUpload.isMultipartContent(request);
    if (!isMultipart) {
      return resultList;
    }
    DiskFileItemFactory dff = new DiskFileItemFactory();
    dff.setSizeThreshold(50 * 1024 * 1024);
    dff.setRepository(new File("/temp"));
    ServletFileUpload upload = new ServletFileUpload(dff);
    upload.setHeaderEncoding(request.getCharacterEncoding());
    upload.setFileSizeMax(1000 * 1024 * 1024);

    try {
      List<FileItem> items = upload.parseRequest(request);
      if (items != null && items.size() > 0) {
        for (FileItem item : items) {
          if (!item.isFormField()) {
            resultList.add(item);
          }
        }
      }
    } catch (FileUploadException e) {
      throw new ServiceApplicationException("Parse Request Failed", e);
    }

    return resultList;
  }

  public static CandidateProfileExtVO handleSpecialFields(CandidateProfileExtVO extProfile,
      CandidateProfileVO candidateProfileVO) {

    // get pinyin from user name
    String pinyin = CandidateFileUtil.getPinyinFromChinese(candidateProfileVO.getLastName(),
        candidateProfileVO.getFirstName());
    extProfile.setPinyin(pinyin);
    // process state/province
    if (!StringUtils.isEmpty(candidateProfileVO.getResidence())) {
      extProfile.setState(CandidateFileUtil.getState(CandidateFileUtil.getCity(candidateProfileVO.getResidence())));
    }
    // process work start date
    SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
    Date tmpDate = new Date();
    String currentCompany = "";
    Date tempDate;
    try {
      tempDate = sdf.parse("1900/01/01");
      if (candidateProfileVO.getWorkExprs() != null && candidateProfileVO.getWorkExprs().size() > 0) {
        for (CandidateBgWorkExprVO exprVO : candidateProfileVO.getWorkExprs()) {
          String startDate = exprVO.getStartDate();
          try {
            if (tmpDate.after(sdf.parse(startDate))) {
              tmpDate = sdf.parse(startDate);
            }
          } catch (ParseException e) {
            continue;
          }
          try {
            if (sdf.parse(startDate).after(tempDate)) {
              tempDate = sdf.parse(startDate);
              currentCompany = exprVO.getEmployer();
            }
          } catch (ParseException e) {
            continue;
          }
        }
      }
      extProfile.setStartWorkDate(sdf.format(tmpDate));
      extProfile.setCurrentCompany(currentCompany);
    } catch (ParseException e1) {

    }

    return extProfile;
  }
}
