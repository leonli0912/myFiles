package com.sap.hcm.resume.collection.integration.service;

import java.util.List;
import java.util.Locale;

import com.sap.hcm.resume.collection.bean.JobAppQuestionResponse;
import com.sap.hcm.resume.collection.entity.DataModelMapping;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;
import com.sap.hcm.resume.collection.entity.view.JobApplyMappingVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.bean.CandProfileDataModelMapping;
import com.sap.hcm.resume.collection.integration.sf.bean.QueryInfo;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJob;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatJobApplicationVO;

public interface JobApplicationIntegrationService extends IntegrationService {

  WechatJobApplicationVO insertJobApplication(CandidateProfileVO candidateProfileVO, DataModelMapping mapping,
      WechatJob wechatJob, JobApplyMappingVO jobApplyMappingVO, CandProfileDataModelMapping profileMapping,
      List<JobAppQuestionResponse> questionResponses) throws ServiceApplicationException;

  String getOdataFeedStringFromSF(QueryInfo queryInfo) throws ServiceApplicationException;

  String queryApplicationStatus(String applicationId, Locale locale) throws ServiceApplicationException;
}
