package com.sap.hcm.resume.collection.integration.zhilian;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.springframework.context.MessageSource;

import com.sap.hcm.resume.collection.entity.view.CandidateBgCertificateVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgEducationVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgLanguageVO;
import com.sap.hcm.resume.collection.entity.view.CandidateBgWorkExprVO;
import com.sap.hcm.resume.collection.entity.view.CandidateProfileVO;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.parser.TextDocumentParser;
import com.sap.hcm.resume.collection.util.CandidateDateUtil;
import com.sap.hcm.resume.collection.util.MappingUtil;

public class ResumeParserZL extends TextDocumentParser {

  public ResumeParserZL(MessageSource messageSource) {
    super(messageSource);
  }

  public static final String SOURCE_DATE_FORMAT = "yyyy.MM";

  public static final String TARGET_DATE_FORMAT = "yyyy/MM/dd";

  @Override
  public CandidateProfileVO parseProfile(CandidateProfileVO candidateProfileVO, String text)
      throws ServiceApplicationException {

    text = text.replaceAll("[\u0020\u3000\u00a0\u0009]", " ").replaceAll(" {2,}", " ");// 将所有tab和所有种类的空格转换成一个英文空格
    try {
      String regex = null;

      // primaryEmail 电子邮件 主键
      regex = "(?<=E-mail：\\s{0,1})\\S{1,500}"; // 获取邮箱的正则
      candidateProfileVO.setPrimaryEmail(MappingUtil.matchSingle(regex, text));

      // contactEmail 电子邮件
      candidateProfileVO.setContactEmail(MappingUtil.matchSingle(regex, text));

      // country 国籍
      candidateProfileVO.setCountry("CN");

      regex = "\\S*(?=\\s{0,1}手机\\s{0,1}：)"; // 获取姓名的正则
      String fullName = MappingUtil.matchSingle(regex, text).trim();

      // firstName 名
      candidateProfileVO.setFirstName(fullName.substring(1, fullName.length()));

      // middleName
      candidateProfileVO.setMiddleName("");

      // lastName 姓
      candidateProfileVO.setLastName(fullName.substring(0, 1));

      // cellPhone 移动电话
      regex = "(?<=手机：)\\d*"; // 获取手机号码的正则
      candidateProfileVO.setCellPhone(MappingUtil.matchSingle(regex, text));

      // ENName 英文名
      candidateProfileVO.setEnglishName("");

      // gender 性别
      // regex = "(?<=手机：\\d{11}[\r\n|\n]{1,2})\\S{1}"; // 获取性别的正则
      regex = "\\S{1}(?=\\s[0-9]+岁)";
      String gender = MappingUtil.matchSingle(regex, text);
      if ("男".equals(gender)) {
        candidateProfileVO.setGender("Male");
      } else if ("女".equals(gender)) {
        candidateProfileVO.setGender("Female");
      }

      // identitycard 身份证码
      regex = "(?<=身份证：)\\S+"; // 获取身份证码的正则
      candidateProfileVO.setIdentityCard(MappingUtil.matchSingle(regex, text));

      // dateOfBirth
      regex = "(?<=岁\\()\\d{4}年\\d+月"; // 获取出生日期的正则
      String dateOfBirth = MappingUtil.matchSingle(regex, text);
      String year = dateOfBirth.substring(0, 4);
      regex = "(?<=年)\\d+";
      String month = MappingUtil.matchSingle(regex, dateOfBirth);
      if (month.length() == 1) {
        month = "0" + month;
      }
      candidateProfileVO.setDateOfBirth(year + "/" + month + "/01");

      // nationality 国籍
      candidateProfileVO.setNationality("");

      // ethnicity
      candidateProfileVO.setEthnicity("Asian");

      // marriage 婚姻状况
      regex = "\\S{2}(?=\r\n现居住地：)"; // 获取地址的正则
      String marriage = MappingUtil.matchSingle(regex, text);
      if ("已婚".equals(marriage)) {
        candidateProfileVO.setMarriage("Y");
      } else {
        candidateProfileVO.setMarriage("N");
      }

      // residence 现居住城市
      regex = "(?<=现居住地：)\\S*"; // 获取城市的正则
      candidateProfileVO.setResidence(MappingUtil.matchSingle(regex, text));

      // address
      candidateProfileVO.setAddress(MappingUtil.matchSingle(regex, text));

      // houseHold 户口性质
      candidateProfileVO.setHousehold("");

      // minAnnualSal
      regex = "(?<=期望月薪：\\s)\\d+(?=-\\d+元/月)"; // 获取期望收入的正则
      String minAnnualSal = MappingUtil.matchSingle(regex, text);
      if (!StringUtils.isEmpty(minAnnualSal)) {
        candidateProfileVO.setMinAnnualSal(Integer.parseInt(MappingUtil.matchSingle(regex, text)) * 12 + "");
      } else {
        candidateProfileVO.setMinAnnualSal("0");
      }

      // preferredLoc
      regex = "(?<=期望工作地区：\\s)\\S*(?=[\\r\\n|\\n])"; // 获取期望工作城市的正则
      candidateProfileVO.setPreferredLoc(MappingUtil.matchSingle(regex, text));

      // // currentTitle
      // String workExp = getWorkExpMatchGroup(text);
      // regex = "(?<=\\d{4}\\.\\d{2}.{0,150}\r\n)\\S*(?=\\s\\|)"; // 获取职位的正则
      // rowData.add(MappingUtil.matchSingle(regex, workExp));
      //
      // // currentCompany
      // regex = "(?<=\\d{4}\\.\\d{2}\\s-\\s至今  )\\S*(?=  )"; // 获取当前工作单位的正则
      // rowData.add(MappingUtil.matchSingle(regex, text));

      // veteranStatus 1688 is the default value for SF
      candidateProfileVO.setVeteranStatus("1649");

      // currency CNY is the default value for SF
      candidateProfileVO.setCurrency("CNY");

      // lastLogin
      candidateProfileVO.setLastModify(null);
    } catch (Exception e) {
      throw new ServiceApplicationException("Profile parse error: " + e.getMessage());
    }

    return candidateProfileVO;
  }

  /**
   * get workExp
   * 
   * @return dataList
   */
  @Override
  public CandidateProfileVO parseBackgroundWorkExp(CandidateProfileVO candidateProfileVO, String text)
      throws ServiceApplicationException {

    text = text.replaceAll("[\u0020\u3000\u00a0\u0009]", " ").replaceAll(" {2,}", " ");// 将所有tab和所有种类的空格转换成一个英文空格
    try {
      String regex = null;
      List<CandidateBgWorkExprVO> candidateBgWorkExprVOList = new ArrayList<CandidateBgWorkExprVO>();

      String workExp = getWorkExpMatchGroup(text);

      regex = "\\d{4}\\.\\d{2}[\\s\\S]*?(?=\\d{4}\\.\\d{2}\\s-\\s\\d{4}\\.\\d{2}|$)";
      Pattern pattern = Pattern.compile(regex);
      Matcher matcher = pattern.matcher(workExp);

      CandidateBgWorkExprVO candidateBgWorkExprVO = null;

      while (matcher.find()) {

        candidateBgWorkExprVO = new CandidateBgWorkExprVO();

        // presentEmployer
        regex = "\\d{4}\\.\\d{2}\\s-\\s至今";
        String presentEmployer = MappingUtil.matchSingle(regex, matcher.group());
        if (!StringUtils.isEmpty(presentEmployer)) {
          candidateBgWorkExprVO.setIsPresent(true);
          candidateBgWorkExprVO.setPresentEmployer("Yes");
        } else {
          candidateBgWorkExprVO.setIsPresent(false);
          candidateBgWorkExprVO.setPresentEmployer("No");
        }

        // employer 公司名称
        regex = "(?<=\\d{4}\\.\\d{2}\\s-\\s(\\d{4}\\.\\d{2}|至今) )[\\s\\S]*?(?= （)";
        candidateBgWorkExprVO.setEmployer(MappingUtil.matchSingle(regex, matcher.group()));

        // title 职位
        regex = "(?<=\\d{4}\\.\\d{2}.{0,150}[\r\n]{1,2})\\S*(?=\\s\\|)";
        if(StringUtils.isEmpty(MappingUtil.matchSingle(regex, matcher.group()))){
          regex = "(?<=\\d{4}\\.\\d{2}.{0,150}）\\s)\\S*(?=\\s\\|)";
        }
        candidateBgWorkExprVO.setJobTitle(MappingUtil.matchSingle(regex, matcher.group()));

         //businessType
         regex = "(?<=\\d{4}\\.\\d{2}.{0,150}[\r\n]{1,2}.{0,150}[\r\n]{1,2})\\S*(?=\\s\\|)";
         candidateBgWorkExprVO.setBusinessType(MappingUtil.matchSingle(regex, matcher.group()));

        // startDate 开始时间
        regex = "^\\d{4}\\.\\d{1,2}";
        String startDate = MappingUtil.matchSingle(regex, matcher.group());
        // startDate 开始时间
        candidateBgWorkExprVO.setStartDate(this.formatDate(startDate));

        // endDate 结束时间
        regex = "(?<=\\d{4}\\.\\d{2}\\s-\\s)\\d{4}\\.\\d{2}";
        String endDate = MappingUtil.matchSingle(regex, matcher.group());
        // endDate 结束时间
        if(!StringUtils.isEmpty(endDate)){
          candidateBgWorkExprVO.setEndDate(this.formatDate(endDate));
        }else if(!StringUtils.isEmpty(presentEmployer)){
          candidateBgWorkExprVO.setEndDate("NOW");
        }
        // exitReason
        candidateBgWorkExprVO.setExitReason("no comment");

        // salary
        String salaryRaw = MappingUtil.matchSingle("[\\d-]+(?=元/月)", matcher.group()).trim();
        String[] salaries = salaryRaw.split("-");
        if (salaries.length == 1) {
          candidateBgWorkExprVO.setSalary(salaries[0]);
          candidateBgWorkExprVO.setSalaryEnd(salaries[0]);
        } else if (salaries.length > 1) {
          candidateBgWorkExprVO.setSalary(salaries[0]);
          candidateBgWorkExprVO.setSalaryEnd(salaries[1]);
        } else {
          candidateBgWorkExprVO.setSalary("0");
          // salaryEnd
          candidateBgWorkExprVO.setSalaryEnd("0");
        }

        // description
        String descr = MappingUtil.matchSingle("(?<=工作描述：)[\\s\\S]+", matcher.group()).trim();
        candidateBgWorkExprVO.setDescription(descr);
        candidateBgWorkExprVOList.add(candidateBgWorkExprVO);
      }

      candidateProfileVO.setWorkExprs(candidateBgWorkExprVOList);
    } catch (Exception e) {
      throw new ServiceApplicationException("Work experience parse error: " + e.getMessage());
    }
    return candidateProfileVO;
  }

  /**
   * get education
   * 
   * @return dataList
   */
  @Override
  public CandidateProfileVO parseBackgroundEducation(CandidateProfileVO candidateProfileVO, String text)
      throws ServiceApplicationException {
    text = text.replaceAll("[\u0020\u3000\u00a0\u0009]", " ").replaceAll(" {2,}", " ");// 将所有tab和所有种类的空格转换成一个英文空格

    try {
      List<CandidateBgEducationVO> candidateBgEducationVOList = new ArrayList<CandidateBgEducationVO>();

      String education = getEducationMatchGroup(text);
      
      CandidateBgEducationVO candidateBgEducationVO = null;

      String regex = "\\d{4}\\.\\d{2}[^\\n]*";
      Pattern pattern = Pattern.compile(regex);
      Matcher matcher = pattern.matcher(education);
      while (matcher.find()) {

        candidateBgEducationVO = new CandidateBgEducationVO();
        
        String[] fields = matcher.group().split("\\s+");
        if(fields.length == 6){
          candidateBgEducationVO.setStartDate(this.formatDate(fields[0]));
          candidateBgEducationVO.setEndDate(this.formatDate(fields[2]));
          candidateBgEducationVO.setSchool(fields[3]);
          candidateBgEducationVO.setMajor(fields[4]);
          
          String degreeTemp = fields[5];
          if ("大专".equals(degreeTemp)) {
            candidateBgEducationVO.setDegree("大专");
          } else if ("本科".equals(degreeTemp)) {
            candidateBgEducationVO.setDegree("学士");
          } else if ("研究生".equals(degreeTemp)) {
            candidateBgEducationVO.setDegree("硕士");
          } else if ("博士生".equals(degreeTemp)) {
            candidateBgEducationVO.setDegree("博士");
          } else {
            candidateBgEducationVO.setDegree("其他");
          }
          
          // schoolState
          candidateBgEducationVO.setSchoolState("unkown");
          // gpa
          candidateBgEducationVO.setGpa("unkown");

          candidateBgEducationVOList.add(candidateBgEducationVO);
        }else{
          continue;
        }
      }
      candidateProfileVO.setEducation(candidateBgEducationVOList);
    } catch (Exception e) {
      throw new ServiceApplicationException("Education parse error: " + e.getMessage());
    }

    return candidateProfileVO;
  }

  /**
   * get language
   * 
   * @return dataList
   */
  @Override
  public CandidateProfileVO parseBackgroundLanguage(CandidateProfileVO candidateProfileVO, String text)
      throws ServiceApplicationException {

    text = text.replaceAll("[\u0020\u3000\u00a0\u0009]", " ").replaceAll(" {2,}", " ");// 将所有tab和所有种类的空格转换成一个英文空格
    try {
      String regex = null;
      ArrayList<String> languageAbilityList = this.getLanguageMatchGroup(text);

      CandidateBgLanguageVO candidateBgLanguageVO = null;
      List<CandidateBgLanguageVO> candidateBgLanguageVOList = new ArrayList<CandidateBgLanguageVO>();

      for (String str : languageAbilityList) {

        if (!StringUtils.isEmpty(str) && !str.equals("\r") && (str.indexOf("读写能力") >= 0 || str.indexOf("听说能力") >= 0)) {
          candidateBgLanguageVO = new CandidateBgLanguageVO();

          String arrData0;
          String arrData1;
          if (str.indexOf("|") >= 0) {
            String[] arrData = str.split("\\|");

            arrData0 = arrData[0];
            arrData1 = arrData[1];
          } else {
            arrData0 = str;
            arrData1 = str;
          }
          regex = "(\\S+)：读写能力(\\S+)";
          Pattern pattern = Pattern.compile(regex);
          Matcher matcher = pattern.matcher(arrData0);
          if (matcher.find()) {
            candidateBgLanguageVO.setName(matcher.group(1));
            // speakingProf
            candidateBgLanguageVO.setReadingProf(matcher.group(2));
            candidateBgLanguageVO.setWritingProf(matcher.group(2));

            regex = "(?<=听说能力)\\S+";
            // readingProf&writingProf,writingProf is same with readingProf
            candidateBgLanguageVO.setSpeakingProf(MappingUtil.matchSingle(regex, arrData1));
            
          }
          if (StringUtils.isEmpty(candidateBgLanguageVO.getReadingProf())) {
            candidateBgLanguageVO.setReadingProf("一般");
          }
          if (StringUtils.isEmpty(candidateBgLanguageVO.getWritingProf())) {
            candidateBgLanguageVO.setWritingProf("一般");
          }
          if (StringUtils.isEmpty(candidateBgLanguageVO.getSpeakingProf())) {
            candidateBgLanguageVO.setSpeakingProf("一般");
          }
          candidateBgLanguageVOList.add(candidateBgLanguageVO);
        }
      }

      candidateProfileVO.setLanguages(candidateBgLanguageVOList);
    } catch (Exception e) {
      throw new ServiceApplicationException("Languages parse error:" + e.getMessage());
    }

    return candidateProfileVO;
  }

  /**
   * get certificate
   * 
   * @return dataList
   */
  @Override
  // TODO It will be update if needed.
  public CandidateProfileVO parseBackgroundCertificate(CandidateProfileVO candidateProfileVO, String text)
      throws ServiceApplicationException {

//    text = text.replaceAll("[\u0020\u3000\u00a0\u0009]", " ").replaceAll(" {2,}", " ");// 将所有tab和所有种类的空格转换成一个英文空格
    try {
      List<CandidateBgCertificateVO> candidateBgCertificateVOList = new ArrayList<CandidateBgCertificateVO>();
      candidateProfileVO.setCertificates(candidateBgCertificateVOList);
    } catch (Exception e) {
      throw new ServiceApplicationException("Certificates parse error:" + e.getMessage());
    }

    return candidateProfileVO;
  }

  /**
   * work Exp match
   * 
   * @return workExp
   */
  public String getWorkExpMatchGroup(String text) {

    String regex = null;
    if (text.contains("项目经历")) {
      regex = "(?<=工作经历.{0,100}\\s)[\\S\\s]*(?=项目经历)";// 获取工作经历的正则[结果为多条，需要进一步解析]
    } else {
      regex = "(?<=工作经历.{0,100}\\s)[\\S\\s]*(?=教育经历)";// 获取工作经历的正则[结果为多条，需要进一步解析]
    }
    String workExp = MappingUtil.matchSingle(regex, text);

    return workExp;
  }

  /**
   * education match
   * 
   * @return education
   */
  public String getEducationMatchGroup(String text) {

    String regex = null;
    if(text.contains("培训经历")) {
      regex = "(?<=教育经历\\s)[\\S\\s]*(?=培训经历)";// 获取教育经历的正则[结果为多条，需要进一步解析]
    }else if(text.contains("证书")) {
      regex = "(?<=教育经历\\s)[\\S\\s]*?(?=证书)";
    }else {
      regex = "(?<=教育经历\\s)[\\S\\s]*";
    }
    String education = MappingUtil.matchSingle(regex, text).trim();

    return education;
  }

  public ArrayList<String> getLanguageMatchGroup(String text) {
    String regex = "(?<=语言能力\\s)[\\S\\s]*";// 获取语言能力的正则[结果为多条，需要进一步解析]
      String languageAbility = MappingUtil.matchSingle(regex, text).trim();
      String regexLan = "\\S*：(读写能力|听说能力)\\S*(\\s\\|\\s\\S*){0,1}";
      Pattern pattern = Pattern.compile(regexLan);
      Matcher matcher = pattern.matcher(languageAbility);
      ArrayList<String> arrLanguage = new ArrayList<String>();
      while(matcher.find()){
        arrLanguage.add(matcher.group());
      }
      
      
    return arrLanguage;
  }

  /**
   * format date to target date
   * 
   * @param dateStr
   * @return
   */
  private String formatDate(String dateStr) {
    return CandidateDateUtil.formatDate(SOURCE_DATE_FORMAT, TARGET_DATE_FORMAT, dateStr);
  }

}