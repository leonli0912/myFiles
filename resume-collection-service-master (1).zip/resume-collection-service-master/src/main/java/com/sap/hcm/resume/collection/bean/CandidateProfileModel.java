package com.sap.hcm.resume.collection.bean;

import java.io.Serializable;
import java.util.List;

public class CandidateProfileModel implements Serializable {
    /**
     * serialVersionUID
     */
    private static final long serialVersionUID = 684983055159651548L;

    private List<CandidateAttribute> attributes;

    /**
     * @return the attributes
     */
    public List<CandidateAttribute> getAttributes() {
        return attributes;
    }

    /**
     * @param attributes
     *            the attributes to set
     */
    public void setAttributes(List<CandidateAttribute> attributes) {
        this.attributes = attributes;
    }
    
    /**
     * 
     * @param proName
     * @return
     */
    public boolean isExtProfile(String proName) {
        if (this.attributes != null) {
            for (CandidateAttribute attr : attributes) {
                if (proName.equals(attr.getName())) {
                    return attr.getIsExt();
                }
            }
        }
        return false;
    }
    
    /**
     * 
     * @param proName
     * @return
     */
    public boolean isComplex(String proName) {
        if (this.attributes != null) {
            for (CandidateAttribute attr : attributes) {
                if (attr instanceof CandidateComplexAttribute) {
                    return true;
                }
            }
        }
        return false;
    }
}
