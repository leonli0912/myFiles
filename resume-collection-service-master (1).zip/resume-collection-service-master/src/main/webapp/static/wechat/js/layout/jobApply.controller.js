sap.ui.controller("static.wechat.js.layout.jobApply", {
	
	_router: null,
	_jobId : null,
	
//	/**
//	 * Called when a controller is instantiated and its View controls (if
//	 * available) are already created. Can be used to modify the View before it
//	 * is displayed, to bind event handlers and do other one-time
//	 * initialization.
//	 * 
//	 * @memberOf resume-collection-service.jobDetail
//	 */
	onInit : function() {
		this._router = sap.ui.core.UIComponent.getRouterFor(this);
		var that = this;
		
		this._router.getRoute("jobApply").attachPatternMatched(function(oEvent){
			var query = oEvent.getParameter("arguments")['?query'];
			if(query && query.jobId) {
				that._jobId = query.jobId;
			}else{
				that._jobId = null;
			}
		});
		
	},
	
	onButtonPress : function(oEvent){
		var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
		if(this._jobId) {
			oRouter.navTo("candidateList", {query:{jobId:this._jobId}});
		}else{
			oRouter.navTo("candidateList");
		}
	},
	
	importFrom51 : function(oEvent){
		if(this._jobId) {
			this._router.navTo("UserAuthorize",{vendorName: "job51", query:{jobId:this._jobId}});
		}else{
			this._router.navTo("UserAuthorize",{vendorName: "job51"});
		}
	},
	
	importFromZL : function(oEvent){
		if(this._jobId) {
			this._router.navTo("UserAuthorize",{vendorName: "zhilian", query:{jobId:this._jobId}});
		}else{
			this._router.navTo("UserAuthorize",{vendorName: "zhilian"});
		}
	},
	
	importFromLP : function(oEvent){
		if(this._jobId) {
			this._router.navTo("UserAuthorize",{vendorName: "liepin", query:{jobId:this._jobId}});
		}else{
			this._router.navTo("UserAuthorize",{vendorName: "liepin"});
		}
	},
	
	importFromDJ: function(oEvent){
		if(this._jobId) {
			this._router.navTo("UserAuthorize", {vendorName:"dajie", query:{jobId:this._jobId}});
		}else{
			this._router.navTo("UserAuthorize", {vendorName:"dajie"});
		}
	},
	
	createResume : function(oEvent){
		if(this._jobId) {
		this._router.navTo("candidateInput", {query:{jobId:this._jobId}});
		}else{
			this._router.navTo("candidateInput");
		}
	}
/**
 * Similar to onAfterRendering, but this hook is invoked before the controller's
 * View is re-rendered (NOT before the first rendering! onInit() is used for
 * that one!).
 * 
 * @memberOf resume-collection-service.jobDetail
 */
// onBeforeRendering: function() {
//
// },
/**
 * Called when the View has been rendered (so its HTML is part of the document).
 * Post-rendering manipulations of the HTML could be done here. This hook is the
 * same one that SAPUI5 controls get after being rendered.
 * 
 * @memberOf resume-collection-service.jobDetail
 */
// onAfterRendering: function() {
//
// },
/**
 * Called when the Controller is destroyed. Use this one to free resources and
 * finalize activities.
 * 
 * @memberOf resume-collection-service.jobDetail
 */
// onExit: function() {
//
// }
});