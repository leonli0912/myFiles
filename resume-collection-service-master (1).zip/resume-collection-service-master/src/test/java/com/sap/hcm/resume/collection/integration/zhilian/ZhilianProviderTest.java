
package com.sap.hcm.resume.collection.integration.zhilian;

import static org.junit.Assert.assertEquals;

import java.io.IOException;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.impl.client.CloseableHttpClient;
import org.jsoup.nodes.Document;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.springframework.mock.web.MockHttpServletRequest;

import com.sap.hcm.resume.collection.exception.AuthenticationFailedException;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.HttpRequestMatcher;
import com.sap.hcm.resume.collection.integration.MockHttpEntity;
import com.sap.hcm.resume.collection.integration.bean.ResumeDownloadBean;
import com.sap.hcm.resume.collection.util.CandidateFileUtil;

/**
 * @author I324117
 * SAP
 */
@RunWith(PowerMockRunner.class)
@PrepareForTest(CandidateFileUtil.class)
public class ZhilianProviderTest {
  
  private ZhilianProvider zhilianProvider;
  
  private HttpClient httpClient = null;
  
  @Before
  public void setUp() throws Exception {
    zhilianProvider = PowerMockito.spy(new ZhilianProvider());
    httpClient = Mockito.mock(CloseableHttpClient.class);

    PowerMockito.doReturn(httpClient).when(zhilianProvider,"createHttpClient");
  }
  
  @Test(expected=ServiceApplicationException.class)
  public void testPreLogin() throws ServiceApplicationException{
    zhilianProvider.preLogin();
  }
  
  @Test(expected=ServiceApplicationException.class)
  public void tesGetVerifyCode() throws ServiceApplicationException{
    MockHttpServletRequest mockRequest = new MockHttpServletRequest();
    zhilianProvider.getVerifyCode(mockRequest);
  }
  
  @Test(expected=ServiceApplicationException.class)
  public void testGetResumeFailWithLoginResponseIsNull() throws ClientProtocolException, IOException, ServiceApplicationException{
    HttpRequestMatcher loginPost = new HttpRequestMatcher(zhilianProvider.getLoginUrl());
    Mockito.when(httpClient.execute(Matchers.argThat(loginPost))).thenReturn(null);
    MockHttpServletRequest mockRequest = new MockHttpServletRequest();
    assertEquals(new ServiceApplicationException("failed to connect to zhilian"), zhilianProvider.getResume(mockRequest, "qaz", "wsx", "edc"));
  }
  
  @Test(expected=ServiceApplicationException.class)
  public void testGetResumeFailWithToStringIOEx() throws ClientProtocolException, IOException, ServiceApplicationException{
    HttpRequestMatcher loginPost = new HttpRequestMatcher(zhilianProvider.getLoginUrl());
    Mockito.when(httpClient.execute(Matchers.argThat(loginPost))).thenThrow(new IOException());
    MockHttpServletRequest mockRequest = new MockHttpServletRequest();
    assertEquals(new ServiceApplicationException("failed to connect to zhilian"), zhilianProvider.getResume(mockRequest, "qaz", "wsx", "edc"));
  }
  
  @Test(expected=ServiceApplicationException.class)
  public void testGetResumeFailWithTooManyLogin() throws ClientProtocolException, IOException, ServiceApplicationException{
    CloseableHttpResponse loginResponse = Mockito.mock(CloseableHttpResponse.class);
    HttpRequestMatcher loginPost = new HttpRequestMatcher(zhilianProvider.getLoginUrl());
    Mockito.when(httpClient.execute(Matchers.argThat(loginPost))).thenReturn(loginResponse);
    String continueText = "您的操作有些频繁";
    HttpEntity loginEntity = new MockHttpEntity("text/html; charset=utf-8", continueText);
    Mockito.when(loginResponse.getEntity()).thenReturn(loginEntity);
    
    MockHttpServletRequest mockRequest = new MockHttpServletRequest();
    assertEquals(new ServiceApplicationException("too many login attempt found"),zhilianProvider.getResume(mockRequest, "qaz", "wsx", "edc"));
  }
  
  @Test(expected=AuthenticationFailedException.class)
  public void testGetResumeFailWithAuthenticationFailedException() throws ClientProtocolException, IOException, ServiceApplicationException{
    CloseableHttpResponse loginResponse = Mockito.mock(CloseableHttpResponse.class);
    HttpRequestMatcher loginPost = new HttpRequestMatcher(zhilianProvider.getLoginUrl());
    Mockito.when(httpClient.execute(Matchers.argThat(loginPost))).thenReturn(loginResponse);
    String continueText = "用户登录_智联招聘";
    HttpEntity loginEntity = new MockHttpEntity("text/html; charset=utf-8", continueText);
    Mockito.when(loginResponse.getEntity()).thenReturn(loginEntity);
    
    MockHttpServletRequest mockRequest = new MockHttpServletRequest();
    assertEquals(new AuthenticationFailedException(),zhilianProvider.getResume(mockRequest, "qaz", "wsx", "edc"));
  }
  
  @Test(expected=ServiceApplicationException.class)
  public void testGetResumeFailWithFailedCallingAPI() throws ClientProtocolException, IOException, ServiceApplicationException{
    CloseableHttpResponse loginResponse = Mockito.mock(CloseableHttpResponse.class);
    HttpRequestMatcher loginPost = new HttpRequestMatcher(zhilianProvider.getLoginUrl());
    Mockito.when(httpClient.execute(Matchers.argThat(loginPost))).thenReturn(loginResponse);
    String continueText = "123";
    HttpEntity loginEntity = new MockHttpEntity("text/html; charset=utf-8", continueText);
    Mockito.when(loginResponse.getEntity()).thenReturn(loginEntity);
    
    HttpRequestMatcher getResumeIdGet = new HttpRequestMatcher(zhilianProvider.getServiceUrl());
    Mockito.when(httpClient.execute(Matchers.argThat(getResumeIdGet))).thenThrow(new IOException());
    MockHttpServletRequest mockRequest = new MockHttpServletRequest();
    assertEquals(new ServiceApplicationException("failed from calling remote API"),zhilianProvider.getResume(mockRequest, "qaz", "wsx", "edc"));
  }
  
  @Test
  public void testGetResumeSuccess() throws ClientProtocolException, IOException, ServiceApplicationException{
    CloseableHttpResponse loginResponse = Mockito.mock(CloseableHttpResponse.class);
    HttpRequestMatcher loginPost = new HttpRequestMatcher(zhilianProvider.getLoginUrl());
    Mockito.when(httpClient.execute(Matchers.argThat(loginPost))).thenReturn(loginResponse);
    String continueText = "<a href=\"aaa\">我不需要修改，确认跳过</a>";
    HttpEntity loginEntity = new MockHttpEntity("text/html; charset=utf-8", continueText);
    Mockito.when(loginResponse.getEntity()).thenReturn(loginEntity);
    HttpRequestMatcher continueGet = new HttpRequestMatcher("https://passport.zhaopin.comaaa");
    Mockito.when(httpClient.execute(Matchers.argThat(continueGet))).thenReturn(loginResponse);
    
    CloseableHttpResponse servicePageResponse = Mockito.mock(CloseableHttpResponse.class);
    HttpRequestMatcher getResumeIdGet = new HttpRequestMatcher(zhilianProvider.getServiceUrl());
    Mockito.when(httpClient.execute(Matchers.argThat(getResumeIdGet))).thenReturn(servicePageResponse);
    String resumeEntityContentZh = "<div class=\"myTxt\" data-ext_id=\"JM663827968R90250000000\" data-resume_id=\"240917343\" data-version_number=\"1\" data-language_id=\"1\">";
    String resumeEntityContentEn = "<div class=\"myTxt\" data-ext_id=\"JM663827968R90250000000\" data-resume_id=\"240917343\" data-version_number=\"1\" data-language_id=\"2\">";
    HttpEntity resumeIdEntity = new MockHttpEntity("text/html", resumeEntityContentZh+resumeEntityContentEn);
    Mockito.when(servicePageResponse.getEntity()).thenReturn(resumeIdEntity);
    
    CloseableHttpResponse resumeResponse = Mockito.mock(CloseableHttpResponse.class);
    HttpRequestMatcher getResumeGet = new HttpRequestMatcher("http://i.zhaopin.com/Home/resumeexport?resumeNumber=JM663827968R90250000000&resumeId=240917343&version=1&language=1&dflag=2");
    Mockito.when(httpClient.execute(Matchers.argThat(getResumeGet))).thenReturn(resumeResponse);
    HttpEntity resumeEntity = new MockHttpEntity("text/html", "chinese resume");
    Mockito.when(resumeResponse.getEntity()).thenReturn(resumeEntity);
    
    getResumeGet = new HttpRequestMatcher("http://i.zhaopin.com/Home/resumeexport?resumeNumber=JM663827968R90250000000&resumeId=240917343&version=1&language=2&dflag=2");
    Mockito.when(httpClient.execute(Matchers.argThat(getResumeGet))).thenReturn(resumeResponse);
    resumeEntity = new MockHttpEntity("text/html", "english resume");
    Mockito.when(resumeResponse.getEntity()).thenReturn(resumeEntity);
    
    MockHttpServletRequest mockRequest = new MockHttpServletRequest();
    List<ResumeDownloadBean> fileNameList = zhilianProvider.getResume(mockRequest, "qaz", "wsx", "edc");
    assertEquals(2, fileNameList.size());
  }
  
  
  @Test
  public void testGetFileContent() throws ServiceApplicationException{
    String content = "orz";
    Document doc = new Document("12");
    PowerMockito.mockStatic(CandidateFileUtil.class);
    PowerMockito.when(CandidateFileUtil.getFileContentFromHtml(content.getBytes())).thenReturn(doc);
    assertEquals(doc, zhilianProvider.getFileContent(content.getBytes()).getHtmlDocument());
  }

}
