package com.sap.hcm.resume.collection.entity.view;

import java.io.Serializable;
import java.util.List;

import com.sap.hcm.resume.collection.annotation.ExtendedProfile;
import com.sap.hcm.resume.collection.annotation.ProfileBackground;
import com.sap.hcm.resume.collection.entity.CandidateProfile;

/**
 * full candidate profile information for display
 * 
 * @author i065831
 */
public class CandidateProfileVO extends CandidateProfile implements Serializable {

  /**
   * 9030737842000082574L
   */
  private static final long serialVersionUID = -9030737842000082574L;

  /**
   * extended profile
   */
  @ExtendedProfile(name = CandidateProfileConstants.EXT_NAME, type = CandidateProfileExtVO.class)
  private CandidateProfileExtVO extProfile = new CandidateProfileExtVO();

  /**
   * work expr
   */
  @ProfileBackground(name = CandidateProfileConstants.BG_WORKEXPR_NAME, type = CandidateBgWorkExprVO.class)
  private List<CandidateBgWorkExprVO> workExprs;

  /**
   * language
   */
  @ProfileBackground(name = CandidateProfileConstants.BG_LANGU_NAME, type = CandidateBgLanguageVO.class)
  private List<CandidateBgLanguageVO> languages;

  /**
   * education
   */
  @ProfileBackground(name = CandidateProfileConstants.BG_EDUC_NAME, type = CandidateBgEducationVO.class)
  private List<CandidateBgEducationVO> education;

  /**
   * certificates
   */
  @ProfileBackground(name = CandidateProfileConstants.BG_CERT_NAME, type = CandidateBgCertificateVO.class)
  private List<CandidateBgCertificateVO> certificates;

  /**
   * family
   */
  @ProfileBackground(name = CandidateProfileConstants.BG_FAMI_NAME, type = CandidateBgFamilyVO.class)
  private List<CandidateBgFamilyVO> families;

  /**
   * @return the extProfile
   */
  public CandidateProfileExtVO getExtProfile() {
    return extProfile;
  }

  /**
   * @param extProfile
   *          the extProfile to set
   */
  public void setExtProfile(CandidateProfileExtVO extProfile) {
    this.extProfile = extProfile;
  }

  /**
   * @return the workExprs
   */
  public List<CandidateBgWorkExprVO> getWorkExprs() {
    return workExprs;
  }

  /**
   * @param workExprs
   *          the workExprs to set
   */
  public void setWorkExprs(List<CandidateBgWorkExprVO> workExprs) {
    this.workExprs = workExprs;
  }

  /**
   * @return the languages
   */
  public List<CandidateBgLanguageVO> getLanguages() {
    return languages;
  }

  /**
   * @param languages
   *          the languages to set
   */
  public void setLanguages(List<CandidateBgLanguageVO> languages) {
    this.languages = languages;
  }

  /**
   * @return the education
   */
  public List<CandidateBgEducationVO> getEducation() {
    return education;
  }

  /**
   * @param education
   *          the education to set
   */
  public void setEducation(List<CandidateBgEducationVO> education) {
    this.education = education;
  }

  /**
   * @return the certificates
   */
  public List<CandidateBgCertificateVO> getCertificates() {
    return certificates;
  }

  /**
   * @param certificates
   *          the certificates to set
   */
  public void setCertificates(List<CandidateBgCertificateVO> certificates) {
    this.certificates = certificates;
  }

  /**
   * @return the families
   */
  public List<CandidateBgFamilyVO> getFamilies() {
    return families;
  }

  /**
   * @param families
   *          the families to set
   */
  public void setFamilies(List<CandidateBgFamilyVO> families) {
    this.families = families;
  }

}
