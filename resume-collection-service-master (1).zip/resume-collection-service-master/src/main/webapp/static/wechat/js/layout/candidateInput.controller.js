sap.ui.define([
               'static/wechat/js/layout/ResumeInputUtil',
               'sap/ui/core/mvc/Controller',
               'sap/m/MessageBox'
               ], function(ResumeInputUtil, Controller, MessageBox){
	"use strict";
	var candidateInput = Controller.extend("static.wechat.js.layout.candidateInput",{
		_candidateId : null,
		_jobId: null,
		_mapping: [],
		_inputs: [],
		_profileLan: "zh",

		/**
		* Called when a controller is instantiated and its View controls (if available) are already created.
		* Can be used to modify the View before it is displayed, to bind event handlers and do other one-time initialization.
		* @memberOf resume-collection-service.CandidateInput
		*/
			onInit: function() {

				this._router = sap.ui.core.UIComponent.getRouterFor(this);
				var that = this;

				this._router.getRoute("candidateInput").attachPatternMatched(function(oEvent){
					var query = oEvent.getParameter("arguments")['?query'];
					if(query && query.jobId){
						that._jobId = query.jobId;
					}else{
						that._jobId = null;
					}
					if(query && query.profileLan){
						that._profileLan = query.profileLan;
					}
					that._candidateId = oEvent.getParameter("arguments").candidateId;
			        var oModel = null;
			        var aModel = new sap.ui.model.json.JSONModel();
			        var resumeInputUtil = new ResumeInputUtil();
			        if(that._candidateId){
			          oModel = resumeInputUtil.getCandidateData(that._candidateId);
			          var oData = oModel.getData();
			          aModel.setData(oData);
			          oData = oData.profile;
			          oModel.setData(oData);
			        }else{
			          oModel = resumeInputUtil.getCandidateData(null);
					  var oData = oModel.getData();
			          aModel.setData(oData);
			          oData = oData.profile;
			          oModel.setData(oData);
			        }
					that.getView().byId("candidateInputPage").setModel(oModel);
					that.getView().byId("candidateInputPage").setModel(aModel,"allData");
					var lanModel = new sap.ui.model.resource.ResourceModel({bundleName:"static.i18n.i18n",bundleLocale:that._profileLan});
					that.getView().setModel(lanModel, "pi18n");

					// attach handlers for validation errors
					sap.ui.getCore().attachValidationError(function (evt) {
						var control = evt.getParameter("element");
						control.getParent().addStyleClass("inputListItemErrorClass");
						MessageBox.alert(that.getView().getModel("wi18n").getResourceBundle().getText("ERROR_MSG_CANDIDATE_INPUT_INVALID"));
					});
					sap.ui.getCore().attachValidationSuccess(function (evt) {
						var control = evt.getParameter("element");
						control.getParent().removeStyleClass("inputListItemErrorClass");
					});

					var resumeInputUtil = new ResumeInputUtil();
				    var profilePanel = that.getView().byId("profilePanel");
				    var additionalFieldPanel = that.getView().byId("additionalFieldPanel");
					that._inputs = resumeInputUtil.buildGenericProfilePage("profile", profilePanel ,that.getView().getModel("pi18n"),that._profileLan);
					resumeInputUtil.buildGenericAdditionalFieldInput(additionalFieldPanel, aModel, that._profileLan);
				})
			},
			
			validate : function(oModel) {
				var additionalFieldPanel = this.getView().byId("additionalFieldPanel");
				var items = additionalFieldPanel.getContent();
				var canContinue = true;
				jQuery.each(items, function (i, item) {
					var input = item.getContent()[0];
					if(input instanceof sap.m.Input){
						if (!input.getValue()){
							input.getParent().addStyleClass("inputListItemErrorClass");
							canContinue = false;
						}
					}else if(input instanceof sap.m.Select){
						if(!input.getSelectedKey()){
							input.getParent().addStyleClass("inputListItemErrorClass");
							canContinue = false;
						}
					}
				});
				if(!canContinue){
					MessageBox.alert(oModel.getResourceBundle().getText("ERROR_MSG_CANDIDATE_INPUT_EMPTY"));
				}
				return canContinue
			},

			onSave : function() {
				if (!this.validate(this.getView().getModel("wi18n"))) {
					return;
				}
				var that = this;
				var aData = that.getView().byId("candidateInputPage").getModel("allData").getData();
				var oData = that.getView().byId("candidateInputPage").getModel().getData();
				aData.profile = oData;
				var jsonData = aData;
				var resumeInputUtil = new ResumeInputUtil();
				jsonData = resumeInputUtil.integrateExtProfile(jsonData);
				if (resumeInputUtil.validateRequiredInputs(that._inputs, that.getView().getModel("wi18n"))) {
					var cfg = {
						type : 'POST',
						data: JSON.stringify(jsonData),
						dataType : 'json',
						contentType : 'application/json;charset=UTF-8'
					};
					cfg.url = "cv/saveCandidate";
				    $.ajax(cfg).success(function(oEvent) {
				    	if(that._jobId) {
				    		that._router.navTo("candidatePreview",{candidateId:oEvent.candidateProfileVO.candidateId, query:{jobId:that._jobId,profileLan:that._profileLan}});
				    	}else {
				    		that._router.navTo("candidatePreview",{candidateId:oEvent.candidateProfileVO.candidateId, query:{profileLan:that._profileLan}});
				    	}
				    });
				}
			},

			onCancel : function() {

				var oHistory = sap.ui.core.routing.History.getInstance();
				var sPreviousHash = oHistory.getPreviousHash();

				if (sPreviousHash !== undefined) {
					window.history.go(-1);
				} else {
					var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
					oRouter.navTo("jobList", true);
				}
			},

			proLanTranslat:function(val){
				return this.getView().getModel("pi18n").getResourceBundle().getText(val);
			},

		/**
		* Similar to onAfterRendering, but this hook is invoked before the controller's View is re-rendered
		* (NOT before the first rendering! onInit() is used for that one!).
		* @memberOf resume-collection-service.CandidateInput
		*/
//			onBeforeRendering: function() {
//
//			},

		/**
		* Called when the View has been rendered (so its HTML is part of the document). Post-rendering manipulations of the HTML could be done here.
		* This hook is the same one that SAPUI5 controls get after being rendered.
		* @memberOf resume-collection-service.CandidateInput
		*/
//			onAfterRendering: function() {
//
//			},

		/**
		* Called when the Controller is destroyed. Use this one to free resources and finalize activities.
		* @memberOf resume-collection-service.CandidateInput
		*/
//			onExit: function() {
//
//			}
	});
	return candidateInput;
});
