package com.sap.hcm.resume.collection.integration.sf.cdm;

import org.junit.Assert;
import org.junit.Test;

import com.sap.hcm.resume.collection.integration.sf.bean.cdm.SFCDMFieldLabel;

public class SFCDMFieldLabelTest {
  
  @Test
  public void testGetterSetter(){
    SFCDMFieldLabel label = new SFCDMFieldLabel();
    label.setMimeType("mime");
    label.setValue("value");
    
    Assert.assertEquals("mime", label.getMimeType());
    Assert.assertEquals("value", label.getValue());
  }
}
