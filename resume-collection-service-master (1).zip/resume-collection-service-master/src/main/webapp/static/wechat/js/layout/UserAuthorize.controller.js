jQuery.sap.require("sap.m.MessageBox");
sap.ui.controller("static.wechat.js.layout.UserAuthorize", {

	_router: null,
	_vendor: null,
	_jobId:null,

	_oAuthData:{
		zhilian:{
			iconUrl:"static/wechat/img/zhilian.png"
		},
		job51:{
			iconUrl:"static/wechat/img/job51.png"
		},
		liepin:{
			iconUrl:"static/wechat/img/liepin.png"
		},
		dajie:{
			iconUrl:"static/wechat/img/dajie.png"
		}
	},

//	/**
//	 * Called when a controller is instantiated and its View controls (if
//	 * available) are already created. Can be used to modify the View before it
//	 * is displayed, to bind event handlers and do other one-time
//	 * initialization.
//	 *
//	 * @memberOf resume-collection-service.jobDetail
//	 */
	onInit : function() {
		this._router = sap.ui.core.UIComponent.getRouterFor(this);
		var that = this;

		this._router.attachRouteMatched(function(oEvent){
			if (oEvent.getParameter("name") !== "UserAuthorize") {
				return;
			}
			var query = oEvent.getParameter("arguments")['?query'];
			if(query && query.jobId) {
			that._jobId = query.jobId;
			}else{
				that._jobId = null;
			}
			that._vendor = oEvent.getParameter("arguments").vendorName;

			if (that._vendor === "job51" || that._vendor === "dajie" || that._vendor === "liepin") {
				that.getView().byId("verifyCode").setVisible(true);
				that.getView().byId("verifyCodeImg").setVisible(true);
				that.initPageData();
			} else {
				that.getView().byId("verifyCode").setVisible(false);
				that.getView().byId("verifyCodeImg").setVisible(false);
			}

			var oData = that._oAuthData[that._vendor];
			that.getView().byId("vendorIcon").setSrc(oData.iconUrl + "?random=" + that.generateRandomValue());

		});

		var oHistory = sap.ui.core.routing.History.getInstance();
		var sPreviousHash = oHistory.getPreviousHash();
		if(sPreviousHash && sPreviousHash.indexOf("jobdetail") >= 0){
			this._jobId = sPreviousHash.replace("jobdetail","").replace("apply","").replace(/\//g,"");
		}
		
		var that = this;
		var cfg = {
			type : 'GET',
			dataType : 'json',
			url : 'wechatuser/user'
		};
		$.ajax(cfg).success(function(data) {
			if (data && data.userInfo && data.userInfo.dpcsAgreed) {
				that.getView().byId("dpcsAgreed").setVisible(false);
			}
		});
	},

	initPageData : function() {
		this.preLogin();
		this.getVerifyCode();
	},

	preLogin : function() {
		var preLoginUrl = "parse/" + this._vendor + "/preLogin";
		var preLoginInfoModel = new sap.ui.model.json.JSONModel(preLoginUrl);
	},

	getVerifyCode : function() {
		var that = this;
		var verifyCodeUrl = "parse/" + this._vendor + "/verifyCode";
		var verifyCodeModel = new sap.ui.model.json.JSONModel(verifyCodeUrl);
		verifyCodeModel.attachRequestCompleted(function(oEvent) {
			var imageData = {
					verifyCodeUrl : "parse/verifyCodeImage" + "?random=" + that.generateRandomValue(),
			};
			verifyCodeModel.setData(imageData);
		});
		that.getView().setModel(verifyCodeModel);
	},
	generateRandomValue : function(){
		return Math.random();
	},
	authLogin: function(){

		var username = this.getView().byId("username").getValue();
		var password = this.getView().byId("password").getValue();
		var verifyCode = this.getView().byId("verifyCode").getValue();
		var aggreementCheck = this.getView().byId("aggreementCheck").getSelected();
		var dpcsShowed = this.getView().byId("dpcsAgreed").getVisible();
		if (dpcsShowed) {
			if(!aggreementCheck){
				sap.m.MessageBox.alert(
				    	this.translatWechatLabel("WEB_AUTH_AGGREMENT_ERROR"),
				    	{
				    		styleClass: bCompact? "sapUiSizeCompact" : ""
				    	}
				    );
				return;
			}
		}

		if (username === "" || password === "") {
			var bCompact = !!this.getView().$().closest(".sapUiSizeCompact").length;
			sap.m.MessageBox.alert(
			    	"请输入用户名和密码",
			    	{
			    		styleClass: bCompact? "sapUiSizeCompact" : ""
			    	}
			    );
			return;
		}

		this.getView().setBusy(true);
		var param = "?username=" + username +
					"&password=" + password +
					"&vendor=" + this._vendor + 
					"&dpcsAgreed=" + aggreementCheck;

		var that = this;
		var cfg = {
			type : 'POST',
			dataType : 'json'
		};

		cfg.url = "parse/pr/" + this._vendor + param;
		if(verifyCode){
			cfg.url = cfg.url + "&captcha=" + verifyCode;
		}

	    $.ajax(cfg).success(function(data) {
	    	that.getView().setBusy(false);
	    	if(data){
	    		if (that._vendor === "job51" || that._vendor === "dajie" || that._vendor === "liepin") {
	    			that.getVerifyCode();
	    		}
	    		//handle framework level error code
	    		if(!data.code){
					if(data.failureCount == 0){
						that.showMessage(that.getView().getModel("wi18n").getResourceBundle().getText("RESUME_IMPORT_SUCCESS"), jQuery.proxy(that.goToCandidateList, that));
					}else if (data.failureCount != 0 && data.failure[0].status == -1){
						that.showMessage(that.getView().getModel("wi18n").getResourceBundle().getText("RESUME_ALREADY_EXIST"), jQuery.proxy(that.goToCandidateList, that));
					}else{
						that.showMessage(data.failureCount + that.getView().getModel("wi18n").getResourceBundle().getText("RESUME_IMPORT_FAILED"), jQuery.proxy(that.goToCandidateList, that));
					}
	    		}else if (data.code){
	    			if(data.code == "-1001" || data.code == "-1002"){
	    				that.showMessage(that.getView().getModel("wi18n").getResourceBundle().getText(data.message));
	    			}else{
	    				that.showMessage(that.getView().getModel("wi18n").getResourceBundle().getText("CANDIDATE_LIST_ERROR_MESSAGE"));
	    			}
				}
	    	}else{
	    		that.showMessage(that.getView().getModel("wi18n").getResourceBundle().getText("CANDIDATE_LIST_ERROR_MESSAGE"));
	    	}
	    }).error(function(){
	    	that.getView().setBusy(false);
	    	that.showMessage(that.getView().getModel("wi18n").getResourceBundle().getText("RESUME_IMPORT_FAILED"));
	    });
	},

	showMessage: function(msg, onClose){
		sap.m.MessageBox.information(
			msg,
	    	{
	    		styleClass: true ? "sapUiSizeCompact" : "",
					onClose: onClose
	    	}
	    )
	},
	onButtonPress:function(oEvent){
		var oHistory = sap.ui.core.routing.History.getInstance();
		var sPreviousHash = oHistory.getPreviousHash();

		if (sPreviousHash !== undefined) {
			window.history.go(-1);
		}
	},

	goToCandidateList: function(){
		if(this._jobId){
			this._router.navTo("candidateList",{query:
			{
    			"jobId":this._jobId
    			}
    		});
		}else{
			this._router.navTo("candidateList");
		}
	},

	showAggreement: function(){
		var that = this;
		var cfg = {
			type : 'GET',
			dataType : 'json',
			url : 'company/dpcs'
		};
		$.ajax(cfg).success(function(data) {
			if (data) {
				var dpcsModel = new sap.ui.model.json.JSONModel();
				dpcsModel.setData(data);
				that.getView().setModel(dpcsModel);
			}
		});
		this.getView().byId("dpcsDialog").open();
	},
	translatWechatLabel : function(val) {
		if(!val) return "";
		return this.getView().getModel("wi18n")
				.getResourceBundle().getText(val);
	},

	dpcsDialogClose: function(){
		this.getView().byId("dpcsDialog").close();
	}

/**
 * Similar to onAfterRendering, but this hook is invoked before the controller's
 * View is re-rendered (NOT before the first rendering! onInit() is used for
 * that one!).
 *
 * @memberOf resume-collection-service.jobDetail
 */
// onBeforeRendering: function() {
//
// },
/**
 * Called when the View has been rendered (so its HTML is part of the document).
 * Post-rendering manipulations of the HTML could be done here. This hook is the
 * same one that SAPUI5 controls get after being rendered.
 *
 * @memberOf resume-collection-service.jobDetail
 */
// onAfterRendering: function() {
//
// },
/**
 * Called when the Controller is destroyed. Use this one to free resources and
 * finalize activities.
 *
 * @memberOf resume-collection-service.jobDetail
 */
// onExit: function() {
//
// }
});
