package com.sap.hcm.resume.collection.integration.wechat.controller;

import java.io.IOException;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.bean.SimpleJsonResponse;
import com.sap.hcm.resume.collection.controller.ControllerBase;
import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.entity.Photo;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatApplyHistory;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatAuth;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatUser;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatAuthService;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatJobService;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatUserService;
import com.sap.hcm.resume.collection.integration.wechat.util.Constraints;

/**
 * @author I324117
 */
@Controller
@RequestMapping(value = "wechatuser")
public class UserInfoController extends ControllerBase {

  /**
   * logger
   */
  private static final Logger logger = LoggerFactory.getLogger(UserInfoController.class);

  private final static String WECHATUSER_LOGO = "_logo";

  @Autowired
  private WechatUserService wechatUserService;

  @Autowired
  private WechatJobService wechatJobService;

  @Autowired
  private WechatAuthService wechatAuthService;

  @Autowired
  private Params params;

  @RequestMapping(value = { "/user" }, method = { org.springframework.web.bind.annotation.RequestMethod.GET })
  @ResponseBody
  public Map<String, Object> getUserInfoList(HttpSession session) throws ServiceApplicationException, IOException {
    Map<String, Object> map = new HashMap<String, Object>();
    String userEmail = params.getUserEmail();
    String companyId = params.getCompanyId();
    if (!StringUtils.isEmpty(userEmail)) {
      WechatUser wechatUser = wechatUserService.getUserInfoByEmail(userEmail, companyId);
      map.put("userInfo", wechatUser);
    }
    if (!StringUtils.isEmpty(companyId)) {
      CompanyInfo companyInfo = compInfoService.getCompanyInfo(companyId);
      map.put("companyInfo", companyInfo);
    }
    return map;
  }

  @RequestMapping(value = "/userinfo/save", method = RequestMethod.POST)
  public @ResponseBody WechatUser bindInternalEmail(HttpSession session, @RequestBody WechatUser wechatUser,
      @RequestParam("verifyCode") String verifyCodeInput) throws ServiceApplicationException {
    WechatUser wechatUserInfo = null;

    String companyId = params.getCompanyId();

    WechatUser wu = wechatUserService.getUserInfoByEmail(wechatUser.getWechatId(), companyId);

    Photo photo = new Photo();
    if (!StringUtils.isEmpty(wu.getPhotoId())) {
      photo.setPhotoId(wu.getPhotoId());
    }
    photo.setCategory("wechat_portrait");
    String portraitSessionKey = params.getWechatOpenId() + WECHATUSER_LOGO;
    byte[] portrait = (byte[]) session.getAttribute(portraitSessionKey);
    if (!StringUtils.isEmpty(portrait)) {
      photo.setContent((byte[]) session.getAttribute(portraitSessionKey));
      session.removeAttribute(portraitSessionKey);
      photo = wechatUserService.saveImg(photo);
    }
    wechatUser.setPhotoId(photo.getPhotoId());
    wechatUser.setCompanyId(companyId);
    wechatUserInfo = wechatUserService.saveWechatUser(wechatUser);
    session.setAttribute(Constraints.SESSION_KEY_VERIFICATION_CODE, "");
    return wechatUserInfo;
  }

  @RequestMapping(value = "/applyHistory", method = RequestMethod.GET)
  public @ResponseBody List<WechatApplyHistory> getApplyHistoryList(HttpServletRequest request) {

    List<WechatApplyHistory> applyHistoryList = new ArrayList<WechatApplyHistory>();

    // get wechatId and companyId from session
    String companyId = params.getCompanyId();
    String userEmail = params.getUserEmail();

    try {
      applyHistoryList = wechatJobService.findApplyHistory(userEmail, companyId, null);
    } catch (ServiceApplicationException e) {
      e.printStackTrace();
    }

    return applyHistoryList;
  }

  @RequestMapping(value = "/sendEmail", method = RequestMethod.GET)
  public @ResponseBody SimpleJsonResponse verifyInternalEmail(HttpServletRequest request,
      @RequestParam("email") String email) throws ServiceApplicationException {
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(1);

    SecureRandom sr = new SecureRandom();
    sr.setSeed((new Date()).getTime());
    Double rnd = sr.nextDouble();

    int code = (int) ((rnd * 9 + 1) * 1000);
    String verifyCode = Integer.toString(code);
    HttpSession session = request.getSession();
    session.setAttribute(Constraints.SESSION_KEY_VERIFICATION_CODE, verifyCode);

    try {
      wechatUserService.sendVerificationCode(email, verifyCode);
    } catch (ServiceApplicationException e) {
      rsp.setCode(-1);
      rsp.setMessage("send email failed");
      logger.error("send email failed with exception: " + e.getMessage());
    }

    return rsp;
  }

  @RequestMapping(value = "/userinfo/validateInternalEmail", method = RequestMethod.GET)
  public @ResponseBody SimpleJsonResponse fetchUserInfo(HttpServletRequest request) {
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    String companyId = params.getCompanyId();
    String userEmail = params.getUserEmail();

    WechatUser wu = wechatUserService.getUserInfoByEmail(userEmail, companyId);
    if (!StringUtils.isEmpty(wu.getInternalEmail())) {
      rsp.setCode(1);
    } else {
      rsp.setCode(-1);
    }

    return rsp;
  }

  @RequestMapping(value = "checkApplied", method = RequestMethod.GET)
  public @ResponseBody SimpleJsonResponse checkAlreadyApplied(HttpServletRequest request) {
    // get wechatId and companyId from session
    SimpleJsonResponse rsp = new SimpleJsonResponse();
    rsp.setCode(-1);
    rsp.setMessage("not applied");
    List<WechatApplyHistory> applyList = this.getApplyHistoryList(request);
    if (applyList != null && !applyList.isEmpty()) {
      rsp.setCode(0);
      rsp.setMessage("applied");
    }
    return rsp;
  }
  
  @RequestMapping(value = "checkUserExist", method = RequestMethod.GET)
  public @ResponseBody Map<String, Object> checkExistByOpenId() throws ServiceApplicationException {
    Map<String, Object> data = new HashMap<String, Object>();
    try {
      WechatAuth wechatAuth = wechatAuthService.getWechatAuthByOpenId(params.getWechatOpenId(), params.getCompanyId());
      if (wechatAuth != null) {
        data.put("primaryEmail", wechatAuth.getPrimaryEmail());
      } else {
        data.put("primaryEmail", null);
      }
    } catch(Exception ex) {
      throw new ServiceApplicationException(ex.getMessage());
    }
    return data;
  }
  
  @RequestMapping(value = "checkEmailExist", method = RequestMethod.GET)
  public @ResponseBody Map<String, Object> checkExistByEmail(@RequestParam("email") String email) throws ServiceApplicationException {
    Map<String, Object> data = new HashMap<String, Object>();
    try {
      List<WechatAuth> wechatAuthList = wechatAuthService.getWechatAuthByEmail(email, params.getCompanyId());
      data.put("exist", wechatAuthList.size());
    } catch(Exception ex) {
      throw new ServiceApplicationException(ex.getMessage());
    }
    return data;
  }
  
  @RequestMapping(value = "saveAuth", method = RequestMethod.POST)
  public @ResponseBody WechatAuth saveWechatAuth(@RequestParam("email") String email) throws ServiceApplicationException {
    WechatAuth wechatAuth = new WechatAuth();
    wechatAuth.setOpenId(params.getWechatOpenId());
    wechatAuth.setCompanyId(params.getCompanyId());
    wechatAuth.setPrimaryEmail(email);
    try {
      wechatAuth = wechatAuthService.saveWechatAuth(wechatAuth);
      
      //set the user email to the params
      params.setUserEmail(email);
      
      //check whether wechat user is exist
      //use user's email as wechat user id
      WechatUser user = wechatUserService.getUserInfoByEmail(email, params.getCompanyId());
      if(user == null || user.getWechatId() == null){
        user = new WechatUser();
        user.setActive(true);
        user.setCompanyId(params.getCompanyId());
        user.setDpcsAgreed(false);
        user.setLoginTime(new Date());
        user.setWechatId(email);
        wechatUserService.saveWechatUser(user);
      }
      
    } catch(Exception ex) {
      throw new ServiceApplicationException(ex.getMessage());
    }
    
    
    
    return wechatAuth;
  }
}
