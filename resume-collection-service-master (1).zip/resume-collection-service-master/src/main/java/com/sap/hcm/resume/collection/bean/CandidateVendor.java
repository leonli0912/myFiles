package com.sap.hcm.resume.collection.bean;

import java.io.Serializable;

public class CandidateVendor implements Serializable{
	
	/**
	 * serialVersionUID
	 */
    private static final long serialVersionUID = 3485200221955604928L;

	private CandidateVendorEnum name;
	
	private CountryEnum country;
	
	private String templateName;
	
	private String templatePath;
	
	public CandidateVendor(){
	  
	}
	
	public CandidateVendor(CountryEnum country, CandidateVendorEnum name, String templateName, String templatePath){
		this.name = name;
		this.country = country;
		this.templateName = templateName;
		this.templatePath = templatePath;
	}
	
	/**
	 * @return the name
	 */
	public CandidateVendorEnum getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(CandidateVendorEnum name) {
		this.name = name;
	}

	/**
	 * @return the country
	 */
	public CountryEnum getCountry() {
		return country;
	}

	/**
	 * @param country the country to set
	 */
	public void setCountry(CountryEnum country) {
		this.country = country;
	}

	/**
	 * @return the templateName
	 */
	public String getTemplateName() {
		return templateName;
	}

	/**
	 * @param templateName the templateName to set
	 */
	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	/**
	 * @return the templatePath
	 */
	public String getTemplatePath() {
		return templatePath;
	}

	/**
	 * @param templatePath the templatePath to set
	 */
	public void setTemplatePath(String templatePath) {
		this.templatePath = templatePath;
	}
	
}
