package com.sap.hcm.resume.collection.integration.sf.cdm;

import org.junit.Assert;
import org.junit.Test;

import com.sap.hcm.resume.collection.integration.sf.bean.cdm.SFCDMFieldEnum;


public class SFCDMFieldEnumTest {
  
  @Test
  public void testGetterSetter(){
    SFCDMFieldEnum fenum = new SFCDMFieldEnum();
    fenum.setEnumLabel(null);
    fenum.setValue("test");
    
    Assert.assertEquals(null, fenum.getEnumLabel());
    Assert.assertEquals("test", fenum.getValue());
  }
}
