package com.sap.hcm.resume.collection.integration.xml;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.SortedSet;
import java.util.TreeSet;

import org.apache.commons.io.IOUtils;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.core.io.ClassPathResource;

import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.bean.CandProfileDataModelMapping;
import com.sap.hcm.resume.collection.integration.bean.DataMappingOverwrite;
import com.sap.hcm.resume.collection.integration.bean.DataMappingPicklist;
import com.sap.hcm.resume.collection.integration.bean.DataMappingPicklistOption;
import com.sap.hcm.resume.collection.integration.bean.DataMappingPkOptionMapping;
import com.sap.hcm.resume.collection.integration.bean.DataModelMappingItem;

public class DataModelMappingXMLConverterTest {

  private static CandProfileDataModelMapping candProfileDataModelMapping = new CandProfileDataModelMapping();

  private static String jobReqXML = null;

  private static DataMappingPkOptionMapping dataMappingPkOptionMapping = new DataMappingPkOptionMapping();

  @BeforeClass
  public static void Init() throws IOException {
    // CandProfileDataModelMapping
    SortedSet<DataModelMappingItem> itemList = new TreeSet<DataModelMappingItem>();
    DataModelMappingItem item = new DataModelMappingItem();
    item.setFrom("hehe");
    item.setTo("haha");
    itemList.add(item);

    Map aMap = new HashMap();
    aMap.put("work", "workexP");
    aMap.put("shit", "shitExp");
    candProfileDataModelMapping.setAliases(aMap);

    candProfileDataModelMapping.setProfile(itemList);

    candProfileDataModelMapping.setCertificates(itemList);

    DataMappingPkOptionMapping pkOptionMap = new DataMappingPkOptionMapping();

    List<DataMappingPicklist> pkList = new ArrayList<DataMappingPicklist>();
    DataMappingPicklist pk = new DataMappingPicklist();
    pk.setId("major");
    pk.setOther("未知");

    List<DataMappingPicklistOption> opList = new ArrayList<DataMappingPicklistOption>();
    DataMappingPicklistOption op = new DataMappingPicklistOption();
    op.setSource("haha");
    op.setTarget("ala");
    opList.add(op);

    op = new DataMappingPicklistOption();
    op.setSource("学士");
    op.setTarget("硕士");
    opList.add(op);

    pk.setOptions(opList);

    pkList.add(pk);
    pkOptionMap.setPicklists(pkList);

    candProfileDataModelMapping.setPicklistOptionMapping(pkOptionMap);

    String rule1 = "a = b + c";
    String rule2 = "b =d";
    List<String> overwrite = new ArrayList<String>();
    overwrite.add(rule1);
    overwrite.add(rule2);
    DataMappingOverwrite ov = new DataMappingOverwrite();
    ov.setRules(overwrite);

    candProfileDataModelMapping.setDataMappingOverwrites(ov);

    // JobReqDataModelMappingXML
    ClassPathResource resource = new ClassPathResource("/xml/job_requisition_model_mapping.xml");
    InputStream is = null;
    try {
      is = resource.getInputStream();
      jobReqXML = IOUtils.toString(is, "utf-8");

      // DataMappingPkOptionMapping
      dataMappingPkOptionMapping = new DataMappingPkOptionMapping();
      dataMappingPkOptionMapping.setPicklists(pkList);
    } catch (IOException e) {
    } finally {
      IOUtils.closeQuietly(is);
    }
  }

  @Test
  public void testMappingToXML() {
    String xml = DataModelMappingXMLConverter.toXML(candProfileDataModelMapping);
    Assert.assertNotNull(xml);
  }

  @Test
  public void testMappingFromXML() {
    String xml = DataModelMappingXMLConverter.toXML(candProfileDataModelMapping);
    Assert.assertEquals("hehe", DataModelMappingXMLConverter.fromXML(xml).getProfile().first().getFrom());
  }

  @Test
  public void testMappingFromByte() {
    byte[] content = DataModelMappingXMLConverter.toXML(candProfileDataModelMapping).getBytes(StandardCharsets.UTF_8);
    Assert.assertEquals("hehe", DataModelMappingXMLConverter.fromByte(content).getProfile().first().getFrom());
  }

  @Test
  public void testFromJobReqXML() throws IOException {
    Assert.assertEquals("country", DataModelMappingXMLConverter.fromJobReqXML(jobReqXML).getItems().get(0)
        .getSourceField());
  }

  @Test
  public void testFromJobReqByteSuccess() throws IOException, ServiceApplicationException {
    byte[] content = jobReqXML.getBytes(StandardCharsets.UTF_8);
    Assert.assertEquals("country", DataModelMappingXMLConverter.fromJobReqByte(content, "utf-8").getItems().get(0)
        .getSourceField());
  }

  @Test(expected = ServiceApplicationException.class)
  public void testFromJobReqByteFail() throws IOException, ServiceApplicationException {
    byte[] content = jobReqXML.getBytes(StandardCharsets.UTF_8);
    DataModelMappingXMLConverter.fromJobReqByte(content, "123");
  }

  @Test
  public void testFromApplyStatusReqXML() throws IOException {
    ClassPathResource resource = new ClassPathResource("/xml/apply_status_req.xml");
    InputStream is = null;
    try {
      is = resource.getInputStream();
      String applyStatusReqXML = IOUtils.toString(is, "utf-8");
      Assert.assertEquals("484", DataModelMappingXMLConverter.fromApplyStatusReqXML(applyStatusReqXML)
          .getStatusSetItem().get(1).getStatusSetItemId());
    } catch (IOException e) {
    } finally {
      IOUtils.closeQuietly(is);
    }
  }

  @Test
  public void testToOptionXML() {
    String optionXml = DataModelMappingXMLConverter.toOptionXML(dataMappingPkOptionMapping);
    Assert.assertNotNull(optionXml);
  }

  @Test
  public void testFromOptionXML() {
    String optionXml = DataModelMappingXMLConverter.toOptionXML(dataMappingPkOptionMapping);
    Assert.assertEquals("major", DataModelMappingXMLConverter.fromOptionXML(optionXml).getPicklists().get(0).getId());
  }

}
