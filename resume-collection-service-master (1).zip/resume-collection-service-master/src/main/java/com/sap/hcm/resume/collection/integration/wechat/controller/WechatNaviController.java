package com.sap.hcm.resume.collection.integration.wechat.controller;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.IOUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.sap.hcm.resume.collection.bean.Params;
import com.sap.hcm.resume.collection.bean.SimpleJsonResponse;
import com.sap.hcm.resume.collection.controller.ControllerBase;
import com.sap.hcm.resume.collection.entity.CompanyInfo;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.wechat.entity.OAuthAccessToken;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatAuth;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatAuthService;
import com.sap.hcm.resume.collection.integration.wechat.service.WechatLoginService;
import com.sap.hcm.resume.collection.service.PhotoService;
import com.sap.hcm.resume.collection.util.HTTPConnection;

@Controller
@RequestMapping(value = "wechat")
public class WechatNaviController extends ControllerBase {

  @Autowired
  PhotoService photoService;

  @Autowired
  HTTPConnection httpConnection;

  @Autowired
  WechatLoginService wechatLoginService;

  @Autowired
  WechatAuthService wechatAuthService;

  @Autowired
  private Params params;

  private final Logger logger = LoggerFactory.getLogger(WechatNaviController.class);

  @RequestMapping(value = "local/{wechatOpenId}", method = RequestMethod.GET)
  public ModelAndView localTest(HttpSession session, HttpServletRequest request, HttpServletResponse response,
      @PathVariable(value = "wechatOpenId") String wechatOpenId) throws ServiceApplicationException, IOException {
    String companyId = params.getCompanyId();
    params.setWechatOpenId(wechatOpenId);

    WechatAuth wechatAuth = wechatAuthService.getWechatAuthByOpenId(wechatOpenId, companyId);

    if (wechatAuth == null || StringUtils.isEmpty(wechatAuth.getOpenId())) {
      wechatAuth = new WechatAuth();
      wechatAuth.setOpenId(wechatOpenId);
      wechatAuth.setCompanyId(companyId);
      wechatAuth.setLastModify(new Date());
      wechatAuth.setCreateAt(new Date());
      wechatAuthService.saveWechatAuth(wechatAuth);
    } else {
      params.setUserEmail(wechatAuth.getPrimaryEmail());
    }

    ModelAndView mav = new ModelAndView();
    mav.setViewName("redirect:/wechat/index/");
    return mav;
  }

  @RequestMapping(value = "/{companyId}", method = RequestMethod.GET)
  public void visitWechatPage(HttpSession session, HttpServletRequest request, HttpServletResponse response,
      @PathVariable(value = "companyId") String companyId, @RequestParam(value = "jobId", required = false) Long jobId)
      throws ServiceApplicationException, IOException {
    if (companyId == null) {
      throw new ServiceApplicationException("Company Id is invalid");
    }
    if(jobId != null){
      request.getSession().setAttribute("jobId", jobId);
    }
    String redirectUrl = request.getRequestURL().toString();
    String loginUrl = wechatLoginService.getLoginURL(companyId,
        redirectUrl.substring(0, redirectUrl.length() - 1 - companyId.length()));
    response.sendRedirect(loginUrl);
  }

  @RequestMapping(value = "/callback/{companyId}", method = RequestMethod.GET)
  public ModelAndView gotoWechatPage(HttpSession session, HttpServletRequest request, HttpServletResponse response,
      @RequestParam(value = "code", required = true) String code) throws ServiceApplicationException {
    ModelAndView mav = new ModelAndView();
    String companyId = params.getCompanyId();
    OAuthAccessToken oAuthAccessToken = wechatLoginService.getOAuthAccessToken(code);
    if (oAuthAccessToken != null) {
      // String accessToken = oAuthAccessToken.getAccessToken();
      String openId = oAuthAccessToken.getOpenId();
      params.setWechatOpenId(openId);

      WechatAuth wechatAuth = wechatAuthService.getWechatAuthByOpenId(openId, companyId);

      if (wechatAuth == null || StringUtils.isEmpty(wechatAuth.getOpenId())) {
        wechatAuth = new WechatAuth();
        wechatAuth.setOpenId(openId);
        wechatAuth.setCompanyId(companyId);
        wechatAuth.setLastModify(new Date());
        wechatAuth.setCreateAt(new Date());
        wechatAuthService.saveWechatAuth(wechatAuth);
      } else {
        params.setUserEmail(wechatAuth.getPrimaryEmail());
      }

    } else {
      throw new ServiceApplicationException("Retrieve access token error");
    }
    mav.setViewName("redirect:/wechat/index/");
    return mav;

  }

  @RequestMapping(value = "/index/", method = RequestMethod.GET)
  public ModelAndView changeWechatPage(HttpSession session, HttpServletRequest request, HttpServletResponse response) {
    ModelAndView mav = new ModelAndView();
    mav.setViewName("wechat");

    String openId = params.getWechatOpenId();
    String companyId = params.getCompanyId();

    // validate Company first
    // get companyLogo from companyInfo
    CompanyInfo companyInfo = getCompanyInfo(companyId);
    if (companyInfo == null) {
      mav.setViewName("invalid_company");
      return mav;
    }

    Map<String, Object> comInfoMap = new HashMap<String, Object>();
    comInfoMap.put("logo", companyInfo.getLogoId());
    comInfoMap.put("qrcode", companyInfo.getTwoDimensionCode());

    // initial setup
    ObjectMapper mapper = new ObjectMapper();

    // add wechatId to page
    if (StringUtils.isEmpty(openId)) {
      comInfoMap.put("isLogin", false);
    } else {
      comInfoMap.put("isLogin", true);
    }
    comInfoMap.put("cdmId", companyInfo.getDmMappingId());
    comInfoMap.put("companyId", companyId);
    try {
      mav.addObject("companyInfo", mapper.writeValueAsString(comInfoMap));
    } catch (JsonProcessingException e) {
      mav.addObject("companyInfo", "{}");
    }
    return mav;

  }

  private CompanyInfo getCompanyInfo(String companyId) {

    try {
      CompanyInfo companyInfo = compInfoService.getCompanyInfo(companyId);
      return companyInfo;
    } catch (ServiceApplicationException e) {
      return null;
    }
  }

  @RequestMapping(value = "/getsig", method = RequestMethod.GET)
  public @ResponseBody Map<String, String> getWechatJsSignature(@RequestParam(value = "url") String url,
      HttpServletRequest request) throws ServiceApplicationException, IOException {

    return wechatLoginService.getWechatJsAPIConfiguration(params.getCompanyId(), url, request);
  }

  @RequestMapping(value = "menu_create", method = RequestMethod.POST)
  public @ResponseBody SimpleJsonResponse createMenu(HttpServletRequest request,
      @RequestParam(value = "appId") String appId, @RequestParam(value = "appSecret") String appSecret)
      throws ServiceApplicationException, FileNotFoundException, IOException {

    String companyId = "sap";
    SimpleJsonResponse rsp = new SimpleJsonResponse();

    if (StringUtils.isEmpty(appId) || StringUtils.isEmpty(appSecret)) {
      logger.error("wechat appId : " + appId + " do not have a valid appSecret");
      throw new ServiceApplicationException("wechat appid and appsecret is not created");
    }
    try {
      String access_token = wechatLoginService.getAccessToken(companyId, appId, appSecret);
      String menuString = IOUtils.toString(request.getInputStream(), "UTF-8");
      String result = wechatLoginService.createMenu(access_token, menuString);
      if ("success".equals(result)) {
        rsp.setCode(0);
        rsp.setMessage("create menu success");
      } else {
        rsp.setCode(-1);
        rsp.setMessage("");
      }
    } catch (IOException e) {
      throw new ServiceApplicationException(e.getMessage());
    }
    return rsp;
  }
}
