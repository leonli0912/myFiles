package com.sap.hcm.resume.collection.bean;

import org.junit.Assert;
import org.junit.Test;


public class JobRequisitionAttributeTest {
  
  @Test
  public void testGetterSetter(){
    JobRequisitionAttribute attr = new JobRequisitionAttribute();
    attr.setFilterable(false);
    attr.setLabel("test");
    attr.setName("test");
    attr.setType("test");
    
    Assert.assertEquals(attr.isFilterable(), false);
    Assert.assertEquals(attr.getLabel(), "test");
    Assert.assertEquals(attr.getName(), "test");
    Assert.assertEquals(attr.getType(), "test");
  }
}
