package com.sap.hcm.resume.collection.integration.wechat.service;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.wechat.entity.WechatAuth;

@Service
public class WechatAuthService {

  private Logger logger = LoggerFactory.getLogger(WechatAuthService.class);

  @PersistenceContext
  private EntityManager entityManager;
  
  public WechatAuth getWechatAuthByOpenId(String openId, String companyId) throws ServiceApplicationException {
    try {
      String sel = "select au from WechatAuth au where au.openId = :openId and au.companyId = :companyId";
      TypedQuery<WechatAuth> queryJobInfo = entityManager.createQuery(sel, WechatAuth.class);
      queryJobInfo.setParameter("openId", openId);
      queryJobInfo.setParameter("companyId", companyId);
      List<WechatAuth> wechatAuthList = queryJobInfo.getResultList();
      if (wechatAuthList != null && !wechatAuthList.isEmpty()) {
        return wechatAuthList.get(0);
      } else {
        return null;
      }
    } catch (Exception ex) {
      logger.error("failed to get WechatAuth : " + ex.getMessage());
      throw new ServiceApplicationException("failed to get WechatAuth");
    }
  }
  
  public List<WechatAuth> getWechatAuthByEmail(String primaryEmail, String companyId) throws ServiceApplicationException {
    try {
      String sel = "select au from WechatAuth au where au.primaryEmail = :primaryEmail and au.companyId = :companyId";
      TypedQuery<WechatAuth> queryJobInfo = entityManager.createQuery(sel, WechatAuth.class);
      queryJobInfo.setParameter("primaryEmail", primaryEmail);
      queryJobInfo.setParameter("companyId", companyId);
      List<WechatAuth> wechatAuthList = queryJobInfo.getResultList();
      return wechatAuthList;
    } catch (Exception ex) {
      logger.error("failed to get WechatAuth : " + ex.getMessage());
      throw new ServiceApplicationException("failed to get WechatAuth");
    }
  }
  
  public WechatAuth saveWechatAuth(WechatAuth wechatAuth) throws ServiceApplicationException {
    try {
      WechatAuth wechatAuthExist = this.getWechatAuthByOpenId(wechatAuth.getOpenId(), wechatAuth.getCompanyId());
      if (wechatAuthExist == null) {
        wechatAuth.setCreateAt(new Date());
      }
      wechatAuth.setLastModify(new Date());
      wechatAuth = entityManager.merge(wechatAuth);
      return wechatAuth;
    } catch (Exception ex) {
      logger.error("failed to save WechatAuth : " + ex.getMessage());
      throw new ServiceApplicationException("failed to save WechatAuth");
    }
  }
}
