package com.sap.hcm.resume.collection.bean;

import org.jsoup.nodes.Document;

/**
 * @author I324117 SAP
 */
public class ResumeInfo {

  private String textContent;

  private String resumeExtension;

  private byte[] attachment;

  private String charset;
  
  private Document htmlDocument;

  /**
   * @return the resumeEncode
   */
  public String getCharset() {
    return charset;
  }

  /**
   * @param resumeEncode
   *          the resumeEncode to set
   */
  public void setCharset(String charset) {
    this.charset = charset;
  }

  public String getTextContent() {
    return textContent;
  }

  public void setTextContent(String textContent) {
    this.textContent = textContent;
  }

  public String getResumeExtension() {
    return resumeExtension;
  }

  public void setResumeExtension(String resumeName) {
    this.resumeExtension = resumeName;
  }

  public byte[] getAttachment() {
    return attachment;
  }

  public void setAttachment(byte[] attachment) {
    this.attachment = attachment;
  }

  /**
   * @return the htmlDocument
   */
  public Document getHtmlDocument() {
    return htmlDocument;
  }

  /**
   * @param htmlDocument the htmlDocument to set
   */
  public void setHtmlDocument(Document htmlDocument) {
    this.htmlDocument = htmlDocument;
  }
 
}
