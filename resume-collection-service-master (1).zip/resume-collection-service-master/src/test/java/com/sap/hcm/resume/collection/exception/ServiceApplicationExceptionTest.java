package com.sap.hcm.resume.collection.exception;


import org.junit.Assert;
import org.junit.Test;

public class ServiceApplicationExceptionTest {
  
  @Test
  public void testValidException(){
    ServiceApplicationException exp = new ServiceApplicationException("test");
    ServiceApplicationException exp2 = new ServiceApplicationException(20, "test");
    ServiceApplicationException exp3 = new ServiceApplicationException("test", new ServiceApplicationException("test"));
    ServiceApplicationException exp4 = new ServiceApplicationException("test", new ServiceApplicationException("test"));
    exp4.setCode(20);
    
    Assert.assertNotNull(exp);
    Assert.assertNotNull(exp2);
    Assert.assertEquals(exp2.getCode(), 20);
    Assert.assertNotNull(exp3);
    Assert.assertEquals(exp4.getCode(), 20);
  }
}
