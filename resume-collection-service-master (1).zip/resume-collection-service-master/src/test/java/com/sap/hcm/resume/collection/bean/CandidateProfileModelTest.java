package com.sap.hcm.resume.collection.bean;

import java.util.ArrayList;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

public class CandidateProfileModelTest {
  
  /**
   * test external candidate
   */
  @Test
  public void testIsExtCandidate(){
    CandidateAttribute attr = new CandidateAttribute();
    attr.setIsExt(true);
    attr.setName("test");
    List<CandidateAttribute> attrList = new ArrayList<CandidateAttribute>();
    attrList.add(attr);
    
    CandidateProfileModel model = new CandidateProfileModel();
    model.setAttributes(attrList);
    
    boolean result = model.isExtProfile(attr.getName());
    
    Assert.assertEquals(result, true);
  }
  
  @Test
  public void testNotExtCandidate(){
    CandidateProfileModel model = new CandidateProfileModel();
    Assert.assertEquals(model.isExtProfile("test"), false);
    
    CandidateAttribute attr = new CandidateAttribute();
    attr.setIsExt(true);
    attr.setName("test");
    List<CandidateAttribute> attrList = new ArrayList<CandidateAttribute>();
    attrList.add(attr);
    
    model.setAttributes(attrList);
    Assert.assertEquals(model.isExtProfile("invalid"), false);
  }
  
  
  
  @Test
  public void testIsComplexCandidate(){
    CandidateComplexAttribute complexAttr = new CandidateComplexAttribute();
    complexAttr.setName("test");
    complexAttr.setIsExt(false);
    
    List<CandidateAttribute> attrList = new ArrayList<CandidateAttribute>();
    CandidateProfileModel model = new CandidateProfileModel();
    attrList.add(complexAttr);
    model.setAttributes(attrList);
    
    boolean result = model.isComplex(complexAttr.getName());
    
    Assert.assertEquals(result, true);
  }
  
  @Test
  public void testNotComplexCandidate(){
    CandidateProfileModel model = new CandidateProfileModel();
    Assert.assertEquals(model.isComplex("test"), false);
    
    CandidateAttribute attr = new CandidateAttribute();
    attr.setIsExt(true);
    attr.setName("test");
    List<CandidateAttribute> attrList = new ArrayList<CandidateAttribute>();
    attrList.add(attr);
    
    model.setAttributes(attrList);
    Assert.assertEquals(model.isComplex("invalid"), false);
    
  }
  
  
}
