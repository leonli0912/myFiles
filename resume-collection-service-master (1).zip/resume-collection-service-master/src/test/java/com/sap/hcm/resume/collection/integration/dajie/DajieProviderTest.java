package com.sap.hcm.resume.collection.integration.dajie;

import static org.mockito.Mockito.mock;

import java.io.IOException;
import javax.servlet.http.HttpServletRequest;

import org.apache.http.HttpEntity;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.CookieStore;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.CloseableHttpClient;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.BlockJUnit4ClassRunner;
import org.mockito.Mockito;
import org.powermock.api.mockito.PowerMockito;
import org.powermock.core.classloader.annotations.PrepareForTest;
import org.powermock.modules.junit4.PowerMockRunner;
import org.powermock.modules.junit4.PowerMockRunnerDelegate;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mock.web.MockHttpServletRequest;

import com.sap.hcm.resume.collection.exception.InvalidVerifyCodeException;
import com.sap.hcm.resume.collection.exception.ServiceApplicationException;
import com.sap.hcm.resume.collection.integration.MockHttpEntity;

@RunWith(PowerMockRunner.class)
@PowerMockRunnerDelegate(BlockJUnit4ClassRunner.class)
@PrepareForTest(DajieProvider.class)
public class DajieProviderTest {
	
	private CookieStore cookieStore = new BasicCookieStore();

	private DajieProvider dajieProvider;
	
	private CloseableHttpClient httpClient;
	
	@Before
	public void setUp() throws Exception{
		dajieProvider = PowerMockito.spy(new DajieProvider());
		httpClient = Mockito.mock(CloseableHttpClient.class);
		
		PowerMockito.doReturn(httpClient).when(dajieProvider, "createHttpClient");
	}
	
	@Test
	public void testPreLogin_Success() throws ServiceApplicationException, ClientProtocolException, IOException{
		CloseableHttpResponse response = Mockito.mock(CloseableHttpResponse.class);
		Mockito.when(httpClient.execute(Mockito.any(HttpGet.class))).thenReturn(response);
		dajieProvider.preLogin();
	}
	
	@Test(expected=ServiceApplicationException.class)
	public void testPreLogin_Failure() throws ServiceApplicationException, ClientProtocolException, IOException{
		Mockito.when(httpClient.execute(Mockito.any(HttpGet.class))).thenThrow(new IOException());
		dajieProvider.preLogin();
	} 
	
	@Test
	public void testGetVerifyCode_Success() throws ClientProtocolException, IOException, ServiceApplicationException{
		CloseableHttpResponse response = Mockito.mock(CloseableHttpResponse.class);
		Mockito.when(httpClient.execute(Mockito.any(HttpGet.class))).thenReturn(response);
		
		MockHttpServletRequest mockRequest = new MockHttpServletRequest();
		ClassPathResource image = new ClassPathResource("/images/test.png");
		HttpEntity mockGetVerifyCodeEntity = new MockHttpEntity("image/png", image.getInputStream());
		Mockito.when(response.getEntity()).thenReturn(mockGetVerifyCodeEntity);
		dajieProvider.getVerifyCode(mockRequest);
	}
	
	@Test(expected=InvalidVerifyCodeException.class)
	public void testGetResume_EmptyCaptcha() throws ServiceApplicationException {
		HttpServletRequest request = mock(HttpServletRequest.class);
		
		dajieProvider.getResume(request, "Ryan", "123", null);
	}
	
	@Test(expected=ServiceApplicationException.class)
	public void testGetResume_NullResponse() throws ServiceApplicationException, ClientProtocolException, IOException {
		HttpServletRequest request = mock(HttpServletRequest.class);
		Mockito.when(httpClient.execute(Mockito.any(HttpGet.class))).thenReturn(null);
		
		dajieProvider.getResume(request, "Ryan", "123", "1234");
	}
	
	@Test(expected=ServiceApplicationException.class)
	public void testGetResume_InvalidInfo() throws ServiceApplicationException, ClientProtocolException, IOException {
		HttpServletRequest request = mock(HttpServletRequest.class);
		CloseableHttpResponse response = Mockito.mock(CloseableHttpResponse.class);
		HttpEntity mockContent = new MockHttpEntity("application/json", "{error:'帐号和密码不匹配'}");
		Mockito.when(httpClient.execute(Mockito.any(HttpGet.class))).thenReturn(response);
		Mockito.when(response.getEntity()).thenReturn(mockContent);
		
		dajieProvider.getResume(request, "Ryan", "123", "1234");
	}
	
	@Test(expected=InvalidVerifyCodeException.class)
	public void testGetResume_InvalidVerifyCode() throws ServiceApplicationException, ClientProtocolException, IOException {
		HttpServletRequest request = mock(HttpServletRequest.class);
		CloseableHttpResponse response = Mockito.mock(CloseableHttpResponse.class);
		HttpEntity mockContent = new MockHttpEntity("application/json", "{error:'请输入正确验证码'}");
		Mockito.when(httpClient.execute(Mockito.any(HttpGet.class))).thenReturn(response);
		Mockito.when(response.getEntity()).thenReturn(mockContent);
		
		dajieProvider.getResume(request, "Ryan", "123", "1234");
	}
	
	@Test
	public void testGetResume_Success() throws ServiceApplicationException, ClientProtocolException, IOException {
		HttpServletRequest request = mock(HttpServletRequest.class);
		CloseableHttpResponse response = Mockito.mock(CloseableHttpResponse.class);
		HttpEntity mockContent = new MockHttpEntity("application/json", "{resume}");
		Mockito.when(httpClient.execute(Mockito.any(HttpGet.class))).thenReturn(response);
		Mockito.when(response.getEntity()).thenReturn(mockContent);
		
		dajieProvider.getResume(request, "Ryan", "123", "1234");
	}
}
