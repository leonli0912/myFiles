package com.sap.hcm.resume.collection.entity.view;

import org.junit.Assert;
import org.junit.Test;


public class CandidateBgEducationVOTest {
  
  @Test
  public void test(){
    CandidateBgEducationVO vo = new CandidateBgEducationVO();
    vo.setDegree("test");
    vo.setEndDate("test");
    vo.setGpa("test");
    vo.setMajor("test");
    vo.setSchool("test");
    vo.setSchoolState("test");
    vo.setStartDate("test");
    
    Assert.assertEquals(vo.getDegree(), "test");
    Assert.assertEquals(vo.getEndDate(), "test");
    Assert.assertEquals(vo.getGpa(), "test");
    Assert.assertEquals(vo.getMajor(), "test");
    Assert.assertEquals(vo.getSchool(), "test");
    Assert.assertEquals(vo.getSchoolState(), "test");
    Assert.assertEquals(vo.getStartDate(), "test");
    
  }
}
